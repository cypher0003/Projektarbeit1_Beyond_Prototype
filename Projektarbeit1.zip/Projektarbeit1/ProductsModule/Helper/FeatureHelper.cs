﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ProductsModule.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsModule.Helper;

public static class FeatureHelper
{
    #region Methods

    /// <summary>
    /// Get name of equivalent feature
    /// </summary>
    /// <param name="feature">Feature</param>
    /// <returns> name of equivalent feature</returns>
    public static string GetEquivalentFeatureNameFromEquivalentFeature(Feature feature)
    {
        var ret = $"{feature?.Name}";

        if (!string.IsNullOrWhiteSpace(feature?.Version))
        {
            ret += $", {feature?.Version}";
        }

        if (!string.IsNullOrWhiteSpace(feature?.DisplayName))
        {
            ret += $" [{feature?.DisplayName}]";
        }

        return ret;
    }

    /// <summary>
    /// Get name of equivalent feature
    /// </summary>
    /// <param name="feature">Feature</param>
    /// <returns> name of equivalent feature</returns>
    public static string GetEquivalentFeatureName(Feature feature)
    {
        var ret = $"{feature?.EquivalentFeatureName}";

        if (!string.IsNullOrWhiteSpace(feature?.EquivalentFeatureVersion))
        {
            ret += $", {feature?.EquivalentFeatureVersion}";
        }

        if (!string.IsNullOrWhiteSpace(feature?.EquivalentFeatureDisplayName))
        {
            ret += $" [{feature?.EquivalentFeatureDisplayName}]";
        }

        return ret;
    }

    public static FeatureViewModel GetFeatureViewModel(ProductFeature productFeature)
    {
        var featureViewModel = new FeatureViewModel
        {
            ProductFeature = productFeature,
            Count = productFeature.Count,
            Name = productFeature.Feature.Name,
            Version = productFeature.Feature.Version
        };

        if (productFeature.Feature is Feature)
        {
            var f = (Feature)productFeature.Feature;
            featureViewModel.DisplayName = f.DisplayName;
            featureViewModel.EquivalentFeatureName = GetEquivalentFeatureName(f);
        }

        return featureViewModel;
    }

    #endregion
}
