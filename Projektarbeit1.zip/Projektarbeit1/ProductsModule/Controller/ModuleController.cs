﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Backend.UI.DataTypes;

namespace Zeiss.Licensing.Backend.UI.ProductsModule;

/// <summary>
/// Products Module Controller
/// </summary>
public class ModuleController : IModuleController
{
    #region Methods

    /// <summary>
    /// Get Module
    /// </summary>
    /// <param name="user">User</param>
    /// <returns>Module</returns>
    public DataTypes.Module? GetModule(User user)
    {
        DataTypes.Module? retValue = null;

        if (user != null && (user.AccountType == AccountType.SuperUser || user.Modules.Any(c => c.Name == "Products")))
        {
            retValue = new DataTypes.Module("Products", SharedResource.PRODUCTS, "zi-camera-lenses");
            retValue.AddSubmodule(SharedResource.PRODUCTVARIANTS, "ProductVariants", "zi-popup-zoom-lightbox_1");
            retValue.AddSubmodule(SharedResource.PRODUCTFAMILIES, "Productfamilies", "zi-image");
            retValue.AddSubmodule(SharedResource.FEATURES, "Features", "zi-fair-exposition");
            retValue.AddSubmodule(SharedResource.LICENSEMODELS, "LicenseModels", "zi-events-calendar_1");
            retValue.AddSubmodule(SharedResource.IMPORT, "Import", "zi-plus-add_1");
        }

        return retValue;
    }

    #endregion
}
