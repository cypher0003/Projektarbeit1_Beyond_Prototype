﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ProductsModule.ViewModels;

public class ValidationItemViewModel
{
    #region Constructors

    public ValidationItemViewModel(RefProductVariant refProductVariant)
    {
        RefProductVariant = refProductVariant;
    }

    #endregion

    #region Properties

    public RefProductVariant RefProductVariant { get; set; }

    public string ProductVariantNameVersion
    {
        get => $"{RefProductVariant.Name}  {RefProductVariant.Version}";
        set => throw new NotImplementedException();
    }

    #endregion
}
