﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.ObjectModel;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace ProductsModule.ViewModels;

public class UpgradeRuleGridComponentViewModel
{
    #region Constructors

    public UpgradeRuleGridComponentViewModel(IProductVariantClient productVariantClient)
    {
        ProductVariant = new ProductVariant();
        ProductVariantClient = productVariantClient;
    }

    #endregion

    #region Properties

    public ObservableCollection<UpgradeRuleViewModel> UpgradeRuleViewModels { get; set; } = new();

    public UpgradeRuleViewModel SelectedUpgradeRuleViewModel { get; set; } = new();

    public ObservableCollection<UpgradeRuleViewModel> ValidationRootUpgradeRuleViewModels { get; set; } = new();

    private IProductVariantClient ProductVariantClient { get; }

    private ProductVariant ProductVariant { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Add new upgrade rule and set output product variant
    /// </summary>
    /// <param name="productVariant">Out product variant</param>
    /// <returns></returns>
    public async Task AddUpgradeRule(ProductVariant productVariant)
    {
        var upgradeRuleViewModel = await CreateUpgradeRuleViewModel(productVariant);
        UpgradeRuleViewModels.Add(upgradeRuleViewModel);

        SelectedUpgradeRuleViewModel = upgradeRuleViewModel;
        ValidationRootUpgradeRuleViewModels.Clear();
        ValidationRootUpgradeRuleViewModels.Add(SelectedUpgradeRuleViewModel);
    }

    /// <summary>
    /// Change output product variant of selected upgrade rule
    /// </summary>
    /// <param name="productVariant">Out product variant</param>
    /// <returns></returns>
    public Task ChangeUpgradeRuleOutputProductVariant(ProductVariant productVariant)
    {
        SelectedUpgradeRuleViewModel.OutputProductVariant = productVariant;
        return Task.CompletedTask;
    }

    /// <summary>
    /// Load all additional data of the product variant
    /// </summary>
    /// <param name="productVariant"></param>
    /// <returns></returns>
    public async Task FillUpgradeRules(ProductVariant productVariant)
    {
        ProductVariant = productVariant;

        await LoadOutputProductVariants();

        if (UpgradeRuleViewModels.Any())
        {
            SelectedUpgradeRuleViewModel = UpgradeRuleViewModels[0];
        }
    }

    /// <summary>
    /// Save data to product variant model
    /// </summary>
    public void SaveToModel()
    {
        ProductVariant.UpgradeRules.Clear();

        foreach (var upgradeRuleViewModel in UpgradeRuleViewModels)
        {
            upgradeRuleViewModel.SaveToModel();
        }

        ProductVariant.UpgradeRules.AddRange(UpgradeRuleViewModels.Select(upgradeRuleViewModel => upgradeRuleViewModel.UpgradeRule));
    }

    /// <summary>
    /// Delete upgrade rule
    /// </summary>
    public void ActionDelete()
    {
        UpgradeRuleViewModels.Remove(SelectedUpgradeRuleViewModel);
    }

    /// <summary>
    /// Upgrade rule selection changed - root upgrade rule updated
    /// </summary>
    /// <param name="upgradeRuleViewModel"></param>
    public void OnSelectedRowChanged(UpgradeRuleViewModel upgradeRuleViewModel)
    {
        SelectedUpgradeRuleViewModel = upgradeRuleViewModel;
        ValidationRootUpgradeRuleViewModels = new() { upgradeRuleViewModel };
    }

    /// <summary>
    /// Set product variant, to which the upgrade rules belong
    /// </summary>
    /// <param name="selectedProductVariant">Product variant</param>
    /// <returns></returns>
    public async Task SetProductVariant(ProductVariant selectedProductVariant)
    {
        ProductVariant = selectedProductVariant;

        await LoadOutputProductVariants();
    }

    private async Task<UpgradeRuleViewModel> CreateUpgradeRuleViewModel(ProductVariant productVariant)
    {
        var outputProductVariant = await ProductVariantClient.GetProductVariantById(productVariant.Id);
        var upgradeRule = new UpgradeRule { OutputProductVariant = productVariant };

        var upgradeRuleViewModel = new UpgradeRuleViewModel(upgradeRule, outputProductVariant);
        return upgradeRuleViewModel;
    }

    private async Task LoadOutputProductVariants()
    {
        UpgradeRuleViewModels = new ObservableCollection<UpgradeRuleViewModel>();

        foreach (var upgradeRule in ProductVariant.UpgradeRules)
        {
            var upgradeProductVariant = await ProductVariantClient.GetProductVariantById(upgradeRule.OutputProductVariant.Id);

            UpgradeRuleViewModels.Add(new UpgradeRuleViewModel(upgradeRule, upgradeProductVariant));
        }
    }

    #endregion
}
