﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace ProductsModule.ViewModels;

internal class ProductVariantViewModel
{
    #region Constructors

    public ProductVariantViewModel(IProductVariantClient productVariantClient)
    {
        ProductVariantClient = productVariantClient;
        UpgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(ProductVariantClient);
    }

    #endregion

    #region Properties

    /// <summary>
    /// Flag, if the product variant is an upgrade variant
    /// </summary>
    public bool IsUpgrade => SelectedProductVariant.Type == ProductVariantType.Upgrade;

    /// <summary>
    /// List of variant states
    /// </summary>
    public IEnumerable<SelectModel> ProductVariantStateList { get; set; } = new List<SelectModel>();

    /// <summary>
    /// Selected product variant state
    /// </summary>
    public int SelectedProductVariantStateValue { get; set; } = 0;

    /// <summary>
    /// List of concurrency states
    /// </summary>
    public IEnumerable<SelectModel> ConcurrencyStateList { get; set; } = new List<SelectModel>();

    /// <summary>
    /// Selected concurrency state
    /// </summary>
    public int SelectedConcurrencyStateValue { get; set; } = 1;

    public ProductVariant EditOriginalProductVariant { get; set; } = new();

    public List<LicenseModel> LicenseModels { get; set; } = new();

    public List<LicenseModel> FilteredLicenseModels { get; set; } = new();

    public List<LicenseModel> FilteredLicenseModelsAdditional { get; } = new();

    public string ProductText { get; set; } = string.Empty;

    public string SelectedProductVariantFormattedMaterialNumber { get; set; } = string.Empty;

    public DeviceType? Hasp { get; set; } = new();


    public bool ShowSearchDialog { get; set; }

    public string NamedUsersConcurrencyCriteriaText => SelectedProductVariant.NamedUsersConcurrencyCriteria > 0 ? SelectedProductVariant.NamedUsersConcurrencyCriteria.ToString() : string.Empty;

    public bool ShowNamedUser
    {
        get
        {
            var licenseModel = LicenseModels.FirstOrDefault(c => c.Name == SelectedProductVariant.LicenseModel);
            return null != licenseModel && licenseModel.IsConnected;
        }
    }

    public bool DeleteIsLoading { get; set; }

    public UpgradeRuleGridComponentViewModel UpgradeRuleGridComponentViewModel { get; set; }

    public bool ShowToUpgradeDialog { get; set; }

    internal ProductVariant SelectedProductVariant { get; set; } = new();

    /// <summary>
    /// Email behaviour of the selected product variant
    /// </summary>
    internal bool SelectedProductVariantUseEmailInSalesOrder
    {
        get => SelectedProductVariant.EmailBehaviour == EmailBehaviour.EmailBySalesorder;
        set
        {
            if (value)
            {
                SelectedProductVariant.EmailBehaviour = EmailBehaviour.EmailBySalesorder;
            }
            else
            {
                SelectedProductVariant.EmailBehaviour = EmailBehaviour.None;
            }
        }
    }

    private IProductVariantClient ProductVariantClient { get; }

    #endregion

    #region Methods

    public void SelectProductVariantChanged(ProductVariant selectedProductVariant)
    {
        SelectedProductVariant = selectedProductVariant;
        SelectedProductVariantStateValue = (int)SelectedProductVariant.State;
        SelectedProductVariantFormattedMaterialNumber = SelectedProductVariant.FormattedMaterialNumber;
        SelectedConcurrencyStateValue = (int)SelectedProductVariant.NamedUsersConcurrencyCriteria;
    }

    public void SelectedProductVariantStateChanged(int newValue)
    {
        SelectedProductVariantStateValue = newValue;
        SelectedProductVariant.State = (ProductVariantState)newValue;
    }

    public void SelectedConcurrencyStateChanged(int newValue)
    {
        SelectedConcurrencyStateValue = newValue;
        SelectedProductVariant.NamedUsersConcurrencyCriteria = (NamedUsersConcurrencyCriteria)newValue;
    }

    public void BusinessGroupValueChanged(object newValue)
    {
        SelectedProductVariant.Businessgroup = (string)newValue;
        FilteredLicenseModels = LicenseModels.Where(c => c.Enabled && c.Name.StartsWith(SelectedProductVariant.Businessgroup + "_")).OrderBy(d => d.Name).ToList();
        SelectedProductVariant.LicenseModel = FilteredLicenseModels.FirstOrDefault()?.Name;
    }

    public void VariantLicenseModelValueChanged(string newValue)
    {
        SelectedProductVariant.LicenseModel = newValue;

        if (ShowNamedUser && SelectedProductVariant.NamedUsersConcurrencyCriteria == 0)
        {
            SelectedProductVariant.NamedUsersConcurrencyCriteria = NamedUsersConcurrencyCriteria.PerLogin;
        }
    }

    public void LicenseModelAdditionalChanged(string licenseModel)
    {
        SelectedProductVariant.LicenseModelAdditional = licenseModel;
        SelectedProductVariant.DeviceTypeNameAdditional = string.IsNullOrWhiteSpace(licenseModel) ? string.Empty : Hasp!.Name;
        SelectedProductVariant.DeviceTypeIdAdditional = string.IsNullOrWhiteSpace(licenseModel) ? string.Empty : Hasp!.Id;
    }

    public void ActionAdd(string? businessGroup)
    {
        EditOriginalProductVariant = SelectedProductVariant;

        SelectedProductVariant = new ProductVariant
        {
            Businessgroup = businessGroup
        };

        FilteredLicenseModels = LicenseModels.Where(c => c.Enabled && c.Name.StartsWith(SelectedProductVariant.Businessgroup + "_")).OrderBy(d => d.Name).ToList();
        SelectedProductVariant.LicenseModel = FilteredLicenseModels.FirstOrDefault()?.Name;
        SelectedProductVariant.LicenseModelAdditional = FilteredLicenseModelsAdditional.FirstOrDefault()?.Name;
        SelectedProductVariantStateValue = (int)SelectedProductVariant.State;
        SelectedProductVariantFormattedMaterialNumber = SelectedProductVariant.FormattedMaterialNumber;
        ProductText = string.Empty;
        SelectedConcurrencyStateValue = (int)NamedUsersConcurrencyCriteria.PerLogin;
    }

    public void ActionEdit()
    {
        EditOriginalProductVariant = SelectedProductVariant;
        SelectedProductVariant = (ProductVariant)EditOriginalProductVariant.Clone();
        FilteredLicenseModels = LicenseModels.Where(c => c.Enabled && c.Name.StartsWith(SelectedProductVariant.Businessgroup + "_")).OrderBy(d => d.Name).ToList();
        SelectedProductVariantStateValue = (int)SelectedProductVariant.State;
        SelectedProductVariantFormattedMaterialNumber = SelectedProductVariant.FormattedMaterialNumber;
        SelectedConcurrencyStateValue = (int)SelectedProductVariant.NamedUsersConcurrencyCriteria;
    }

    public void ActionEditUseNamedUsers()
    {
        if (SelectedProductVariant.UseNamedUsers && (int)SelectedProductVariant.NamedUsersConcurrencyCriteria == 0)
        {
            SelectedProductVariant.NamedUsersConcurrencyCriteria = NamedUsersConcurrencyCriteria.PerLogin;
            SelectedConcurrencyStateValue = (int)NamedUsersConcurrencyCriteria.PerLogin;
        }
    }

    public void AssignSearchedProduct(object product)
    {
        ShowSearchDialog = false;

        ProductText = $"{((Product)product).Name}, {((Product)product).Version}";
        SelectedProductVariant.ProductId = ((Product)product).Id;
    }

    public void PrepareSaving(bool showAdditional, DeviceType? selectedDeviceType)
    {
        if (!showAdditional)
        {
            SelectedProductVariant.LicenseModelAdditional = string.Empty;
            SelectedProductVariant.DeviceTypeNameAdditional = string.Empty;
            SelectedProductVariant.DeviceTypeIdAdditional = string.Empty;
        }

        if (!ShowNamedUser)
        {
            SelectedProductVariant.UseNamedUsers = false;
            SelectedProductVariant.LimitNamedUserAssignment = false;
            SelectedProductVariant.NamedUsersConcurrencyCriteria = 0;
        }

        // Upgrade product variant
        if (IsUpgrade)
        {
            // Save upgrade rules
            UpgradeRuleGridComponentViewModel.SaveToModel();

            if (string.IsNullOrWhiteSpace(SelectedProductVariant.Id))
            {
                // Reset Device Type
                SelectedProductVariant.DeviceTypeId = string.Empty;
                SelectedProductVariant.DeviceTypeName = string.Empty;

                // Reset LicenseModel
                SelectedProductVariant.LicenseModel = string.Empty;
            }
        }
        else
        {
            SelectedProductVariant.DeviceTypeId = selectedDeviceType?.Id;
            SelectedProductVariant.DeviceTypeName = selectedDeviceType?.Name;
        }
    }

    public void UseNamedUserChanged(bool useNamedUser)
    {
        SelectedProductVariant.UseNamedUsers = useNamedUser;
        SelectedProductVariant.LimitNamedUserAssignment = false;
        SelectedConcurrencyStateValue = useNamedUser ? (int)NamedUsersConcurrencyCriteria.PerLogin : 0;
        SelectedProductVariant.NamedUsersConcurrencyCriteria = useNamedUser ? NamedUsersConcurrencyCriteria.PerLogin : 0;
    }

    public async Task SetUpgradeProductVariant(ProductVariant selectedProductVariant)
    {
        await UpgradeRuleGridComponentViewModel.FillUpgradeRules(selectedProductVariant);
    }

    /// <summary>
    /// Reset all not needed properties, set also default upgrade license model and device type
    /// </summary>
    public async Task SetToUpgradeVariant()
    {
        SelectedProductVariant.Type = ProductVariantType.Upgrade;

        ClearNotUpgradeProperties();

        await UpgradeRuleGridComponentViewModel.SetProductVariant(SelectedProductVariant);
    }

    private void ClearNotUpgradeProperties()
    {
        SelectedProductVariant.DefaultDuration = 0;
        SelectedProductVariant.DemoDuration = 0;
        SelectedProductVariant.Description = string.Empty;
        SelectedProductVariant.DeployOnDelivery = false;
        SelectedProductVariant.DeviceTypeId = string.Empty;
        SelectedProductVariant.DeviceTypeIdAdditional = string.Empty;
        SelectedProductVariant.DeviceTypeName = string.Empty;
        SelectedProductVariant.DeviceTypeNameAdditional = string.Empty;
        SelectedProductVariant.AllowMultipleGenerationPerUser = false;
        SelectedProductVariant.IsDemoProduct = false;
        SelectedProductVariant.IsPackage = false;
        SelectedProductVariant.LicenseModel = string.Empty;
        SelectedProductVariant.LicenseModelAdditional = string.Empty;
        SelectedProductVariant.LimitNamedUserAssignment = false;
        SelectedProductVariant.NamedUsersConcurrencyCriteria = NamedUsersConcurrencyCriteria.PerLogin;
        SelectedProductVariant.Notes = string.Empty;
        SelectedProductVariant.ProductId = string.Empty;
        SelectedProductVariant.ProductRatePlanChargeDescription = string.Empty;
        SelectedProductVariant.ProductRatePlanChargeId = string.Empty;
        SelectedProductVariant.ProductRatePlanChargeName = string.Empty;
        SelectedProductVariant.ProductRatePlanDescription = string.Empty;
        SelectedProductVariant.ProductRatePlanId = string.Empty;
        SelectedProductVariant.ProductRatePlanName = string.Empty;
        SelectedProductVariant.SubscriptionTerm = SubscriptionTerm.UNDEFINED;
        SelectedProductVariant.SerialNumberRequired = false;
        SelectedProductVariant.UpgradeFrom = new List<ProductVariant>();
        SelectedProductVariant.UseNamedUsers = false;
        SelectedProductVariant.Type = ProductVariantType.Upgrade;
    }

    #endregion
}
