﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsModule.ViewModels;

public class FeatureViewModel
{
    #region Properties

    /// <summary>
    /// Name
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Displayname
    /// </summary>
    public string DisplayName { get; set; } = string.Empty;

    /// <summary>
    /// Version
    /// </summary>
    public string Version { get; set; } = string.Empty;

    /// <summary>
    /// Count
    /// </summary>
    public int Count { get; set; }

    /// <summary>
    /// Equivalent feature name
    /// </summary>
    public string EquivalentFeatureName { get; set; } = string.Empty;

    /// <summary>
    /// Product feature model
    /// </summary>
    public ProductFeature? ProductFeature { get; set; }

    #endregion
}
