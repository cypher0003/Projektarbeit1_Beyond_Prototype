﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace ProductsModule.ViewModels;

public class DocumentProductAssignmentViewModel : ObservableObject
{
    #region Fields

    private string _DocumentId = string.Empty;
    private string _DocumentName = string.Empty;
    private string _Businessgroup = string.Empty;
    private string _ProductFamily = string.Empty;
    private string _ProductId = string.Empty;
    private DateTime? _ValidFrom;
    private DateTime? _ValidTo;
    private int _State = (int)DocumentAssignmentState.DRAFT;

    #endregion

    #region Constructors

    public DocumentProductAssignmentViewModel(DocumentProductAssignment assignment)
    {
        Assignment = assignment;

        ReadFromModel();
    }

    #endregion

    #region Properties

    public DocumentProductAssignment Assignment { get; }

    public bool Editing { get; set; }

    public string DocumentId
    {
        get => _DocumentId;
        set => SetProperty(ref _DocumentId, value);
    }

    public string DocumentName
    {
        get => _DocumentName;
        set => SetProperty(ref _DocumentName, value);
    }

    public string Businessgroup
    {
        get => _Businessgroup;
        set => SetProperty(ref _Businessgroup, value);
    }

    public string ProductFamily
    {
        get => _ProductFamily;
        set => SetProperty(ref _ProductFamily, value);
    }

    public string ProductId
    {
        get => _ProductId;
        set => SetProperty(ref _ProductId, value);
    }

    public DateTime? ValidFrom
    {
        get => _ValidFrom;
        set => SetProperty(ref _ValidFrom, value);
    }

    public DateTime? ValidTo
    {
        get => _ValidTo;
        set => SetProperty(ref _ValidTo, value);
    }

    public int State
    {
        get => _State;
        set => SetProperty(ref _State, value);
    }

    public string StateAsString => ((DocumentAssignmentState)_State).ToString();

    #endregion

    #region Methods

    public void SaveToModel()
    {
        Assignment.DocumentId = DocumentId;
        Assignment.DocumentName = DocumentName;
        Assignment.Businessgroup = Businessgroup;
        Assignment.ProductFamily = ProductFamily;
        Assignment.ProductId = ProductId;
        Assignment.ValidFrom = ValidFrom;
        Assignment.ValidTo = ValidTo;
        Assignment.State = (DocumentAssignmentState)State;
    }

    public void ReadFromModel()
    {
        DocumentId = Assignment.DocumentId;
        DocumentName = Assignment.DocumentName;
        Businessgroup = Assignment.Businessgroup;
        ProductFamily = Assignment.ProductFamily;
        ProductId = Assignment.ProductId;
        ValidFrom = Assignment.ValidFrom;
        ValidTo = Assignment.ValidTo;
        State = (int)Assignment.State;
    }

    #endregion
}
