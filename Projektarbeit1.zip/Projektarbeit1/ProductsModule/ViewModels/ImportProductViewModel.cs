﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsModule.ViewModels;

/// <summary>
/// Viewmodel of ImportProduct
/// </summary>
public class ImportProductViewModel
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    public ImportProductViewModel()
    {
        ImportProduct = new ImportProduct();
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="importProduct">Import product</param>
    public ImportProductViewModel(ImportProduct importProduct)
    {
        ImportProduct = importProduct;

        if (string.IsNullOrWhiteSpace(importProduct.Error))
        {
            Selected = true;
        }
    }

    #endregion

    #region Properties

    /// <summary>
    /// Import product model
    /// </summary>
    public ImportProduct ImportProduct { get; set; }

    public string Validation
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(ImportProduct.Error))
            {
                return ImportProduct.Error;
            }

            if (!string.IsNullOrWhiteSpace(ImportProduct.Warning))
            {
                return ImportProduct.Warning;
            }

            return string.Empty;
        }
    }

    /// <summary>
    /// Selection flag
    /// </summary>
    public bool Selected { get; set; }

    /// <summary>
    /// Selection allowed flag
    /// </summary>
    public bool SelectedAllowed => string.IsNullOrWhiteSpace(ImportProduct.Error);

    /// <summary>
    /// LineNumber
    /// </summary>
    public int LineNumber => ImportProduct.LineNumber;

    /// <summary>
    /// Product name
    /// </summary>
    public string ProductName => ImportProduct.ProductName;

    /// <summary>
    /// Product version
    /// </summary>
    public string ProductVersion => ImportProduct.ProductVersion;

    /// <summary>
    /// Features
    /// </summary>
    public string Features => FeaturesToString();

    /// <summary>
    /// Materialnumbers
    /// </summary>
    public string Materialnumbers => $"{string.Join(",", ImportProduct?.Materialnumbers ?? new List<string>())}";

    /// <summary>
    /// Materialnumbers
    /// </summary>
    public string IconName
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(ImportProduct.Error))
            {
                return "error.svg";
            }

            if (!string.IsNullOrWhiteSpace(ImportProduct.Warning))
            {
                return "sign_warning.svg";
            }

            return string.Empty;
        }
    }

    #endregion

    #region Methods

    /// <summary>
    /// Features to String
    /// </summary>
    private string FeaturesToString()
    {
        var ret = string.Empty;

        try
        {
            if (null != ImportProduct)
            {
                foreach (var item in ImportProduct.Features)
                {
                    ret += $"{(!string.IsNullOrWhiteSpace(ret) ? "," : string.Empty)}{item.Name}({item.DisplayName})[{item.Version}]";
                }
            }
        }
        catch (Exception)
        {
            ret = string.Empty;
        }

        return ret;
    }

    #endregion
}
