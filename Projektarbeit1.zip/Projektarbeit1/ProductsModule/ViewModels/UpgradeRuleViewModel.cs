﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.ObjectModel;

namespace ProductsModule.ViewModels;

public class UpgradeRuleViewModel
{
    #region Constructors

    public UpgradeRuleViewModel(UpgradeRule upgradeRule, ProductVariant productVariant)
    {
        UpgradeRule = upgradeRule;
        SelectedUpgradeCompareOperator = (int)upgradeRule.CompareOperator;
        OutputProductVariant = productVariant;

        InitValidations();
    }

    public UpgradeRuleViewModel()
    {
        UpgradeRule = new UpgradeRule();
        OutputProductVariant = new ProductVariant();
    }

    #endregion

    #region Properties

    public UpgradeRule UpgradeRule { get; }

    public ObservableCollection<ValidationItemViewModel> Validations { get; set; } = new();

    public ObservableCollection<UpgradeRuleViewModel> InnerUpgradeRules { get; set; } = new();

    public ProductVariant OutputProductVariant { get; set; }

    public string OutputProductVariantName
    {
        get => OutputProductVariant.Name;
        set => OutputProductVariant.Name = value;
    }

    public string OutputProductVariantVersion
    {
        get => OutputProductVariant.Version;
        set => OutputProductVariant.Version = value;
    }

    public string OutputProductVariantState => OutputProductVariant.State.ToString();

    public string OutputProductVariantLicenseModel => OutputProductVariant.LicenseModel;

    public string OutputProductVariantDeviceType => OutputProductVariant.DeviceTypeName;

    public bool ShowSearchDialog { get; set; }

    public ValidationItemViewModel SelectedValidationViewModel { get; set; } = null!;

    public bool IsAddCondition { get; set; }

    public int SelectedUpgradeCompareOperator { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Delete validation entry
    /// </summary>
    public void DeleteValidation()
    {
        Validations.Remove(SelectedValidationViewModel);
    }

    /// <summary>
    /// Searched product variant is added or replaced in validation list
    /// </summary>
    /// <param name="productVariant">Searched product variant</param>
    public void OnSearchOkClick(ProductVariant productVariant)
    {
        if (IsAddCondition)
        {
            SelectedValidationViewModel = new ValidationItemViewModel(productVariant);
            Validations.Add(SelectedValidationViewModel);
        }
        else
        {
            SelectedValidationViewModel.RefProductVariant = productVariant;
        }

        ShowSearchDialog = false;
    }

    /// <summary>
    /// Save to model
    /// </summary>
    public void SaveToModel()
    {
        UpgradeRule.ValidationList.Clear();
        UpgradeRule.InnerUpgradeRules.Clear();
        UpgradeRule.ValidationList.AddRange(Validations.Select(c => c.RefProductVariant));
        UpgradeRule.CompareOperator = (UpgradeCompareOperator)SelectedUpgradeCompareOperator;

        foreach (var upgradeRuleViewModel in InnerUpgradeRules)
        {
            upgradeRuleViewModel.SaveToModel();
            UpgradeRule.InnerUpgradeRules.Add(upgradeRuleViewModel.UpgradeRule);
        }
    }

    /// <summary>
    /// Action handling in the validation grid
    /// </summary>
    /// <param name="actionType">Type of action (add, edit, delete)</param>
    /// <param name="validationItemViewModel">Validation that will be handled</param>
    public void OnValidationActionClicked(ActionType actionType, ValidationItemViewModel? validationItemViewModel)
    {
        if (null != validationItemViewModel && SelectedValidationViewModel != validationItemViewModel)
        {
            SelectedValidationViewModel = validationItemViewModel;
        }

        switch (actionType)
        {
            case ActionType.Add:
                ShowSearchDialog = true;
                IsAddCondition = true;
                break;
            case ActionType.Delete:
                DeleteValidation();
                break;
            case ActionType.Edit:
                ShowSearchDialog = true;
                IsAddCondition = false;
                break;
        }
    }

    private void InitValidations()
    {
        Validations.Clear();

        foreach (var refProductVariant in UpgradeRule.ValidationList)
        {
            var validation = new ValidationItemViewModel(refProductVariant);
            Validations.Add(validation);
        }

        // Inner upgrade rules
        foreach (var upgradeRuleInnerUpgradeRule in UpgradeRule.InnerUpgradeRules)
        {
            InnerUpgradeRules.Add(new UpgradeRuleViewModel(upgradeRuleInnerUpgradeRule, OutputProductVariant));
        }
    }

    #endregion
}
