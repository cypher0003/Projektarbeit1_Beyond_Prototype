﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ProductsModule.Models;

public class SelectUpgradeCompareOperatorModel
{
    #region Properties

    /// <summary>
    /// Value 
    /// </summary>
    public UpgradeCompareOperator Value { get; set; }

    /// <summary>
    /// Text
    /// </summary>
    public string Text { get; set; } = string.Empty;

    #endregion
}
