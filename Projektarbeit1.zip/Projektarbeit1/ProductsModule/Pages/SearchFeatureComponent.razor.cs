#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ProductsModule.Pages;

public partial class SearchFeatureComponent
{
    #region Properties

    [Parameter]
    public EventCallback<Feature> SelectedFeatureChanged { get; set; }

    [Parameter]
    public EventCallback<List<Feature>> SelectedFeaturesChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public Feature SelectedFeature { get; set; } = new Feature();

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsMultiselect { get; set; } = false;


    /// <summary>
    /// Selected feature
    /// </summary>
    public SearchObjectFeature SearchObjectFeature { get; set; } = new SearchObjectFeature();

    /// <summary>
    /// Selected features
    /// </summary>
    public List<Feature> SelectedFeatures { get; set; } = new();

    private SearchFeatureList SearchFeatureList { get; set; } = null!;

    private SearchFeatureMask SearchFeatureMask { get; set; } = null!;

    #endregion

    #region Methods

    /// <summary>
    /// Set Business group
    /// </summary>
    /// <param name="businessGroup">Business group</param>
    public void SetBusinessGroup(string businessGroup)
    {
        try
        {
            SearchFeatureMask!.SetBusinessGroup(businessGroup);
            SearchFeatureList!.ClearList();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Remove Feature from list
    /// </summary>
    /// <param name = "feature">Feature to be removed</param>
    public void RemoveFeature(Feature feature)
    {
        try
        {
            SearchFeatureList!.RemoveFeature(feature);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save feature to list
    /// </summary>
    /// <param name = "origFeature">Original feature(Update)</param>
    /// <param name = "feature">Feature to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveFeature(Feature origFeature, Feature feature, bool isAdd)
    {
        try
        {
            SearchFeatureList!.SaveFeature(origFeature, feature, isAdd);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Restart search to update feature list
    /// </summary>
    public async Task RestartSearch()
    {
        try
        {
            await SearchFeatureMask.RestartSearch();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectFeature.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchFeature">Search object to load features</param>
    private async Task OnSearchClickedFeature(object searchFeature)
    {
        try
        {
            // List component loads features
            SearchObjectFeature = (SearchObjectFeature)searchFeature;
            await SearchFeatureList!.UpdateList(SearchObjectFeature);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected feature has changed
    /// </summary>
    private void OnSelectedFeatureChanged(Feature selFeature)
    {
        try
        {
            SelectedFeature = selFeature;
            SelectedFeatureChanged.InvokeAsync(SelectedFeature);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected feature has changed
    /// </summary>
    private void OnSelectedFeaturesChanged(List<Feature> selFeatures)
    {
        try
        {
            SelectedFeatures = selFeatures;
            SelectedFeaturesChanged.InvokeAsync(SelectedFeatures);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        SearchFeatureMask!.SetLoading((bool)showLoading);
    }

    #endregion
}
