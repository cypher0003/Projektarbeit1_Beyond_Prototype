#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ProductsModule.Models;
using ProductsModule.ViewModels;

namespace ProductsModule.Pages;

public partial class UpgradeRuleComponent
{
    #region Properties

    [Parameter]
    public EventCallback Delete { get; set; }

    [Parameter]
    public UpgradeRuleViewModel UpgradeRuleViewModel { get; set; } = new();

    [Parameter]
    public bool IsUpgradeReadOnly { get; set; }

    public List<SelectUpgradeCompareOperatorModel> UpgradeCompareOperatorsList { get; set; } =
        new()
        {
            new SelectUpgradeCompareOperatorModel
            {
                Text = ProductResource.AND, Value = UpgradeCompareOperator.And
            },
            new SelectUpgradeCompareOperatorModel
            {
                Text = ProductResource.OR, Value = UpgradeCompareOperator.Or
            }
        };

    #endregion

    #region Methods

    /// <summary>
    /// Delete Upgrade rule with all inner conditions. this must be done by parent upgrade rule
    /// </summary>
    private void OnClickDeleteCondition()
    {
        Delete.InvokeAsync(UpgradeRuleViewModel);
    }

    /// <summary>
    /// Add a upgrade rule as inner condition
    /// </summary>
    private void OnClickInnerCondition()
    {
        UpgradeRuleViewModel.InnerUpgradeRules.Add(new UpgradeRuleViewModel());
    }

    /// <summary>
    /// Removes inner condition (upgrade rule) from list
    /// </summary>
    /// <param name="obj">Deleted upgrade rule</param>
    private void OnDeleteClicked(object obj)
    {
        UpgradeRuleViewModel.InnerUpgradeRules.Remove((UpgradeRuleViewModel)obj);
    }

    #endregion
}
