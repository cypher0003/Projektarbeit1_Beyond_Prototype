#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Blazorise;
using Microsoft.Extensions.Localization;
using Zeiss.Licensing.Data.Models;

namespace ProductsModule.Pages;

public partial class EquivalentFeatureComponent
{
    #region Properties

    [Parameter]
    public bool IsDisabled { get; set; }

    [Parameter]
    public Feature? SelectedFeature { get; set; }


    private string SelectedEquivalentFeatureText { get; set; } = string.Empty;

    private Feature? SelectedEquivalentFeature { get; set; }

    private SearchFeatureDialog RefSearchFeatureDialog { get; set; } = null!;

    #endregion

    #region Methods

    /// <summary>
    /// Parameters set
    /// </summary>
    protected override void OnParametersSet()
    {
        base.OnParametersSet();

        if (null != SelectedFeature)
        {
            SelectedEquivalentFeatureText = Helper.FeatureHelper.GetEquivalentFeatureName(SelectedFeature);
        }
    }


    /// <summary>
    /// Show feature search dialog
    /// </summary>
    private void OnSearchFeatureButtonClicked()
    {
        try
        {
            RefSearchFeatureDialog.ShowFeatureSelection();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete selected feature
    /// </summary>
    private void OnDeleteFeatureButtonClicked()
    {
        SelectedEquivalentFeatureText = string.Empty;
        SelectedEquivalentFeature = null;

        if (null != SelectedFeature)
        {
            SelectedFeature.EquivalentFeatureId = string.Empty;
            SelectedFeature.EquivalentFeatureName = string.Empty;
            SelectedFeature.EquivalentFeatureVersion = string.Empty;
            SelectedFeature.EquivalentFeatureDisplayName = string.Empty;
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnFeatureDialogOKClicked(Feature feature)
    {
        try
        {
            SelectedEquivalentFeature = feature;
            CreateEquivalentFeatureText();

            if (null != SelectedFeature)
            {
                SelectedFeature.EquivalentFeatureId = SelectedEquivalentFeature.Id;
                SelectedFeature.EquivalentFeatureName = SelectedEquivalentFeature.Name;
                SelectedFeature.EquivalentFeatureVersion = SelectedEquivalentFeature.Version;
                SelectedFeature.EquivalentFeatureDisplayName = SelectedEquivalentFeature.DisplayName;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private void CreateEquivalentFeatureText()
    {
        if (SelectedEquivalentFeature != null)
        {
            SelectedEquivalentFeatureText = Helper.FeatureHelper.GetEquivalentFeatureNameFromEquivalentFeature(SelectedEquivalentFeature);
        }
        else
        {
            SelectedEquivalentFeatureText = string.Empty;
        }
    }

    #endregion
}
