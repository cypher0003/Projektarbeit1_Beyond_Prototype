#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Zeiss.Licensing.Data.Models;
using Blazorise;
using Microsoft.Extensions.Localization;

namespace ProductsModule.Pages;

public partial class SearchFeatureDialog
{
    #region Properties

    [Parameter]
    public string Businessgroup { get; set; } = string.Empty;

    [Parameter]
    public EventCallback<Feature> OKClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    public Modal? RefSearchFeatureDialog { get; set; }

    private Feature SelectedFeature { get; set; } = new Feature();

    private SearchFeatureComponent? SearchFeatureComponent { get; set; }

    #endregion

    #region Methods

    public void ShowFeatureSelection()
    {
        SearchFeatureComponent!.SetBusinessGroup(Businessgroup);
        RefSearchFeatureDialog!.Show();
    }


    /// <summary>
    /// Selected feature changed
    /// </summary>
    private void OnSelectedFeatureChanged(object selFeature)
    {
        try
        {
            if (null != selFeature)
            {
                SelectedFeature = (Feature)selFeature;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Feature Dialog with OK
    /// </summary>
    private void OnClickOK()
    {
        try
        {
            OKClicked.InvokeAsync(SelectedFeature);
            RefSearchFeatureDialog!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Feature Dialog with Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            DiscardClicked.InvokeAsync("Discard pressed");
            RefSearchFeatureDialog!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
