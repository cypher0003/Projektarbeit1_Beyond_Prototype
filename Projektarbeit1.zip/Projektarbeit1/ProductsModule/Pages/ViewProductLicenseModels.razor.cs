#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Text.Json;

namespace ProductsModule.Pages;

public partial class ViewProductLicenseModels
{
    #region Fields

    private const string EnforcementFilter = "Sentinel RMS";
    private LicenseModel EditOriginalLicenseModel = new();

    #endregion

    #region Properties

    private List<LicenseModel> LicenseModels { get; set; } = new();

    private LicenseModel SelectedLicenseModel { get; set; } = new();

    private string Info { get; set; } = string.Empty;

    private bool IsInfoVisible { get; set; }

    #endregion

    #region Methods

    //Dialogs / Messageboxes

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            IsLoading = true;

            // grants
            CurrentUser = await UserClient!.Authenticate();
            IsUserEditGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantLicenseModel >= GrantType.Edit);
            LicenseModels = await ProductClient!.GetLicenseModels();
            IsLoading = false;

            HasNavItemRoute = true;
            NavItemRoute = "Products/LicenseModels";

            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private async Task OnActionClicked(LicenseModel licenseModel, object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            IsInfoVisible = false;

            // Info
            var seropt = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true,
                PropertyNameCaseInsensitive = true
            };

            Info = JsonSerializer.Serialize(licenseModel, seropt);

            switch (action)
            {
                case ActionType.View:
                    IsReadOnly = true;
                    EditOriginalLicenseModel = licenseModel;
                    SelectedLicenseModel = (LicenseModel)EditOriginalLicenseModel.Clone();
                    break;
                case ActionType.Edit:
                    EditOriginalLicenseModel = licenseModel;
                    SelectedLicenseModel = (LicenseModel)EditOriginalLicenseModel.Clone();
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
            IsListVisible = true;
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Entitlement details save button clicked
    /// </summary>
    private async Task OnDetailsSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            StateHasChanged();
            await ProductClient!.UpdateLicenseModel(SelectedLicenseModel);
            var idx = LicenseModels.IndexOf(EditOriginalLicenseModel);
            LicenseModels.Remove(EditOriginalLicenseModel);
            LicenseModels.Insert(idx, SelectedLicenseModel);
            IsListVisible = true;
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    #endregion
}
