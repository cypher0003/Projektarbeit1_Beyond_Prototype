#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ProductsModule.Pages;

public partial class SearchFeatureMask
{
    #region Properties

    [Parameter]
    public EventCallback SearchClicked { get; set; }

    public SearchObjectFeature SearchObjectFeature { get; set; } = new SearchObjectFeature();

    private bool IsBGReadOnly { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Remove Feature from list
    /// </summary>
    /// <param name = "feature">Feature to be removed</param>
    public void SetBusinessGroup(string businessGroup)
    {
        try
        {
            SearchObjectFeature.Businessgroup = businessGroup;
            IsBGReadOnly = true;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Restart search to update feature list
    /// </summary>
    public async Task RestartSearch()
    {
        try
        {
            await OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            IsBGReadOnly = false;
            SearchObjectFeature = new SearchObjectFeature();
            await base.OnInitializedAsync();
            await base.LoadBusinessGroups();
            SearchObjectFeature.Businessgroup = BusinessGroups.FirstOrDefault();
            await base.GetSavedSearchMode();
            SearchObjectFeature.SearchPattern = (SearchPattern)SelectedSearchModeValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            SearchObjectFeature.UseLoadMore = true;
            SearchObjectFeature.RestartLoadMore = true;
            await SearchClicked.InvokeAsync(SearchObjectFeature);
            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
