#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Exceptions;
using ResourceLibrary.Helper;
using Zeiss.Licensing.Data.Exceptions;

namespace ProductsModule.Pages;

public partial class ViewProductfamilies
{
    #region Fields

    private Alert? _ErrorZeissLicensingAlert = new Alert();

    private DataGrid<ProductFamily>? _DgProductFamilies;

    #endregion

    #region Properties

    internal ProductFamily SelectedProductFamily { get; set; } = new();

    internal bool CanAddProductFamily => IsSuperUser || (IsUserAddGranted && IsBusinessAdmin);

    internal bool CanDeleteProductFamily => (IsSuperUser || (IsUserDeleteGranted && IsBusinessAdmin && SelectedProductFamily.Businessgroup == CurrentUser?.AdminBusinessGroup)) && ProductFamilies.Any() && IsReadOnly;

    internal bool CanSaveProductFamily => !string.IsNullOrWhiteSpace(SelectedProductFamily.Name);

    internal List<ProductFamily> ProductFamilies { get; set; } = new();

    private ProductFamily EditOriginalProductFamily { get; set; } = new();

    private List<string> FilteredBusinessGroups { get; set; } = new();

    private bool Loading { get; set; } = false;

    private bool IsBusinessAdmin { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        await InitializedAsync();
    }

    internal async Task InitializedAsync()
    {
        try
        {
            IsLoading = true;

            var businessGroupsTask = ProductClient!.GetBusinessgroups();
            var productFamiliesTask = AppSettingClient!.GetProductFamilies();

            // grants
            CurrentUser = await UserClient!.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Any(c => c.GrantProductFamily >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantProductFamily >= GrantType.Delete);
            IsBusinessAdmin = !string.IsNullOrWhiteSpace(CurrentUser.AdminBusinessGroup);
            BusinessGroups = await businessGroupsTask;
            ProductFamilies = await productFamiliesTask;

            // Filter BusinessGroups for BusinessAdmins
            if (IsSuperUser)
            {
                FilteredBusinessGroups = BusinessGroups;
            }
            else if (IsBusinessAdmin)
            {
                FilteredBusinessGroups = BusinessGroups.Where(c => c == CurrentUser.AdminBusinessGroup).ToList();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsLoading = false;
        }
    }


    /// <summary>
    /// Selected product changed
    /// </summary>
    internal void OnSelectedProductFamilyChanged(ProductFamily selp)
    {
        SelectedProductFamily = selp;
        IsReadOnly = true;
    }

    /// <summary>
    /// BusinessGroup selection changed
    /// </summary>
    /// <param name = "newValue">New value</param>
    internal void BusinessGroupValueChangedHandler(string newValue)
    {
        SelectedProductFamily.Businessgroup = newValue;
    }

    /// <summary>
    /// Add button pressed
    /// </summary>
    internal void OnAddButtonClicked()
    {
        _ErrorZeissLicensingAlert!.Hide();
        EditOriginalProductFamily = SelectedProductFamily;
        IsReadOnly = false;

        SelectedProductFamily = new ProductFamily
        {
            Businessgroup = FilteredBusinessGroups.FirstOrDefault()
        };
    }

    /// <summary>
    /// Delete Dialog - OK
    /// </summary>
    internal async Task OnDeleteOK()
    {
        try
        {
            await AppSettingClient!.DeleteProductFamily(SelectedProductFamily);
            ProductFamilies.Remove(SelectedProductFamily);
            SelectedProductFamily = new ProductFamily();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            ShowDeleteDialog = false;
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    internal void OnDiscardButtonClicked()
    {
        SelectedProductFamily = EditOriginalProductFamily;

        IsReadOnly = true;
    }

    internal void OnPageChanged(DataGridPageChangedEventArgs obj)
    {
        CurrentPage = obj.Page;
    }

    /// <summary>
    /// Delete button pressed
    /// </summary>
    private void OnDeleteButtonClicked()
    {
        if (ProductFamilies.Contains(SelectedProductFamily))
        {
            ShowDeleteDialog = true;
            _ErrorZeissLicensingAlert!.Hide();
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            Loading = true;
            StateHasChanged();
            await AppSettingClient!.AddProductFamily(SelectedProductFamily);
            ProductFamilies.Add(SelectedProductFamily);
            CurrentPage = (ProductFamilies.Count + _DgProductFamilies!.PageSize - 1) / _DgProductFamilies.PageSize;

            await _ErrorZeissLicensingAlert!.Hide();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            // ex.Errorcode in Resource [ex.Errocode] or ex.Message [ex.errorcode]
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            Loading = false;
            IsReadOnly = true;
            StateHasChanged();
        }
    }

    #endregion
}
