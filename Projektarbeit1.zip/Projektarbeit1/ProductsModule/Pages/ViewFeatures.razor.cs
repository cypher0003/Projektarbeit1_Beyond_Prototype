#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ProductsModule.Pages;

public partial class ViewFeatures
{
    #region Fields

    private Alert errorZeissLicensingAlert = new Alert();

    #endregion

    #region Properties

    private Feature SelectedFeature { get; set; } = new Feature();

    private Feature EditOriginalFeature { get; set; } = new Feature();

    private SearchFeatureComponent RefSearchFeatureComp { get; set; } = null!;

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await UserClient!.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserEditGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantProduct >= GrantType.Edit);

            OnSelectedFeatureChanged(SelectedFeature);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;

            switch (action)
            {
                case ActionType.Add:
                    EditOriginalFeature = SelectedFeature;
                    SelectedFeature = new Feature();
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    EditOriginalFeature = SelectedFeature;
                    SelectedFeature = (Feature)EditOriginalFeature.Clone();
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    EditOriginalFeature = SelectedFeature;
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected feature changed
    /// </summary>
    private void OnSelectedFeatureChanged(object selFeature)
    {
        try
        {
            if (null != selFeature)
            {
                SelectedFeature = (Feature)selFeature;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            var isAdd = false;
            await errorZeissLicensingAlert.Hide();

            SelectedFeature = await ProductClient!.UpdateFeature(SelectedFeature);

            RefSearchFeatureComp.SaveFeature(EditOriginalFeature, SelectedFeature, isAdd);
            await RefSearchFeatureComp.RestartSearch();

            IsListVisible = true;

            StateHasChanged();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await errorZeissLicensingAlert.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await errorZeissLicensingAlert.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            IsListVisible = true;
            errorZeissLicensingAlert.Hide();

            if (null != EditOriginalFeature)
            {
                SelectedFeature = EditOriginalFeature;
            }
            else
            {
                SelectedFeature = new Feature();
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
