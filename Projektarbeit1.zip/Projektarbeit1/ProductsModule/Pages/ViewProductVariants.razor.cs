﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Exceptions;
using Microsoft.Extensions.Localization;
using ProductsModule.ViewModels;
using ResourceLibrary.Helper;
using Zeiss.Licensing.Data.Exceptions;
using ProductResource = ResourceLibrary.ProductResource;

namespace ProductsModule.Pages;

public partial class ViewProductVariants
{
    #region Fields

    private Alert? _ErrorZeissLicensingAlert;
    private HistoryDialog? _HistoryDialog;

    #endregion

    #region Properties

    [Parameter]
    public string? ProductVariantId { get; set; } = string.Empty;

    [Inject]
    internal IStringLocalizer<ProductResource>? ProductResourceLibrary { get; set; }

    internal ProductVariantViewModel ProductVariantViewModel { get; set; } = null!;

    private SearchProductVariantComponent? RefSearchProdComp { get; set; }

    private bool ShowAdditional => ProductVariantViewModel.SelectedProductVariant.LicenseModel == "RMS_PC_Bound" && SelectedDeviceType?.Name == "PC";

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        ProductVariantViewModel = new ProductVariantViewModel(ProductVariantClient);
        await InitializedAsync();
    }

    /// <summary>
    /// Parameter set
    /// </summary>
    /// <returns></returns>
    protected override async Task OnParametersSetAsync()
    {
        if (!string.IsNullOrWhiteSpace(ProductVariantId))
        {
            ProductVariantViewModel.SelectedProductVariant = new ProductVariant { Id = ProductVariantId };
            await OnActionClicked(ActionType.View);
        }
    }

    internal async Task InitializedAsync()
    {
        try
        {
            IsLoading = !string.IsNullOrWhiteSpace(ProductVariantId);

            if (IsLoading)
            {
                StateHasChanged();
            }

            var licenseModelsTask = ProductClient.GetLicenseModels();

            // grants
            CurrentUser = await UserClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.Edit);
            AdminBusinessGroup = CurrentUser.AdminBusinessGroup;

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Exists(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);

            await base.LoadDeviceTypes();
            await base.LoadBusinessGroups();

            ProductVariantViewModel.LicenseModels = await licenseModelsTask;

            // Variant state list
            List<string> listText = new();

            foreach (ProductVariantState varState in Enum.GetValues(typeof(ProductVariantState)))
            {
                listText.Add(null != ProductResourceLibrary ? ProductResourceLibrary.GetString("PRODUCTVARIANTSTATE" + varState.ToString().ToUpper()) : varState.ToString());
            }

            ProductVariantViewModel.ProductVariantStateList = Enumerable.Range(1, listText.Count).Select(x => new SelectModel { Text = listText[x - 1], Value = x - 1 });

            // Concurrency state list
            List<string> listConcurrencyText = new()
            {
                ResourceLibrary.Resources.ProductResource.PERLOGIN,
                ResourceLibrary.Resources.ProductResource.PERUSER
            };

            ProductVariantViewModel.ConcurrencyStateList = Enumerable.Range(1, listConcurrencyText.Count).Select(x => new SelectModel { Text = listConcurrencyText[x - 1], Value = x });

            HasNavItemRoute = true;
            NavItemRoute = "Products/ProductVariants";

            await base.OnInitializedAsync();

            ProductVariantViewModel.Hasp = DeviceTypes.Find(c => c.Name == "HASP");

            var dongle = ProductVariantViewModel.LicenseModels.Find(c => c.Name == "RMS_Dongle_Bound");

            if (null != dongle)
            {
                ProductVariantViewModel.FilteredLicenseModelsAdditional.Add(dongle);
            }

            ProductVariantViewModel.FilteredLicenseModelsAdditional.Insert(0, new LicenseModel { Id = string.Empty, Name = string.Empty });
            ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional = ProductVariantViewModel.FilteredLicenseModelsAdditional.FirstOrDefault()?.Name;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Selected product changed
    /// </summary>
    internal void OnSelectedProductVariantChanged(ProductVariant selectedProductVariant)
    {
        try
        {
            ProductVariantViewModel.SelectProductVariantChanged(selectedProductVariant);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// ProductVariant State changed
    /// </summary>
    /// <param name="newValue">new value</param>
    private void OnSelectedProductVariantStateChanged(int newValue)
    {
        try
        {
            ProductVariantViewModel.SelectedProductVariantStateChanged(newValue);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Concurrency State changed
    /// </summary>
    /// <param name="newValue">new value</param>
    private void OnSelectedConcurrencyStateChanged(int newValue)
    {
        try
        {
            ProductVariantViewModel.SelectedConcurrencyStateChanged(newValue);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Businessgroup selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void BusinessGroupValueChangedHandler(object newValue)
    {
        try
        {
            ProductVariantViewModel.BusinessGroupValueChanged(newValue);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Variant LicenseModel selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void VariantLicenseModelValueChangedHandler(string newValue)
    {
        try
        {
            ProductVariantViewModel.VariantLicenseModelValueChanged(newValue);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Change additional license model
    /// </summary>
    /// <param name="licenseModel">License model</param>
    private void LicenseModelAdditionalChanged(string licenseModel)
    {
        ProductVariantViewModel.LicenseModelAdditionalChanged(licenseModel);
    }

    /// <summary>
    /// Select product pressed
    /// </summary>
    private void OnSelectProductClicked()
    {
        try
        {
            ProductVariantViewModel.ShowSearchDialog = true;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private async Task OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            await _ErrorZeissLicensingAlert!.Hide();

            if (DeviceTypes.Count == 0)
            {
                await base.LoadDeviceTypes();
            }

            switch (action)
            {
                case ActionType.Add:
                    SelectedDeviceTypeId = DeviceTypes.FirstOrDefault()?.Id ?? string.Empty;
                    ProductVariantViewModel.ActionAdd(BusinessGroups.FirstOrDefault());
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    ProductVariantViewModel.ActionEdit();
                    await LoadAdditionalData();
                    ProductVariantViewModel.ActionEditUseNamedUsers();
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    ProductVariantViewModel.EditOriginalProductVariant = ProductVariantViewModel.SelectedProductVariant;
                    await LoadAdditionalData();
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
            IsListVisible = true;
        }
        finally
        {
            IsLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Load additional data to product
    /// </summary>
    private async Task LoadAdditionalData()
    {
        try
        {
            // ProductVariant load full data :
            ProductVariantViewModel.SelectedProductVariant = await ProductVariantClient.GetProductVariantById(ProductVariantViewModel.SelectedProductVariant.Id);

            if (!string.IsNullOrWhiteSpace(ProductVariantViewModel.SelectedProductVariant.ProductId))
            {
                var prod = await ProductClient.GetById(ProductVariantViewModel.SelectedProductVariant.ProductId);

                if (null == prod)
                {
                    throw new ZeissLicensingException($"Assigned product {ProductVariantViewModel.SelectedProductVariant.ProductId} invalid. Please contact CIT-SCD.", "");
                }

                ProductVariantViewModel.ProductText = $"{prod.Name}, {prod.Version}";
            }
            else
            {
                ProductVariantViewModel.ProductText = string.Empty;
            }

            // Check device type
            if (DeviceTypes.TrueForAll(c => c.Id != ProductVariantViewModel.SelectedProductVariant.DeviceTypeId))
            {
                ProductVariantViewModel.SelectedProductVariant.DeviceTypeName = string.Empty;
                ErrorZeissLicensingText = E["UNKNOWNDEVICETYPE"];
                await _ErrorZeissLicensingAlert!.Show();
            }

            var devTypeId = DeviceTypes.FirstOrDefault(c => c.Id == ProductVariantViewModel.SelectedProductVariant.DeviceTypeId)?.Id ?? string.Empty;
            SelectedDeviceTypeId = !string.IsNullOrWhiteSpace(devTypeId) ? devTypeId : DeviceTypes.FirstOrDefault()?.Id ?? string.Empty;
            ProductVariantViewModel.SelectedProductVariantFormattedMaterialNumber = ProductVariantViewModel.SelectedProductVariant.FormattedMaterialNumber;
            CreateLastUsedItem(ProductVariantViewModel.SelectedProductVariant.Id, ProductVariantViewModel.SelectedProductVariant.Name, "products/productvariants", SharedResource.PRODUCTVARIANT);

            // Upgrade product variant
            if (ProductVariantViewModel.IsUpgrade)
            {
                await ProductVariantViewModel.SetUpgradeProductVariant(ProductVariantViewModel.SelectedProductVariant);
            }

            StateHasChanged();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Delete Dialog OK
    /// </summary>
    private async Task OnDeleteOK()
    {
        try
        {
            ProductVariantViewModel.DeleteIsLoading = true;
            await ProductVariantClient.Delete(ProductVariantViewModel.SelectedProductVariant);

            RefSearchProdComp!.RemoveProductVariant(ProductVariantViewModel.SelectedProductVariant);
            ProductVariantViewModel.SelectedProductVariant = new ProductVariant();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            ProductVariantViewModel.DeleteIsLoading = false;
            ShowDeleteDialog = false;
        }
    }

    /// <summary>
    /// Delete Dialog Discard
    /// </summary>
    private void OnDeleteDiscard()
    {
        try
        {
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search product OK pressed
    /// </summary>
    private void OnSearchProductOKClick(object product)
    {
        try
        {
            ProductVariantViewModel.AssignSearchedProduct(product);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search product Discard pressed
    /// </summary>
    private void OnSearchProductDiscardClick()
    {
        try
        {
            ProductVariantViewModel.ShowSearchDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            // Check Material number:
            if (ProductHelper.CheckMaterialnumber(ProductVariantViewModel.SelectedProductVariantFormattedMaterialNumber))
            {
                ProductVariantViewModel.SelectedProductVariant.FormattedMaterialNumber = ProductVariantViewModel.SelectedProductVariantFormattedMaterialNumber;
            }
            else
            {
                var msg = ExceptionResource.MATERIALNUMBERWRONGFORMAT;
                await ErrorHandler!.ProcessError(new Exception(msg));
                return;
            }

            IsSaving = true;
            var isAdd = false;

            ProductVariantViewModel.PrepareSaving(ShowAdditional, SelectedDeviceType);

            if (string.IsNullOrWhiteSpace(ProductVariantViewModel.SelectedProductVariant.Id))
            {
                ProductVariantViewModel.SelectedProductVariant = await ProductVariantClient.Add(ProductVariantViewModel.SelectedProductVariant);
                isAdd = true;
                CreateLastUsedItem(ProductVariantViewModel.SelectedProductVariant.Id, ProductVariantViewModel.SelectedProductVariant.Name, "products/productvariants", SharedResource.PRODUCTVARIANT);
            }
            else
            {
                ProductVariantViewModel.SelectedProductVariant = await ProductVariantClient.Update(ProductVariantViewModel.SelectedProductVariant);
            }

            RefSearchProdComp!.SaveProductVariant(ProductVariantViewModel.EditOriginalProductVariant, ProductVariantViewModel.SelectedProductVariant, isAdd);

            await _ErrorZeissLicensingAlert!.Hide();
            IsListVisible = true;

            StateHasChanged();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            IsListVisible = true;

            ProductVariantViewModel.SelectedProductVariant = ProductVariantViewModel.EditOriginalProductVariant;

            _ErrorZeissLicensingAlert!.Hide();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement history button clicked
    /// </summary>
    private void OnHistoryButtonClicked()
    {
        try
        {
            _ = _HistoryDialog!.ShowHistory(ProductVariantViewModel.SelectedProductVariant.Id, ProductVariantViewModel.SelectedProductVariant.Name, HistoryType.Productvariant);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            InfoDialog!.SetInfo(ProductVariantViewModel.SelectedProductVariant);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    private void OnUseNamedUserChanged(bool useNamedUser)
    {
        ProductVariantViewModel.UseNamedUserChanged(useNamedUser);
    }

    private void OnToUpgradeClicked()
    {
        // Show Dialog
        ProductVariantViewModel.ShowToUpgradeDialog = true;
    }

    private void OnToUpgradeDiscard()
    {
        ProductVariantViewModel.ShowToUpgradeDialog = false;
    }

    private async Task OnToUpgradeOK()
    {
        ProductVariantViewModel.ShowToUpgradeDialog = false;

        await ProductVariantViewModel.SetToUpgradeVariant();
    }

    #endregion
}
