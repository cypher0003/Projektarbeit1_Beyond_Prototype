#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Microsoft.Extensions.Logging;
using ProductsModule.ViewModels;

namespace ProductsModule.Pages;

public partial class ViewImport
{
    #region Fields

    private Alert? _ErrorImportAlert;

    #endregion

    #region Properties

    private string FileContent { get; set; } = string.Empty;

    private string SelectedFile { get; set; } = string.Empty;

    private bool IsValidating { get; set; }

    private bool HasSelection => SelectedImportProducts.Any();

    private bool CompleteProduct { get; set; }

    private List<ImportProductViewModel> ImportProducts { get; } = new();

    private ImportProductViewModel SelectedImportProduct { get; set; } = new();

    private List<ImportProductViewModel> SelectedImportProducts { get; set; } = new();

    private string ErrorImportText { get; set; } = string.Empty;

    private string ErrorImportDescription { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Import button clicked
    /// </summary>
    private async Task OnImportButtonClicked()
    {
        try
        {
            IsSaving = true;

            var importedProducts = new List<ImportProduct>();

            foreach (var importProductViewModel in SelectedImportProducts.ToList())
            {
                var importProduct = importProductViewModel.ImportProduct;
                importProduct.CompleteProduct = CompleteProduct;

                var importedProduct = await productClient.ImportProductsCsv(new List<ImportProduct> { importProduct });

                importedProducts.AddRange(importedProduct);

                // only remove products from the table if the import was successful
                if (!ContainsError(importedProduct))
                {
                    ImportProducts.Remove(importProductViewModel);
                    SelectedImportProducts.Remove(importProductViewModel);
                    StateHasChanged();
                }
            }

            // Show Message after all elements are processed
            if (ContainsError(importedProducts))
            {
                var lineNumbers = string.Join(',', importedProducts.Where(c => !string.IsNullOrWhiteSpace(c.Error)).Select(c => c.LineNumber));
                var success = importedProducts.Count(c => string.IsNullOrWhiteSpace(c.Error));
                ErrorImportText = string.Format(ExceptionResource.IMPORTERRORFAILED, lineNumbers);
                ErrorImportDescription = string.Format(ExceptionResource.IMPORTERRORSUCCESS, success);
                await _ErrorImportAlert!.Show();
            }
            else
            {
                SelectedFile = string.Empty;
                SnackbarException.ShowMessage(string.Format(SharedResource.IMPORTSUCCESS, importedProducts.Count));
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsSaving = false;
        }
    }

    private static bool ContainsError(IEnumerable<ImportProduct> importedProducts)
    {
        return importedProducts.Any(c => !string.IsNullOrWhiteSpace(c.Error));
    }

    /// <summary>
    /// Only selection by Checkbox
    /// </summary>
    /// <param name="rowSelectableEventArgs">Event args</param>
    /// <returns></returns>
    private bool RowSelectableHandler(RowSelectableEventArgs<ImportProductViewModel> rowSelectableEventArgs)
    {
        return rowSelectableEventArgs.Item.SelectedAllowed;
    }

    /// <summary>
    /// SelectFile
    /// </summary>
    /// <param name = "e">File changed event args</param>
    /// <returns></returns>
    private async Task OnFileEditChanged(FileChangedEventArgs e)
    {
        try
        {
            ImportProducts.Clear();
            await _ErrorImportAlert!.Hide();
            ErrorImportText = string.Empty;

            foreach (var file in e.Files)
            {
                SelectedFile = file.Name;

                var stream = file.OpenReadStream();
                // Use the stream reader to read the content of uploaded file,
                // in this case we can assume it is a textual file.
                using (var reader = new StreamReader(stream))
                {
                    FileContent = await reader.ReadToEndAsync();
                    Logger.LogInformation("OnFileEditChanged(): File: {fileName} Data/FileContent: {fileContent}", file.Name, FileContent);
                }

                await CreateTable(FileContent);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Creates the list of the file content
    /// </summary>
    /// <param name = "fileContent">file content</param>
    private async Task CreateTable(string fileContent)
    {
        try
        {
            IsValidating = true;

            var lines = fileContent.Split(new[] { System.Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            StateHasChanged();

            // Ignore first row -> column headers
            for (var i = 1; i < lines.Length; i++)
            {
                // Ignore empty lines
                var product = CreateImportLine(lines[i], i);
                if (product == null)
                {
                    continue;
                }

                // Each validation can take some time, so we don't do them all at once
                // and instead do it line by line to give the user immediate feedback
                // and have the opportunity to cancel the process any time.
                var importProducts = await productClient.ValidateImportProductsCsv(new List<ImportProduct> { product });
                foreach (var importProduct in importProducts)
                {
                    var viewModel = new ImportProductViewModel(importProduct);
                    ImportProducts.Add(viewModel);

                    if (viewModel.SelectedAllowed)
                    {
                        SelectedImportProducts.Add(viewModel);
                    }

                    StateHasChanged();
                }
            }

            // Info
            var msg = string.Format(ProductResource.IMPORTUPLOADSUCCESSFUL, ImportProducts.Count);
            SnackbarException.ShowMessage(msg);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsValidating = false;
        }
    }

    /// <summary>
    /// Create an import line
    /// </summary>
    /// <param name = "line">Data</param>
    /// <param name = "lineNumber">Line number of csv file</param>
    /// <returns></returns>
    private ImportProduct? CreateImportLine(string line, int lineNumber)
    {
        ImportProduct? ret = null;

        var cells = line.Split(';');

        if (cells.Length > 0 && cells.Any(c => c.Length > 0))
        {
            ret = new();

            if (cells.Length < 4)
            {
                ret.Features = new List<Feature>();
                ret.Materialnumbers = new List<string>();
            }
            else
            {
                ret.LineNumber = lineNumber;
                ret.ProductName = cells[0];
                ret.ProductVersion = cells[1];
                ret.Features = CreateFeatureList(cells[2]);
                ret.Materialnumbers = cells[3].Split(",", StringSplitOptions.RemoveEmptyEntries).ToList();
            }
        }

        return ret;
    }

    /// <summary>
    /// Creates feature list
    /// </summary>
    /// <param name = "features">String with features</param>
    /// <returns>feature list</returns>
    private List<Feature> CreateFeatureList(string features)
    {
        List<Feature> retList = new();

        if (!string.IsNullOrWhiteSpace(features))
        {
            var featureList = features.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            foreach (var item in featureList)
            {
                var startBrake = item.IndexOf("[", StringComparison.InvariantCulture);
                var startBrakeRound = item.IndexOf("(", StringComparison.InvariantCulture);
                var namelen = item.Length;

                if (startBrake > -1 && startBrake < namelen)
                {
                    namelen = startBrake;
                }

                if (startBrakeRound > -1 && startBrakeRound < namelen)
                {
                    namelen = startBrakeRound;
                }

                var name = item.Substring(0, namelen).Trim();
                var version = string.Empty;

                if (startBrake >= 0 && item.Contains(']'))
                {
                    var index = item.IndexOf("]", StringComparison.InvariantCulture);
                    version = item.Substring(startBrake + 1, index - startBrake - 1).Trim();
                }

                var displayname = string.Empty;

                if (startBrakeRound >= 0 && item.Contains(')'))
                {
                    var index = item.IndexOf(")", StringComparison.InvariantCulture);
                    displayname = item.Substring(startBrakeRound + 1, index - startBrakeRound - 1).Trim();
                }

                var feature = new Feature { DisplayName = displayname, Name = name, Version = version };
                retList.Add(feature);
            }
        }

        return retList;
    }

    #endregion
}
