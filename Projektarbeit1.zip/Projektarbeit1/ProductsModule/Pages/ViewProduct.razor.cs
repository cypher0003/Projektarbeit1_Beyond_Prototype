﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Components.Documents;
using ComponentsLibrary.ViewModels.Documents;
using ProductsModule.ViewModels;
using Zeiss.Licensing.Backend.WebServiceClient.Clients;
using Zeiss.Licensing.Data.Exceptions;
using Zeiss.Licensing.Data.Models;

namespace ProductsModule.Pages;

public partial class ViewProduct
{
    #region Fields

    //Dialogs / Messageboxes
    private Modal _ModalRefAddFeature = null!;
    private Modal _ModalRefAddNewFeature = null!;
    private Modal _ModalRefAddProductVariant = null!;
    private Modal _ModalRefAddNewProductVariant = null!;
    private Modal _ModalRefAddDocumentAssignment = null!;
    private Alert _ErrorBusinessGroup = null!;
    private Alert _ErrorZeissLicensingAlert = null!;
    private DialogOkDiscard _ConfirmDlg = null!;

    private DataGrid<ProductVariant> _DgProductVariants = null!;
    private HistoryDialog _HistoryDialog = null!;
    private SearchFeatureComponent _SearchFeatureComponent = null!;
    private SearchDocumentComponent _SearchDocumentComponent = null!;

    #endregion

    #region Properties

    [Parameter]
    public string? ProductId { get; set; } = string.Empty;

    /// <summary>
    /// Selected features
    /// </summary>
    public List<Feature> SelectedFeatures { get; set; } = new();

    private string SelectedTab { get; set; } = "variants";

    private FeatureViewModel SelectedFeatureVM { get; set; } = new();

    private DocumentProductAssignmentViewModel SelectedDocumentAssignmentVM { get; set; } = new(new());

    private DocumentProductAssignmentViewModel AddEditDocumentAsssignmentVM { get; set; } = new(new());

    private ProductVariant SelectedProductProductVariant { get; set; } = new();

    private Product EditOriginalProduct { get; set; } = new();

    private List<LicenseModel> LicenseModels { get; set; } = new();

    private List<LicenseModel> FilteredLicenseModels { get; set; } = new();

    private List<ProductFamily> ProductFamilies { get; set; } = new();

    private List<ProductFamily> ProductFamiliesEdit { get; set; } = new();

    private Product SelectedProduct { get; set; } = new Product();

    // Add grids
    private Feature SelectedFeature { get; set; } = new();

    private ProductVariant SelectedProductVariant { get; set; } = new();

    private ProductFeature NewFeature { get; set; } = new();

    private ProductVariant NewVariant { get; set; } = new();

    private List<FeatureViewModel> ValidFeatures { get; } = new();

    private List<DocumentProductAssignmentViewModel> DocumentAssignments { get; } = new();

    private List<DocumentProductAssignmentViewModel> RemovedDocumentAssignments { get; } = new();

    private List<DocumentProductAssignmentViewModel> EditDocumentAssignments { get; } = new();

    private IEnumerable<SelectModel> DocumentAssignmentStateList { get; set; } = new List<SelectModel>();

    private bool IsDeleteVariantBtnDisabled { get; set; } = true;

    private bool ShowConfirmDialog { get; set; }

    private string ConfirmText { get; set; } = string.Empty;

    private string ConfirmCaption { get; set; } = string.Empty;

    private bool IsReadOnlyOrEnabled => IsReadOnly || SelectedProduct.State != ProductState.DRAFT;

    private string NewProductVariantFormattedMaterialNumber { get; set; } = string.Empty;

    private SearchProductComponent? RefSearchProdComp { get; set; }

    private SearchProductVariantComponent? ModalRefAddProductVariantSearchProductVariantComponent { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            NewFeature.Feature = new Feature();

            IsLoading = !string.IsNullOrWhiteSpace(ProductId);

            if (IsLoading)
            {
                StateHasChanged();
            }

            var licenseModelsTask = ProductClient.GetLicenseModels();
            var productFamiliesTask = AppSettingClient.GetProductFamilies(false);

            // grants
            CurrentUser = await UserClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.Edit);
            IsUserViewGranted = IsSuperUser   || CurrentUser.Roles.Exists(c => c.GrantProduct >= GrantType.View);

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Exists(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);

            // Document assignment state list
            List<string> listText = new();

            foreach (DocumentAssignmentState varState in Enum.GetValues(typeof(DocumentAssignmentState)))
            {
                listText.Add(P["DOCUMENTASSIGNMENTSTATE" + varState.ToString().ToUpper()]);
            }

            DocumentAssignmentStateList = Enumerable.Range(1, listText.Count).Select(x => new SelectModel { Text = listText[x - 1], Value = x - 1 });

            LicenseModels = await licenseModelsTask;
            ProductFamilies = await productFamiliesTask;

            HasNavItemRoute = true;
            NavItemRoute = "Products";

            await base.OnInitializedAsync();
            await base.LoadBusinessGroups();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Parameter set
    /// </summary>
    /// <returns></returns>
    protected override async Task OnParametersSetAsync()
    {
        if (!string.IsNullOrWhiteSpace(ProductId))
        {
            SelectedProduct = new Product { Id = ProductId };
            await OnActionClicked(ActionType.View);
        }
    }

    /// <summary>
    /// Selected Tab changed
    /// </summary>
    /// <param name="name">Name of tab</param>
    private void OnSelectedTabChanged(string name)
    {
        try
        {
            SelectedTab = name;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected product changed
    /// </summary>
    private void OnSelectedProductChanged(object selp)
    {
        try
        {
            if (null != selp)
            {
                SelectedProduct = (Product)selp;
            }
            else
            {
                SelectedProduct = new Product();
                ValidFeatures.Clear();
                DocumentAssignments.Clear();
                RemovedDocumentAssignments.Clear();
                EditDocumentAssignments.Clear();
            }

            IsDeleteVariantBtnDisabled = SelectedProductProductVariant == null || SelectedProduct?.ProductVariants?.Count == 0;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Businessgroup selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void BusinessGroupValueChangedHandler(string newValue)
    {
        try
        {
            SelectedProduct.Businessgroup = newValue;
            ProductFamiliesEdit = ProductFamilies.Where(c => c.Businessgroup == SelectedProduct.Businessgroup).ToList();
            SelectedProduct.ProductFamily = ProductFamiliesEdit.FirstOrDefault();
            SelectedProduct.ProductFeatures.Clear();

            // Delete all features
            ValidFeatures.Clear();
            DocumentAssignments.Clear();
            RemovedDocumentAssignments.Clear();
            EditDocumentAssignments.Clear();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// ProductFamily selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void ProductFamilyValueChangedHandler(object newValue)
    {
        try
        {
            SelectedProduct.ProductFamily = ProductFamiliesEdit.FirstOrDefault(c => c.Name == (string)newValue);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Variant LicenseModel selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void VariantLicenseModelValueChangedHandler(object newValue)
    {
        try
        {
            NewVariant.LicenseModel = (string)newValue;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private async Task OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            await _ErrorZeissLicensingAlert.Hide();

            switch (action)
            {
                case ActionType.Add:
                    EditOriginalProduct = SelectedProduct;

                    SelectedProduct = new Product
                    {
                        Businessgroup = BusinessGroups.FirstOrDefault()
                    };

                    ProductFamiliesEdit = ProductFamilies.Where(c => c.Businessgroup == SelectedProduct.Businessgroup).ToList();
                    SelectedProduct.ProductFamily = ProductFamiliesEdit.FirstOrDefault();
                    ValidFeatures.Clear();
                    DocumentAssignments.Clear();
                    RemovedDocumentAssignments.Clear();
                    EditDocumentAssignments.Clear();
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    EditOriginalProduct = SelectedProduct;
                    SelectedProduct = (Product)EditOriginalProduct.Clone();
                    await LoadAdditionalData();
                    ProductFamiliesEdit = ProductFamilies.Where(c => c.Businessgroup == SelectedProduct.Businessgroup).ToList();
                    CreateLastUsedItem(SelectedProduct.Id, SelectedProduct.Name, "products", SharedResource.PRODUCT);
                    SelectedDocumentAssignmentVM = DocumentAssignments.FirstOrDefault() ?? new(new());
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    EditOriginalProduct = SelectedProduct;
                    await LoadAdditionalData();
                    CreateLastUsedItem(SelectedProduct.Id, SelectedProduct.Name, "products", SharedResource.PRODUCT);
                    SelectedDocumentAssignmentVM = DocumentAssignments.FirstOrDefault() ?? new(new());
                    break;
                case ActionType.Complete:
                    ConfirmCaption = P["CONFIRMCAPTION"];
                    ConfirmText = P["CONFIRMCOMPLETE"];
                    isListVisible = true;
                    ShowConfirmDialog = true;
                    break;
                case ActionType.EndOfLife:
                    ConfirmCaption = P["CONFIRMCAPTION"];
                    ConfirmText = P["CONFIRMENDOFLIFE"];
                    isListVisible = true;
                    ShowConfirmDialog = true;
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
            IsListVisible = true;
        }
        finally
        {
            IsLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Load additional data to product
    /// </summary>
    private async Task LoadAdditionalData()
    {
        try
        {
            // Clear list
            ValidFeatures.Clear();
            DocumentAssignments.Clear();
            RemovedDocumentAssignments.Clear();
            EditDocumentAssignments.Clear();

            // Product load full data:
            if (null == SelectedProduct.ProductVariants && !string.IsNullOrWhiteSpace(SelectedProduct.Id))
            {
                SelectedProduct = await ProductClient.GetById(SelectedProduct.Id);
            }

            foreach (var productFeature in SelectedProduct.ProductFeatures)
            {
                if (productFeature.Feature is not Feature)
                {
                    var fe = await ProductClient.GetFeature(productFeature.Feature.Id);
                    productFeature.Feature = fe;
                }
            }

            var invalidIds = SelectedProduct.InvalidFeatures.Select(c => c.Id).ToList();

            if (null != SelectedProduct.ProductFeatures)
            {
                foreach (var productFeature in SelectedProduct.ProductFeatures.Where(c => !invalidIds.Contains(c.Feature.Id)).ToList())
                {
                    var featureViewModel = Helper.FeatureHelper.GetFeatureViewModel(productFeature);
                    ValidFeatures.Add(featureViewModel);
                }
            }

            RemovedDocumentAssignments.Clear();
            EditDocumentAssignments.Clear();

            var documentAssignments = await ProductClient.GetDocumentAssignments(new SearchObjectDocumentAssignment
            {
                ProductId = SelectedProduct.Id,
                SearchPattern = SearchPattern.Exact
            });

            foreach (var documentProductAssignment in documentAssignments.List)
            {
                DocumentProductAssignmentViewModel assignmentViewModel = new(documentProductAssignment);
                DocumentAssignments.Add(assignmentViewModel);
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Confirm Dialog OK
    /// </summary>
    private async Task OnConfirmOK()
    {
        try
        {
            ShowConfirmDialog = false;

            if (_ConfirmDlg.Text == P["CONFIRMCOMPLETE"])
            {
                await OnCompleteButtonClicked();
            }
            else if (_ConfirmDlg.Text == P["CONFIRMENDOFLIFE"])
            {
                await OnEndOfLifeButtonClicked();
            }

            StateHasChanged();
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            SnackbarException.ShowException(ErrorZeissLicensingText);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Confirm Dialog Discard
    /// </summary>
    private void OnConfirmDiscard()
    {
        try
        {
            ShowConfirmDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete Dialog OK
    /// </summary>
    private async Task OnDeleteOK()
    {
        try
        {
            ShowDeleteDialog = false;
            await ProductClient.Delete(SelectedProduct);

            RefSearchProdComp!.RemoveProduct(SelectedProduct);
            SelectedProduct = new Product();
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            SnackbarException.ShowException(ErrorZeissLicensingText);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Delete Dialog Discard
    /// </summary>
    private void OnDeleteDiscard()
    {
        try
        {
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Button Complete product clicked
    /// </summary>
    private async Task OnCompleteButtonClicked()
    {
        try
        {
            await SaveStateChanges(ProductState.ENABLE);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Button End of life of product clicked
    /// </summary>
    private async Task OnEndOfLifeButtonClicked()
    {
        try
        {
            await SaveStateChanges(ProductState.DISABLE);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save product with changed states
    /// </summary>
    private async Task SaveStateChanges(ProductState newProductState)
    {
        var oldProductState = SelectedProduct.State;

        try
        {
            EditOriginalProduct = SelectedProduct;
            SelectedProduct = await ProductClient.GetById(SelectedProduct.Id);
            SelectedProduct.State = newProductState;
            SelectedProduct = await ProductClient.Update(SelectedProduct);
            RefSearchProdComp!.SaveProduct(EditOriginalProduct, SelectedProduct, false);

            await _ErrorZeissLicensingAlert.Hide();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert.Show();
            SelectedProduct.State = oldProductState;

            await CheckImportFailed(ex);

            SnackbarException.ShowException(ErrorZeissLicensingText);
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert.Show();
        }
        finally
        {
            StateHasChanged();
        }
    }

    private async Task CheckImportFailed(ZeissLicensingException ex)
    {
        if (ex.ErrorCode == "21-1046")
        {
            SelectedProduct = await ProductClient.GetById(SelectedProduct.Id);
            RefSearchProdComp!.SaveProduct(EditOriginalProduct, SelectedProduct, false);
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            var isAdd = false;

            if (string.IsNullOrWhiteSpace(SelectedProduct.Id))
            {
                SelectedProduct = await ProductClient.Add(SelectedProduct, SelectedProduct.ProductFeatures.Select(c => (Feature)c.Feature).ToList());
                isAdd = true;
                CreateLastUsedItem(SelectedProduct.Id, SelectedProduct.Name, "products", SharedResource.PRODUCT);
            }
            else
            {
                SelectedProduct = await ProductClient.Update(SelectedProduct, SelectedProduct.ProductFeatures.Select(c => (Feature)c.Feature).ToList());
            }

            foreach (var documentProductAssignmentViewModel in DocumentAssignments)
            {
                if (string.IsNullOrEmpty(documentProductAssignmentViewModel.Assignment.Id))
                {
                    documentProductAssignmentViewModel.Assignment.ProductId = SelectedProduct.Id;
                    documentProductAssignmentViewModel.Assignment.Businessgroup = SelectedProduct.Businessgroup;
                    documentProductAssignmentViewModel.Assignment.ProductFamily = SelectedProduct.ProductFamily.Name;
                    await ProductClient.AddDocumentAssignment(documentProductAssignmentViewModel.Assignment);
                }
            }

            foreach (var documentProductAssignmentViewModel in EditDocumentAssignments)
            {
                if (!string.IsNullOrEmpty(documentProductAssignmentViewModel.Assignment.Id))
                {
                    await ProductClient.UpdateDocumentAssignment(documentProductAssignmentViewModel.Assignment);
                }
            }

            foreach (var documentProductAssignmentViewModel in RemovedDocumentAssignments)
            {
                if (!string.IsNullOrEmpty(documentProductAssignmentViewModel.Assignment.Id))
                {
                    await ProductClient.DeleteDocumentAssignment(documentProductAssignmentViewModel.Assignment);
                }
            }

            RefSearchProdComp!.SaveProduct(EditOriginalProduct, SelectedProduct, isAdd);

            EndEdit();
            await _ErrorZeissLicensingAlert.Hide();
            IsListVisible = true;

            StateHasChanged();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            IsListVisible = true;

            if (null != EditOriginalProduct)
            {
                SelectedProduct = EditOriginalProduct;
            }
            else
            {
                SelectedProduct = new Product();
            }

            EndEdit();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement history button clicked
    /// </summary>
    private async Task OnHistoryButtonClicked()
    {
        try
        {
            await _HistoryDialog.ShowHistory(SelectedProduct.Id, SelectedProduct.Name, HistoryType.Product);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            InfoDialog!.SetInfo(SelectedProduct);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Add Variant button pressed
    /// </summary>
    private void OnAddVariantButtonClicked()
    {
        try
        {
            SelectedProductVariant = new ProductVariant();
            ModalRefAddProductVariantSearchProductVariantComponent!.ClearList();
            _ModalRefAddProductVariant.Show();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Add new Variant button pressed
    /// </summary>
    private void OnAddNewVariantButtonClicked()
    {
        try
        {
            FilteredLicenseModels = LicenseModels.Where(c => c.Enabled && c.Name.StartsWith(SelectedProduct.Businessgroup + "_")).ToList();

            NewVariant = new ProductVariant
            {
                LicenseModel = FilteredLicenseModels.Count > 0 ? FilteredLicenseModels[0].Name : string.Empty
            };

            _ErrorBusinessGroup.Hide();
            NewProductVariantFormattedMaterialNumber = string.Empty;

            _ModalRefAddNewProductVariant.Show();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Variant Modal Discard
    /// </summary>
    private void HideModalAddVariantDiscard()
    {
        try
        {
            _ModalRefAddProductVariant.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide add new Variant Modal Discard
    /// </summary>
    private void HideModalAddNewVariantDiscard()
    {
        try
        {
            _ModalRefAddNewProductVariant.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Variant Modal Add
    /// </summary>
    private void HideModalAddVariantAdd()
    {
        try
        {
            if (null == SelectedProduct.ProductVariants)
            {
                SelectedProduct.ProductVariants = new List<ProductVariant>();
            }

            SelectedProduct.ProductVariants.Add(SelectedProductVariant);
            SelectedProductProductVariant = SelectedProductVariant;
            CurrentPage = (SelectedProduct.ProductVariants.Count + _DgProductVariants.PageSize - 1) / _DgProductVariants.PageSize;
            _ModalRefAddProductVariant.Hide();
            IsDeleteVariantBtnDisabled = SelectedProduct.ProductVariants.Count == 0;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Variant Modal Add
    /// </summary>
    private async Task HideModalAddNewVariantAdd()
    {
        try
        {
            if (null == SelectedProduct.ProductVariants)
            {
                SelectedProduct.ProductVariants = new List<ProductVariant>();
            }

            // Check Materialnumber:
            if (ProductHelper.CheckMaterialnumber(NewProductVariantFormattedMaterialNumber))
            {
                NewVariant.FormattedMaterialNumber = NewProductVariantFormattedMaterialNumber;
            }
            else
            {
                var msg = ExceptionResource.MATERIALNUMBERWRONGFORMAT;
                await ErrorHandler!.ProcessError(new Exception(msg));
                return;
            }

            SelectedProduct.ProductVariants.Add(NewVariant);
            SelectedProductProductVariant = NewVariant;

            await _ModalRefAddNewProductVariant.Hide();
            IsDeleteVariantBtnDisabled = SelectedProduct.ProductVariants.Count == 0;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete Variant button pressed
    /// </summary>
    private void OnDeleteVariantButtonClicked()
    {
        try
        {
            SelectedProduct.ProductVariants.Remove(SelectedProductProductVariant);

            if (SelectedProduct.ProductVariants.Count > 0)
            {
                SelectedProductProductVariant = SelectedProduct.ProductVariants[0];
            }

            IsDeleteVariantBtnDisabled = SelectedProduct.ProductVariants.Count == 0;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected product changed
    /// </summary>
    private void OnSelectedProductVariantChanged(object selp)
    {
        try
        {
            if (null != selp)
            {
                SelectedProductVariant = (ProductVariant)selp;
            }
            else
            {
                SelectedProductVariant = new ProductVariant();
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Add Feature button pressed
    /// </summary>
    private void OnAddFeatureButtonClicked()
    {
        try
        {
            SelectedFeature = new Feature();

            NewFeature = new ProductFeature
            {
                Count = 1,
                Feature = SelectedFeature
            };

            SelectedFeatures.Clear();
            _SearchFeatureComponent.SetBusinessGroup(SelectedProduct.Businessgroup);
            _ModalRefAddFeature.Show();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Add new Feature button pressed
    /// </summary>
    private void OnAddNewFeatureButtonClicked()
    {
        try
        {
            FilteredLicenseModels = LicenseModels.Where(c => c.Enabled && c.Name.StartsWith(SelectedProduct.Businessgroup + "_")).ToList();

            NewFeature = new ProductFeature
            {
                Count = 1,
                Feature = new Feature
                {
                    Businessgroup = SelectedProduct.Businessgroup
                }
            };

            _ModalRefAddNewFeature.Show();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Feature Modal Discard
    /// </summary>
    private void HideModalAddFeatureDiscard()
    {
        try
        {
            _ModalRefAddFeature.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide add new Feature Modal Discard
    /// </summary>
    private void HideModalAddNewFeatureDiscard()
    {
        try
        {
            _ModalRefAddNewFeature.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Feature Modal Add
    /// </summary>
    private void HideModalAddFeatureAdd()
    {
        try
        {
            foreach (var feature in SelectedFeatures)
            {
                ProductFeature productFeature = new() { Feature = feature, Count = NewFeature.Count };
                SelectedProduct.ProductFeatures.Add(productFeature);

                var featureViewModel = Helper.FeatureHelper.GetFeatureViewModel(productFeature);
                ValidFeatures.Add(featureViewModel);

                SelectedFeatureVM = featureViewModel;
            }

            _ModalRefAddFeature.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Feature Modal Add
    /// </summary>
    private void HideModalAddNewFeatureAdd()
    {
        try
        {
            SelectedProduct.ProductFeatures.Add(NewFeature);

            var featureViewModel = Helper.FeatureHelper.GetFeatureViewModel(NewFeature);
            ValidFeatures.Add(featureViewModel);
            SelectedFeatureVM = featureViewModel;
            _ModalRefAddNewFeature.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete Feature button pressed
    /// </summary>
    private void OnDeleteFeatureButtonClicked()
    {
        try
        {
            SelectedProduct.ProductFeatures.Remove(SelectedFeatureVM.ProductFeature);
            ValidFeatures.Remove(SelectedFeatureVM);

            if (ValidFeatures.Count > 0)
            {
                SelectedFeatureVM = ValidFeatures[0];
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Features selection changed
    /// </summary>
    private void OnSelectedFeaturesChanged(List<Feature> features)
    {
        try
        {
            if (null != features)
            {
                SelectedFeatures = features;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Add document assignment button pressed
    /// </summary>
    private async Task OnAddDocumentAssignmentButtonClicked()
    {
        try
        {
            AddEditDocumentAsssignmentVM = new(new());

            await _SearchDocumentComponent.UpdateList(new SearchObjectDocument
            {
                BusinessGroup = SelectedProduct.Businessgroup,
                SearchPattern = SearchPattern.Exact
            });

            await _ModalRefAddDocumentAssignment.Show();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Edit document assignment button pressed
    /// </summary>
    private async Task OnEditDocumentAssignmentButtonClicked()
    {
        try
        {
            await _SearchDocumentComponent.UpdateList(new SearchObjectDocument
            {
                BusinessGroup = SelectedProduct.Businessgroup,
                SearchPattern = SearchPattern.Exact
            });

            _SearchDocumentComponent.SetSelectedDocument(SelectedDocumentAssignmentVM.DocumentId);

            AddEditDocumentAsssignmentVM = new(SelectedDocumentAssignmentVM.Assignment);
            AddEditDocumentAsssignmentVM.Editing = true;

            await _ModalRefAddDocumentAssignment.Show();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete document assignment button pressed
    /// </summary>
    private void OnDeleteDocumentAssignmentButtonClicked()
    {
        try
        {
            RemovedDocumentAssignments.Add(SelectedDocumentAssignmentVM);
            DocumentAssignments.Remove(SelectedDocumentAssignmentVM);

            if (DocumentAssignments.Count > 0)
            {
                SelectedDocumentAssignmentVM = DocumentAssignments[0];
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide document assignment Modal Discard
    /// </summary>
    private void HideModalAddDocumentAssignmentDiscard()
    {
        try
        {
            AddEditDocumentAsssignmentVM = new(new());
            _ModalRefAddDocumentAssignment.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide document assignment Modal Add
    /// </summary>
    private void HideModalAddDocumentAssignmentAdd()
    {
        try
        {
            AddEditDocumentAsssignmentVM.SaveToModel();
            DocumentProductAssignmentViewModel assignmentViewModel;

            if (AddEditDocumentAsssignmentVM.Editing)
            {
                assignmentViewModel = DocumentAssignments.Single(c => c.Assignment == AddEditDocumentAsssignmentVM.Assignment);
                assignmentViewModel.ReadFromModel();

                if (!string.IsNullOrEmpty(assignmentViewModel.Assignment.Id))
                {
                    EditDocumentAssignments.Add(assignmentViewModel);
                }
            }
            else
            {
                assignmentViewModel = new DocumentProductAssignmentViewModel(AddEditDocumentAsssignmentVM.Assignment);
                DocumentAssignments.Add(assignmentViewModel);
            }

            SelectedDocumentAssignmentVM = assignmentViewModel;

            _ModalRefAddDocumentAssignment.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected documentViewModel has changed
    /// </summary>
    private void OnSelectedDocumentViewModelChanged(DocumentViewModel selectedDocumentViewModel)
    {
        try
        {
            AddEditDocumentAsssignmentVM.DocumentId = selectedDocumentViewModel.Document.Id;
            AddEditDocumentAsssignmentVM.DocumentName = selectedDocumentViewModel.Document.Name;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// End editing/adding
    /// </summary>
    private void EndEdit()
    {
        try
        {
            IsReadOnly = true;
            _ErrorBusinessGroup.Hide();
            _ErrorZeissLicensingAlert.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    private void OnPageChanged(DataGridPageChangedEventArgs obj)
    {
        CurrentPage = obj.Page;
    }

    #endregion
}
