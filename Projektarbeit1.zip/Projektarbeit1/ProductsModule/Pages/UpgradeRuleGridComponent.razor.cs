#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ProductsModule.ViewModels;

namespace ProductsModule.Pages;

public partial class UpgradeRuleGridComponent
{
    #region Properties

    [Parameter]
    public UpgradeRuleGridComponentViewModel UpgradeRuleGridComponentViewModel { get; set; } = null!;

    [Parameter]
    public IEnumerable<LicenseModel> LicenseModels { get; set; } = null!;

    [Parameter]
    public bool IsUpgradeReadOnly
    {
        get => IsReadOnly;
        set => IsReadOnly = value;
    }

    private bool IsAdd { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Upgrade Rule: Action Button clicked
    /// </summary>
    private async Task OnRuleActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;

            switch (action)
            {
                case ActionType.Add:
                    IsAdd = true;
                    ShowSearchDialog = true;
                    break;
                case ActionType.Delete:
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    ShowSearchDialog = true;
                    break;
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsLoading = false;
            StateHasChanged();
        }
    }

    private async Task OnSearchProductVariantOkClick(ProductVariant productVariant)
    {
        try
        {
            if (IsAdd)
            {
                await UpgradeRuleGridComponentViewModel.AddUpgradeRule(productVariant);
            }
            else
            {
                await UpgradeRuleGridComponentViewModel.ChangeUpgradeRuleOutputProductVariant(productVariant);
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsAdd = false;
            ShowSearchDialog = false;
        }
    }

    private async Task OnSearchProductVariantDiscardClick()
    {
        try
        {
            ShowSearchDialog = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    private async Task OnDeleteDiscard()
    {
        try
        {
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    private async Task OnDeleteOK()
    {
        try
        {
            UpgradeRuleGridComponentViewModel.ActionDelete();
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    private void OnSelectedRowChanged(UpgradeRuleViewModel upgradeRuleViewModel)
    {
        UpgradeRuleGridComponentViewModel.OnSelectedRowChanged(upgradeRuleViewModel);
        StateHasChanged();
    }

    private void OnDeleteClicked(object obj)
    {
        UpgradeRuleGridComponentViewModel.SelectedUpgradeRuleViewModel.Validations.Clear();
        UpgradeRuleGridComponentViewModel.SelectedUpgradeRuleViewModel.InnerUpgradeRules.Clear();
    }

    #endregion
}
