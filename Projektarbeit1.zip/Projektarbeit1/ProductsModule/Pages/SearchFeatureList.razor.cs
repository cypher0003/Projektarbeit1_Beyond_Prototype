#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ProductsModule.Pages;

public partial class SearchFeatureList
{
    #region Properties

    [Parameter]
    public EventCallback<Feature> SelectedFeatureChanged { get; set; }

    [Parameter]
    public EventCallback<List<Feature>> SelectedFeaturesChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsMultiselect { get; set; } = false;


    public override bool IsLoadMoreDisable => Features.Count == 0 || base.IsLoadMoreDisable;

    /// <summary>
    /// Selected feature
    /// </summary>
    public Feature SelectedFeature { get; set; } = new();

    /// <summary>
    /// Selected features
    /// </summary>
    public List<Feature> SelectedFeatures { get; set; } = new();

    public SearchObjectFeature SearchObjectFeature { get; set; } = new SearchObjectFeature();

    private List<Feature> Features { get; set; } = new List<Feature>();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectFeature">Search object of feature</param>
    public async Task UpdateList(SearchObjectFeature searchObjectFeature)
    {
        try
        {
            LoadMoreEnded = !searchObjectFeature.RestartLoadMore;
            Features.Clear();
            await UpdateDataList(searchObjectFeature);

            if (Features.Any())
            {
                OnSelectedFeatureChanged(Features.First());
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectFeature">Search object of feature</param>
    public async Task UpdateDataList(SearchObjectFeature searchObjectFeature)
    {
        try
        {
            if (null == searchObjectFeature)
            {
                SelectedFeatures = new();
                Features = new List<Feature>();
            }
            else
            {
                await SearchStarted.InvokeAsync(true);
                SearchObjectFeature = searchObjectFeature;
                searchObjectFeature.PageSize = Convert.ToInt32(configuration["PageSize"]);

                // Trim Strings of SearchObject
                TrimSearchObject(searchObjectFeature);
                PartialList<Feature> partialList = await productClient.GetFeatures(searchObjectFeature);
                var retFeatures = partialList.List;

                if (searchObjectFeature.Businessgroup == "RMS")
                {
                    retFeatures = retFeatures.Where(c => !c.Name.EndsWith("_")).ToList();
                }

                Features.AddRange(retFeatures);
                LoadMoreEnded = partialList.TotalCount <= partialList.PageIndex * partialList.PageSize;
                StateHasChanged();
                await SearchStarted.InvokeAsync(false);
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Remove feature from list
    /// </summary>
    /// <param name = "feature">Feature to be removed</param>
    public void RemoveFeature(Feature feature)
    {
        try
        {
            if (Features.Contains(feature))
            {
                Features.Remove(feature);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save feature to list
    /// </summary>
    /// <param name = "origFeature">Original feature(Update)</param>
    /// <param name = "feature">Feature to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveFeature(Feature origFeature, Feature feature, bool isAdd)
    {
        try
        {
            if (isAdd)
            {
                Features.Insert(0, feature);
                SelectedFeature = feature;
            }
            else
            {
                var idxOrig = Features.IndexOf(origFeature);

                if (idxOrig >= 0)
                {
                    Features.Insert(idxOrig, feature);
                    Features.Remove(origFeature);
                }

                SelectedFeature = feature;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clear list
    /// </summary>
    public void ClearList()
    {
        Features.Clear();
    }

    /// <summary>
    /// Clear list
    /// </summary>
    public void SetFeatureList(List<Feature> features)
    {
        Features.Clear();
        Features = features;
        OnSelectedFeatureChanged(Features.FirstOrDefault());
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectFeature.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object? obj, ActionType actionType)
    {
        try
        {
            if (null != obj && SelectedFeature != (Feature)obj)
            {
                OnSelectedFeatureChanged((Feature)obj);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectFeature.UseLoadMore = true;
            SearchObjectFeature.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectFeature);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected feature changed
    /// </summary>
    private void OnSelectedFeatureChanged(Feature? selobj)
    {
        try
        {
            if (!IsMultiselect && null != selobj && selobj != SelectedFeature)
            {
                SelectedFeature = selobj;
                SelectedFeatureChanged.InvokeAsync(selobj);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected features changed
    /// </summary>
    private void OnSelectedFeaturesChanged(List<Feature> selobj)
    {
        try
        {
            if (null != selobj)
            {
                SelectedFeatures = selobj;
                SelectedFeaturesChanged.InvokeAsync(selobj);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
