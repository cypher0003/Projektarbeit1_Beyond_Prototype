﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Backend.UI.DataTypes;

/// <summary>
/// Interface Module Controller
/// </summary>
public interface IModuleController
{
    #region Methods

    /// <summary>
    /// Get Module
    /// </summary>
    /// <param name="user">User</param>
    /// <returns>Module</returns>
    public Module? GetModule(User user);

    #endregion
}
