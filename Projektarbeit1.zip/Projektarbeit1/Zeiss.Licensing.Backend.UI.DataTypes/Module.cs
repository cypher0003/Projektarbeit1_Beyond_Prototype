﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;

namespace Zeiss.Licensing.Backend.UI.DataTypes;

/// <summary>
/// Modules class
/// </summary>
public class Module
{
    #region Fields

    /// <summary>
    /// Name
    /// </summary>
    public readonly string Name;

    /// <summary>
    /// Route
    /// </summary>
    public readonly string Route;

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor 
    /// </summary>
    /// <param name="route">Route</param>
    /// <param name="displayname">Displayname</param>
    /// <param name="icon">Icon name</param>
    public Module(string route, string displayname, string icon)
    {
        Name = displayname; //Nicht Teil der URI, Name des Links in der Navigation

        Route = route; //Teil der URI

        Submodules = new List<Submodule>();

        Icon = icon;
    }

    #endregion

    #region Properties

    /// <summary>
    /// List of submodules
    /// </summary>
    public List<Submodule> Submodules { get; }

    /// <summary>
    /// Icon
    /// </summary>
    public string Icon { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Add submodule
    /// </summary>
    /// <param name="name">Name</param>
    /// <param name="route">Route</param>
    /// <param name="icon">Icon name</param>
    public void AddSubmodule(string name, string route, string icon)
    {
        Submodules.Add(new Submodule(name, Route + "/" + route, icon));
    }

    #endregion
}

/// <summary>
/// Submodule class
/// </summary>
public class Submodule
{
    #region Fields

    /// <summary>
    /// Name
    /// </summary>
    public readonly string Name;

    /// <summary>
    /// Route
    /// </summary>
    public readonly string Route;

    #endregion

    #region Constructors

    /// <summary>
    /// Contructor
    /// </summary>
    public Submodule()
    {
        Name = "";

        Route = "";
        Icon = "zi-home-startscreen";
    }

    /// <summary>
    /// Contructor
    /// </summary>
    /// <param name="name">Name of the submodule</param>
    /// <param name="route">Rout of the submodule</param>
    /// <param name="icon">Icon name</param>
    public Submodule(string name, string route, string icon)
    {
        Name = name;
        Route = route;
        Icon = icon;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Icon
    /// </summary>
    public string Icon { get; set; }

    #endregion
}
