﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using OrganizationsModule.ViewModels;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace OrganizationsModule.Pages;

public partial class ViewOrganizations
{
    #region Fields

    //Dialogs / Messageboxes
    private Alert? _ErrorZeissLicensingAlert;

    #endregion

    #region Properties

    internal OrganizationViewModel OrganizationViewModel { get; set; } = new OrganizationViewModel(new Organization());

    [Inject]
    private IOrganizationClient OrganizationClient { get; set; } = null!;

    private SearchOrganizationComponent? RefSearchOrganizationComponent { get; set; }

    private bool IsCheckEnabled { get; set; }

    private bool IsUpdateButtonDisabled => IsReadOnly || string.IsNullOrWhiteSpace(SelectedOrganization.Number) || string.IsNullOrWhiteSpace(SelectedOrganization.Id);

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await UserClient!.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Any(c => c.GrantOrganization >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantOrganization >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantOrganization >= GrantType.Edit);
            IsUserViewGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantOrganization >= GrantType.View);

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);

            HasNavItemRoute = true;
            NavItemRoute = "Organizations";

            await base.OnInitializedAsync();
            OnSelectedOrganizationChanged(SelectedOrganization);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Organization type changed
    /// </summary>
    /// <param name="newValue">new value</param>
    private void SelectedOrganizationTypeHandler(int newValue)
    {
        try
        {
            if (IsNewOrganization)
            {
                SelectedOrganizationTypeValue = newValue;
                SelectedOrganization.OrganizationType = (OrganizationType)newValue;
            }
            else
            {
                // Is Publisher: No change, is partner/customer: no change to publisher
                if ((SelectedOrganizationTypeValue == (int)OrganizationType.Publisher && newValue != (int)OrganizationType.Publisher) ||
                    (SelectedOrganizationTypeValue != (int)OrganizationType.Publisher && newValue == (int)OrganizationType.Publisher))
                {
                    string errText = O["CHANGEORGANIZATIONTYPENOTALLOWED"];
                    SnackbarException!.ShowException(errText);
                }
                else
                {
                    SelectedOrganizationTypeValue = newValue;
                    SelectedOrganization.OrganizationType = (OrganizationType)newValue;
                }
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            editOriginalOrganization = SelectedOrganization;

            switch (action)
            {
                case ActionType.Add:

                    SelectedOrganization = new Organization();
                    SelectedCountry = string.Empty;
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    SelectedOrganization = (Organization)editOriginalOrganization.Clone();
                    SelectedOrganizationTypeValue = (int)SelectedOrganization.OrganizationType;
                    SelectedCountry = SelectedOrganization.Country;
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    SelectedCountry = SelectedOrganization.Country;
                    break;
            }

            IsListVisible = isListVisible;
            OrganizationViewModel = new OrganizationViewModel(SelectedOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected organization changed
    /// </summary>
    private void OnSelectedOrganizationChanged(Organization selOrg)
    {
        try
        {
            SelectedOrganization = selOrg;
            SelectedCountry = SelectedOrganization.Country?.ToUpper() ?? string.Empty;
            IsCheckEnabled = SelectedOrganization.State.Equals(OrganizationState.ENABLE);
            OrganizationViewModel = new OrganizationViewModel(SelectedOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete Dialog OK
    /// </summary>
    private async Task OnDeleteOK()
    {
        try
        {
            await OrganizationClient.Delete(SelectedOrganization);

            RefSearchOrganizationComponent!.RemoveOrganization(SelectedOrganization);
            SelectedOrganization = new Organization();
            OrganizationViewModel = new OrganizationViewModel(SelectedOrganization);
            ShowDeleteDialog = false;
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Delete Dialog Discard
    /// </summary>
    private void OnDeleteDiscard()
    {
        try
        {
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Update button clicked
    /// </summary>
    private async Task OnUpdateButtonClicked()
    {
        try
        {
            IsLoading = true;

            var erpOrg = await OrganizationClient.AutoUpdate(SelectedOrganization.Number);

            if (null != erpOrg)
            {
                SelectedOrganization.Address = erpOrg.Address;
                SelectedOrganization.City = erpOrg.City;
                SelectedCountryChanged(erpOrg.Country);
                SelectedOrganization.PostalCode = erpOrg.PostalCode;
                SelectedOrganization.Name = erpOrg.Name;
                SelectedOrganization.SalesOrganizations = erpOrg.SalesOrganizations;
                SelectedOrganization.Description = erpOrg.Description;
                SelectedOrganizationTypeHandler((int)erpOrg.OrganizationType);
            }
            else
            {
                SnackbarException!.ShowException(OrganizationResource.UNKNOWNCUSTOMER);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
        finally
        {
            IsLoading = false;
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            var isAdd = false;

            SelectedOrganization.SalesOrganizations = OrganizationViewModel.GetSalesOrganizations();

            if (string.IsNullOrWhiteSpace(SelectedOrganization.Id))
            {
                SelectedOrganization = await OrganizationClient.Add(SelectedOrganization);
                isAdd = true;
            }
            else
            {
                SelectedOrganization = await OrganizationClient.Update(SelectedOrganization);
            }

            RefSearchOrganizationComponent!.SaveOrganization(editOriginalOrganization, SelectedOrganization, isAdd);

            EndEdit();
            await _ErrorZeissLicensingAlert!.Hide();
            IsListVisible = true;

            StateHasChanged();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            IsListVisible = true;

            SelectedOrganization = editOriginalOrganization;

            OrganizationViewModel = new OrganizationViewModel(SelectedOrganization);
            EndEdit();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            InfoDialog!.SetInfo(SelectedOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Enable state changed
    /// </summary>
    private void OnEnableCheckedChanged(bool ischecked)
    {
        try
        {
            IsCheckEnabled = ischecked;
            SelectedOrganization.State = ischecked ? OrganizationState.ENABLE : OrganizationState.DISABLE;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// End editing/adding
    /// </summary>
    private void EndEdit()
    {
        try
        {
            IsReadOnly = true;
            _ErrorZeissLicensingAlert!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
