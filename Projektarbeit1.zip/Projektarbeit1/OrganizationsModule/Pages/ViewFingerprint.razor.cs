#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace OrganizationsModule.Pages;

public partial class ViewFingerprint
{
    #region Properties

    private Organization SelectedOrganization { get; set; } = new Organization();

    private List<Fingerprint> Fingerprints { get; set; } = new List<Fingerprint>();

    private Fingerprint SelectedFingerprint { get; } = new Fingerprint();

    #endregion

    #region Methods

    /// <summary>
    /// Selected organization has changed
    /// </summary>
    /// <param name = "organization">Selected organization</param>
    private async Task OnSelectedOrganizationChanged(object organization)
    {
        try
        {
            SelectedOrganization = (Organization)organization;
            Fingerprints.Clear();

            if (!string.IsNullOrWhiteSpace(SelectedOrganization.Number))
            {
                Fingerprints = await organizationClient.GetFingerprints(SelectedOrganization.Number);
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    #endregion

    //Dialogs / Messageboxes
}
