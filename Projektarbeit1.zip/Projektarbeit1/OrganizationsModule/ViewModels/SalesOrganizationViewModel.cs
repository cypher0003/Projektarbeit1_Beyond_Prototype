﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace OrganizationsModule.ViewModels;

internal class SalesOrganizationViewModel
{
    #region Constructors

    public SalesOrganizationViewModel(string salesOrganization)
    {
        SalesOrganization = salesOrganization;
    }

    public SalesOrganizationViewModel()
    {
        SalesOrganization = string.Empty;
    }

    #endregion

    #region Properties

    public string SalesOrganization { get; set; }

    #endregion
}
