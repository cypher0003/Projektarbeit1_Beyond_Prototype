﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace OrganizationsModule.ViewModels;

internal class OrganizationViewModel
{
    #region Constructors

    public OrganizationViewModel(Organization organization)
    {
        Organization = organization;
        SalesOrganizations.AddRange(Organization.SalesOrganizations.Select(c => new SalesOrganizationViewModel(c)));
    }

    #endregion

    #region Properties

    public List<SalesOrganizationViewModel> SalesOrganizations { get; } = new();

    private Organization Organization { get; }

    #endregion

    #region Methods

    public List<string> GetSalesOrganizations()
    {
        return SalesOrganizations.Select(c => c.SalesOrganization).ToList();
    }

    #endregion
}
