﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Microsoft.Extensions.Localization;

namespace ResourceLibrary
{
    public class SharedResource
    {
    }

    /// <summary>
    /// Product resources
    /// </summary>
    public class ProductResource
    {
    }

    /// <summary>
    /// Organization resources
    /// </summary>
    public class OrganizationResource
    {
    }

    /// <summary>
    /// Orders resources
    /// </summary>
    public class OrderResource
    {
    }

    /// <summary>
    /// Exception resources
    /// </summary>
    public class ExceptionResource
    {
    }

    /// <summary>
    /// Entitlement resources
    /// </summary>
    public class EntitlementResource
    {
    }

    /// <summary>
    /// License resources
    /// </summary>
    public class LicenseResource
    {
    }
}
