﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Zeiss.Licensing.Data.Exceptions;
using ResourceLibrary;
using Microsoft.Extensions.Localization;

namespace ResourceLibrary.Helper
{
    /// <summary>
    /// Helper for exceptions
    /// </summary>
    public static class ExceptionHelper
    {
        #region Methods

        /// <summary>
        /// Get Text of an error code
        /// </summary>
        /// <param name="ex"></param>
        /// <returns>Text of an error code</returns>
        public static string GetErrorTextOfResource(ZeissLicensingException ex, IStringLocalizer<ExceptionResource> e)
        {
            string errText = e[ex.ErrorCode];
            errText = (string.IsNullOrWhiteSpace(errText) || errText == ex.ErrorCode ? ex.Message : errText) + $" [{ex.ErrorCode}]";

            var innerEx = ex.InnerException;

            while (null != innerEx)
            {
                errText += $"  - {innerEx.Message}.";
                innerEx = innerEx.InnerException;
            }

            return errText;
        }

        #endregion
    }
}
