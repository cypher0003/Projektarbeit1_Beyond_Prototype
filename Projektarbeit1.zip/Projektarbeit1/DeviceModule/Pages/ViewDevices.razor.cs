﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Exceptions;
using ResourceLibrary.Helper;
using Zeiss.Licensing.Data.Exceptions;

namespace DeviceModule.Pages;

public partial class ViewDevices
{
    #region Fields

    //Dialogs / Messageboxes
    private Alert? _ErrorZeissLicensingAlert;
    private RehostDialog? _ReHostDialog;
    private HistoryDialog? _HistoryDialog;
    private Validation? _RefNameValidation = null!;
    private readonly int _LimitSyncReHost = 20;

    #endregion

    #region Properties

    [Parameter]
    public string? DeviceId { get; set; } = string.Empty;

    /// <summary>
    /// Flag: Show revoke dialog
    /// </summary>
    public bool ShowRevokeDialog { get; set; }

    public bool ShowHistoryInfo { get; set; }

    private Device SelectedDevice { get; set; } = new();

    private Device EditOriginalDevice { get; set; } = new();

    private SearchDeviceComponent? RefSearchDeviceComponent { get; set; }

    private LicenseList LicenseList { get; set; } = null!;

    private CustomerSelectionModel CustomerEditSelectionModel { get; set; } = new();

    private string ValidationErrorText { get; set; } = string.Empty;

    private bool IsNameInvalid { get; set; }

    private bool ReHostAsync => LicenseList.NumberOfLicenses > _LimitSyncReHost;

    private bool IsReHostDisabled => IsReadOnly || LicenseList.NumberOfLicenses == 0;

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await UserClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Exists(c => c.GrantDevice >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Exists(c => c.GrantDevice >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Exists(c => c.GrantDevice >= GrantType.Edit);
            IsUserViewGranted = IsSuperUser   || CurrentUser.Roles.Exists(c => c.GrantDevice >= GrantType.View);

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Exists(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);

            IsLoading = !string.IsNullOrWhiteSpace(DeviceId);

            if (IsLoading)
            {
                StateHasChanged();
            }

            await base.LoadDeviceTypes();

            OnSelectedDeviceChanged(null);
            HasNavItemRoute = true;
            NavItemRoute = "device";

            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Parameter set
    /// </summary>
    /// <returns></returns>
    protected override async Task OnParametersSetAsync()
    {
        if (!string.IsNullOrWhiteSpace(DeviceId))
        {
            SelectedDevice = await DeviceClient.GetById(DeviceId);
            await OnActionClicked(ActionType.View);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    protected override void OnSelectOrganizationOKClick(object organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick((Organization)organization);
            SelectedDevice.EndCustomerNumber = ((Organization)organization).Number;
            SelectedDevice.EndCustomerName = ((Organization)organization).Name;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    protected override async Task OnDeleteOrgButtonClicked()
    {
        try
        {
            await base.OnDeleteOrgButtonClicked();
            SelectedDevice.EndCustomerName = string.Empty;
            SelectedDevice.EndCustomerNumber = string.Empty;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private async Task OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;

            switch (action)
            {
                case ActionType.Add:
                    EditOriginalDevice = SelectedDevice;
                    SelectedDevice = new Device();
                    SelectedDeviceTypeId = DeviceTypes.FirstOrDefault()?.Id ?? string.Empty;
                    LicenseList.ClearLicenseList();
                    PrepareDetails();
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    EditOriginalDevice = SelectedDevice;
                    SelectedDevice = (Device)EditOriginalDevice.Clone();
                    SelectedDeviceTypeId = SelectedDevice.DeviceTypeId;
                    await LicenseList.LoadLicenseList(SelectedDevice);
                    PrepareDetails();
                    CreateLastUsedItem(SelectedDevice.Id, SelectedDevice.FriendlyName, "device", SharedResource.DEVICE);
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    SelectedDeviceTypeId = SelectedDevice.DeviceTypeId;
                    EditOriginalDevice = SelectedDevice;
                    await LicenseList.LoadLicenseList(SelectedDevice);
                    PrepareDetails();
                    CreateLastUsedItem(SelectedDevice.Id, SelectedDevice.FriendlyName, "device", SharedResource.DEVICE);
                    break;
            }

            OnSelectedDeviceTypeChanged(SelectedDeviceTypeId);
            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
            IsListVisible = true;
        }
        finally
        {
            IsLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Prepare details
    /// </summary>
    private void PrepareDetails()
    {
        try
        {
            CustomerEditSelectionModel = new CustomerSelectionModel();

            var number = string.IsNullOrWhiteSpace(SelectedDevice.DistributorNumber) ? string.Empty : $"[{SelectedDevice.DistributorNumber}]";
            CustomerEditSelectionModel.DistributorText = $"{SelectedDevice.DistributorName} {number}";

            if (!string.IsNullOrEmpty(SelectedDevice.DistributorNumber))
            {
                CustomerEditSelectionModel.Distributor = new RefOrganization
                {
                    Name = SelectedDevice.DistributorName,
                    Number = SelectedDevice.DistributorNumber
                };
            }

            number = string.IsNullOrWhiteSpace(SelectedDevice.EndCustomerNumber) ? string.Empty : $"[{SelectedDevice.EndCustomerNumber}]";
            CustomerEditSelectionModel.EndcustomerText = $"{SelectedDevice.EndCustomerName} {number}";

            if (!string.IsNullOrEmpty(SelectedDevice.EndCustomerNumber) && !string.IsNullOrEmpty(SelectedDevice.EndCustomerName))
            {
                CustomerEditSelectionModel.Endcustomer = new RefOrganization
                {
                    Name = SelectedDevice.EndCustomerName,
                    Number = SelectedDevice.EndCustomerNumber
                };
            }

            number = string.IsNullOrWhiteSpace(SelectedDevice.FactoryNumber) ? string.Empty : $"[{SelectedDevice.FactoryNumber}]";
            CustomerEditSelectionModel.FactoryText = $"{SelectedDevice.FactoryName} {number}";

            if (!string.IsNullOrEmpty(SelectedDevice.FactoryNumber))
            {
                CustomerEditSelectionModel.Factory = new RefOrganization
                {
                    Name = SelectedDevice.FactoryName,
                    Number = SelectedDevice.FactoryNumber
                };
            }

            number = string.IsNullOrWhiteSpace(SelectedDevice.SSC1Number) ? string.Empty : $"[{SelectedDevice.SSC1Number}]";
            CustomerEditSelectionModel.SSC1Text = $"{SelectedDevice.SSC1Name} {number}";

            if (!string.IsNullOrEmpty(SelectedDevice.SSC1Number))
            {
                CustomerEditSelectionModel.SSC1 = new RefOrganization
                {
                    Name = SelectedDevice.SSC1Name,
                    Number = SelectedDevice.SSC1Number
                };
            }

            number = string.IsNullOrWhiteSpace(SelectedDevice.SSC2Number) ? string.Empty : $"[{SelectedDevice.SSC2Number}]";
            CustomerEditSelectionModel.SSC2Text = $"{SelectedDevice.SSC2Name} {number}";

            if (!string.IsNullOrEmpty(SelectedDevice.SSC2Number))
            {
                CustomerEditSelectionModel.SSC2 = new RefOrganization
                {
                    Name = SelectedDevice.SSC2Name,
                    Number = SelectedDevice.SSC2Number
                };
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected device changed
    /// </summary>
    private void OnSelectedDeviceChanged(object? selDevice)
    {
        try
        {
            if (null != selDevice)
            {
                SelectedDevice = (Device)selDevice;
                SelectedDeviceTypeId = DeviceTypes.Find(c => c.Id == SelectedDevice.DeviceTypeId)?.Id ?? string.Empty;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete Dialog OK
    /// </summary>
    private void OnDeleteOK()
    {
        try
        {
            ShowRevokeDialog = true;
            SelectedDevice.IsDeleted = true;
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Revoke Dialog OK
    /// </summary>
    private async Task OnRevoke(bool revoke)
    {
        try
        {
            ShowRevokeDialog = false;
            ShowDeleteDialog = false;

            await DeviceClient.Delete(SelectedDevice, revoke);
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Delete Dialog Discard
    /// </summary>
    private void OnDeleteDiscard()
    {
        try
        {
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// ReHost Dialog
    /// </summary>
    private void OnReHostButtonClicked()
    {
        _ReHostDialog!.ShowReHost(SelectedDevice, ReHostAsync);
    }

    /// <summary>
    /// Device history button clicked
    /// </summary>
    private async Task OnHistoryButtonClicked()
    {
        try
        {
            // Load device again, to check if history is created/loaded
            SelectedDevice = await DeviceClient.GetById(SelectedDevice.Id);

            switch (SelectedDevice.HistoryState)
            {
                case DeviceHistoryState.NotLoaded:
                    // message "loading" and start loading in service
                    ShowHistoryInfo = true;
                    await HistoryClient.GetDeviceHistory(SelectedDevice.Id);
                    break;
                case DeviceHistoryState.Loading:
                    // message "loading" 
                    ShowHistoryInfo = true;
                    break;
                case DeviceHistoryState.Loaded:
                    await _HistoryDialog!.ShowHistory(SelectedDevice.Id, SelectedDevice.FriendlyName, HistoryType.Device);
                    break;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            var isAdd = false;
            IsSaving = true;

            // Customers data
            if (null != CustomerEditSelectionModel.Distributor)
            {
                SelectedDevice.DistributorName = CustomerEditSelectionModel.Distributor.Name;
                SelectedDevice.DistributorNumber = CustomerEditSelectionModel.Distributor.Number;
            }
            else
            {
                SelectedDevice.DistributorName = string.Empty;
                SelectedDevice.DistributorNumber = string.Empty;
            }

            if (null != CustomerEditSelectionModel.Endcustomer)
            {
                SelectedDevice.EndCustomerName = CustomerEditSelectionModel.Endcustomer.Name;
                SelectedDevice.EndCustomerNumber = CustomerEditSelectionModel.Endcustomer.Number;
            }
            else
            {
                SelectedDevice.EndCustomerName = string.Empty;
                SelectedDevice.EndCustomerNumber = string.Empty;
            }

            if (null != CustomerEditSelectionModel.Factory)
            {
                SelectedDevice.FactoryName = CustomerEditSelectionModel.Factory.Name;
                SelectedDevice.FactoryNumber = CustomerEditSelectionModel.Factory.Number;
            }
            else
            {
                SelectedDevice.FactoryName = string.Empty;
                SelectedDevice.FactoryNumber = string.Empty;
            }

            if (null != CustomerEditSelectionModel.SSC1)
            {
                SelectedDevice.SSC1Name = CustomerEditSelectionModel.SSC1.Name;
                SelectedDevice.SSC1Number = CustomerEditSelectionModel.SSC1.Number;
            }
            else
            {
                SelectedDevice.SSC1Name = string.Empty;
                SelectedDevice.SSC1Number = string.Empty;
            }

            if (null != CustomerEditSelectionModel.SSC2)
            {
                SelectedDevice.SSC2Name = CustomerEditSelectionModel.SSC2.Name;
                SelectedDevice.SSC2Number = CustomerEditSelectionModel.SSC2.Number;
            }
            else
            {
                SelectedDevice.SSC2Name = string.Empty;
                SelectedDevice.SSC2Number = string.Empty;
            }

            // Device Type
            SelectedDevice.DeviceTypeId = SelectedDeviceType?.Id;
            SelectedDevice.DeviceTypeName = SelectedDeviceType?.Name;

            if (string.IsNullOrWhiteSpace(SelectedDevice.Id))
            {
                SelectedDevice = await DeviceClient.Add(SelectedDevice);
                isAdd = true;
                CreateLastUsedItem(SelectedDevice.Id, SelectedDevice.FriendlyName, "device", SharedResource.DEVICE);
            }
            else
            {
                SelectedDevice = await DeviceClient.Update(SelectedDevice);
            }

            RefSearchDeviceComponent!.SaveDevice(EditOriginalDevice, SelectedDevice, isAdd);

            await _ErrorZeissLicensingAlert!.Hide();
            IsListVisible = true;

            StateHasChanged();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            IsListVisible = true;

            SelectedDevice = EditOriginalDevice;

            _ErrorZeissLicensingAlert!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            InfoDialog!.SetInfo(SelectedDevice);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private async Task OnShowDialogChanged(Device device)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(device.Id))
            {
                if (LicenseList.NumberOfLicenses > _LimitSyncReHost)
                {
                    SnackbarException.ShowMessage(SharedResource.REHOST_ASYNC);
                }

                SelectedDevice = await DeviceClient.GetById(device.Id);
                await LicenseList.LoadLicenseList(SelectedDevice);
                PrepareDetails();
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    private void OnSelectedDeviceTypeChanged(string deviceTypeId)
    {
        SelectedDeviceTypeId = deviceTypeId;

        ValidationErrorText = DeviceHelper.CreateValidationErrorText(SelectedDeviceType);

        _ = _RefNameValidation!.Validate();
    }

    private void ValidateDeviceName(ValidatorEventArgs e)
    {
        e.Status = DeviceHelper.ValidateDeviceName(e.Value?.ToString(), SelectedDeviceType);

        IsNameInvalid = e.Status == ValidationStatus.Error;
    }

    #endregion
}
