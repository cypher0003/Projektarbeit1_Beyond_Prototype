﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace DeviceModule.Pages;

public partial class LicenseList
{
    #region Properties

    public int NumberOfLicenses => Licenses.Count;

    private Activation SelectedLicense { get; set; } = new();

    private List<Activation> Licenses { get; set; } = new();

    private Device Device { get; set; } = new();

    private bool DismisableAlert { get; set; } = true;

    private string DownloadText { get; set; } = string.Empty;

    private bool IsDownloadBtnDisabled { get; set; } = true;

    private bool IsDownloadAllBtnDisabled => null == Device || Device.IsDeleted || Licenses.Count == 0 || Licenses.All(c => c.LicenseFileExtension.ToLower().EndsWith("xml"));

    private bool IsFne { get; set; }

    private bool IsRegenerationLoading { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Loads the list of licenses
    /// </summary>
    /// <param name="searchObjectDevice">Search object of device</param>
    public async Task LoadLicenseList(Device device)
    {
        try
        {
            Device = device;
            DismisableAlert = false;
            IsDownloadBtnDisabled = true;
            SelectedLicense = new Activation();

            if (null == device || string.IsNullOrWhiteSpace(device.Id))
            {
                Licenses = new List<Activation>();
            }
            else
            {
                var searchObjectLicense = new SearchObjectLicense
                {
                    PageSize = 10000,
                    SearchPattern = SearchPattern.Exact,
                    DeviceId = device.Id
                };

                // Trim Strings of SearchObject
                TrimSearchObject(searchObjectLicense);
                PartialList<Activation> partialList = await licenseClient.GetLicenses(searchObjectLicense);
                Licenses = partialList.List.Where(c => c.State == ActivationState.ACTIVATED && c.UpgradeStatus == UpgradeStatus.Empty).ToList();
                IsFne = Licenses.All(c => c.LicenseFileExtension.EndsWith("bin"));
                StateHasChanged();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Clear the list of licenses
    /// </summary>
    public void ClearLicenseList()
    {
        try
        {
            Licenses.Clear();
            DismisableAlert = false;
            IsDownloadBtnDisabled = true;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            DismisableAlert = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected license/activaton has changed
    /// </summary>
    /// <param name="activation">Selected license</param>
    private void OnSelectedLicenseChanged(Activation activation)
    {
        try
        {
            SelectedLicense = activation;
            IsDownloadBtnDisabled = null == activation || Device.IsDeleted;

            DismisableAlert = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Download button pressed
    /// </summary>
    private async Task OnDownloadButtonClicked()
    {
        DismisableAlert = false;

        try
        {
            if (null != SelectedLicense)
            {
                SelectedLicense = await licenseClient.GetLicense(SelectedLicense.ActivationId);
                await LicenseHelper.SaveLicenseFile(SelectedLicense, JSRuntime);

                DownloadStatusColor = Color.Success;
                DownloadText = LIC["DOWNLOADOK"];
            }
        }
        catch (Exception)
        {
            DownloadStatusColor = Color.Danger;
            DownloadText = LIC["DOWNLOADERROR"];
        }
        finally
        {
            DismisableAlert = true;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Download button pressed
    /// </summary>
    private async Task OnDownloadAllButtonClicked()
    {
        DismisableAlert = false;

        try
        {
            IsLoading = true;
            var deviceLicenseResponse = await licenseClient.GetLicenseForDevice(Device.Id);

            await LicenseHelper.SaveConsolidatedLicenseFile(deviceLicenseResponse, JSRuntime);

            DownloadStatusColor = Color.Success;
            DownloadText = LIC["DOWNLOADOK"];
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Exception)
        {
            DownloadStatusColor = Color.Danger;
            DownloadText = LIC["DOWNLOADERROR"];
        }
        finally
        {
            DismisableAlert = true;
            IsLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Download button pressed
    /// </summary>
    private async Task OnRegenerateButtonClicked()
    {
        DismisableAlert = false;

        try
        {
            IsRegenerationLoading = true;
            var deviceLicenseResponse = await licenseClient.RegenerateLicenseForDevice(Device.Id);

            DownloadStatusColor = Color.Success;
            DownloadText = LicenseResource.REGENERATIONSUCCESS;
        }
        catch (Exception ex)
        {
            DownloadStatusColor = Color.Danger;
            DownloadText = $"{LicenseResource.REGENERATE}: {ex.Message}";
        }
        finally
        {
            DismisableAlert = true;
            IsRegenerationLoading = false;
            StateHasChanged();
        }
    }

    #endregion
}
