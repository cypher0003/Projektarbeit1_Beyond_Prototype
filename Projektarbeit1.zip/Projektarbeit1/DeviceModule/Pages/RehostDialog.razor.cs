#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace DeviceModule.Pages;

public partial class RehostDialog
{
    #region Fields

    private bool _IsReHosting = false;

    /// <summary>
    /// Modal Reference
    /// </summary>
    private Modal? _ModalReHost;

    private Alert? _ErrorZeissLicensingAlert;

    private bool _ReHostAsync;

    private DialogOkDiscard? _ConfirmationDialog = null!;

    private SearchDeviceComponent? _RefSearchDeviceComponent;

    #endregion

    #region Properties

    [Parameter]
    public EventCallback<Device> ShowDialogChanged { get; set; }

    public Device InitialDevice { get; set; } = new();

    public bool IsNewDevice { get; set; } = false;

    private Device SelectedDevice { get; set; } = new();

    private bool HasSelection => !string.IsNullOrEmpty(SelectedDevice.Id);

    private bool ShowConfirmationDialog { get; set; }

    private string SelectedDeviceFriendlyName { get; set; } = string.Empty;

    private string DeactivateText { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Show reHost Dialog
    /// </summary>
    /// <param name = "device">Initial device</param>
    /// <param name="reHostAsync"></param>
    public void ShowReHost(Device device, bool reHostAsync)
    {
        try
        {
            InitialDevice = device;
            SelectedDevice = new();
            SelectedDeviceTypeId = InitialDevice.DeviceTypeId;
            _RefSearchDeviceComponent!.SetSelectedDeviceTypeId(SelectedDeviceTypeId);
            _ReHostAsync = reHostAsync;
            _ModalReHost!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            await base.LoadDeviceTypes();
            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Close dialog
    /// </summary>
    /// <returns></returns>
    private async Task Discard(bool discard)
    {
        try
        {
            if (discard)
            {
                SelectedDevice = new Device();
            }

            IsListVisible = true;
            _IsReHosting = false;
            _RefSearchDeviceComponent!.ClearList();
            await _ModalReHost!.Hide();
            await ShowDialogChanged.InvokeAsync(SelectedDevice);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// ReHost
    /// </summary>
    private void ReHost()
    {
        try
        {
            _IsReHosting = true;
            DeactivateText = string.Format(L["DEACTIVATEOLDDEVICE"], InitialDevice.FriendlyName);
            ShowConfirmationDialog = true;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Confirm discard
    /// </summary>
    private async Task ConfirmDiscard()
    {
        try
        {
            ShowConfirmationDialog = false;
            _IsReHosting = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await Discard(true);
        }
    }

    /// <summary>
    /// ReHost
    /// </summary>
    /// <returns></returns>
    private async Task PerformReHost()
    {
        try
        {
            ShowConfirmationDialog = false;
            var isChecked = _ConfirmationDialog!.Checked;

            if (IsNewDevice)
            {
                // Device Type
                SelectedDevice.DeviceTypeId = SelectedDeviceType?.Id;
                SelectedDevice.DeviceTypeName = SelectedDeviceType?.Name;
                SelectedDevice.LockCode = SelectedDevice.FriendlyName;
                SelectedDevice.DistributorName = InitialDevice.DistributorName;
                SelectedDevice.DistributorNumber = InitialDevice.DistributorNumber;
                SelectedDevice.EndCustomerName = InitialDevice.EndCustomerName;
                SelectedDevice.EndCustomerNumber = InitialDevice.EndCustomerNumber;
                SelectedDevice.FactoryName = InitialDevice.FactoryName;
                SelectedDevice.FactoryNumber = InitialDevice.FactoryNumber;
                SelectedDevice.SSC1Name = InitialDevice.SSC1Name;
                SelectedDevice.SSC1Number = InitialDevice.SSC1Number;
                SelectedDevice.SSC2Name = InitialDevice.SSC2Name;
                SelectedDevice.SSC2Number = InitialDevice.SSC2Number;
                SelectedDevice = await deviceClient.Add(SelectedDevice);
            }

            if (isChecked)
            {
                await deviceClient.Delete(InitialDevice);
            }

            if (_ReHostAsync)
            {
                _ = LicenseClient.Rehost(new() { ActualDeviceId = InitialDevice.Id, NewDeviceId = SelectedDevice?.Id, });
            }
            else
            {
                await LicenseClient.Rehost(new() { ActualDeviceId = InitialDevice.Id, NewDeviceId = SelectedDevice?.Id, });
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await Discard(false);
        }
    }

    /// <summary>
    /// Selected device changed
    /// </summary>
    private void OnSelectedDeviceChanged(object selDevice)
    {
        try
        {
            SelectedDevice = (Device)selDevice;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Text changed at device name
    /// </summary>
    private void OnTextChangedDeviceName(string name)
    {
        try
        {
            SelectedDeviceFriendlyName = name;
            SelectedDevice.FriendlyName = name;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;

            switch (action)
            {
                case ActionType.Add:
                    SelectedDevice = new();
                    SelectedDeviceTypeId = InitialDevice.DeviceTypeId;
                    SelectedDeviceFriendlyName = string.Empty;
                    SelectedDevice.EndCustomerName = InitialDevice.EndCustomerName;
                    SelectedDevice.EndCustomerNumber = InitialDevice.EndCustomerNumber;
                    IsNewDevice = true;
                    break;
            }

            StateHasChanged();
            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
