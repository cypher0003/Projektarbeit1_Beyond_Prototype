﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Linq;
using Zeiss.Licensing.Backend.UI.DataTypes;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Backend.UI.DeviceModule;

/// <summary>
/// Device Module Controller
/// </summary>
public class ModuleController : IModuleController
{
    #region Methods

    /// <summary>
    /// Get Module
    /// </summary>
    /// <param name="user">User</param>
    /// <returns>Module</returns>
    public DataTypes.Module? GetModule(User user)
    {
        DataTypes.Module? retValue = null;

        if (user != null && (user.AccountType == AccountType.SuperUser || user.Modules.Count(c => c.Name == "Devices") > 0))
        {
            retValue = new DataTypes.Module("device", SharedResource.DEVICES, "zi-sbu-research-microscopy-solutions");
        }

        return retValue;
    }

    #endregion
}
