﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Helpers
{
    [AttributeUsage(AttributeTargets.Class |
                    AttributeTargets.Struct) // Multiuse attribute.  
    ]
    public class EMSAppSettingsRecordNameAttribute : Attribute
    {
        #region Fields

        private readonly string name;

        #endregion

        #region Constructors

        public EMSAppSettingsRecordNameAttribute(string name)
        {
            this.name = name;
        }

        #endregion

        #region Methods

        public string GetName()
        {
            return name;
        }

        #endregion
    }
}
