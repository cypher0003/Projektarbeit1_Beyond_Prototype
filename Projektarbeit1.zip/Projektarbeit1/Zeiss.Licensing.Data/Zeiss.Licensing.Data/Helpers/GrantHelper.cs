﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Linq;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Exceptions;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.Helpers
{
    public static class GrantHelper
    {
        #region Methods

        /// <summary>
        /// Checks the user grants
        /// </summary>
        /// <param name="user">User</param>
        /// <param name="func">Function for get grant properties</param>
        /// <param name="grantType">Grant type to check</param>
        /// <param name="throwException">Throws an exception if user is not authorized</param>
        /// <returns>User authorized true / false</returns>
        public static bool CheckUserGrants(User user, Func<Role, GrantType> func, GrantType grantType, bool throwException = false)
        {
            if (null == user)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_FOR_AUTHENTICATION_IS_MISSING);
            }

            var result = user.AccountType == AccountType.SuperUser || (null != user.Roles && user.Roles.Select(func).Count(c => c >= grantType) > 0);

            if (!result && throwException)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_NOT_AUTHENTICATED, user.Name);
            }

            return result;
        }

        /// <summary>
        /// Checks the user grants for businessgroup
        /// </summary>
        /// <param name="user">User</param>
        /// <param name="func">Function for get grant properties</param>
        /// <param name="grantType">Grant type to check</param>
        /// <param name="businessgroup">Businessgroup</param>
        /// <param name="throwException">Throws an exception if user is not authorized</param>
        /// <returns>User authorized true / false</returns>
        public static bool CheckUserBusinessgroup(User user, Func<Role, GrantType> func, GrantType grantType, string businessgroup, bool throwException = false)
        {
            if (null == user)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_FOR_AUTHENTICATION_IS_MISSING);
            }

            var result = user.AccountType == AccountType.SuperUser || (null != user.Roles && user.Roles.Where(c => c.Businessgroup == businessgroup).Select(func).Count(c => c >= grantType) > 0);

            if (!result && throwException)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_NOT_AUTHENTICATED_FOR_BUSINESSGROUP, user.Name, businessgroup);
            }

            return result;
        }

        /// <summary>
        /// Checks the user grants for a product family
        /// </summary>
        /// <param name="user">User</param>
        /// <param name="func">Function for get grant properties</param>
        /// <param name="grantType">Grant type to check</param>
        /// <param name="productFamily">Product family</param>
        /// <param name="throwException">Throws an exception if user is not authorized</param>
        /// <returns>User authorized true / false</returns>
        [Obsolete("Use CheckUserProductFamily with product family as parameter instead.")]
        public static bool CheckUserProductFamily(User user, Func<Role, GrantType> func, GrantType grantType, string productFamily, bool throwException = false)
        {
            if (null == user)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_FOR_AUTHENTICATION_IS_MISSING);
            }

            var result = user.AccountType == AccountType.SuperUser || (null != user.Roles && user.Roles.Where(c => c.ProductFamilies.Contains(productFamily)).Select(func).Count(c => c >= grantType) > 0);

            if (!result && throwException)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_NOT_AUTHENTICATED_FOR_PRODUCTFAMILY, user.Name, productFamily);
            }

            return result;
        }

        /// <summary>
        /// Checks the user grants for a product family
        /// </summary>
        /// <param name="user">User</param>
        /// <param name="func">Function for get grant properties</param>
        /// <param name="grantType">Grant type to check</param>
        /// <param name="productFamily">Product family</param>
        /// <param name="throwException">Throws an exception if user is not authorized</param>
        /// <returns>User authorized true / false</returns>
        public static bool CheckUserProductFamily(User user, Func<Role, GrantType> func, GrantType grantType, ProductFamily productFamily, bool throwException = false)
        {
            if (null == user)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_FOR_AUTHENTICATION_IS_MISSING);
            }

            var result = user.AccountType == AccountType.SuperUser || (!string.IsNullOrEmpty(user.AdminBusinessGroup) && null != productFamily && user.AdminBusinessGroup == productFamily.Businessgroup) || (null != user.Roles && null != productFamily && user.Roles.Where(c => c.ProductFamilies.Contains(productFamily.Name)).Select(func).Count(c => c >= grantType) > 0);

            if (!result && throwException)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_NOT_AUTHENTICATED_FOR_PRODUCTFAMILY, user.Name, productFamily?.Name);
            }

            return result;
        }

        /// <summary>
        /// Checks an additional grant of the user
        /// </summary>
        /// <param name="user">User</param>
        /// <param name="additionalGrant">Name of the additional grant</param>
        /// <param name="throwException">Throws an exception if user is not authorized</param>
        /// <returns>User authorized true / false</returns>
        public static bool CheckUserAdditionalGrant(User user, AdditionalGrant additionalGrant, bool throwException = false)
        {
            if (null == user)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_FOR_AUTHENTICATION_IS_MISSING);
            }

            var result = user.AccountType == AccountType.SuperUser || user.Roles.Any(c => c.AdditionalGrants.ContainsKey(additionalGrant.ToString()));

            if (!result && throwException)
            {
                throw new ZeissLicensingException(ZeissLicensingError.GENERAL_USER_NOT_AUTHENTICATED, user.Name);
            }

            return result;
        }

        #endregion
    }
}
