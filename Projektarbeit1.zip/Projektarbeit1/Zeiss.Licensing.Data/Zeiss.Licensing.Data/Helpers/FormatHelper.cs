﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Helpers
{
    public static class FormatHelper
    {
        #region Methods

        /// <summary>
        /// Get MaterialNumber in Format 000000-0000-000, if to short fill with leading 0
        /// </summary>
        /// <param name="materialNumber">MaterialNumber</param>
        /// <returns>MaterialNumber in Format 000000-0000-000</returns>
        public static string GetFormattedMaterialnumber(string materialNumber)
        {
            if (materialNumber != null)
            {
                if (materialNumber.Length < 13)
                {
                    materialNumber = materialNumber.PadLeft(13, '0');
                }

                materialNumber = materialNumber.Substring(materialNumber.Length - 13, 13);
                return $"{materialNumber.Substring(0, 6)}-{materialNumber.Substring(6, 4)}-{materialNumber.Substring(10, 3)}";
            }

            return string.Empty;
        }

        /// <summary>
        /// Get MaterialNumber in Format 000000000000000000 (18 numbers), if to short fill with leading 0
        /// </summary>
        /// <param name="materialNumber">MaterialNumber</param>
        /// <returns>MaterialNumber in Format 000000000000000000</returns>
        public static string GetUnFormattedMaterialnumber(string materialNumber)
        {
            if (materialNumber != null)
            {
                materialNumber = materialNumber.Replace("-", "");

                if (materialNumber.Length < 18)
                {
                    materialNumber = materialNumber.PadLeft(18, '0');
                }

                return materialNumber;
            }

            return string.Empty;
        }

        #endregion
    }
}
