﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// License generator return request
    /// </summary>
    public class LicenseGeneratorReturnRequest
    {
        #region Properties

        /// <summary>
        /// Request for FNP trusted storage return
        /// </summary>
        public string FNPTrustedStorageReturnRequest { get; set; }

        #endregion
    }
}
