﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Import product class
    /// </summary>
    public class ImportProduct
    {
        #region Properties

        /// <summary>
        /// Line number
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// List of features
        /// </summary>
        public List<Feature> Features { get; set; }

        /// <summary>
        /// List of material numbers
        /// </summary>
        public List<string> Materialnumbers { get; set; }

        /// <summary>
        /// Set state to completed after create product
        /// </summary>
        public bool CompleteProduct { get; set; }

        /// <summary>
        /// Error
        /// </summary>
        public string Error { get; set; }

        /// <summary>
        /// Warning
        /// </summary>
        public string Warning { get; set; }

        #endregion
    }
}
