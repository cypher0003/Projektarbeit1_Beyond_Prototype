﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Actvation/License response class
    /// </summary>
    public class DeviceLicenseResponse
    {
        #region Properties

        /// <summary>
        /// License key
        /// </summary>
        public string LicenseKey { get; set; }

        /// <summary>
        /// License key
        /// </summary>
        public List<LicenseFileV1> LicenseFiles { get; set; } = new List<LicenseFileV1>();

        /// <summary>
        /// Device friendly name
        /// </summary>
        public string DeviceFriendlyName { get; set; }

        /// <summary>
        /// License file extension
        /// </summary>
        public string LicenseFileExtension { get; set; }

        #endregion
    }
}
