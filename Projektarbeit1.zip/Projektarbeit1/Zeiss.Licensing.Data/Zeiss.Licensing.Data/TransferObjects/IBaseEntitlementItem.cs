﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class EntitlementItem
    {
        #region Constructors

        public EntitlementItem()
        {
            Fulfillments = new List<Fulfillment>();
        }

        #endregion

        #region Properties

        public string ActivationId { get; set; }

        public State State { get; set; }

        public string MaterialNumber { get; set; }

        public string MaterialName { get; set; }

        public string MaterialVersion { get; set; }

        public int Quantity { get; set; }

        public OrderType OrderType { get; set; }

        public int? Duration { get; set; }

        public string SapOrderId { get; set; }

        public string SapOrderItemId { get; set; }

        public BusinessUnit? BusinessUnit { get; set; }

        public string IbaseMaterialNumber { get; set; }

        public string IbaseSerialNumber { get; set; }

        public List<Fulfillment> Fulfillments { get; set; }

        public DateTime? LastModificationDate { get; set; }

        #endregion
    }
}
