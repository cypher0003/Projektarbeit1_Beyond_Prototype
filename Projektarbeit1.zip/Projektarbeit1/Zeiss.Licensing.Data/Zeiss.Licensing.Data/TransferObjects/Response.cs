﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Generic response class
    /// </summary>
    public class Response<TZeissModel> : Response
    {
        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public Response()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="error">Error</param>
        public Response(Error error) : base(error)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="exception">Exception</param>
        public Response(Exception exception) : base(exception)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="data">Data</param>
        public Response(TZeissModel data)
        {
            Data = data;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Data
        /// </summary>
        public TZeissModel Data { get; set; }

        /// <summary>
        /// Data type of Data property
        /// </summary>
        public string DataType => typeof(TZeissModel).ToString();

        #endregion
    }


    /// <summary>
    /// Response class
    /// </summary>
    public class Response
    {
        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public Response()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="error">Error</param>
        public Response(Error error)
        {
            Error = error;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="exception">Exception</param>
        public Response(Exception exception)
        {
            Error = new Error(exception);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Inner error
        /// </summary>
        public Error Error { get; set; }

        #endregion
    }
}
