﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Report response class
    /// </summary>
    public class ReportResponse
    {
        #region Properties

        /// <summary>
        /// Report format type
        /// </summary>
        public ReportFormatType ReportFormatType { get; set; } = ReportFormatType.Html;

        /// <summary>
        /// Report
        /// </summary>
        public string Report { get; set; } = string.Empty;

        /// <summary>
        /// Entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Product key ids
        /// </summary>
        public List<string> ProductKeyIds { get; set; } = new List<string>();

        #endregion
    }
}
