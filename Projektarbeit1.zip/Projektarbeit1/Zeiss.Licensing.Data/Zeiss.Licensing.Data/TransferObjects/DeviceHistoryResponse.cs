﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Linq;
using Zeiss.Licensing.Data.Collections;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class DeviceHistoryResponse
    {
        #region Properties

        public PartialList<DeviceHistory> DeviceHistory { get; set; } = new PartialList<DeviceHistory>();

        public DateTime? LicenseGenerationDateTime
        {
            get
            {
                DateTime? ret = null;

                if (null != DeviceHistory && DeviceHistory.List.Count > 0)
                {
                    ret = DeviceHistory.List.Where(c => c.Action == "LicenseGenerated").OrderBy(c => c.CreationDate).LastOrDefault()?.CreationDate;
                }

                return ret;
            }
        }

        #endregion
    }
}
