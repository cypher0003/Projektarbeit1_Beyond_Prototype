﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class Fulfillment
    {
        #region Properties

        public string FulfillmentID { get; set; }

        public LicenseType? LicenseType { get; set; }

        public string HostId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public string DublinInstrumentSerialNumber { get; set; }

        public string DublinSecurityCode { get; set; }

        public string DublinLicenseKey { get; set; }

        public string DublinNodeId { get; set; }

        public string DublinInstallationType { get; set; }

        public string DublinFeature { get; set; }

        public string SupportType { get; set; }

        public string Count { get; set; }

        #endregion
    }
}
