﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Information for UpgradeRequest which contains a custom value (dongle name)
    /// and if the value should be used for activation
    /// </summary>
    public class UpgradeRequestCustom
    {
        #region Properties

        /// <summary>
        /// Custom value (dongle name) which is used to find existing activations
        /// and possibly used for new activation
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Custom value should be used for new activation
        /// </summary>
        public bool UseForActivation { get; set; }

        #endregion
    }
}
