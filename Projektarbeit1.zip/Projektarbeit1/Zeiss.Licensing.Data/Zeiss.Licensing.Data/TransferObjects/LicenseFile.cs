﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class LicenseFileV2 : LicenseFile
    {
        #region Properties

        /// <summary>
        /// License file details (entitlement id, product key id and activation id)
        /// </summary>
        public List<LicenseFileDetails> Items { get; set; } = new List<LicenseFileDetails>();

        #endregion
    }

    public class LicenseFileV1 : LicenseFile
    {
        #region Properties

        /// <summary>
        /// EntitlementId of activation
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// ProductKeyId of the activation
        /// </summary>
        public string ProductKeyID { get; set; }

        /// <summary>
        /// ActivationId of activation
        /// </summary>
        public string ActivationId { get; set; }

        #endregion
    }

    public abstract class LicenseFile
    {
        #region Properties

        /// <summary>
        /// DeviceId of activation
        /// </summary>
        public string DeviceId { get; set; }

        /// <summary>
        /// File extension defined by license type.
        /// lic  -> Certificate
        /// xml  -> TrustedStorage
        /// zlic -> thales
        /// vis  -> Visumax
        /// dub  -> DublinLegacy
        /// bin  -> embedded
        /// </summary>
        public string Extension { get; set; }

        /// <summary>
        /// The generated license String
        /// </summary>
        public string LicenseString { get; set; }

        /// <summary>
        /// The name of the file.
        /// </summary>
        public string FileName { get; set; }

        #endregion
    }
}
