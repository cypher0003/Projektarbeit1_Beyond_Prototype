﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Xml.Serialization;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Represents the State of Operations
    /// </summary>
    public class Status
    {
        #region Constructors

        /// <summary>
        /// Parameterless constructor.
        /// </summary>
        public Status() : this(true, null, null)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="success">Was it successfull?</param>
        /// <param name="message">If not what message Operations gives.</param>
        /// <param name="flexnetErrorCode">Was an error code setted?</param>
        public Status(bool success, string message, string flexnetErrorCode)
        {
            Success = success;
            Message = message;
            FlexnetErrorCode = flexnetErrorCode;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Was it successfull?
        /// </summary>
        [XmlElement("success")] // Do not change! This affects XI/PI interface.
        public bool Success { get; set; }

        /// <summary>
        /// If it wasn't successful, what message Operations gives.
        /// </summary>
        [XmlElement("message")] // Do not change! This affects XI/PI interface.
        public string Message { get; set; }

        /// <summary>
        /// The error code if any.
        /// </summary>
        [XmlElement("flexnetErrorCode")] // Do not change! This affects XI/PI interface.
        public string FlexnetErrorCode { get; set; }

        #endregion
    }
}
