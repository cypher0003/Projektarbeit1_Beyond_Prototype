﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class ZuoraRatePlanCharge
    {
        #region Properties

        /// <summary>
        /// Product rate plan charge id
        /// </summary>
        public string ProductRatePlanChargeId { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// Send a mail to the customer 
        /// </summary>
        public bool SendEmailToCustomer { get; set; }

        #endregion
    }
}
