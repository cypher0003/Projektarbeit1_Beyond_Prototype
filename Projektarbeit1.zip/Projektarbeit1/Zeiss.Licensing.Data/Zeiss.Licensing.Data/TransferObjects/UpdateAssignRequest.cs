﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Update assign transfer object
    /// </summary>
    public class UpdateAssignRequest
    {
        #region Properties

        /// <summary>
        /// The product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// The friendly name
        /// </summary>
        public string FriendlyName { get; set; }

        /// <summary>
        /// Marked for deassign
        /// </summary>
        public bool MarkedForDeassign { get; set; }

        #endregion
    }
}
