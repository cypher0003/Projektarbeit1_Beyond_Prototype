﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class EsbCustomerEntitlementProductKey
    {
        #region Properties

        public string ProductKey { get; set; }

        public string ProductName { get; set; }

        public string ProductVersion { get; set; }

        public string ProductVariantName { get; set; }

        public string ProductVariantVersion { get; set; }

        public string MaterialNumber { get; set; }

        public string State { get; set; }

        public string OrderId { get; set; }

        public string OrderItemId { get; set; }

        public int Quantity { get; set; }

        public int AvailableQuantity { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public int? Duration { get; set; }

        public string SerialNumber { get; set; }

        #endregion
    }
}
