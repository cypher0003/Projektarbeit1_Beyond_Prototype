﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Upgrade response class
    /// </summary>
    public class UpgradeResponse : UpgradeResponseBase
    {
        #region Properties

        /// <summary>
        /// ActivationResponses for new product keys
        /// </summary>
        public List<ActivationResponseV2> ItemIds { get; set; } = new List<ActivationResponseV2>();

        #endregion
    }
}
