﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects.V2
{
    /// <summary>
    /// Activatable item
    /// </summary>
    public class ActivatableItem
    {
        #region Nested types

        /// <summary>
        /// License binding options
        /// </summary>
        public enum LicenseBinding
        {
            NotSupported,
            Fingerprint,
            TrustedStorage,
            Custom,
            Lease
        }

        /// <summary>
        /// Upgrade state
        /// </summary>
        public enum UpgradeState
        {
            None,
            Rms
        }

        #endregion

        #region Properties

        /// <summary>
        /// Product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// Entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// Available quantity
        /// </summary>
        public int AvailableQuantity { get; set; }

        /// <summary>
        /// Allow multiple activation
        /// </summary>
        public bool AllowMultipleActivation { get; set; }

        /// <summary>
        /// Is floating license model
        /// </summary>
        public bool IsFloating { get; set; }

        /// <summary>
        /// License mode
        /// </summary>
        public string LicenseMode { get; set; } = Enums.LicenseMode.Undefined.ToString();

        public List<string> LicenseBindings { get; set; } = new List<string>();

        /// <summary>
        /// RegEx expression for validation 
        /// </summary>
        public string CustomRegEx { get; set; }

        /// <summary>
        /// Upgrade state
        /// </summary>
        public string Upgrade { get; set; } = UpgradeState.None.ToString();

        #endregion
    }
}
