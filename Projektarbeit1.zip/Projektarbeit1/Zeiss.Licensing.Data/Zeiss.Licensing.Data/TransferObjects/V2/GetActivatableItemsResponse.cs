﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects.V2
{
    /// <summary>
    /// Get activatable item response
    /// </summary>
    public class GetActivatableItemsResponse
    {
        #region Properties

        /// <summary>
        /// Activatable items
        /// </summary>
        public List<ActivatableItem> ActivatableItems { get; set; } = new List<ActivatableItem>();

        /// <summary>
        /// Invalid activatable items
        /// </summary>
        public List<InvalidItem> InvalidActivatableItems { get; set; } = new List<InvalidItem>();

        #endregion
    }
}
