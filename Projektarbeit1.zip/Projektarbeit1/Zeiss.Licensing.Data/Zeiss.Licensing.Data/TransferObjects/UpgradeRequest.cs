﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Upgrade request class
    /// </summary>
    public class UpgradeRequest
    {
        #region Properties

        /// <summary>
        /// Device name
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// FNP Trusted Storage request
        /// </summary>
        public string FnpTrustedStorageRequest { get; set; }

        /// <summary>
        /// Fingerprint for the license
        /// </summary>
        public string FingerPrint { get; set; }

        /// <summary>
        /// Items to activate/upgrade
        /// </summary>
        public List<string> ItemIds { get; set; } = new List<string>();

        /// <summary>
        /// Custom values (dongle names) which are used to find existing activations
        /// Also contains information if and which custom value should be used for new activation
        /// </summary>
        public List<UpgradeRequestCustom> Customs { get; set; } = new List<UpgradeRequestCustom>();

        #endregion
    }
}
