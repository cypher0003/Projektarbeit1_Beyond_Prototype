﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    ///
    /// </summary>
    public class InstallbaseRequest
    {
        #region Properties

        /// <summary>
        ///
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        ///
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// BusinessUnit (MIC | IMT | MED)
        /// </summary>
        public string BusinessUnit { get; set; }

        #endregion
    }
}
