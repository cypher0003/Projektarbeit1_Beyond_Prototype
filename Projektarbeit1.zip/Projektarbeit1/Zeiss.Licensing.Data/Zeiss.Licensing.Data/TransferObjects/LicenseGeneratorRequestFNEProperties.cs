﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// License generator request FNE properties
    /// </summary>
    public class LicenseGeneratorRequestFNEProperties
    {
        #region Properties

        /// <summary>
        /// Activation
        /// </summary>
        public Activation Activation { get; set; }

        public List<Feature> Features { get; set; } = new List<Feature>();

        #endregion
    }
}
