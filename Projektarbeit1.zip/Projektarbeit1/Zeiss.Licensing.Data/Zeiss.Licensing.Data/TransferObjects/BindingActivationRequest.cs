﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Activation request for licenses which are bound to either a PC, a dongle or any other device
    /// </summary>
    public class BindingActivationRequest
    {
        #region Properties

        /// <summary>
        /// Name of the PC, dongle or device
        /// </summary>
        public string DeviceName { get; set; } = string.Empty;

        /// <summary>
        /// Item ids (entitlement or product key id) which should be activated and the quantity that should be activated
        /// </summary>
        public Dictionary<string, int> ItemIds { get; set; } = new Dictionary<string, int>();

        /// <summary>
        /// Fingerprint of the PC
        /// </summary>
        public string Fingerprint { get; set; } = string.Empty;

        /// <summary>
        /// Flexera trusted storage activation request
        /// </summary>
        public string TrustedStorageActivationRequest { get; set; } = string.Empty;

        /// <summary>
        /// Value to generate a lock code from custom criteria
        /// </summary>
        public string CustomValue { get; set; } = string.Empty;

        #endregion
    }
}
