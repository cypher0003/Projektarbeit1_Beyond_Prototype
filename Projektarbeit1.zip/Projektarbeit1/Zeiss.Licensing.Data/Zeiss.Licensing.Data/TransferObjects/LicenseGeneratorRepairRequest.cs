﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// License generator repair request
    /// </summary>
    public class LicenseGeneratorRepairRequest
    {
        #region Properties

        /// <summary>
        /// Request for FNP trusted storage repair
        /// </summary>
        public string FNPTrustedStorageRepairRequest { get; set; }

        #endregion
    }
}
