﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Activation request class
    /// </summary>
    public class ActivationRequest
    {
        #region Properties

        /// <summary>
        /// Item ids
        /// </summary>
        public Dictionary<string, int> ItemIdsWithQuantity { get; set; } = new Dictionary<string, int>();

        /// <summary>
        /// Item ids
        /// </summary>
        [Obsolete("Use 'ItemIdsWithQuantity' instead.")]
        public List<string> ItemIds { get; set; } = new List<string>();

        /// <summary>
        /// Lock code
        /// </summary>
        public string LockCode { get; set; }

        /// <summary>
        /// Lock criterion
        /// </summary>
        public string LockCriterion { get; set; }

        /// <summary>
        /// License FingerPrint
        /// </summary>
        public string FingerPrint { get; set; }

        /// <summary>
        /// Device name
        /// Use logic to decide if update ot create
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// Device ID
        /// If set update this Device and do not create a new one.
        /// </summary>
        public string DeviceId { get; set; }

        /// <summary>
        /// Device type name
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Activation quantity
        /// </summary>
        [Obsolete("Use 'ItemIdsWithQuantity' instead.")]
        public int ActivationQuantity { get; set; } = 1;

        /// <summary>
        /// Xml request for FNP trusted storage activation
        /// </summary>
        [JsonPropertyName("FNPTrustedStorageRequest")]
        public string FNPTrustedStorageRequest { get; set; }

        /// <summary>
        /// DublinLegacy activation
        /// </summary>
        public ActivationPropertiesDublinLegacy DublinLegacyActivation { get; set; }

        #endregion
    }
}
