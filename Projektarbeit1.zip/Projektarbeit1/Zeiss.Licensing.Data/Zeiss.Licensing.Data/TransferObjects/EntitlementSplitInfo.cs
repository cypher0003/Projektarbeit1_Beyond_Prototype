﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Entitlement split info transfer object
    /// </summary>
    public class EntitlementSplitInfo
    {
        #region Properties

        /// <summary>
        /// The organization number of entitlement split receiver
        /// </summary>
        public string ReceiverOrganizationNumber { get; set; }

        /// <summary>
        /// The organization tier of entitlement split receiver
        /// </summary>
        public OrganizationTier ReceiverOrganizationTier { get; set; }

        /// <summary>
        /// Flag, if the split will create one or for each product key and quantity a new entitlement
        /// </summary>
        public bool SeparateEntitlements { get; set; }

        /// <summary>
        /// The entitlement split info items
        /// </summary>
        public List<EntitlementSplitInfoItem> Items { get; set; }

        #endregion
    }
}
