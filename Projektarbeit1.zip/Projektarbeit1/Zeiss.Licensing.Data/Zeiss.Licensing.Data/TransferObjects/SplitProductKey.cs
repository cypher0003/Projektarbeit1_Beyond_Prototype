﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Data of the original entitlement / product key ( original entitlement id, product key, product partner set) and the new
    /// data of the created entitlements of the splitting process
    /// </summary>
    public class SplitProductKey
    {
        #region Properties

        public string OriginalEntitlementId { get; set; } = string.Empty;

        public string OriginalProductKeyId { get; set; } = string.Empty;

        public string ProductName { get; set; } = string.Empty;

        public string ProductVersion { get; set; } = string.Empty;

        public string FactoryNumber { get; set; } = string.Empty;

        public string FactoryName { get; set; } = string.Empty;

        public string DistributorNumber { get; set; } = string.Empty;

        public string DistributorName { get; set; } = string.Empty;

        public string Ssc1Number { get; set; } = string.Empty;

        public string Ssc1Name { get; set; } = string.Empty;

        public string Ssc2Number { get; set; } = string.Empty;

        public string Ssc2Name { get; set; } = string.Empty;

        public string EndCustomerNumber { get; set; } = string.Empty;

        public string EndCustomerName { get; set; } = string.Empty;

        public List<NewEntitlementProductKeyInfo> EntitlementProductKeyInfos { get; set; } = new List<NewEntitlementProductKeyInfo>();

        #endregion
    }
}
