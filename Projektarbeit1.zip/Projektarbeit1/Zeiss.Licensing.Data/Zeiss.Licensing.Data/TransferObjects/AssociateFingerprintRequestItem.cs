﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class AssociateFingerprintRequestItem
    {
        #region Properties

        /// <summary>
        /// The items (product keys ids) the fingerprint should be associated with.
        /// </summary>
        public List<string> ItemIds { get; set; } = new List<string>();

        /// <summary>
        /// The XML generated from Sentinel.RMS.net.core.Wrapper.Services.UnifiedRMSService.GetFingerPrint() as a string
        /// </summary>
        public string Fingerprint { get; set; } = string.Empty;

        /// <summary>
        /// The fingerprint friendly name also used as deviceID
        /// </summary>
        public string FriendlyName { get; set; } = string.Empty;

        /// <summary>
        /// If the fingerprint is already assigned to a customer this property
        /// contains the organization number.
        /// Otherwise, it is an empty string.
        /// </summary>
        public string Customer { get; set; } = string.Empty;

        #endregion
    }
}
