﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Rehost request
    /// </summary>
    public class RehostRequest
    {
        #region Properties

        /// <summary>
        /// The actual device id
        /// </summary>
        public string ActualDeviceId { get; set; }

        /// <summary>
        /// The new device id
        /// </summary>
        public string NewDeviceId { get; set; }

        /// <summary>
        /// List of product key ids to be rehosted
        /// </summary>
        public List<string> ProductKeyIds { get; set; }

        #endregion
    }
}
