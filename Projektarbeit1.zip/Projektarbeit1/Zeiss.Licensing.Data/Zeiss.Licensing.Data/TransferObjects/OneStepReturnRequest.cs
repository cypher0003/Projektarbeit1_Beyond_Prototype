﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// One-Step return request transfer object
    /// </summary>
    public class OneStepReturnRequest
    {
        #region Properties

        /// <summary>
        /// Product Key which should be revoked
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// Activation id which should be revoked
        /// </summary>
        public string ActivationId { get; set; }

        /// <summary>
        /// Status of the activation on the client
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// List with all features of the activation (name:version)
        /// </summary>
        public List<RefFeature> Features { get; set; } = new List<RefFeature>();

        /// <summary>
        /// Revocation time stamp
        /// </summary>
        public DateTime RevocationDateTime { get; set; }

        /// <summary>
        /// Lock code
        /// </summary>
        public string LockCode { get; set; }

        /// <summary>
        /// Lock criterion
        /// </summary>
        public string LockCriterion { get; set; }

        #endregion
    }
}
