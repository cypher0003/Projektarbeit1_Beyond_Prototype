﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Assign info transfer object
    /// </summary>
    public class AssignInformation
    {
        #region Properties

        /// <summary>
        /// The subscription name
        /// </summary>
        public string SubscriptionName { get; set; }

        /// <summary>
        /// List of entitlements
        /// </summary>
        public List<AssignInformationEntitlement> Entitlements { get; set; }

        #endregion
    }

    /// <summary>
    /// Assign info entitlement transfer object
    /// </summary>
    public class AssignInformationEntitlement
    {
        #region Properties

        /// <summary>
        /// The entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// The rate plan name
        /// </summary>
        public string RatePlanName { get; set; }

        /// <summary>
        /// The list of product keys
        /// </summary>
        public List<AssignInformationProductKey> ProductKeys { get; set; }

        #endregion
    }

    /// <summary>
    /// Assign info product key transfer object
    /// </summary>
    public class AssignInformationProductKey
    {
        #region Properties

        /// <summary>
        /// The product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// The product rate plan charge id
        /// </summary>
        public string ProductRatePlanChargeId { get; set; }

        /// <summary>
        /// The quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// The list of assigned devices
        /// </summary>
        public List<AssignInformationDevice> AssignedDevices { get; set; }

        #endregion
    }

    /// <summary>
    /// Assign information device transfer object
    /// </summary>
    public class AssignInformationDevice
    {
        #region Properties

        /// <summary>
        /// The friendly name
        /// </summary>
        public string FriendlyName { get; set; }

        /// <summary>
        /// Whether it's marked for deassign
        /// </summary>
        public bool MarkedForDeassign { get; set; }

        #endregion
    }
}
