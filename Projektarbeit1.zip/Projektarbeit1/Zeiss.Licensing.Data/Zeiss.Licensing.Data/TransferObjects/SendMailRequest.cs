﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class SendMailRequest
    {
        #region Properties

        /// <summary>
        /// The mail subject
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// The email body (HTML)
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// List of email addresses for recipients
        /// </summary>
        public List<string> Recipients { get; set; }

        /// <summary>
        /// List of email addresses for cc recipients
        /// </summary>
        public List<string> RecipientsCc { get; set; }

        /// <summary>
        /// From email address
        /// </summary>
        public string From { get; set; }

        /// <summary>
        /// Sender
        /// </summary>
        public string Sender { get; set; }

        /// <summary>
        /// Reply to email address
        /// </summary>
        public string ReplyTo { get; set; }

        /// <summary>
        /// List of attachments (Base-64 encoded)
        /// </summary>
        public List<string> Attachments { get; set; }

        #endregion
    }
}
