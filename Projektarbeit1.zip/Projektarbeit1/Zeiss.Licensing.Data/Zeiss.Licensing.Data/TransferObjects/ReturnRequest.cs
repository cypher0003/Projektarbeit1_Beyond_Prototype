﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Return request class
    /// </summary>
    public class ReturnRequest
    {
        #region Properties

        /// <summary>
        /// Item ids
        /// </summary>
        public List<string> ItemIds { get; set; }

        /// <summary>
        /// Xml request for FNP trusted storage return
        /// </summary>
        public string FNPTrustedStorageReturnRequest { get; set; }

        #endregion
    }
}
