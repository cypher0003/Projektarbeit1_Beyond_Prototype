﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects.V1
{
    /// <summary>
    /// Activatable item
    /// </summary>
    public class ActivatableItem
    {
        #region Properties

        /// <summary>
        /// Product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// Entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// Available quantity
        /// </summary>
        public int AvailableQuantity { get; set; }

        /// <summary>
        /// Locking mode
        /// </summary>
        public string LockingMode { get; set; }

        /// <summary>
        /// Allow multiple activation
        /// </summary>
        public bool AllowMultipleActivation { get; set; }

        /// <summary>
        /// Is floating license model
        /// </summary>
        public bool IsFloating { get; set; }

        /// <summary>
        /// License mode
        /// </summary>
        public string LicenseMode { get; set; } = Enums.LicenseMode.Undefined.ToString();

        /// <summary>
        /// Device type name which is assigned to the product variant of the product key
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// Is Upgrade item
        /// </summary>
        public bool IsUpgrade { get; set; }

        #endregion
    }
}
