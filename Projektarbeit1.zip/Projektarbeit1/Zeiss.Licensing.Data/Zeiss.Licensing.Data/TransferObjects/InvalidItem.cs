﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Invalid item
    /// </summary>
    public class InvalidItem
    {
        #region Properties

        /// <summary>
        /// Item id
        /// </summary>
        public string ItemId { get; set; }

        /// <summary>
        /// Reason
        /// </summary>
        public string Reason { get; set; }

        #endregion
    }
}
