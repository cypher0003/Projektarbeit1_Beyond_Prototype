﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Zeiss.Licensing.Data.TransferObjects
{
    [Serializable]

    //[SoapType(TypeName = "Entitlement")]
    //[XmlType(TypeName ="Entitlement")]
    [XmlRoot(ElementName = "Entitlement")]
    public class SOAPEntitlement
    {
        #region Properties

        public string entitlementID { get; set; }

        public string soldToId { get; set; }

        public string soldToName { get; set; }

        public List<EntitlementItem> entitlementItems { get; set; }

        #endregion
    }
}
