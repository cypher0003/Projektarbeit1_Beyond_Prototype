﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class ActivationResponseV2
    {
        #region Properties

        /// <summary>
        /// A list of licensesFiles.
        /// </summary>
        public List<LicenseFileV2> Licenses { get; set; } = new List<LicenseFileV2>();

        /// <summary>
        /// Invalid items
        /// </summary>
        public List<InvalidItem> InvalidItems { get; set; } = new List<InvalidItem>();

        #endregion
    }

    public class ActivationResponseV1
    {
        #region Properties

        /// <summary>
        /// A list of licensesFiles.
        /// </summary>
        public List<LicenseFileV1> Licenses { get; set; } = new List<LicenseFileV1>();

        /// <summary>
        /// Invalid item ids
        /// </summary>
        public List<string> InvalidItemIds { get; set; } = new List<string>();

        #endregion
    }

    [Obsolete("Use ActivationResponseV1 instead")]
    public class ActivationRespone
    {
        #region Properties

        /// <summary>
        /// Thales License text
        /// </summary>
        [Obsolete("String license is deprecated. The thales licenses are integrated into the List<LicenseFile> Licenses property.")]
        public string license
        {
            get
            {
                var licenseKeys = Licenses.Where(c => c.Extension == "zlic").Select(c => c.LicenseString).ToList();

                var agregatedLicenseString = string.Join("\n", licenseKeys);

                return agregatedLicenseString;
            }
        }

        /// <summary>
        /// A list of licensesFiles.
        /// </summary>
        public List<LicenseFileV1> Licenses { get; set; } = new List<LicenseFileV1>();

        /// <summary>
        /// Invalid item ids
        /// </summary>
        public List<string> InvalidItemIds { get; set; } = new List<string>();

        #endregion
    }
}
