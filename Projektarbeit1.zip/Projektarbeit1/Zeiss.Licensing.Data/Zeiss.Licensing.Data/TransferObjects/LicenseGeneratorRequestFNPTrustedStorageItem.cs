﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// License generator request item for FNP Trusted Storage
    /// </summary>
    public class LicenseGeneratorRequestFNPTrustedStorageItem
    {
        #region Properties

        /// <summary>
        /// The entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// The activation id
        /// </summary>
        public string ActivationId { get; set; }

        /// <summary>
        /// The product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// The material number
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// The product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// The product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// The total quantity
        /// </summary>
        public int TotalQuantity { get; set; }

        /// <summary>
        /// The duration in days
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// Start date
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// The license model
        /// </summary>
        public string LicenseModel { get; set; }

        #endregion
    }
}
