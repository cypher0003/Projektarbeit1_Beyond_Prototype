﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Infos of new created entitlement and product key at the splitting process
    /// </summary>
    public class NewEntitlementProductKeyInfo
    {
        #region Properties

        public string NewEntitlementId { get; set; } = string.Empty;

        public string NewProductKeyId { get; set; } = string.Empty;

        #endregion
    }
}
