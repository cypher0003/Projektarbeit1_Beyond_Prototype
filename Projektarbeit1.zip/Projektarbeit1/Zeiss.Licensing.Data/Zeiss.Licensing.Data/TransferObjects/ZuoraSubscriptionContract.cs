﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class ZuoraSubscriptionContract
    {
        #region Properties

        /// <summary>
        /// Get / set the sales organization
        /// </summary>
        public string SalesOrganization { get; set; }

        /// <summary>
        /// Sold to id
        /// </summary>
        public string SoldToId { get; set; }

        /// <summary>
        /// Sold to name
        /// </summary>
        public string SoldToName { get; set; }

        /// <summary>
        /// Get / set the ship to id
        /// </summary>
        public string ShipToId { get; set; }

        /// <summary>
        /// Get / set the ship to name
        /// </summary>
        public string ShipToName { get; set; }

        /// <summary>
        /// Get / set the end customer id
        /// </summary>
        public string EndCustomerId { get; set; }

        /// <summary>
        /// Get / set the end customer name
        /// </summary>
        public string EndCustomerName { get; set; }

        /// <summary>
        /// Get / set the sales representative id
        /// </summary>
        public string SalesRepId { get; set; }

        /// <summary>
        /// Get / set the sales representative name
        /// </summary>
        public string SalesRepName { get; set; }

        /// <summary>
        /// Get / set the sales man id
        /// </summary>
        public string SalesManId { get; set; }

        /// <summary>
        /// Get / set the sales man name
        /// </summary>
        public string SalesManName { get; set; }

        /// <summary>
        /// Start date
        /// </summary>
        public string StartDate { get; set; }

        /// <summary>
        /// End date
        /// </summary>
        public string EndDate { get; set; }

        /// <summary>
        /// Subscription name
        /// </summary>
        public string SubscriptionName { get; set; }

        /// <summary>
        /// Recipient first name
        /// </summary>
        public string LicenseRecipientFirstName { get; set; }

        /// <summary>
        /// Recipient last name
        /// </summary>
        public string LicenseRecipientLastName { get; set; }

        /// <summary>
        /// Recipient E-Mail
        /// </summary>
        public string LicenseRecipientEmail { get; set; }

        /// <summary>
        /// Language
        /// </summary>
        public string Language { get; set; }

        /// <summary>
        /// Rate plans
        /// </summary>
        public List<ZuoraRatePlan> RatePlans { get; set; }

        #endregion
    }
}
