﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Request to create a lock code for either a custom value (e.g. a dongle) or a pc fingerprint
    /// </summary>
    public class LockCodeRequest
    {
        #region Properties

        /// <summary>
        /// Custom value (e.g. dongle name)
        /// </summary>
        public string CustomValue { get; set; } = string.Empty;

        /// <summary>
        /// Fingerprint of a pc (xml format)
        /// </summary>
        public string Fingerprint { get; set; } = string.Empty;

        /// <summary>
        /// Lock selector who defines which criteria of the fingerprint should be used to create a lock code
        /// </summary>
        public int LockSelector { get; set; }

        #endregion
    }
}
