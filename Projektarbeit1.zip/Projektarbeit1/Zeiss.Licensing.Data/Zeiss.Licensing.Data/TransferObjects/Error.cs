﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Exceptions;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Error information classes
    /// </summary>
    public class Error
    {
        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public Error()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="exception">Exception</param>
        public Error(Exception exception)
        {
            Message = exception.Message;
            DebugMessage = exception.Message + exception.StackTrace;

            if (exception is ZeissLicensingException)
            {
                Code = ((ZeissLicensingException)exception).ErrorCode;
            }

            if (null != exception.InnerException)
            {
                InnerError = new Error(exception.InnerException);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Error code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Error message 
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Error debug message 
        /// </summary>
        public string DebugMessage { get; set; }

        /// <summary>
        /// Inner error
        /// </summary>
        public Error InnerError { get; set; }

        #endregion
    }
}
