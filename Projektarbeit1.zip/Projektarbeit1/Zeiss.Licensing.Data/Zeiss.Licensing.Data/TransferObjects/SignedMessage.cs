﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Object with serialized and signed data string
    /// </summary>
    public class SignedMessage
    {
        #region Properties

        /// <summary>
        /// Type of the serialized data
        /// </summary>
        public string DataType { get; set; }

        /// <summary>
        /// Serialized data
        /// </summary>
        public string Data { get; set; }

        /// <summary>
        /// Version of the signature
        /// </summary>
        public string SignatureVersion { get; set; }

        /// <summary>
        /// Signature
        /// </summary>
        public byte[] Signature { get; set; }

        #endregion
    }
}
