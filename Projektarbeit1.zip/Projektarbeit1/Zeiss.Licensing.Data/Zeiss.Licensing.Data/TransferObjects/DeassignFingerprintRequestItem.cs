﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class DeassignFingerprintRequestItem
    {
        #region Properties

        /// <summary>
        /// The items (ProductKeys) the Fingerprint should be removed from.
        /// </summary>
        public List<string> ItemIds { get; set; }

        /// <summary>
        /// The fingerprint friendly name also used as deviceID
        /// </summary>
        public string FriendlyName { get; set; }

        #endregion
    }
}
