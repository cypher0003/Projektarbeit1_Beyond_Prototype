﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class LicenseFileDetails
    {
        #region Properties

        /// <summary>
        /// EntitlementId of activation
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// ProductKeyId of the activation
        /// </summary>
        public string ProductKeyId { get; set; }

        /// <summary>
        /// ActivationId of activation
        /// </summary>
        public string ActivationId { get; set; }

        /// <summary>
        /// Product name of activation
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product version of activation
        /// </summary>
        public string ProductVersion { get; set; }

        #endregion
    }
}
