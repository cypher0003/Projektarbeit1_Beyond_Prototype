﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class EsbCustomerEntitlement
    {
        #region Properties

        public string EntitlementId { get; set; }

        public string FactoryName { get; set; }

        public string FactoryNumber { get; set; }

        public string DistributorName { get; set; }

        public string DistributorNumber { get; set; }

        public string SSC1Name { get; set; }

        public string SSC1Number { get; set; }

        public string SSC2Name { get; set; }

        public string SSC2Number { get; set; }

        public string EndCustomerName { get; set; }

        public string EndCustomerNumber { get; set; }

        public string State { get; set; }

        public List<EsbCustomerEntitlementProductKey> ProductKeys { get; set; } = new List<EsbCustomerEntitlementProductKey>();

        #endregion
    }
}
