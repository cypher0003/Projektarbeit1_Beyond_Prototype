﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class AuthZSubscriptionProductKey
    {
        #region Properties

        public string ProductKey { get; set; } = string.Empty;

        public string ProductName { get; set; } = string.Empty;

        public string ProductVersion { get; set; } = string.Empty;

        public string MaterialNumber { get; set; } = string.Empty;

        public int Quantity { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public string Status { get; set; } = string.Empty;

        public List<string> NamedUsers { get; set; } = new List<string>();

        public bool LimitNamedUserAssignment { get; set; }

        #endregion
    }
}
