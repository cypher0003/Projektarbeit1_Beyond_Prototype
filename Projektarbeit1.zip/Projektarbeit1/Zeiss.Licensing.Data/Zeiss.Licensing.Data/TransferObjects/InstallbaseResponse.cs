﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    ///
    /// </summary>
    [Serializable]
    public class InstallbaseResponse
    {
        #region Constructors

        /// <summary>
        ///
        /// </summary>
        /// <param name="status"></param>
        /// <param name="entitlements"></param>
        public InstallbaseResponse(Status status, List<SOAPEntitlement> entitlements)
        {
            Status = status;
            Entitlements = entitlements;
        }

        /// <summary>
        ///
        /// </summary>
        public InstallbaseResponse() : this(new Status(), new List<SOAPEntitlement>())
        {
        }

        #endregion

        #region Properties

        /// <summary>
        ///
        /// </summary>
        public Status Status { get; set; }

        [XmlArray("Entitlements")]
        [XmlArrayItem(typeof(SOAPEntitlement), ElementName = "Entitlement")]

        /// <summary>
        ///
        /// </summary>
        public List<SOAPEntitlement> Entitlements { get; set; }

        #endregion
    }
}
