﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Request for visumax license generator
    /// </summary>
    public class LicenseGeneratorRequestVisumax
    {
        #region Properties

        /// <summary>
        /// Feature name
        /// </summary>
        public string FeatureName { get; set; }

        /// <summary>
        /// Count
        /// </summary>
        public string Count { get; set; }

        /// <summary>
        /// Device name
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// Device type
        /// </summary>
        public string DeviceType { get; set; }

        #endregion
    }
}
