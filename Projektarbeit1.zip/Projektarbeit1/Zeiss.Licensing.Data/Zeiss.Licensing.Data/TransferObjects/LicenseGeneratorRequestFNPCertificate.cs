﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// License generator request for FNP Certificate
    /// </summary>
    public class LicenseGeneratorRequestFNPCertificate
    {
        #region Properties

        /// <summary>
        /// The activation id
        /// </summary>
        public string ActivationId { get; set; }

        /// <summary>
        /// The product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// The entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// The product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// The product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// The order id
        /// </summary>
        public string OrderId { get; set; }

        /// <summary>
        /// The order item id
        /// </summary>
        public string OrderItemId { get; set; }

        /// <summary>
        /// The device friendly name
        /// </summary>
        public string DeviceFriendlyName { get; set; }

        /// <summary>
        /// The material number
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// The license model
        /// </summary>
        public string LicenseModel { get; set; }

        /// <summary>
        /// The creation date of the activation
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// The fixed quantity
        /// </summary>
        public int FixedQuantity { get; set; }

        /// <summary>
        /// The activation quantity
        /// </summary>
        public int ActivationQuantity { get; set; }

        /// <summary>
        /// The FNP Certificate properties
        /// </summary>
        public LicenseModelPropertiesFNPCertificate FNPCertificateProperties { get; set; }

        /// <summary>
        /// The features
        /// </summary>
        public List<LicenseGeneratorRequestFNPCertificateFeature> Features { get; set; } = new List<LicenseGeneratorRequestFNPCertificateFeature>();

        #endregion
    }

    /// <summary>
    /// License generator request FNP Certificate feature model
    /// </summary>
    public class LicenseGeneratorRequestFNPCertificateFeature
    {
        #region Properties

        /// <summary>
        /// The feature name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The feature version
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Count of the feature
        /// </summary>
        public int Count { get; set; }

        #endregion
    }
}
