﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace Zeiss.Licensing.Data.TransferObjects.Legacy
{
    public class ActivatableItem
    {
        #region Properties

        [DataMember(Name = "orderPosition")]
        [JsonPropertyName("orderPosition")]
        public string OrderPosition { get; set; }

        [DataMember(Name = "activationId")]
        [JsonPropertyName("activationId")]
        public string ActivationId { get; set; }

        [DataMember(Name = "orderQuantity")]
        [JsonPropertyName("orderQuantity")]
        public int OrderQuantity { get; set; }

        [DataMember(Name = "availableQuantity")]
        [JsonPropertyName("availableQuantity")]
        public int AvailableQuantity { get; set; }

        [DataMember(Name = "productName")]
        [JsonPropertyName("productName")]
        public string ProductName { get; set; }

        [DataMember(Name = "productVersion")]
        [JsonPropertyName("productVersion")]
        public string ProductVersion { get; set; }

        [DataMember(Name = "partNumber")]
        [JsonPropertyName("partNumber")]
        public string PartNumber { get; set; }

        [DataMember(Name = "allowedTypes", EmitDefaultValue = false)]
        [JsonPropertyName("allowedTypes")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string[] AllowedTypes { get; set; }

        [DataMember(Name = "fulfillments", EmitDefaultValue = false)]
        [JsonPropertyName("fulfillments")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public Fulfillment[] Fulfillments { get; set; }

        [DataMember(Name = "addOnLicenses", EmitDefaultValue = false)]
        [JsonPropertyName("addOnLicenses")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public AddOnLicense[] AddOnLinceses { get; set; }

        [DataMember(Name = "compatibilityInformation", EmitDefaultValue = false)]
        [JsonPropertyName("compatibilityInformation")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public CompatibilityInformation CompatibilityInformation { get; set; }

        #endregion
    }
}
