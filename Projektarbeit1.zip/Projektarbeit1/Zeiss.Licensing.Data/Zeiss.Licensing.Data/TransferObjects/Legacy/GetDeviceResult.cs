﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Text.Json.Serialization;

namespace Zeiss.Licensing.Data.TransferObjects.Legacy
{
    public class GetDeviceResultContainer
    {
        #region Properties

        /// <summary>
        /// GetDeviceResult
        /// </summary>
        [JsonPropertyName("GetDeviceResult")]
        public GetDeviceResult GetDeviceResult { get; set; }

        #endregion
    }

    public class GetDeviceResult
    {
        #region Properties

        /// <summary>
        /// Unique error code in case of non success
        /// </summary>
        [JsonPropertyName("ErrorCode")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string ErrorCode { get; set; }

        /// <summary>
        /// Error message in case of non success
        /// </summary>
        [JsonPropertyName("ErrorMessage")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string ErrorMessage { get; set; }

        /// <summary>
        /// DeviceID
        /// </summary>
        [JsonPropertyName("DeviceID")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string DeviceID { get; set; }

        /// <summary>
        /// DeviceType
        /// </summary>
        [JsonPropertyName("HostType")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string HostType { get; set; }

        /// <summary>
        /// HttpStatusCode
        /// </summary>
        [JsonPropertyName("HttpStatusCode")]
        public int HttpStatusCode { get; set; }

        [JsonPropertyName("CustomerName")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string CustomerName { get; set; }

        [JsonPropertyName("CustomerCountry")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string CustomerCountry { get; set; }

        #endregion
    }
}
