﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Zeiss.Licensing.Data.TransferObjects.Legacy
{
    public class GetAvailableLicensesResultContainer
    {
        #region Properties

        /// <summary>
        /// GetDeviceResult
        /// Specifies that this property should be serialized/deserialized with the JSON property name
        /// "GetAvailableLicensesResult".
        /// </summary>
        [JsonPropertyName("GetAvailableLicensesResult")]
        public GetAvailableLicensesResult GetAvailableLicensesResult { get; set; }

        #endregion
    }

    public class GetAvailableLicensesResult: GetDeviceResult
    {
        #region Properties

        [JsonPropertyName("AvailableDemoLicenses")]
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public List<string> AvailableDemoLicenses { get; set; }

        #endregion
    }
}
