﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Upgrade response class
    /// </summary>
    public abstract class UpgradeResponseBase
    {
        #region Properties

        /// <summary>
        /// List of Thales activation ids to revoke
        /// </summary>
        public List<string> ActivationIdsToRevoke { get; set; } = new List<string>();

        /// <summary>
        /// List of Flexera fulfillment ids to revoke (certificate and trusted storage)
        /// </summary>
        public List<string> FulfillmentIdsToRevoke { get; set; } = new List<string>();

        /// <summary>
        /// List of Flexera certificates (license strings) to revoke
        /// </summary>
        public List<string> LicenseStringsToRevoke { get; set; } = new List<string>();

        #endregion
    }
}
