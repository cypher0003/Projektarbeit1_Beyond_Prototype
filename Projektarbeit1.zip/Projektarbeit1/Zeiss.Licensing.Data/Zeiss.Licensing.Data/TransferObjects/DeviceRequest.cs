﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class DeviceRequest
    {
        #region Properties

        public string DeviceName { get; set; }

        public string LockCode { get; set; }

        public string DeviceTypeName { get; set; }

        public string EndCustomerNumber { get; set; }

        public string Ssc1Number { get; set; }

        public string Ssc2Number { get; set; }

        public string FactoryNumber { get; set; }

        public string DistributorNumber { get; set; }

        #endregion
    }
}
