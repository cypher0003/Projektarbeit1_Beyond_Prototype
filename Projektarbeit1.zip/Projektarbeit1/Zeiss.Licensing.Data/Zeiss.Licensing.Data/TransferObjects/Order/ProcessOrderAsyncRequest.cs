﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2023 - 2023 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    /// <summary>
    ///
    /// </summary>
    public class ProcessOrderAsyncRequest : Models.Order
    {
        #region Properties

        public string SoldToId
        {
            get => SoldTo?.Number;
            set
            {
                if (null == SoldTo)
                {
                    SoldTo = new RefOrganization();
                }

                SoldTo.Number = value;
            }
        }

        public string ShipToId
        {
            get => ShipTo?.Number;
            set
            {
                if (null == ShipTo)
                {
                    ShipTo = new RefOrganization();
                }

                ShipTo.Number = value;
            }
        }

        public string EndCustomerId
        {
            get => EndCustomer?.Number;
            set
            {
                if (null == EndCustomer)
                {
                    EndCustomer = new RefOrganization();
                }

                EndCustomer.Number = value;
            }
        }

        public string SalesRepresentativeId
        {
            get => SalesRepresentative?.Number;
            set
            {
                if (null == SalesRepresentative)
                {
                    SalesRepresentative = new RefOrganization();
                }

                SalesRepresentative.Number = value;
            }
        }

        public string SalesManId
        {
            get => SalesMan?.Number;
            set
            {
                if (null == SalesMan)
                {
                    SalesMan = new RefOrganization();
                }

                SalesMan.Number = value;
            }
        }

        public string SenderBusinessSystemId { get; set; }

        #endregion
    }
}
