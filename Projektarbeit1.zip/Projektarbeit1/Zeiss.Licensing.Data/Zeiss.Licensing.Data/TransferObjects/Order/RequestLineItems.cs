﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    public class RequestLineItems
    {
        #region Properties

        /// <summary>
        /// Array of <see cref="OrderManager.Types.OrderManager_LineItem"/>
        /// </summary>
        public OrderManager_LineItem[] OrderManager_LineItem { get; set; }

        #endregion

        #region Methods

        public RequestLineItems Clone()
        {
            var clone = (RequestLineItems)MemberwiseClone();
            var lineItems = new List<OrderManager_LineItem>();

            foreach (var lineItem in OrderManager_LineItem)
            {
                lineItems.Add(lineItem.Clone());
            }

            clone.OrderManager_LineItem = lineItems.ToArray();

            return clone;
        }

        #endregion
    }
}
