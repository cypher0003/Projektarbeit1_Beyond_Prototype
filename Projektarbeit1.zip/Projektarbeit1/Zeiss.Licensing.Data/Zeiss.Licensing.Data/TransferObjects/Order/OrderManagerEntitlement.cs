﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    public class OrderManagerEntitlement
    {
        #region Constructors

        public OrderManagerEntitlement()
        {
        }

        public OrderManagerEntitlement(string sapOrderId, Status status)
        {
            SapOrderId = sapOrderId;
            ProcessOrderStatus = status;
        }

        #endregion

        #region Properties

        public string SapOrderId { get; set; }

        public Status ProcessOrderStatus { get; set; }

        public ResponseLineItem LineItems { get; set; }

        #endregion
    }
}
