﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using System.Linq;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    public class ResponseLineItem
    {
        #region Fields

        private readonly HashSet<OrderManagerEntitlementLineItem> _lineItems = new HashSet<OrderManagerEntitlementLineItem>();

        #endregion

        #region Properties

        public OrderManagerEntitlementLineItem[] OrderManagerEntitlementLineItem
        {
            get => _lineItems.ToArray();
            set
            {
                _lineItems.Clear();
                value.ToList().ForEach(e => _lineItems.Add(e));
            }
        }

        #endregion

        #region Methods

        public void AddLineItem(OrderManagerEntitlementLineItem lineItem)
        {
            _lineItems.Add(lineItem);
        }

        #endregion
    }
}
