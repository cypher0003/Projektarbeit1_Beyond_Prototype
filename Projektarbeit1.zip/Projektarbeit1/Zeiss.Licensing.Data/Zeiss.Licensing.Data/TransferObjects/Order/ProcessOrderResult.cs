﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using System.Linq;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    public class ProcessOrderResult
    {
        #region Fields

        private readonly HashSet<OrderManagerEntitlement> _processedOrders = new HashSet<OrderManagerEntitlement>();

        #endregion

        #region Properties

        public OrderManagerEntitlement[] OrderManagerEntitlement
        {
            get => _processedOrders.ToArray();
            set
            {
                _processedOrders.Clear();
                value.ToList().ForEach(e => _processedOrders.Add(e));
            }
        }

        #endregion

        #region Methods

        public void AddProcessedOrder(OrderManagerEntitlement processedOrder)
        {
            _processedOrders.Add(processedOrder);
        }

        #endregion
    }
}
