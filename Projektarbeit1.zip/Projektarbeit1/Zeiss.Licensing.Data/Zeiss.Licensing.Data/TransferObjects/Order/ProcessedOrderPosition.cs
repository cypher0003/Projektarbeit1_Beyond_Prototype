﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    /// <summary>
    /// Class with additional properties for order process
    /// </summary>
    public class ProcessedOrderPosition : ICloneable
    {
        #region Properties

        /// <summary>
        /// Position
        /// </summary>
        public OrderPosition Position { get; set; }

        /// <summary>
        /// Entitlements created during order process
        /// </summary>
        public List<Entitlement> Entitlements { get; set; } = new List<Entitlement>();

        /// <summary>
        /// Entitlement line items created during order process
        /// </summary>
        public List<EntitlementProductKey> EntitlementLineItems { get; set; } = new List<EntitlementProductKey>();

        #endregion

        #region Methods

        /// <summary>
        /// Clone ProcessedOrderPosition
        /// </summary>
        /// <returns>Clone of ProcessedOrderPosition</returns>
        public object Clone()
        {
            var orderPosition = (ProcessedOrderPosition)MemberwiseClone();
            orderPosition.Position = (OrderPosition)Position.Clone();

            return orderPosition;
        }

        #endregion
    }
}
