﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    /// <summary>
    /// Represents a line item of an order to process by the OrderManger.
    /// </summary>
    public class OrderManager_LineItem
    {
        #region Properties

        /// <summary>
        /// The id of the line item in ERP.
        /// </summary>
        public string SapOrderItemId { get; set; }

        /// <summary>
        /// The ERP Material Number.
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// The Version of the Product.
        /// </summary>
        public string MaterialVersion { get; set; }

        /// <summary>
        /// The ordered quantity.
        /// </summary>
        public int QuantityOrdered { get; set; }

        /// <summary>
        /// The duration of the product license.
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// The IBase Serial Number.
        /// </summary>
        public string IbaseSerialNumber { get; set; }

        /// <summary>
        /// The IBase Material Number.
        /// </summary>
        public string IbaseMaterialNumber { get; set; }

        /// <summary>
        /// Reference for upgrade.
        /// </summary>
        public string UpgradeReference { get; set; }

        /// <summary>
        /// Plant of the sales position (SAP ERP: VBAP-WERKS)
        /// </summary>
        public string Plant { get; set; }

        /// <summary>
        /// Higher level item in sales order (SAP ERP: VBAP-UEPOS)
        /// </summary>
        public string SapOrderBaseItemId { get; set; }

        /// <summary>
        /// Selected in ERP for update
        /// </summary>
        public bool Selected { get; set; }

        #endregion

        #region Methods

        public OrderManager_LineItem Clone()
        {
            var clone = (OrderManager_LineItem)MemberwiseClone();

            return clone;
        }

        #endregion
    }
}
