﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    public class ProcessOrderRequest
    {
        #region Properties

        public OrderManager_Order[] OrderManager_Order { get; set; }

        #endregion

        #region Methods

        public ProcessOrderRequest Clone()
        {
            var clone = (ProcessOrderRequest)MemberwiseClone();
            var list = new List<OrderManager_Order>();

            foreach (var orderManager_Orders in OrderManager_Order)
            {
                list.Add(orderManager_Orders.Clone());
            }

            clone.OrderManager_Order = list.ToArray();

            return clone;
        }

        #endregion
    }
}
