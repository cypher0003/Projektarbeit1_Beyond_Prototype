﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    /// <summary>
    /// Represents an order to process by the OrderManager.
    /// </summary>
    public class OrderManager_Order
    {
        #region Properties

        /// <summary>
        /// Id of the Order in the ERP.
        /// </summary>
        public string SapOrderId { get; set; }

        /// <summary>
        /// Id of the Person the Order is sold to. (SAP: AG)
        /// </summary>
        public string SoldToId { get; set; }

        /// <summary>
        /// Name of the Person the Order is sold to. (SAP: AG)
        /// </summary>
        public string SoldToName { get; set; }

        /// <summary>
        /// Id of the Person the Order is ship to. (SAP: WE)
        /// </summary>
        public string ShipToId { get; set; }

        /// <summary>
        /// Name of the Person the Order is ship to. (SAP: WE)
        /// </summary>
        public string ShipToName { get; set; }

        /// <summary>
        /// Id of the end customer. (SAP: ZE)
        /// </summary>
        public string EndCustomerID { get; set; }

        /// <summary>
        /// Name of the end customer. (SAP: ZE)
        /// </summary>
        public string EndCustomerName { get; set; }

        /// <summary>
        /// Id of the sales representative. (SAP: ZA)
        /// </summary>
        public string SalesRepID { get; set; }

        /// <summary>
        /// Name of the sales representative. (SAP: ZA)
        /// </summary>
        public string SalesRepName { get; set; }

        /// <summary>
        /// Id of the sales manager. (SAP: Y2)
        /// </summary>
        public string SalesManID { get; set; }

        /// <summary>
        /// Name of the sales manager (SAP: Y2)
        /// </summary>
        public string SalesManName { get; set; }

        /// <summary>
        /// Email address which should receive certificates.
        /// </summary>
        public string EmailAddress { get; set; }

        /// <summary>
        /// Distribution Channel (SAP ERP: VBAK-VTWEG)
        /// </summary>
        public string DistributionChannel { get; set; }

        /// <summary>
        /// SalesOrganisation (SAP ERP: VBAK-VKORG)
        /// </summary>
        public string SalesOrganisation { get; set; }

        /// <summary>
        /// Defines if an SMA renewal from Software Download Portal is ongoing
        /// </summary>
        public bool AutomaticSMAPortalProcess { get; set; }

        /// <summary>
        /// First Name of the Customer
        /// </summary>
        public string CustomerFirstName { get; set; }

        /// <summary>
        /// Lat Name of the Customer
        /// </summary>
        public string CustomerLastName { get; set; }

        /// <summary>
        /// Email address of the Customer
        /// </summary>
        public string CustomerEmailAddress { get; set; }

        /// <summary>
        /// LineItems
        /// </summary>
        public RequestLineItems LineItems { get; set; }

        #endregion

        #region Methods

        public OrderManager_Order Clone()
        {
            var clone = (OrderManager_Order)MemberwiseClone();
            var lineItems = LineItems.Clone();
            clone.LineItems = lineItems;

            return clone;
        }

        #endregion
    }
}
