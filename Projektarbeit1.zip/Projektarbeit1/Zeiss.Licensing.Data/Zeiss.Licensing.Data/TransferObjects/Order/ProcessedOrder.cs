﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Zeiss.Licensing.Data.TransferObjects.Order
{
    /// <summary>
    /// Class with additional properties for order process
    /// </summary>
    public class ProcessedOrder : ICloneable
    {
        #region Properties

        public Models.Order Order { get; set; }

        /// <summary>
        /// Order positions
        /// </summary>
        public List<ProcessedOrderPosition> Positions { get; set; } = new List<ProcessedOrderPosition>();

        /// <summary>
        /// Exception (null if successful)
        /// </summary>
        public Error Error { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone ProcessedOrder
        /// </summary>
        /// <returns>Clone of ProcessedOrder</returns>
        public object Clone()
        {
            var order = (ProcessedOrder)MemberwiseClone();
            order.Order = (Models.Order)Order.Clone();
            order.Positions = Positions.Select(c => (ProcessedOrderPosition)c.Clone()).ToList();
            return order;
        }

        #endregion
    }
}
