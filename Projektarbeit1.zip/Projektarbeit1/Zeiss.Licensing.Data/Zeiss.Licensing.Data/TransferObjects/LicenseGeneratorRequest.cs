﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// License generator request
    /// </summary>
    public class LicenseGeneratorRequest
    {
        #region Properties

        /// <summary>
        /// Activation
        /// </summary>
        public Activation Activation { get; set; }

        /// <summary>
        /// Entitlement
        /// </summary>
        public Entitlement Entitlement { get; set; }

        /// <summary>
        /// All features linked in the entitlement
        /// </summary>
        public List<Feature> EntitlementFeatures { get; set; } = new List<Feature>();

        /// <summary>
        /// License model
        /// </summary>
        public LicenseModel LicenseModel { get; set; }

        /// <summary>
        /// Material number
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// Request for FNP trusted storage
        /// </summary>
        public string FNPTrustedStorageRequest { get; set; }

        /// <summary>
        /// All activations / features for FNE
        /// </summary>
        public List<LicenseGeneratorRequestFNEProperties> FNEProperties { get; set; } = new List<LicenseGeneratorRequestFNEProperties>();

        #endregion
    }
}
