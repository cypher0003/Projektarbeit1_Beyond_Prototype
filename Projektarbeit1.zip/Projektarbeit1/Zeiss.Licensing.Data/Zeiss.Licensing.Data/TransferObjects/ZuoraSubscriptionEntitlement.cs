﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.TransferObjects
{
    public class ZuoraSubscriptionEntitlement
    {
        #region Properties

        /// <summary>
        /// Entitlement id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Rate plan id
        /// </summary>
        public string RatePlanId { get; set; }

        /// <summary>
        /// Product keys
        /// </summary>
        public List<ZuoraSubscriptionProductKey> ProductKeys { get; set; } = new List<ZuoraSubscriptionProductKey>();

        #endregion
    }
}
