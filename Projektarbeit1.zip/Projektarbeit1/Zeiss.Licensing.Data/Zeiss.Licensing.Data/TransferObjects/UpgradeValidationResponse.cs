﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.TransferObjects
{
    /// <summary>
    /// Upgrade response class
    /// </summary>
    public class UpgradeValidationResponse : UpgradeResponseBase
    {
        #region Properties

        /// <summary>
        /// Product variants for new product keys
        /// </summary>
        public List<ProductVariant> ProductVariants { get; set; } = new List<ProductVariant>();

        #endregion
    }
}
