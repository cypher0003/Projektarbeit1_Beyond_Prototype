﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class JobStep : BaseModel
    {
        #region Properties

        public int JobStepId { get; set; }

        public int JobId { get; set; }

        public JobStepType Type { get; set; }

        public string Data { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public JobStepStatus Status { get; set; }

        public string StatusMessage { get; set; }

        public DateTime Created { get; set; }

        public DateTime Modified { get; set; }

        #endregion
    }
}
