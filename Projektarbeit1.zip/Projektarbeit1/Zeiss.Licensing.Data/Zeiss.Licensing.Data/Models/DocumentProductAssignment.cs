﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class DocumentProductAssignment : BaseModel
    {
        #region Properties

        public string DocumentId { get; set; }

        public string DocumentName { get; set; }

        public string Businessgroup { get; set; }

        public string ProductFamily { get; set; }

        public string ProductId { get; set; }

        public string ProductVariantId { get; set; }

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTo { get; set; }

        public DocumentAssignmentState State { get; set; } = DocumentAssignmentState.DRAFT;

        public DateTime CreationDate { get; set; }

        public DateTime LastModifiedDate { get; set; }

        #endregion
    }
}
