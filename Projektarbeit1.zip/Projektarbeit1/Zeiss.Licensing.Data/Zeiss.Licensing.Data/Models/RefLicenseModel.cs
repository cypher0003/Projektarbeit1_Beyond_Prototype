﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// license model reference data class
    /// </summary>
    public class RefLicenseModel : BaseModel
    {
        #region Properties

        /// <summary>
        /// Name of the license model
        /// </summary>
        public string Name { get; set; }

        #endregion
    }
}
