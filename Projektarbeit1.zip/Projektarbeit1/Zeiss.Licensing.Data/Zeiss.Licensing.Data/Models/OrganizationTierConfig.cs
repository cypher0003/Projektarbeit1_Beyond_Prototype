﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Organization tier configuration
    /// </summary>
    [EMSAppSettingsRecordNameAttribute("OrganizationTierConfig")]
    public class OrganizationTierConfig
    {
        #region Properties

        /// <summary>
        /// Organization number
        /// </summary>
        public string Number { get; set; }

        /// <summary>
        /// Businessgroup
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// Tier name
        /// </summary>
        public OrganizationTier Tier { get; set; }

        #endregion
    }
}
