﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class DocumentContent : BaseModel
    {
        #region Properties

        public string Name { get; set; }

        /// <summary>
        /// Content coded as base64
        /// </summary>
        public string Content { get; set; }

        public string Language { get; set; } = string.Empty;

        public DocumentState State { get; set; } = DocumentState.DRAFT;

        #endregion
    }
}
