﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// class for role
    /// </summary>
    public class Role : BaseModel
    {
        #region Properties

        /// <summary>
        /// Name of the role.
        /// </summary>
        public string Name { get; set; } = "";

        /// <summary>
        /// Businessgroup
        /// </summary>
        public string Businessgroup { get; set; } = "";

        /// <summary>
        /// ProductFamilies
        /// </summary>
        public List<string> ProductFamilies { get; set; } = new List<string>();

        /// <summary>
        /// GrantProduct
        /// </summary>
        public GrantType GrantProduct { get; set; } = GrantType.None;

        /// <summary>
        /// GrantOrder
        /// </summary>
        public GrantType GrantOrder { get; set; } = GrantType.None;

        /// <summary>
        /// GrantLicense
        /// </summary>
        public GrantType GrantLicense { get; set; } = GrantType.None;

        /// <summary>
        /// GrantEntitlement
        /// </summary>
        public GrantType GrantEntitlement { get; set; } = GrantType.None;

        /// <summary>
        /// GrantDevice
        /// </summary>
        public GrantType GrantDevice { get; set; } = GrantType.None;

        /// <summary>
        /// GrantUser
        /// </summary>
        public GrantType GrantUser { get; set; } = GrantType.None;

        /// <summary>
        /// GrantOrganization
        /// </summary>
        public GrantType GrantOrganization { get; set; } = GrantType.None;

        /// <summary>
        /// GrantNamespace
        /// </summary>
        public GrantType GrantNamespace { get; set; } = GrantType.None;

        /// <summary>
        /// GrantRole
        /// </summary>
        public GrantType GrantRole { get; set; } = GrantType.None;

        /// <summary>
        /// GrantProductFamily
        /// </summary>
        public GrantType GrantProductFamily { get; set; } = GrantType.None;

        /// <summary>
        /// GrantLicenseModel
        /// </summary>
        public GrantType GrantLicenseModel { get; set; } = GrantType.None;

        /// <summary>
        /// GrantModule
        /// </summary>
        public GrantType GrantModule { get; set; } = GrantType.None;

        /// <summary>
        /// Grant device type
        /// </summary>
        public GrantType GrantDeviceType { get; set; } = GrantType.None;

        /// <summary>
        /// Grant document
        /// </summary>
        public GrantType GrantDocument { get; set; } = GrantType.None;

        /// <summary>
        /// Additional grants
        /// </summary>
        public Dictionary<string, bool> AdditionalGrants { get; set; } = new Dictionary<string, bool>();

        /// <summary>
        /// Creation date of the role. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; } = DateTime.Now;

        /// <summary>
        /// Last modified date of the role. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        #endregion

        #region Methods

        public override object Clone()
        {
            var role = (Role)MemberwiseClone();
            role.ProductFamilies = new List<string>();

            if (ProductFamilies != null)
            {
                role.ProductFamilies.AddRange(ProductFamilies);
            }

            return role;
        }

        #endregion
    }
}
