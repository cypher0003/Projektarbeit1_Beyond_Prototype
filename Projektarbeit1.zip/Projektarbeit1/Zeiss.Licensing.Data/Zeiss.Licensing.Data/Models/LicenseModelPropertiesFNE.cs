﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    public class LicenseModelPropertiesFNE : ICloneable
    {
        #region Properties

        /// <summary>
        /// ISV
        /// </summary>
        public string ISV { get; set; }

        /// <summary>
        /// Duration
        /// </summary>
        public string Duration { get; set; }

        /// <summary>
        /// Duration (in days)
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// Vendor
        /// </summary>
        public string Vendor { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Properties FNE
        /// </summary>
        /// <returns>Clone of LicenseModelPropertiesFNE</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
