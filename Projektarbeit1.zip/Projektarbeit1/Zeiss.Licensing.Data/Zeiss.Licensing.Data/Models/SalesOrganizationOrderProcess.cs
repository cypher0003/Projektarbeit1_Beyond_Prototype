﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Sales organization order process mapping
    /// </summary>
    [EMSAppSettingsRecordNameAttribute("SalesOrganizationOrderProcesses")]
    public class SalesOrganizationOrderProcess
    {
        #region Properties

        /// <summary>
        /// Sales organization id
        /// </summary>
        public string SalesOrganizationKey { get; set; }

        /// <summary>
        /// Name of the order process
        /// </summary>
        public string OrderProcessName { get; set; }

        #endregion
    }
}
