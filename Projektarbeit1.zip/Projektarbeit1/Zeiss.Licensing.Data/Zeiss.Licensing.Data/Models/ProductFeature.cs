﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Class for link between product and feature
    /// </summary>
    public class ProductFeature : BaseModel
    {
        #region Properties

        /// <summary>
        /// Feature
        /// </summary>
        public RefFeature Feature { get; set; }

        /// <summary>
        /// Feature count
        /// </summary>
        public int Count { get; set; }

        /// <summary>
        /// License model
        /// </summary>
        public RefLicenseModel LicenseModel { get; set; }

        /// <summary>
        /// State
        /// </summary>
        public ProductFeatureState State { get; set; } = ProductFeatureState.Optional_DefaultOn;

        #endregion

        #region Methods

        /// <summary>
        /// Clone ProductFeature
        /// </summary>
        /// <returns>Clone of ProductFeature</returns>
        public override object Clone()
        {
            var productFeature = (ProductFeature)MemberwiseClone();
            productFeature.Feature = (RefFeature)Feature?.Clone();
            productFeature.LicenseModel = (RefLicenseModel)LicenseModel?.Clone();
            return productFeature;
        }

        #endregion
    }
}
