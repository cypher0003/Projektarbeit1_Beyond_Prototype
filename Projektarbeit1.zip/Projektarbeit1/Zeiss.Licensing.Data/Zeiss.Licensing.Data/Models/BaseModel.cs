﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Base model class
    /// </summary>
    public abstract class BaseModel : ICloneable
    {
        #region Properties

        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; set; } = "";

        #endregion

        #region Methods

        /// <summary>
        /// Clone BaseModel
        /// </summary>
        /// <returns>Clone of BaseModel</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
