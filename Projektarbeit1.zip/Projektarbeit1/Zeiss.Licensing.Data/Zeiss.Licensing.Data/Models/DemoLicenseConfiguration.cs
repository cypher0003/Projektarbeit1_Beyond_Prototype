﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Demo license configuration
    /// </summary>
    [Obsolete("Use infos from product variant.")]
    [EMSAppSettingsRecordNameAttribute("DemoLicenseConfiguration")]
    public class DemoLicenseConfiguration
    {
        #region Properties

        /// <summary>
        /// Material number
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// Default duration
        /// </summary>
        public int DefaultDuration { get; set; }

        /// <summary>
        /// Default license model
        /// </summary>
        [Obsolete("Is not used. License model is defined in product variant.")]
        public string DefautlLicenseModel { get; set; }

        /// <summary>
        /// Multiple generation allowed
        /// </summary>
        public bool MultipleGenerationAllowed { get; set; }

        #endregion
    }
}
