﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Product reference data class
    /// </summary>
    public class RefProduct : BaseModel
    {
        #region Properties

        /// <summary>
        /// Product name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// NameVersion
        /// </summary>
        public string NameVersion => $"{Name}:{Version}";

        #endregion
    }
}
