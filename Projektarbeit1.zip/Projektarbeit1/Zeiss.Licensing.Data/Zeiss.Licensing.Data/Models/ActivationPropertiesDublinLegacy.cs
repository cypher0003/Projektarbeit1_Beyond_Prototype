﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class ActivationPropertiesDublinLegacy
    {
        #region Properties

        /// <summary>
        /// Node id
        /// </summary>
        public string NodeId { get; set; }

        /// <summary>
        /// Prefix
        /// </summary>
        public string Prefix { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Unit prefix
        /// </summary>
        public string UnitPrefix { get; set; }

        /// <summary>
        /// ISerial number
        /// </summary>
        public string ISerialNumber { get; set; }

        /// <summary>
        /// The security code
        /// </summary>
        public string SecurityCode { get; set; }

        /// <summary>
        /// The license key
        /// </summary>
        public string LicenseKey { get; set; }

        /// <summary>
        /// The installation type
        /// </summary>
        public string InstallationType { get; set; }

        /// <summary>
        /// The feature
        /// </summary>
        public string Feature { get; set; }

        /// <summary>
        /// The email address
        /// </summary>
        public string EmailAddress { get; set; }

        #endregion
    }
}
