﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// LicenseModel properties 
    /// </summary>
    public class LicenseModelProperties : BaseModel
    {
        #region Properties

        /// <summary>
        /// LicenseModel Id
        /// </summary>
        public string LicenseModelId { get; set; }

        /// <summary>
        /// Enabled flag
        /// </summary>
        public bool Enabled { get; set; }

        /// <summary>
        /// Number of rehosts
        /// </summary>
        public int NumberOfRehosts { get; set; }

        /// <summary>
        /// Period of rehosts in days
        /// </summary>
        public int PeriodOfRehosts { get; set; }

        /// <summary>
        /// Number of returns
        /// </summary>
        public int NumberOfReturns { get; set; }

        /// <summary>
        /// Period of returns in days
        /// </summary>
        public int PeriodOfReturns { get; set; }

        /// <summary>
        /// Allow multiple activation
        /// </summary>
        public bool AllowMultipleActivation { get; set; }

        /// <summary>
        /// License type as description for the license; editable from user
        /// </summary>
        public string DisplayLicenseType { get; set; }

        #endregion
    }
}
