﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    [EMSAppSettingsRecordNameAttribute("Modules")]
    public class Module : ICloneable
    {
        #region Properties

        /// <summary>
        /// Name of Module
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Display name
        /// </summary>
        public string Displayname { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Module
        /// </summary>
        /// <returns>Clone of Module</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
