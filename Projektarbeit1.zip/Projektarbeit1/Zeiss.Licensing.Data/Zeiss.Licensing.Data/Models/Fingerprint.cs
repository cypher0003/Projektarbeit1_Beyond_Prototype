﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Fingerprint data class
    /// </summary>
    public class Fingerprint : RefFingerprint
    {
        #region Properties

        /// <summary>
        /// Fingerprint Xml data
        /// </summary>
        public string FingerprintXml { get; set; }

        /// <summary>
        /// Creation date of the fingerprint. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the fingerprint. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        #endregion
    }
}
