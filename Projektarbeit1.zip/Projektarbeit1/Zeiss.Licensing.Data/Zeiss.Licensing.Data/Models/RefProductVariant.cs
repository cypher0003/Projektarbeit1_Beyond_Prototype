﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Text.RegularExpressions;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    public class RefProductVariant : BaseModel
    {
        #region Fields

        /// <summary>
        /// Material number
        /// </summary>
        private string _MaterialNumber;

        #endregion

        #region Properties

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The version
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the material number
        /// </summary>
        public string MaterialNumber
        {
            get => _MaterialNumber;
            set
            {
                if (value != _MaterialNumber)
                {
                    if (!string.IsNullOrWhiteSpace(value) && !Regex.IsMatch(value, "^[0-9]{18}$", RegexOptions.None, TimeSpan.FromMilliseconds(100)))
                    {
                        throw new ArgumentOutOfRangeException(nameof(MaterialNumber), $"{nameof(MaterialNumber)} length must be 18 and must be numeric.");
                    }

                    _MaterialNumber = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the formatted material number
        /// </summary>
        public string FormattedMaterialNumber
        {
            get => FormatHelper.GetFormattedMaterialnumber(_MaterialNumber);
            set
            {
                if (value != MaterialNumber)
                {
                    MaterialNumber = FormatHelper.GetUnFormattedMaterialnumber(value);
                }
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Clone ProductVariant
        /// </summary>
        /// <returns>Clone of ProductVariant</returns>
        public override object Clone()
        {
            var productVariant = (RefProductVariant)MemberwiseClone();

            return productVariant;
        }

        #endregion
    }
}
