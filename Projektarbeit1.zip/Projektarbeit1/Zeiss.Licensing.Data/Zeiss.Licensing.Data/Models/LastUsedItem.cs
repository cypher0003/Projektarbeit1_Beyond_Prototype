﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Last used item
    /// </summary>
    public class LastUsedItem : ICloneable
    {
        #region Properties

        /// <summary>
        /// Object type used to navigate to page
        /// </summary>
        public string ObjectType { get; set; } = string.Empty;

        /// <summary>
        /// Name of the object type
        /// </summary>
        public string ObjectTypeName { get; set; } = string.Empty;

        /// <summary>
        /// Id of the object
        /// </summary>
        public string ObjectId { get; set; } = string.Empty;

        /// <summary>
        /// Name of the object
        /// </summary>
        public string ObjectName { get; set; } = string.Empty;

        #endregion

        #region Methods

        /// <summary>
        /// Clone LastUsedItem
        /// </summary>
        /// <returns>Clone of LastUsedItem</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
