﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class Document : BaseModel
    {
        #region Properties

        public string Businessgroup { get; set; }

        public string ProductFamily { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public DocumentState State { get; set; } = DocumentState.DRAFT;

        public DateTime CreationDate { get; set; }

        public DateTime LastModifiedDate { get; set; }

        public List<DocumentContent> Contents { get; set; } = new List<DocumentContent>();

        #endregion

        #region Methods

        /// <summary>
        /// Clone Document
        /// </summary>
        /// <returns>Clone of Document</returns>
        public override object Clone()
        {
            var document = (Document)MemberwiseClone();
            document.Contents = Contents.Select(c => (DocumentContent)c.Clone()).ToList();

            return document;
        }

        #endregion
    }
}
