﻿#region Copyright
// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG
#endregion

using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Entry to enable order position routing by SalesOrg/Plant
    /// </summary>
    [EMSAppSettingsRecordNameAttribute("OrderPositionRouting")]
    public class OrderPositionRoutingEntry
    {
        #region Properties

        /// <summary>
        /// Sales organization id
        /// </summary>
        public string SalesOrganizationKey { get; set; }

        /// <summary>
        /// Plant of the sales position (SAP ERP: VBAP-WERKS)
        /// </summary>
        public string Plant { get; set; }

        /// <summary>
        /// Target system [EU, SIN]
        /// </summary>
        public string Target { get; set; }

        #endregion
    }
}
