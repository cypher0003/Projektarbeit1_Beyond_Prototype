﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Fingerprint reference data class
    /// </summary>
    public class RefFingerprint : BaseModel
    {
        #region Properties

        /// <summary>
        /// Friendly name of the fingerprint
        /// </summary>
        public string FriendlyName { get; set; }

        #endregion
    }
}
