﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class Job : BaseModel
    {
        #region Properties

        public int JobId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int? PredecessorId { get; set; }

        public JobStatus Status { get; set; }

        public int UserId { get; set; }

        public string StatusMessage { get; set; }

        public DateTime? PlannedStartDate { get; set; }

        public List<JobStep> JobSteps { get; set; }

        public DateTime Created { get; set; }

        public DateTime Modified { get; set; }

        #endregion
    }
}
