﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    ///  Product family class
    /// </summary>
    [EMSAppSettingsRecordNameAttribute("ProductFamilies")]
    public class ProductFamily : ICloneable
    {
        #region Properties

        /// <summary>
        /// Name 
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Business group
        /// </summary>
        public string Businessgroup { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone ProductFamily
        /// </summary>
        /// <returns>Clone of ProductFamily</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
