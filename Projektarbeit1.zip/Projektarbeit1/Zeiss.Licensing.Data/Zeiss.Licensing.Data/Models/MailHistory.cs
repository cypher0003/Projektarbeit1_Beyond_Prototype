﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;

namespace Zeiss.Licensing.Data.Models
{
    public class MailHistory : BaseModel
    {
        #region Properties

        /// <summary>
        /// Whether the mail was succesfully sent
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// The ESB mail json data
        /// </summary>
        public string Data { get; set; }

        /// <summary>
        /// The subject
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// The UTC timestamp
        /// </summary>
        public DateTime UtcTimestamp { get; set; }

        /// <summary>
        /// List of recipient mails
        /// </summary>
        public List<string> Recipients { get; set; } = new List<string>();

        #endregion
    }
}
