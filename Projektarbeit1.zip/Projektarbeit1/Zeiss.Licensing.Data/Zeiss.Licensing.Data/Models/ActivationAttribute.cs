﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class ActivationAttribute
    {
        #region Properties

        /// <summary>
        /// Name of the activation attribute.
        /// example: PRIMARY_1_CRITERIA
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Value of the activation attribute.
        /// example: 4
        /// </summary>
        public string value { get; set; }

        /// <summary>
        /// Whether the activation attribute is read-only.
        /// Default: false
        /// </summary>
        public bool readOnly { get; set; }

        /// <summary>
        /// Whether the activation attribute is mandatory.
        /// Default: false
        /// </summary>
        public bool mandatory { get; set; }

        /// <summary>
        /// Name of the group to which this attribute belongs.
        /// example: LOCKING
        /// </summary>
        public string groupName { get; set; }

        /// <summary>
        /// Name of the subgroup to which this attribute belongs.
        /// </summary>
        public string subGroupName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public ActivationAttributeAssociatedAttribute associatedAttribute { get; set; }

        #endregion
    }
}
