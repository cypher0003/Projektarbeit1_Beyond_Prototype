﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Class for organization
    /// </summary>
    public class RefOrganization : BaseModel
    {
        #region Properties

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Number
        /// </summary>
        public string Number { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone RefOrganization
        /// </summary>
        /// <returns>Clone of RefOrganization</returns>
        public override object Clone()
        {
            var refOrganization = (RefOrganization)MemberwiseClone();

            return refOrganization;
        }

        #endregion
    }
}
