﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    public class Activation : BaseModel
    {
        #region Properties

        /// <summary>
        /// User-specified or auto-generated unique identifier of the activation.
        /// </summary>
        public string ActivationId { get; set; }

        /// <summary>
        /// Auto-generated unique identifier of the group activation. Applicable for bulk activation when multiple products are activated together.
        /// </summary>
        public string GroupActivationId { get; set; }

        /// <summary>
        /// Quantity to activate (less than or equal to totalQuantity specified in the entitlement).
        /// The value specified depends on the activation method of the product being activated.
        /// </summary>
        public int? ActivationQuantity { get; set; }

        /// <summary>
        /// ID representing the time zone of the customer. 
        /// </summary>
        public string TimeZoneId { get; set; }

        /// <summary>
        /// Date of activation.
        /// </summary>
        public DateTime? ActivationDate { get; set; }

        /// <summary>
        /// Whether to send notification to contacts after a successful operation.
        /// </summary>
        public bool? SendNotification { get; set; }

        /// <summary>
        /// Email address of the user performing the activation.
        /// </summary>
        [Obsolete("Use SoldToEmail instead")]
        public string ActivatorEmailId { get; set; }

        /// <summary>
        /// Email address of the sold to
        /// </summary>
        public string SoldToEmail { get; set; }

        /// <summary>
        /// State of the activation.
        /// </summary>
        public ActivationState State { get; set; }

        /// <summary>
        /// Creation date of the activation.
        /// </summary>
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the activation.
        /// </summary>
        public DateTime? LastModifiedDate { get; set; }

        /// <summary>
        /// The license
        /// </summary>
        public string LicenseKey { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// Activation product key
        /// </summary>
        public string ActivatonProductKey { get; set; }

        /// <summary>
        /// Customer
        /// </summary>
        public string Customer { get; set; }

        /// <summary>
        /// Device friendly name
        /// </summary>
        public string DeviceFriendlyName { get; set; }

        /// <summary>
        /// Friendly name of the assigned fingerprint (empty string if no fingerprint is assigned)
        /// </summary>
        public string FingerprintFriendlyName { get; set; }

        /// <summary>
        /// Device id
        /// </summary>
        public string DeviceId { get; set; }

        /// <summary>
        /// Fulfillment Id
        /// </summary>
        [Obsolete("Use ActivationId")]
        public string FulfillmentId { get; set; }

        /// <summary>
        /// Entitlement Id
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Activation properties DublinLegacy
        /// </summary>
        public ActivationPropertiesDublinLegacy DublinLegacyProperties { get; set; }

        /// <summary>
        /// Activation properties FNP certificate
        /// </summary>
        public ActivationPropertiesFNPCertificate FNPCertificateProperties { get; set; }

        /// <summary>
        /// Activation properties Visumax
        /// </summary>
        public ActivationPropertiesVisumax VisumaxProperties { get; set; }

        /// <summary>
        /// Activation properties FX
        /// </summary>
        public ActivationPropertiesFX FXProperties { get; set; }

        /// <summary>
        /// The expiration date
        /// </summary>
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Extension of the license file
        /// </summary>
        public string LicenseFileExtension { get; set; }

        /// <summary>
        /// Is shadow activation (without detail data after data migration)
        /// </summary>
        public bool IsShadow { get; set; }

        /// <summary>
        /// SSC1
        /// </summary>
        public string SSC1Number { get; set; }

        /// <summary>
        /// SSC2
        /// </summary>
        public string SSC2Number { get; set; }

        /// <summary>
        /// Factory
        /// </summary>
        public string FactoryNumber { get; set; }

        /// <summary>
        /// Distributor
        /// </summary>
        public string DistributorNumber { get; set; }

        /// <summary>
        /// SSC1
        /// </summary>
        public string SSC1Name { get; set; }

        /// <summary>
        /// SSC2
        /// </summary>
        public string SSC2Name { get; set; }

        /// <summary>
        /// Factory
        /// </summary>
        public string FactoryName { get; set; }

        /// <summary>
        /// Distributor
        /// </summary>
        public string DistributorName { get; set; }

        /// <summary>
        /// The businessgroup the product belongs to
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// Gets or sets the product family
        /// </summary>
        public string ProductFamily { get; set; }

        /// <summary>
        /// Customer (legacy customer cannot be modified)
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Customer (legacy customer cannot be modified)
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Material number
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// Gets or sets the formatted materialnumber
        /// </summary>
        public string FormattedMaterialNumber
        {
            get => FormatHelper.GetFormattedMaterialnumber(MaterialNumber);
            set
            {
                if (value != MaterialNumber)
                {
                    MaterialNumber = FormatHelper.GetUnFormattedMaterialnumber(value);
                }
            }
        }

        /// <summary>
        /// Upgrade status
        /// </summary>
        public UpgradeStatus UpgradeStatus { get; set; } = UpgradeStatus.Empty;

        #endregion
    }
}
