﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Class for organization
    /// </summary>
    public class Organization : RefOrganization
    {
        #region Properties

        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// State
        /// </summary>
        public OrganizationState State { get; set; } = OrganizationState.ENABLE;

        /// <summary>
        /// Address
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// City
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Postal code / ZIP
        /// </summary>
        public string PostalCode { get; set; }

        /// <summary>
        /// Country
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// true = organization is partner / false = organization is customer
        /// </summary>
        [Obsolete("Use OrganizationType")]
        public bool IsPartner { get; set; }

        /// <summary>
        /// Sales organization
        /// </summary>
        [Obsolete("Use SalesOrganizations")]
        public string SalesOrganization { get; set; }

        /// <summary>
        /// Sales organizations
        /// </summary>
        public List<string> SalesOrganizations { get; set; } = new List<string>();

        /// <summary>
        /// Creation date
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// The identifier used in the entitlement
        /// </summary>
        public string Identifier { get; set; }

        /// <summary>
        /// The organization type
        /// </summary>
        public OrganizationType OrganizationType { get; set; }

        #endregion
    }
}
