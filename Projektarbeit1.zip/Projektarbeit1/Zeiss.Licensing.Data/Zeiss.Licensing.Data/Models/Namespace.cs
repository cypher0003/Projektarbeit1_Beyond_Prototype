﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// namespace data class
    /// </summary>
    public class Namespace : RefNamespace
    {
        #region Properties

        /// <summary>
        /// State of the namespace. A namespace is initially created in the DRAFT stage. 
        /// The state is changed to DEPLOYED when an entitlement is created with products belonging to the namespace.
        /// </summary>
        public NamespaceState? State { get; set; } = NamespaceState.DRAFT;

        /// <summary>
        /// Description of the namespace. You can specify up to 500 alphanumeric characters including special characters.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Creation date of the namespace. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the namespace. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        #endregion
    }
}
