﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Class for default license model mapping product variant
    /// </summary>
    [EMSAppSettingsRecordNameAttribute("DefaultLicenseModels")]
    public class DefaultLicenseModel
    {
        #region Properties

        /// <summary>
        /// License technology
        /// </summary>
        public string LicenseTechnology { get; set; }

        /// <summary>
        /// License type
        /// </summary>
        public string LicenseType { get; set; }

        /// <summary>
        /// License model
        /// </summary>
        public string LicenseModel { get; set; }

        /// <summary>
        /// Businessgroup
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// Is subscription
        /// </summary>
        public bool IsSubscription { get; set; }

        #endregion
    }
}
