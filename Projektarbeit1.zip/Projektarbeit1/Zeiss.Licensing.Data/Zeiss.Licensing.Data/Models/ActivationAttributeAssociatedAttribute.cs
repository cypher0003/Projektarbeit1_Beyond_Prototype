﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class ActivationAttributeAssociatedAttribute
    {
        #region Properties

        /// <summary>
        /// example: PRIMARY_1_INFO
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Value of the attribute.
        /// </summary>
        public string value { get; set; }

        /// <summary>
        /// Whether the attribute is read-only.
        /// </summary>
        public bool readOnly { get; set; }

        /// <summary>
        /// Whether the attribute is mandatory.
        /// </summary>
        public bool mandatory { get; set; }

        #endregion
    }
}
