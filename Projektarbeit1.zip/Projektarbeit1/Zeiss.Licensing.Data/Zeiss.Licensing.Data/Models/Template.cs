﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Helpers;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Template mapping
    /// </summary>
    [EMSAppSettingsRecordNameAttribute("Templates")]
    public class Template
    {
        #region Properties

        /// <summary>
        /// The template name
        /// </summary>
        public string TemplateName { get; set; }

        /// <summary>
        /// The product family
        /// </summary>
        public string ProductFamily { get; set; }

        /// <summary>
        /// The product id
        /// </summary>
        public string ProductId { get; set; }

        /// <summary>
        /// The template type
        /// </summary>
        public TemplateType Type { get; set; }

        /// <summary>
        /// Language
        /// </summary>
        public string Language { get; set; }

        /// <summary>
        /// Email subject
        /// </summary>
        public string EmailSubject { get; set; }

        /// <summary>
        /// Email address from
        /// </summary>
        public string EmailAddressFrom { get; set; }

        /// <summary>
        /// Email sender
        /// </summary>
        public string EmailSender { get; set; }

        /// <summary>
        /// Email address reply to
        /// </summary>
        public string EmailAddressReplyTo { get; set; }

        #endregion
    }
}
