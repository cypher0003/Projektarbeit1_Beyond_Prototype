﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Class for a upgrade rule
    /// </summary>
    public class UpgradeRule : ICloneable
    {
        #region Properties

        /// <summary>
        /// Comparison operator (AND / OR)
        /// </summary>
        public UpgradeCompareOperator CompareOperator { get; set; } = UpgradeCompareOperator.And;

        /// <summary>
        /// Product variants which are used for the validation
        /// </summary>
        public List<RefProductVariant> ValidationList { get; set; } = new List<RefProductVariant>();

        /// <summary>
        /// Inner operations which will be validated
        /// </summary>
        public List<UpgradeRule> InnerUpgradeRules { get; set; } = new List<UpgradeRule>();

        /// <summary>
        /// Output product variant
        /// </summary>
        public RefProductVariant OutputProductVariant { get; set; }

        private IEnumerable<string> ProductVariantIds => ValidationList.Select(c => c.Id);

        #endregion

        #region Methods

        /// <summary>
        /// Validate the validation list and the inner upgrade rule.
        /// For validation the product variant id will be compared.
        /// If validation failed and ZeissLicensingUpgradeRuleValidationException will be thrown.
        /// </summary>
        /// <param name="productVariants">Product variants which are used for validation</param>
        /// <returns>Validation is OK or not OK</returns>
        public bool Validate(IEnumerable<RefProductVariant> productVariants)
        {
            if (null == productVariants)
            {
                productVariants = new List<RefProductVariant>();
            }

            var result = ValidatePrivate(productVariants.ToList());

            return result;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            var result = CreateUpgradeRuleString();

            if (!InnerUpgradeRules.Any())
            {
                return result;
            }

            var innerUpgradeRuleString = CreateInnerUpgradeRulesString();

            var stringBuilder = new StringBuilder(result);

            if (!string.IsNullOrEmpty(result) && !string.IsNullOrEmpty(innerUpgradeRuleString))
            {
                stringBuilder.Append($" {CompareOperator.ToString().ToUpper()} ");
            }

            stringBuilder.Append(innerUpgradeRuleString);

            return stringBuilder.ToString();
        }

        /// <inheritdoc />
        public object Clone()
        {
            var upgradeRule = (UpgradeRule)MemberwiseClone();

            if (null != ValidationList)
            {
                upgradeRule.ValidationList = new List<RefProductVariant>();
                upgradeRule.ValidationList.AddRange(ValidationList.Select(c => (RefProductVariant)c.Clone()));
            }

            if (null != InnerUpgradeRules)
            {
                upgradeRule.InnerUpgradeRules = new List<UpgradeRule>();
                upgradeRule.InnerUpgradeRules.AddRange(InnerUpgradeRules.Select(c => (UpgradeRule)c.Clone()));
            }

            if (null != OutputProductVariant)
            {
                upgradeRule.OutputProductVariant = (RefProductVariant)OutputProductVariant.Clone();
            }

            return upgradeRule;
        }

        /// <summary>
        /// Validate the validation list and the inner upgrade rule.
        /// For validation the product variant id will be compared.
        /// If validation failed and ZeissLicensingUpgradeRuleValidationException will be thrown.
        /// </summary>
        /// <param name="productVariants">Product variants which are used for validation</param>
        /// <returns>Validation is OK or not OK</returns>
        private bool ValidatePrivate(IReadOnlyCollection<RefProductVariant> productVariants)
        {
            switch (CompareOperator)
            {
                case UpgradeCompareOperator.And:
                    return ValidateAnd(productVariants);
                case UpgradeCompareOperator.Or:
                    return ValidateOr(productVariants);
                default:
                    return false;
            }
        }

        private bool ValidateAnd(IReadOnlyCollection<RefProductVariant> productVariants)
        {
            var productVariantIds = GetProductVariantIds(productVariants);

            return ProductVariantIds.All(c => productVariantIds.Contains(c)) && ValidateInnerUpgradeRulesAnd(productVariants);
        }

        private bool ValidateOr(IReadOnlyCollection<RefProductVariant> productVariants)
        {
            var productVariantIds = GetProductVariantIds(productVariants);

            if (!ProductVariantIds.Any() || ProductVariantIds.Any(c => productVariantIds.Contains(c)))
            {
                return true;
            }

            return InnerUpgradeRules.Any() && ValidateInnerUpgradeRulesOr(productVariants);
        }

        private bool ValidateInnerUpgradeRulesAnd(IReadOnlyCollection<RefProductVariant> productVariants)
        {
            return InnerUpgradeRules.TrueForAll(c => c.ValidatePrivate(productVariants));
        }

        private bool ValidateInnerUpgradeRulesOr(IReadOnlyCollection<RefProductVariant> productVariants)
        {
            return InnerUpgradeRules.Exists(c => c.ValidatePrivate(productVariants));
        }

        private static IEnumerable<string> GetProductVariantIds(IEnumerable<RefProductVariant> productVariants)
        {
            return productVariants.Select(c => c.Id);
        }

        private string CreateUpgradeRuleString()
        {
            var result = string.Empty;

            switch (CompareOperator)
            {
                case UpgradeCompareOperator.And:
                    result = string.Join(" AND ", ValidationList.Select(c => $"{c.Name}:{c.Version}"));
                    break;
                case UpgradeCompareOperator.Or:
                    result = string.Join(" OR ", ValidationList.Select(c => $"{c.Name}:{c.Version}"));
                    break;
            }

            return result;
        }

        private string CreateInnerUpgradeRulesString()
        {
            var innerUpgradeRuleStrings = CreateInnerUpgradeRulesStrings();

            return !innerUpgradeRuleStrings.Any() ? string.Empty : string.Join($" {CompareOperator.ToString().ToUpper()} ", innerUpgradeRuleStrings);
        }

        private List<string> CreateInnerUpgradeRulesStrings()
        {
            if (!InnerUpgradeRules.Any())
            {
                return new List<string>();
            }

            var results = new List<string>();

            foreach (var innerUpgradeRule in InnerUpgradeRules)
            {
                var stringBuilder = new StringBuilder();
                stringBuilder.Append("(");
                stringBuilder.Append(innerUpgradeRule);
                stringBuilder.Append(")");

                results.Add(stringBuilder.ToString());
            }

            return results;
        }

        #endregion
    }
}
