﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    public class LicenseModelPropertiesFNPCertificate : ICloneable
    {
        #region Properties

        /// <summary>
        /// ISV
        /// </summary>
        public string ISV { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumberTemplate { get; set; }

        /// <summary>
        /// Use start date
        /// </summary>
        public bool UseStartDate { get; set; }

        /// <summary>
        /// Issuer
        /// </summary>
        public string Issuer { get; set; }

        /// <summary>
        /// Allow non routable
        /// </summary>
        public bool AllowNonRoutable { get; set; }

        /// <summary>
        /// Type
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Trusted storage OK
        /// </summary>
        public bool TSOK { get; set; }

        /// <summary>
        /// Duration
        /// </summary>
        public int? Duration { get; set; }

        /// <summary>
        /// Duration (in days)
        /// </summary>
        public int? DurationInDays
        {
            get => Duration;
            set => Duration = value;
        }

        /// <summary>
        /// Generator name
        /// </summary>
        public string GeneratorName { get; set; }

        /// <summary>
        /// Notice
        /// </summary>
        public string NoticeTemplate { get; set; }

        /// <summary>
        /// Vendor
        /// </summary>
        public string VendorTemplate { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Properties FNP Certificate
        /// </summary>
        /// <returns>Clone of LicenseModelPropertiesFNPCertificate</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
