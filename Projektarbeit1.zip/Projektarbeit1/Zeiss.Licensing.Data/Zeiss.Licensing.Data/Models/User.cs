﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// user data class
    /// </summary>
    public class User : BaseModel
    {
        #region Constructors

        public User()
        {
        }

        /// <summary>
        /// Copy Contructor
        /// </summary>
        /// <param name="user"></param>
        [Obsolete("Use .Clone() instead")]
        public User(User user)
        {
            if (user.CreationDate != null)
            {
                CreationDate = new DateTime(user.CreationDate.Ticks);
            }

            if (user.LastModifiedDate != null)
            {
                LastModifiedDate = new DateTime(user.LastModifiedDate.Ticks);
            }

            if (user.LastLogin != null)
            {
                LastLogin = new DateTime(user.LastLogin.Ticks);
            }

            State = user.State;
            Roles = new List<Role>();

            foreach (var item in user.Roles)
            {
                Roles.Add(item);
            }

            ;
            Modules = new List<Module>();

            foreach (var item in user.Modules)
            {
                Modules.Add(item);
            }

            AccountType = user.AccountType;
            AllowedAliases = new List<string>();

            foreach (var item in user.AllowedAliases)
            {
                AllowedAliases.Add(item);
            }

            var builder = new StringBuilder();

            LastName = builder.Append(user.LastName).ToString();

            builder.Clear();

            Email = builder.Append(user.Email).ToString();

            builder.Clear();

            FirstName = builder.Append(user.FirstName).ToString();

            builder.Clear();

            Id = builder.Append(user.Id).ToString();

            builder.Clear();

            UserId = builder.Append(user.UserId).ToString();

            builder.Clear();

            AccountId = builder.Append(user.AccountId).ToString();

            builder.Clear();

            InvitationId = builder.Append(user.InvitationId).ToString();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Unique login ID of the user. This is used to log in to Sentinel EMS.
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Account Id from Zeiss Id
        /// </summary>
        public string AccountId { get; set; }

        /// <summary>
        /// Inivation Id from Zeiss Id
        /// </summary>
        public string InvitationId { get; set; }

        /// <summary>
        /// Name of the user.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Name of the user.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Unique email address of the user. example: TestUser@example.com
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Account type
        /// </summary>
        public AccountType AccountType { get; set; } = AccountType.User;

        /// <summary>
        /// Creation date of the user. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the user. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// Last login date of the user. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastLogin { get; set; }

        /// <summary>
        /// State of the user that specifies whether the user can access Sentinel EMS or not. Default: ENABLE
        /// </summary>
        public UserState State { get; set; } = UserState.ENABLE;

        /// <summary>
        /// List of roles
        /// </summary>
        public List<Role> Roles { get; set; } = new List<Role>();

        /// <summary>
        /// List of roles
        /// </summary>
        public List<Module> Modules { get; set; } = new List<Module>();

        /// <summary>
        /// List of allowed aliases
        /// </summary>
        public List<string> AllowedAliases { get; set; } = new List<string>();

        /// <summary>
        /// Full Name
        /// </summary>
        public string Name => $"{FirstName} {LastName}";

        /// <summary>
        /// The organization id
        /// </summary>
        public string OrganizationId { get; set; }

        /// <summary>
        /// The organization number
        /// </summary>
        public string OrganizationNumber { get; set; }

        /// <summary>
        /// The organization name
        /// </summary>
        public string OrganizationName { get; set; }

        /// <summary>
        /// List of organization numbers
        /// </summary>
        public List<string> OrganizationNumbers { get; set; } = new List<string>();

        /// <summary>
        /// True, if User is publisher
        /// </summary>
        public bool IsPublisher => !string.IsNullOrWhiteSpace(OrganizationNumber);

        /// <summary>
        /// The admin business group
        /// </summary>
        public string AdminBusinessGroup { get; set; }

        /// <summary>
        /// Saved search modes from search masks
        /// </summary>
        public Dictionary<string, string> SearchModes { get; set; } = new Dictionary<string, string>();

        /// <summary>
        /// Get/set if emergency athorization is allowed
        /// </summary>
        public bool AllowEmergencyAuthorization { get; set; }

        /// <summary>
        /// List of last used items
        /// </summary>
        public List<LastUsedItem> LastUsedItems { get; set; } = new List<LastUsedItem>();

        #endregion

        #region Methods

        /// <summary>
        /// Clone User
        /// </summary>
        /// <returns>Clone of User</returns>
        public override object Clone()
        {
            var user = (User)MemberwiseClone();
            user.Roles = new List<Role>();

            foreach (var item in Roles)
            {
                user.Roles.Add((Role)item.Clone());
            }

            ;
            user.Modules = new List<Module>();

            foreach (var item in Modules)
            {
                user.Modules.Add((Module)item.Clone());
            }

            user.AllowedAliases = new List<string>();

            foreach (var item in AllowedAliases)
            {
                user.AllowedAliases.Add(item);
            }

            user.LastUsedItems = new List<LastUsedItem>();

            foreach (var item in LastUsedItems)
            {
                user.LastUsedItems.Add((LastUsedItem)item.Clone());
            }

            return user;
        }

        #endregion
    }
}
