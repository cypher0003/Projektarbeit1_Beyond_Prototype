﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class Device : BaseModel
    {
        #region Properties

        /// <summary>
        /// FriendlyName
        /// </summary>
        public string FriendlyName { get; set; }

        /// <summary>
        /// LockCode used 
        /// </summary>
        public string LockCode { get; set; }

        /// <summary>
        /// The lock selector defines the criteria which were used from the fingerprint to create the lock code
        /// </summary>
        public int LockSelector { get; set; }

        /// <summary>
        /// OrganizationID
        /// </summary>
        [Obsolete("Use EndCustomer instead")]
        public string OrganizationID { get; set; }

        /// <summary>
        /// Host type
        /// </summary>
        [Obsolete("Use DeviceTypeId instead")]
        public string HostType { get; set; }

        /// <summary>
        /// Device type id
        /// </summary>
        public string DeviceTypeId { get; set; }

        /// <summary>
        /// Device type name
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// End customer number
        /// </summary>
        public string EndCustomerNumber { get; set; }

        /// <summary>
        /// End customer name
        /// </summary>
        public string EndCustomerName { get; set; }

        /// <summary>
        /// SSC1
        /// </summary>
        public string SSC1Number { get; set; }

        /// <summary>
        /// SSC2
        /// </summary>
        public string SSC2Number { get; set; }

        /// <summary>
        /// Factory
        /// </summary>
        public string FactoryNumber { get; set; }

        /// <summary>
        /// Distributor
        /// </summary>
        public string DistributorNumber { get; set; }

        /// <summary>
        /// SSC1
        /// </summary>
        public string SSC1Name { get; set; }

        /// <summary>
        /// SSC2
        /// </summary>
        public string SSC2Name { get; set; }

        /// <summary>
        /// Factory
        /// </summary>
        public string FactoryName { get; set; }

        /// <summary>
        /// Distributor
        /// </summary>
        public string DistributorName { get; set; }

        /// <summary>
        /// Date of Creation
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Date of Last modification
        /// </summary>
        public DateTime Modified { get; set; }

        /// <summary>
        /// Flag, if Device is deleted
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// History state
        /// </summary>
        public DeviceHistoryState HistoryState { get; set; } = DeviceHistoryState.NotLoaded;

        #endregion
    }
}
