﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class Transaction : BaseModel
    {
        #region Properties

        /// <summary>
        /// Globally unique identifier of the entity for which the transaction was performed.
        /// </summary>
        public string EntityIdentifier { get; set; }

        /// <summary>
        /// Name of the operation.
        /// </summary>
        /// <example>Entitlement created</example>
        public string Operation { get; set; }

        /// <summary>
        /// Entity for which the transaction was performed.
        /// </summary>
        public EntityType EntityType { get; set; }

        /// <summary>
        /// Name of the operator.
        /// </summary>
        public string OperatedBy { get; set; }

        /// <summary>
        /// Date of the operation.
        /// </summary>
        public DateTime OperationDate { get; set; }

        /// <summary>
        /// Additional comments related to the requested operation.
        /// </summary>
        public string Comments { get; set; }

        /// <summary>
        /// Creation date of the transaction. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the transaction. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        #endregion
    }
}
