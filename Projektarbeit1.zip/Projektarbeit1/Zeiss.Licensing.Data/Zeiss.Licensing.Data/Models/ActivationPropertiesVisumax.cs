﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class ActivationPropertiesVisumax
    {
        #region Properties

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// TherapyNumber
        /// </summary>
        public int TherapyNumber { get; set; }

        /// <summary>
        /// TherapyType
        /// </summary>
        public int TherapyType { get; set; }

        /// <summary>
        /// ProductCategory
        /// </summary>
        public string ProductCategory { get; set; }

        #endregion
    }
}
