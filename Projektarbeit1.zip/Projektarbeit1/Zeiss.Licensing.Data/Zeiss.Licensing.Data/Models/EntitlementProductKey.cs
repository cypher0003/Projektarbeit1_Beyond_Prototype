﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class EntitlementProductKey : BaseModel
    {
        #region Properties

        /// <summary>
        /// Product key id
        /// </summary>
        public string ProductKeyId { get; set; }

        /// <summary>
        /// Order id
        /// </summary>
        public string OrderId { get; set; }

        /// <summary>
        /// Order item id
        /// </summary>
        public string OrderItemId { get; set; }

        /// <summary>
        /// Upgrade from activation id
        /// </summary>
        public string UpgradeFrom { get; set; }

        /// <summary>
        /// Renewal from activation id
        /// </summary>
        public string RenewalFrom { get; set; }

        /// <summary>
        /// Start date
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Expiry date
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// End date
        /// </summary>
        public DateTime? EndDate
        {
            get
            {
                if (DurationInDays.HasValue)
                {
                    return StartDate.AddDays(DurationInDays.Value);
                }

                return null;
            }
            set
            {
                if (value.HasValue)
                {
                    var timeSpan = value.Value - StartDate;
                    DurationInDays = (int)timeSpan.TotalDays;
                }
                else
                {
                    DurationInDays = null;
                }
            }
        }

        /// <summary>
        /// Total quantity
        /// </summary>
        public int TotalQuantity { get; set; }

        /// <summary>
        /// Available quantity
        /// </summary>
        public int AvailableQuantity { get; set; }

        /// <summary>
        /// Splitted quantity
        /// </summary>
        public int SplittedQuantity { get; set; }

        /// <summary>
        /// Fixed quantity
        /// </summary>
        public int FixedQuantity { get; set; }

        /// <summary>
        /// State
        /// </summary>
        public EntitlementProductKeyState State { get; set; } = EntitlementProductKeyState.Draft;

        /// <summary>
        /// Activation method
        /// </summary>
        public EntitlementProductKeyActivationMethod ActivationMethod { get; set; } = EntitlementProductKeyActivationMethod.Fixed;

        /// <summary>
        /// Product
        /// </summary>
        public EntitlementProduct Product { get; set; }

        /// <summary>
        /// Businessgroup of the linked product
        /// </summary>
        public string ProductBusinessgroup { get; set; }

        /// <summary>
        /// Product family of the linked product
        /// </summary>
        public string ProductFamily { get; set; }

        /// <summary>
        /// Product material number
        /// </summary>
        [Obsolete("Use ProductVariantId instead")]
        public string ProductMaterialNumber { get; set; }

        /// <summary>
        /// Product variant id
        /// </summary>
        public string ProductVariantId { get; set; }

        /// <summary>
        /// CZ serial number
        /// </summary>
        [Obsolete("Use SerialNumber instead")]
        public string CZSerialNumber { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Creation date of the entitlement.
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the entitlement.
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// List of activation attributes that specify the locking information associated with the entitlement. 
        /// The list of available activation attributes depends on the license model associated with the entitlement.
        /// </summary>
        public List<ActivationAttribute> activationAttributes { get; set; }

        /// <summary>
        /// Number of rehosts
        /// </summary>
        public int NumberOfRehosts { get; set; }

        /// <summary>
        /// Period of rehosts in days
        /// </summary>
        public int PeriodOfRehosts { get; set; }

        /// <summary>
        /// Number of returns
        /// </summary>
        public int NumberOfReturns { get; set; }

        /// <summary>
        /// Period of returns in days
        /// </summary>
        public int PeriodOfReturns { get; set; }

        public bool IsConnectedLicenseModel => null != NamedUsersProperties;

        public NamedUsersProperties NamedUsersProperties { get; set; }

        /// <summary>
        /// List of named users
        /// </summary>
        public List<NamedUser> NamedUsers { get; set; } = new List<NamedUser>();

        /// <summary>
        /// Is upgrade flag</summary> 
        public bool IsUpgrade { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Entitlement Productkey
        /// </summary>
        /// <returns>Clone of Entitlement Productkey</returns>
        public override object Clone()
        {
            var entitlementProductKey = (EntitlementProductKey)MemberwiseClone();
            entitlementProductKey.NamedUsers = NamedUsers.Select(c => (NamedUser)c.Clone()).ToList();
            entitlementProductKey.Product = (EntitlementProduct)Product?.Clone();

            return entitlementProductKey;
        }

        #endregion
    }
}
