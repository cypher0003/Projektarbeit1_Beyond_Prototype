﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class ActivationPropertiesFX
    {
        #region Properties

        public string VH_AUTH_PASSWORD { get; set; }

        public string VH_AUTH_USER { get; set; }

        public string IOTIdentifier { get; set; }

        public string MAX_BORROW_INTERVAL { get; set; }

        public string UNDO_INTERVAL { get; set; }

        public int GRACE_PERIOD { get; set; }

        public int USABLE_WITH_BASE_OR_LINEITEM { get; set; }

        public int OVERDRAFT { get; set; }

        public bool AUTO_PROVISION { get; set; }

        public int RENEW_INTERVAL { get; set; }

        public bool METERED { get; set; }

        public bool REUSABLE { get; set; }

        public string DEVICE_SERIAL_NUMBER { get; set; }

        public string CZ_LICENSE_TYPE { get; set; }

        public string CZ_ORDER_TYPE { get; set; }

        public string CZM_SERIAL_NO { get; set; }

        public string CZ_SERIAL_NUMBER { get; set; }

        public bool ALLOW_TERMINAL_SERVER { get; set; }

        public string FLOAT_OK { get; set; }

        public int BORROW_HOURS { get; set; }

        public string NOTICE { get; set; }

        public string VENDOR_STRING { get; set; }

        public string ISSUER { get; set; }

        public string PLATFORMS { get; set; }

        public string SERIAL_NUMBER { get; set; }

        public bool INCLUDE_USE_SERVER { get; set; }

        public int HOST_BASED { get; set; }

        public int USER_BASED { get; set; }

        public int OVERDRAFT_MAX { get; set; }

        public int OVERDRAFT_FLOOR { get; set; }

        public int OVERDRAFT_CEILING { get; set; }

        public int MAX_TRANSFERS { get; set; }

        public string CLIENT_REPAIR_COUNT { get; set; }

        public string DUP_GROUP { get; set; }

        public bool ALLOW_ONE_TERMINAL_SERVER { get; set; }

        public string VM_PLATFORMS { get; set; }

        #endregion
    }
}
