﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Zeiss.Licensing.Data.Models
{
    public class Order : BaseModel
    {
        #region Properties

        /// <summary>
        /// Id of the Order in the ERP.
        /// </summary>
        public string SalesorderNumber { get; set; }

        /// <summary>
        /// Person the Order is sold to.
        /// </summary>
        public RefOrganization SoldTo { get; set; }

        /// <summary>
        /// Person the Order is ship to.
        /// </summary>
        public RefOrganization ShipTo { get; set; }

        /// <summary>
        /// End customer
        /// </summary>
        public RefOrganization EndCustomer { get; set; }

        /// <summary>
        /// Sales representative.
        /// </summary>
        public RefOrganization SalesRepresentative { get; set; }

        /// <summary>
        /// Sales man.
        /// </summary>
        public RefOrganization SalesMan { get; set; }

        /// <summary>
        /// Email address which sould receive certificates.
        /// </summary>
        public string EmailAddress { get; set; }

        /// <summary>
        /// SalesOrganisation (SAP ERP: VBAK-VKORG)
        /// </summary>
        public string SalesOrganisation { get; set; }

        /// <summary>
        /// Defines if an SMA renewal from Software Download Portal is ongoing
        /// </summary>
        public bool SMAPortalProcess { get; set; }

        /// <summary>
        /// First Name of the Customer
        /// </summary>
        public string CustomerFirstName { get; set; }

        /// <summary>
        /// Lat Name of the Customer
        /// </summary>
        public string CustomerLastName { get; set; }

        /// <summary>
        /// Emailaddress of the Customer
        /// </summary>
        public string CustomerEmailAddress { get; set; }

        /// <summary>
        /// Order positions
        /// </summary>
        public List<OrderPosition> Positions { get; set; } = new List<OrderPosition>();

        /// <summary>
        /// Creation date of the entitlement.
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the entitlement.
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Product
        /// </summary>
        /// <returns>Clone of Product</returns>
        public override object Clone()
        {
            var order = (Order)MemberwiseClone();
            order.Positions = Positions.Select(c => (OrderPosition)c.Clone()).ToList();
            return order;
        }

        #endregion
    }
}
