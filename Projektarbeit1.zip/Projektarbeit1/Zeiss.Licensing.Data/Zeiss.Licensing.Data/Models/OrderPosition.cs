﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class OrderPosition : BaseModel
    {
        #region Properties

        /// <summary>
        /// The Id of the line item in ERP.
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// Higher level item in salesorder (SAP ERP: VBAP-UEPOS)
        /// </summary>
        public string BasePosition { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// Material number
        /// </summary>
        public string MaterialNumber { get; set; }

        /// <summary>
        /// The ordered quantity.
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// The duration of the product license.
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// The Ibase Serial Number.
        /// </summary>
        public string IbaseSerialNumber { get; set; }

        /// <summary>
        /// The Ibase Material Number.
        /// </summary>
        public string IbaseMaterialNumber { get; set; }

        /// <summary>
        /// Plant of the sales position (SAP ERP: VBAP-WERKS)
        /// </summary>
        public string Plant { get; set; }

        /// <summary>
        /// Selected in ERP for update
        /// </summary>
        public bool Selected { get; set; }

        #endregion
    }
}
