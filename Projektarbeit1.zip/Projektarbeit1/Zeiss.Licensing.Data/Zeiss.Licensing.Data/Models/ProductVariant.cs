﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class ProductVariant : RefProductVariant
    {
        #region Properties

        /// <summary>
        /// The description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Businessgroup
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// The product rate plan charge id
        /// </summary>
        public string ProductRatePlanChargeId { get; set; }

        /// <summary>
        /// The product rate plan charge name
        /// </summary>
        public string ProductRatePlanChargeName { get; set; }

        /// <summary>
        /// The product rate plan charge name
        /// </summary>
        public string ProductRatePlanChargeDescription { get; set; }

        /// <summary>
        /// The product rate plan id
        /// </summary>
        public string ProductRatePlanId { get; set; }

        /// <summary>
        /// The product rate plan name
        /// </summary>
        public string ProductRatePlanName { get; set; }

        /// <summary>
        /// The product rate plan name
        /// </summary>
        public string ProductRatePlanDescription { get; set; }

        /// <summary>
        /// Additional notes
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// The product id
        /// </summary>
        public string ProductId { get; set; }

        /// <summary>
        /// The state
        /// </summary>
        public ProductVariantState State { get; set; } = ProductVariantState.DRAFT;

        /// <summary>
        /// The created date
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// The modified date
        /// </summary>
        public DateTime? Modified { get; set; }

        /// <summary>
        /// The license model
        /// </summary>
        public string LicenseModel { get; set; }

        /// <summary>
        /// Additional license model
        /// </summary>
        public string LicenseModelAdditional { get; set; }

        /// <summary>
        /// The product variant type
        /// </summary>
        public ProductVariantType Type { get; set; } = ProductVariantType.Perpetual;

        /// <summary>
        /// Gets or sets the license type
        /// </summary>
        [Obsolete("Not in use")]
        public LicenseType LicenseType { get; set; } = LicenseType.UNDEFINED;

        /// <summary>
        /// Is package true / false
        /// </summary>
        public bool IsPackage { get; set; }

        /// <summary>
        /// Subscription term [Undefined|Monthly|Yearly]
        /// </summary>
        public SubscriptionTerm SubscriptionTerm { get; set; } = SubscriptionTerm.UNDEFINED;

        /// <summary>
        /// List of ProductIds to upgrade from
        /// </summary>
        public List<ProductVariant> UpgradeFrom { get; set; }

        /// <summary>
        /// List of host types
        /// </summary>
        [Obsolete("Use DeviceTypeId / DeviceTypeName instead")]
        public List<string> HostTypes { get; set; } = new List<string>();

        /// <summary>
        /// Device type id
        /// </summary>
        public string DeviceTypeId { get; set; }

        /// <summary>
        /// Device type name
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// Additional Device type id
        /// </summary>
        public string DeviceTypeIdAdditional { get; set; }

        /// <summary>
        /// Additional Device type name
        /// </summary>
        public string DeviceTypeNameAdditional { get; set; }

        /// <summary>
        /// Is demo product
        /// </summary>
        public bool IsDemoProduct { get; set; }

        /// <summary>
        /// Is demo product
        /// </summary>
        public int DemoDuration { get; set; }

        /// <summary>
        /// Is demo product
        /// </summary>
        public bool AllowMultipleGenerationPerUser { get; set; }

        /// <summary>
        /// Is serial number required
        /// </summary>
        public bool SerialNumberRequired { get; set; }

        /// <summary>
        /// Use named users
        /// </summary>
        public bool UseNamedUsers { get; set; }

        /// <summary>
        /// Concurrency criteria
        /// </summary>
        public NamedUsersConcurrencyCriteria NamedUsersConcurrencyCriteria { get; set; }

        /// <summary>
        /// Limit number of named users to quantity
        /// </summary>
        public bool LimitNamedUserAssignment { get; set; }

        /// <summary>
        /// Default duration
        /// </summary>
        public int? DefaultDuration { get; set; }

        /// <summary>
        /// Behaviour when send e-mail with this product variant
        /// </summary>
        public EmailBehaviour EmailBehaviour { get; set; }

        /// <summary>
        /// Upgrade rules
        /// </summary>
        public List<UpgradeRule> UpgradeRules { get; set; } = new List<UpgradeRule>();

        /// <summary>
        /// Flag DeployOnDelivery
        /// </summary>
        public bool DeployOnDelivery { get; set; }

        /// <summary>
        /// Package size of the product variant
        /// This property is handled during the order processing and the quantity will be multiplied with this property
        /// The default value id 1
        /// </summary>
        public int PackageSize { get; set; } = 1;

        /// <summary>
        /// Global ID used to map between different global EMS systems
        /// </summary>
        public string GlobalId { get; set; } = string.Empty;

        /// <summary>
        /// Is available in SIN
        /// </summary>
        public bool AvailableSin { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone ProductVariant
        /// </summary>
        /// <returns>Clone of ProductVariant</returns>
        public override object Clone()
        {
            var productVariant = (ProductVariant)MemberwiseClone();

            if (null != UpgradeFrom)
            {
                productVariant.UpgradeFrom = new List<ProductVariant>();
                productVariant.UpgradeFrom.AddRange(UpgradeFrom.Select(c => (ProductVariant)c.Clone()));
            }

            if (null != UpgradeRules)
            {
                productVariant.UpgradeRules = new List<UpgradeRule>();
                productVariant.UpgradeRules.AddRange(UpgradeRules.Select(c => (UpgradeRule)c.Clone()));
            }

            return productVariant;
        }

        #endregion
    }
}
