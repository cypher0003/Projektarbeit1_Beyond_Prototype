﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    public class CustomEntity : BaseModel
    {
        #region Properties

        /// <summary>
        /// Name of the custom entity. You can specify up to 100 alphanumeric characters.
        /// The following special characters are not allowed: % ^ & [ ] " < > :
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Description of the custom entity. You can specify up to 510 alphanumeric characters.
        /// The following special characters are not allowed: % ^ & [ ] " < > :
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Creation date of the custom entity.
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the custom entity. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        #endregion
    }
}
