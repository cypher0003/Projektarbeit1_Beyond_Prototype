﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// User named properties
    /// </summary>
    public class NamedUsersProperties
    {
        #region Properties

        /// <summary>
        /// Concurrency criteria
        /// </summary>
        public NamedUsersConcurrencyCriteria ConcurrencyCriteria { get; set; } = NamedUsersConcurrencyCriteria.PerLogin;

        /// <summary>
        /// Max. number of NamedUsers
        /// </summary>
        public int ConcurrencyLimit { get; set; }

        /// <summary>
        /// Flag, using named users
        /// </summary>
        public bool UseNamedUsers { get; set; }

        /// <summary>
        /// Number of named users 
        /// </summary>
        public int NumberOfNamedUsers
        {
            get
            {
                var ret = 100;

                if (LimitNamedUsersAssignment)
                {
                    ret = ConcurrencyLimit;
                }

                return ret;
            }
        }

        /// <summary>
        /// Flag, use limit 
        /// </summary>
        public bool LimitNamedUsersAssignment { get; set; }

        #endregion
    }
}
