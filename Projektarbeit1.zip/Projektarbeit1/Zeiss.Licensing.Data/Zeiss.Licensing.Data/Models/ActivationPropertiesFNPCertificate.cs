﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Models
{
    public class ActivationPropertiesFNPCertificate
    {
        #region Properties

        /// <summary>
        /// Notice
        /// </summary>
        public string Notice { get; set; }

        /// <summary>
        /// Vendor
        /// </summary>
        public string Vendor { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        #endregion
    }
}
