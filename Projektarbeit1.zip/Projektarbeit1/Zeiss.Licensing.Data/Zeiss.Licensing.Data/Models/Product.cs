﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class Product : RefProduct
    {
        #region Properties

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Whether the product is associated with an entitlement.
        /// </summary>
        public bool Deployed { get; set; }

        /// <summary>
        /// The businessgroup the product belongs to
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// Gets or sets the state of the product.
        /// </summary>
        public ProductState State { get; set; } = ProductState.DRAFT;

        /// <summary>
        /// Creation date of the product. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the product. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// Gets or sets the list with product features
        /// </summary>
        public List<ProductFeature> ProductFeatures { get; set; } = new List<ProductFeature>();

        /// <summary>
        ///  Gets or sets the list with invalid features
        /// </summary>
        public List<RefFeature> InvalidFeatures { get; set; } = new List<RefFeature>();

        /// <summary>
        /// Activation method for the product.
        /// 
        /// SAOT(Specify at Order Time) : Indicates that the activation method will be specified when creating an entitlement.The SAOT activation type is referred to as Define in Entitlement in the EMS portal.
        /// FIXED: The provided quantity can be consumed in multiple activations, and each activation will consume a specified fixed quantity.Fixed quantity is 1, by default.
        /// PARTIAL: The provided quantity can be consumed in multiple activations.
        /// FULL: The entire quantity will be consumed in one activation.
        /// UNLIMITED: An unlimited number of activations can be performed for the product.
        /// Note:
        /// 
        /// For lease network and standalone licenses, the FULL and FIXED methods are supported.
        /// For lease redundant licenses, only the FULL method is supported.
        /// For connected licenses, only the FIXED method is supported.        
        /// For on - premise licenses, FIXED, FULL, and PARTIAL methods are supported.
        /// For versionless products, the value is always SAOT.
        /// </summary>
        public ActivationMethod ActivationMethod { get; set; }

        /// <summary>
        /// Quantity to be consumed when the activation method is fixed.
        /// The total quantity can be consumed in multiple activations, and each activation will consume a specified fixed quantity.
        /// Fixed quantity is 1 by default.
        /// It is mandatory if activationMethod is FIXED.
        /// </summary>
        public int FixedQuantity { get; set; } = 1;

        /// <summary>
        /// Gets or sets the product family
        /// </summary>
        public ProductFamily ProductFamily { get; set; }

        /// <summary>
        /// The variants of the product
        /// </summary>
        public List<ProductVariant> ProductVariants { get; set; }

        /// <summary>
        /// Prefix for product key
        /// </summary>
        public string ProductKeyPrefix { get; set; }

        /// <summary>
        /// Global ID used to map between different global EMS systems
        /// </summary>
        public string GlobalId { get; set; } = string.Empty;

        #endregion

        #region Methods

        /// <summary>
        /// Clone Product
        /// </summary>
        /// <returns>Clone of Product</returns>
        public override object Clone()
        {
            var product = (Product)MemberwiseClone();
            product.ProductFeatures = ProductFeatures.Select(c => (ProductFeature)c.Clone()).ToList();
            product.ProductFamily = (ProductFamily)ProductFamily?.Clone();

            if (null != ProductVariants)
            {
                product.ProductVariants = ProductVariants.Select(c => (ProductVariant)c.Clone()).ToList();
            }

            return product;
        }

        #endregion
    }
}
