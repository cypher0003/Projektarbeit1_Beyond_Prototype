﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.Generic;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Model for product variant rule
    /// </summary>
    public class ProductVariantRule
    {
        #region Properties

        /// <summary>
        /// Contained product variants
        /// </summary>
        public List<ProductVariant> ContainedProductVariants { get; set; } = new List<ProductVariant>();

        /// <summary>
        /// Included product variants
        /// </summary>
        public List<ProductVariant> IncludedProductVariants { get; set; } = new List<ProductVariant>();

        /// <summary>
        /// Excluded product variants
        /// </summary>
        public List<ProductVariant> ExcludedProductVariants { get; set; } = new List<ProductVariant>();

        #endregion
    }
}
