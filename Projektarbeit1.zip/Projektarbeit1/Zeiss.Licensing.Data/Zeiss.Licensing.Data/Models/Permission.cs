﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// class for permission
    /// </summary>
    public class Permission
    {
        #region Properties

        /// <summary>
        /// Resource on which role permissions are defined. Possible values are:
        /// CM: Denotes the Customer Management module.
        /// CPM: Denotes the Channel Partner Management module.
        /// DM: Denotes the Download Management module.
        /// EM: Denotes the Entitlement Management module.
        /// LMM: Denotes the License Model Management module.
        /// RM: Denotes the Report Management module.
        /// </summary>
        public PermissionResource Resource { get; set; }

        /// <summary>
        /// Actions that the role can perform on the resource.
        /// V: The role has View permissions on the resource.
        /// VE: The role has View and Edit permissions on the resource.
        /// VEA: The role has View, Edit, and Add permissions on the resource.
        /// VEAD: The role has View, Edit, Add, and Delete permissions on the resource.
        /// </summary>
        public PermissionAction Action { get; set; } = PermissionAction.V;

        #endregion
    }
}
