﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// License model data class
    /// </summary>
    public class LicenseModel : RefLicenseModel
    {
        #region Properties

        /// <summary>
        /// Description of the license model
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Creation date of the license model. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the license model. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// Gets or sets whether the license model is enabled
        /// </summary>
        public bool Enabled { get; set; } = true;

        /// <summary>
        /// Gets or sets the enforcement
        /// </summary>
        [Obsolete("Use EnfocementName instead")]
        public string Enforcement { get; set; }

        /// <summary>
        /// Gets or sets the enforcement
        /// </summary>
        public RefEnforcement RefEnforcement { get; set; }

        /// <summary>
        /// Gets the enforcement
        /// </summary>
        public string EnforcementName => null == RefEnforcement ? string.Empty : RefEnforcement.Name;

        /// <summary>
        /// License mode
        /// </summary>
        public LicenseMode LicenseMode { get; set; } = LicenseMode.Undefined;

        /// <summary>
        /// FNP certificate properties
        /// </summary>
        public LicenseModelPropertiesFNPCertificate FNPCertificateProperties { get; set; }

        /// <summary>
        /// FNE properties
        /// </summary>
        public LicenseModelPropertiesFNE FNEProperties { get; set; }

        /// <summary>
        /// Visumax properties
        /// </summary>
        public LicenseModelPropertiesVisumax VisumaxProperties { get; set; }

        /// <summary>
        /// Dublin legacy properties
        /// </summary>
        public LicenseModelPropertiesDublinLegacy DublinLegacyProperties { get; set; }

        /// <summary>
        /// Sentinel RMS Connected properties
        /// </summary>
        public LicenseModelPropertiesSentinelRMSConnected SentinelRMSConnectedProperties { get; set; }

        /// <summary>
        /// Sentinel RMS CloudLM properties
        /// </summary>
        public LicenseModelPropertiesSentinelRmsCloudLm SentinelRmsCloudLmProperties { get; set; }

        /// <summary>
        /// Sentinel RMS Network properties
        /// </summary>
        public LicenseModelPropertiesSentinelRMSNetwork SentinelRMSNetworkProperties { get; set; }

        /// <summary>
        /// Sentinel RMS NetworkLease properties
        /// </summary>
        public LicenseModelPropertiesSentinelRMSNetworkLease SentinelRMSNetworkLeaseProperties { get; set; }

        /// <summary>
        /// Sentinel RMS Standalone properties
        /// </summary>
        public LicenseModelPropertiesSentinelRMSStandalone SentinelRMSStandaloneProperties { get; set; }

        /// <summary>
        /// Sentinel RMS StandaloneLease properties
        /// </summary>
        public LicenseModelPropertiesSentinelRMSStandaloneLease SentinelRMSStandaloneLeaseProperties { get; set; }

        /// <summary>
        /// Number of rehosts
        /// </summary>
        public int NumberOfRehosts { get; set; }

        /// <summary>
        /// Period of rehosts in days
        /// </summary>
        public int PeriodOfRehosts { get; set; }

        /// <summary>
        /// Number of returns
        /// </summary>
        public int NumberOfReturns { get; set; }

        /// <summary>
        /// Period of returns in days
        /// </summary>
        public int PeriodOfReturns { get; set; }

        /// <summary>
        /// Allow multiple activation
        /// </summary>
        public bool AllowMultipleActivation { get; set; }

        /// <summary>
        /// License type as description for the license; editable from user
        /// </summary>
        public string DisplayLicenseType { get; set; }

        public bool IsThales =>
            LicenseMode == LicenseMode.Thales_CloudLM      ||
            LicenseMode == LicenseMode.Thales_Connected    ||
            LicenseMode == LicenseMode.Thales_Network      ||
            LicenseMode == LicenseMode.Thales_NetworkLease ||
            LicenseMode == LicenseMode.Thales_Standalone   ||
            LicenseMode == LicenseMode.Thales_StandaloneLease;

        public bool IsConnected =>
            LicenseMode == LicenseMode.Thales_CloudLM ||
            LicenseMode == LicenseMode.Thales_Connected;

        public bool IsLease =>
            LicenseMode == LicenseMode.Thales_NetworkLease ||
            LicenseMode == LicenseMode.Thales_StandaloneLease;

        #endregion

        #region Methods

        /// <summary>
        /// Clone License model
        /// </summary>
        /// <returns>Clone of  License model</returns>
        public override object Clone()
        {
            var licenseModel = (LicenseModel)MemberwiseClone();

            licenseModel.RefEnforcement = (RefEnforcement)RefEnforcement?.Clone();
            licenseModel.FNPCertificateProperties = (LicenseModelPropertiesFNPCertificate)FNPCertificateProperties?.Clone();
            licenseModel.FNEProperties = (LicenseModelPropertiesFNE)FNEProperties?.Clone();
            licenseModel.SentinelRMSConnectedProperties = (LicenseModelPropertiesSentinelRMSConnected)SentinelRMSConnectedProperties?.Clone();
            licenseModel.SentinelRMSNetworkLeaseProperties = (LicenseModelPropertiesSentinelRMSNetworkLease)SentinelRMSNetworkLeaseProperties?.Clone();
            licenseModel.SentinelRMSNetworkProperties = (LicenseModelPropertiesSentinelRMSNetwork)SentinelRMSNetworkProperties?.Clone();
            licenseModel.SentinelRMSStandaloneLeaseProperties = (LicenseModelPropertiesSentinelRMSStandaloneLease)SentinelRMSStandaloneLeaseProperties?.Clone();
            licenseModel.SentinelRMSStandaloneProperties = (LicenseModelPropertiesSentinelRMSStandalone)SentinelRMSStandaloneProperties?.Clone();
            licenseModel.SentinelRmsCloudLmProperties = (LicenseModelPropertiesSentinelRmsCloudLm)SentinelRmsCloudLmProperties?.Clone();
            licenseModel.DublinLegacyProperties = (LicenseModelPropertiesDublinLegacy)DublinLegacyProperties?.Clone();
            licenseModel.VisumaxProperties = (LicenseModelPropertiesVisumax)VisumaxProperties?.Clone();

            return licenseModel;
        }

        #endregion
    }
}
