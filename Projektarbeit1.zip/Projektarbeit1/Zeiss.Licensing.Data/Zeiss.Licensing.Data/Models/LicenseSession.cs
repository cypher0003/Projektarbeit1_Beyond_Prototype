﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Models
{
    public class LicenseSession : BaseModel
    {
        #region Properties

        /// <summary>
        /// User of the license.
        /// </summary>
        public string User { get; set; }

        /// <summary>
        /// Auto-generated unique identifier of the entitlement.
        /// </summary>
        public string EId { get; set; }

        /// <summary>
        /// Start time of the license session.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Number of licenses in use.
        /// </summary>
        public int UnitsConsumed { get; set; }

        /// <summary>
        /// Total number of provisioned licenses.
        /// </summary>
        public int TotalUnits { get; set; }

        /// <summary>
        /// The time when the license session was last refreshed.
        /// </summary>
        public DateTime? LastRefreshTime { get; set; }

        #endregion
    }
}
