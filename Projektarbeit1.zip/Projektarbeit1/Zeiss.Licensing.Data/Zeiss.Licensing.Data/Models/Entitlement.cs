﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class Entitlement : BaseModel
    {
        #region Properties

        /// <summary>
        /// User-defined or system-generated identifier of the entitlement.
        /// </summary>
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Whether to perform activations/revocations on all associated products (also referred to as product keys) together.
        /// </summary>
        public bool? EntitlementAsWhole { get; set; }

        /// <summary>
        /// A unique friendly name for the entitlement. If not provided, Sentinel EMS automatically generates the eId after creating an entitlement.
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Is entitlement read only
        /// </summary>
        public bool IsReadOnly { get; set; }

        /// <summary>
        /// Start date of the entitlement.
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Expiry date
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// End date of the entitlement.
        /// </summary>
        public DateTime? EndDate
        {
            get
            {
                if (DurationInDays.HasValue)
                {
                    return StartDate.AddDays(DurationInDays.Value);
                }

                return null;
            }
            set
            {
                if (value.HasValue)
                {
                    var timeSpan = value.Value - StartDate;
                    DurationInDays = (int)timeSpan.TotalDays;
                }
                else
                {
                    DurationInDays = null;
                }
            }
        }

        /// <summary>
        /// Whether activations are allowed for the entitlement.
        /// </summary>
        public bool? ActivationAllowed { get; set; }

        /// <summary>
        /// Whether revocations are allowed for the entitlement.
        /// </summary>
        public bool? RevocationAllowed { get; set; }

        /// <summary>
        /// State of the entitlement.
        /// </summary>
        public EntitlementState? State { get; set; }

        /// <summary>
        /// Whether to send notification to contacts after a successful operation.
        /// </summary>
        public bool? SendNotification { get; set; }

        /// <summary>
        /// Email addresses to receive entitlement certificate. You can specify up to 15 email addresses.
        /// </summary>
        public string CcEmail { get; set; }

        /// <summary>
        /// Whether this is a test entitlement.
        /// A test entitlement enables you to ensure that the products, features, and license models have been defined correctly before deploying them into production.
        /// The process of generating a test entitlement is similar to that of a normal entitlement.However a test entitlement can be created using products/suites that are either in Draft or Enable state.
        /// Test entitlements can be used in Activate and Revoke operations; their data is excluded from reports.
        /// </summary>
        public bool? IsTest { get; set; }

        /// <summary>
        /// End customer
        /// </summary>
        public RefOrganization EndCustomer { get; set; }

        /// <summary>
        /// SSC1
        /// </summary>
        public string SSC1Number { get; set; }

        /// <summary>
        /// SSC2
        /// </summary>
        public string SSC2Number { get; set; }

        /// <summary>
        /// Factory
        /// </summary>
        public string FactoryNumber { get; set; }

        /// <summary>
        /// Distributor
        /// </summary>
        public string DistributorNumber { get; set; }

        /// <summary>
        /// SSC1
        /// </summary>
        public string SSC1Name { get; set; }

        /// <summary>
        /// SSC2
        /// </summary>
        public string SSC2Name { get; set; }

        /// <summary>
        /// Factory
        /// </summary>
        public string FactoryName { get; set; }

        /// <summary>
        /// Distributor
        /// </summary>
        public string DistributorName { get; set; }

        /// <summary>
        /// Product keys
        /// </summary>
        public List<EntitlementProductKey> ProductKeys { get; set; } = new List<EntitlementProductKey>();

        /// <summary>
        /// Creation date of the entitlement.
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the entitlement.
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// The subscription start date
        /// </summary>
        public DateTime? SubscriptionStartDate { get; set; }

        /// <summary>
        /// The subscription end date
        /// </summary>
        public DateTime? SubscriptionEndDate { get; set; }

        /// <summary>
        /// The subscription number
        /// </summary>
        public string SubscriptionNumber { get; set; }

        /// <summary>
        /// The first name of license recipient
        /// </summary>
        public string LicenseRecipientFirstName { get; set; }

        /// <summary>
        /// The last name of license recipient
        /// </summary>
        public string LicenseRecipientLastName { get; set; }

        /// <summary>
        /// The email of license recipient
        /// </summary>
        public string LicenseRecipientEmail { get; set; }

        /// <summary>
        /// The language
        /// </summary>
        public string Language { get; set; }

        /// <summary>
        /// Rate plan name
        /// </summary>
        public string RatePlanName { get; set; }

        /// <summary>
        /// Id of Zuora Rate plan (unique in Zuora)
        /// </summary>
        /// 
        [Obsolete("Not used")]
        public string RatePlanId { get; set; }

        /// <summary>
        /// The entitlement type
        /// </summary>
        public EntitlementType EntitlementType { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Entitlement
        /// </summary>
        /// <returns>Clone of Entitlement</returns>
        public override object Clone()
        {
            var entitlement = (Entitlement)MemberwiseClone();
            entitlement.ProductKeys = ProductKeys.Select(c => (EntitlementProductKey)c.Clone()).ToList();
            entitlement.EndCustomer = (RefOrganization)EndCustomer?.Clone();

            return entitlement;
        }

        #endregion
    }
}
