﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// feature data class
    /// </summary>
    public class Feature : RefFeature
    {
        #region Properties

        /// <summary>
        /// Description of the feature.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// The business group the feature belongs to
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// Whether the feature is associated with an entitlement.
        /// </summary>
        public bool Deployed { get; set; }

        /// <summary>
        /// Friendly name
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// List of license models
        /// </summary>
        public List<RefLicenseModel> LicenseModels { get; set; } = new List<RefLicenseModel>();

        /// <summary>
        /// Creation date of the feature. example: 2019-12-19 06:43
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Last modified date of the feature. example: 2019-12-19 06:43
        /// </summary>
        public DateTime LastModifiedDate { get; set; }

        /// <summary>
        /// Equivalent Feature Id
        /// </summary>
        public string EquivalentFeatureId { get; set; } = string.Empty;

        /// <summary>
        /// Equivalent Feature Name
        /// </summary>
        public string EquivalentFeatureName { get; set; }

        /// <summary>
        /// Equivalent Feature Version
        /// </summary>
        public string EquivalentFeatureVersion { get; set; }

        /// <summary>
        /// Equivalent Feature DisplayName
        /// </summary>
        public string EquivalentFeatureDisplayName { get; set; }

        /// <summary>
        /// Global ID used to map between different global EMS systems
        /// </summary>
        public string GlobalId { get; set; } = string.Empty;

        #endregion

        #region Methods

        /// <summary>
        /// Clone feature
        /// </summary>
        /// <returns>Clone of Feature</returns>
        public override object Clone()
        {
            var featureClone = (Feature)MemberwiseClone();

            featureClone.LicenseModels = LicenseModels.Select(lm => (RefLicenseModel)lm.Clone()).ToList();

            return featureClone;
        }

        #endregion
    }
}
