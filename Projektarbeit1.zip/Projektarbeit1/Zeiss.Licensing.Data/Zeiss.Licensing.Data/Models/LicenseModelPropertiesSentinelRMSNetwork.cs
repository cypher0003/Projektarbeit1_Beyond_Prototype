﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.Models
{
    public class LicenseModelPropertiesSentinelRMSNetwork : ICloneable
    {
        #region Properties

        /// <summary>
        /// Duration (in days)
        /// </summary>
        public int? DurationInDays { get; set; }

        /// <summary>
        /// Start date
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Flag Start from activation date
        /// </summary>
        public bool StartFromActivationDate { get; set; }

        /// <summary>
        /// Locking mode
        /// </summary>
        [Obsolete("Use LockSelector instead.")]
        public LockingMode LockingMode { get; set; } = LockingMode.NONE;

        /// <summary>
        /// Lock selector
        /// </summary>
        public int LockSelector { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Clone Properties Sentinel RMS Network
        /// </summary>
        /// <returns>Clone of LicenseModelPropertiesSentinelRMSNetwork</returns>
        public virtual object Clone()
        {
            return MemberwiseClone();
        }

        #endregion
    }
}
