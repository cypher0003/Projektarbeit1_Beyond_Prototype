﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;

namespace Zeiss.Licensing.Data.Models
{
    /// <summary>
    /// Entitlement product container
    /// </summary>
    public class EntitlementProduct : ICloneable
    {
        #region Properties

        /// <summary>
        /// Product
        /// </summary>
        public RefProduct Product { get; set; }

        /// <summary>
        /// Entitlement product feature container
        /// </summary>
        public List<EntitlementProductFeature> Features { get; set; } = new List<EntitlementProductFeature>();

        #endregion

        #region Methods

        /// <summary>
        /// Clone EntitlementProduct
        /// </summary>
        /// <returns>Clone of EntitlementProduct</returns>
        public virtual object Clone()
        {
            var entitlementProduct = (EntitlementProduct)MemberwiseClone();
            entitlementProduct.Product = (RefProduct)Product?.Clone();

            return entitlementProduct;
        }

        #endregion
    }
}
