﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Zeiss.Licensing.Data.HttpClientProvider
{
    /// <summary>
    /// Interface for http client providers
    /// </summary>
    public interface IHttpClientProvider
    {
        #region Methods

        /// <summary>
        /// Get http client
        /// </summary>
        /// <param name="httpClientType">Http client type</param>
        /// <returns>Http client</returns>
        [Obsolete("Use GetHttpCLientAsyc instead")]
        HttpClient GetHttpClient(EHttpClientType httpClientType);

        /// <summary>
        /// Get http client
        /// </summary>
        /// <param name="httpClientType">Http client type</param>
        /// <returns>Http client</returns>
        Task<HttpClient> GetHttpClientAsync(EHttpClientType httpClientType);

        #endregion
    }
}
