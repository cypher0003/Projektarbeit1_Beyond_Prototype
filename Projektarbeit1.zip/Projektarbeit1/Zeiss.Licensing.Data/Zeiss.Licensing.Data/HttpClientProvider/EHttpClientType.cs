﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.HttpClientProvider
{
    /// <summary>
    /// Client types to generate http client for
    /// </summary>
    public enum EHttpClientType
    {
        Product,
        Entitlement,
        User,
        Organization,
        AppSetting,
        Report,
        Device,
        License,
        Order,
        ESBSAPCore,
        ESBMail,
        EMS,
        ESBSD,
        ZeissIdRead,
        ZeissIdDevice,
        Activation,
        LicenseGenerator,
        Job,
        ReportDatabase,
        ZeissIdUnsubscribe,
        ESBEvaPlatform,
        ESBLicensingIntegration,
        ESBAuthZ,
        AuthZ
    }
}
