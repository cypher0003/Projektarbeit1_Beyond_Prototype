﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.TransferObjects;

namespace Zeiss.Licensing.Data.Exceptions
{
    /// <summary>
    /// Zeiss Exception base class
    /// </summary>
    public class ZeissLicensingException : Exception
    {
        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public ZeissLicensingException()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="message">Error message</param>
        /// <param name="errorCode">Error code</param>
        public ZeissLicensingException(string message, string errorCode)
            : this(message, errorCode, null)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="message">Error message</param>
        /// <param name="errorCode">Error code</param>
        /// <param name="innerException">Inner exception</param>
        public ZeissLicensingException(string message, string errorCode, Exception innerException)
            : base(message, innerException)
        {
            ErrorCode = errorCode;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>

        // This constructor is unnecessary as it would be covered by the same constructor with params.
        // Don't remove this constructor as long as we don't have semantic versioning.
        public ZeissLicensingException(ZeissLicensingError zeissLicensingError)
            : this(zeissLicensingError.ErrorMessage, zeissLicensingError.ErrorCode)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>
        /// <param name="arguments">Parameter for error message</param>
        public ZeissLicensingException(ZeissLicensingError zeissLicensingError, params string[] arguments)
            : this(null, zeissLicensingError, arguments)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="innerException">Inner Exception</param>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>

        // This constructor is unnecessary as it would be covered by the same constructor with params.
        // Don't remove this constructor as long as we don't have semantic versioning.
        public ZeissLicensingException(Exception innerException, ZeissLicensingError zeissLicensingError)
            : this(zeissLicensingError.ErrorMessage, zeissLicensingError.ErrorCode, innerException)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="innerException">Inner Exception</param>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>
        /// <param name="arguments">Parameter for error message</param>
        public ZeissLicensingException(Exception innerException, ZeissLicensingError zeissLicensingError, params string[] arguments)

            // the type of the constructor can not be changed from string[] to object[] because of insufficient code versioning
            // ReSharper disable once CoVariantArrayConversion
            : this(string.Format(zeissLicensingError.ErrorMessage, arguments), zeissLicensingError.ErrorCode, innerException)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="error">Error</param>
        public ZeissLicensingException(Error error)
            : this(error.Message, error.Code, null != error.InnerError ? new ZeissLicensingException(error.InnerError) : null)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// ErrorCode
        /// </summary>
        public string ErrorCode { get; }

        #endregion
    }
}
