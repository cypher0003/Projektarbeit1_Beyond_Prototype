﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Exceptions
{
    /// <summary>
    /// Zeiss Forbidden Exception 
    /// </summary>
    public class ZeissLicensingForbiddenException : ZeissLicensingException
    {
        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public ZeissLicensingForbiddenException()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="message">Error message</param>
        /// <param name="errorCode">Error code</param>
        public ZeissLicensingForbiddenException(string message, string errorCode)
            : base(message, errorCode)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="message">Error message</param>
        /// <param name="errorCode">Error code</param>
        /// <param name="innerException">Inner exception</param>
        public ZeissLicensingForbiddenException(string message, string errorCode, Exception innerException)
            : base(message, errorCode, innerException)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>
        public ZeissLicensingForbiddenException(ZeissLicensingError zeissLicensingError)
            : base(zeissLicensingError)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>
        /// <param name="arguments">Parameter for error message</param>
        public ZeissLicensingForbiddenException(ZeissLicensingError zeissLicensingError, params string[] arguments)
            : base(zeissLicensingError, arguments)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="innerException">Inner Exception</param>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>
        public ZeissLicensingForbiddenException(Exception innerException, ZeissLicensingError zeissLicensingError)
            : base(innerException, zeissLicensingError)
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="innerException">Inner Exception</param>
        /// <param name="zeissLicensingError">Zeiss licensing error</param>
        /// <param name="arguments">Parameter for error message</param>
        public ZeissLicensingForbiddenException(Exception innerException, ZeissLicensingError zeissLicensingError, params string[] arguments)
            : base(innerException, zeissLicensingError, arguments)
        {
        }

        #endregion
    }
}
