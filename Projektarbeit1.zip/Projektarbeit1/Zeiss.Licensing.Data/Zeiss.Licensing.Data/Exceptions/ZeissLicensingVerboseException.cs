﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Text.RegularExpressions;

namespace Zeiss.Licensing.Data.Exceptions
{
    /// <summary>
    /// Exception containing error information for well formatted logging and a Zeiss error code.
    /// </summary>
    public class ZeissLicensingVerboseException : ZeissLicensingException
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of an exception containing error information for well formatted logging and a Zeiss error code.
        /// </summary>
        /// <param name="innerException"></param>
        /// <param name="errorCode"></param>
        /// <param name="messageMask">The message Mask in logging format.</param>
        /// <param name="args">The arguments for rendering the message</param>
        public ZeissLicensingVerboseException(Exception innerException, int errorCode, string messageMask, params object[] args)
            : base(messageMask, $"{errorCode / 10000:00}-{errorCode % 10000:0000}", innerException)
        {
            MessageMask = messageMask;
            Args = args;
        }

        #endregion

        #region Properties

        /// <summary>
        /// The message mask in logging format.
        /// </summary>
        public string MessageMask { get; }

        /// <summary>
        /// The arguments for rendering the message
        /// </summary>
        public object[] Args { get; }

        /// <inheritdoc />
        public override string Message
        {
            get
            {
                var output = MessageMask;
                var expression = new Regex("({[^{0-9}]*})");
                var i = 0;

                while (expression.IsMatch(output))
                {
                    output = expression.Replace(output, $"{{{i++}}}", 1);
                }

                return string.Format(output, Args);
            }
        }

        #endregion
    }
}
