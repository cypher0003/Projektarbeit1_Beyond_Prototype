﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Exceptions
{
    public class ZeissLicensingError
    {
        #region Fields

        public static ZeissLicensingError GENERAL_PARAMETER_NULL = new ZeissLicensingError("0001", "NULL is not valid for parameter '{0}' (type '{1}')!");
        public static ZeissLicensingError GENERAL_PARAMETER_INVALID = new ZeissLicensingError("0002", "'{0}' is not a valid value for parameter '{0}' (type '{1}')!");
        public static ZeissLicensingError GENERAL_USER_FOR_AUTHENTICATION_IS_MISSING = new ZeissLicensingError("0003", "A user is required for authentication!");
        public static ZeissLicensingError GENERAL_USER_NOT_AUTHENTICATED = new ZeissLicensingError("0004", "The user '{0}' is not authorized!");
        public static ZeissLicensingError GENERAL_USER_NOT_AUTHENTICATED_FOR_BUSINESSGROUP = new ZeissLicensingError("0005", "The user '{0}' is not authorized for businessgroup '{1}'!");
        public static ZeissLicensingError GENERAL_USER_NOT_AUTHENTICATED_FOR_PRODUCTFAMILY = new ZeissLicensingError("0006", "The user '{0}' is not authorized for product family '{1}'!");

        #endregion

        #region Constructors

        public ZeissLicensingError(string errorCode, string errorMessage)
        {
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }

        #endregion

        #region Properties

        public string ErrorCode { get; }

        public string ErrorMessage { get; }

        #endregion
    }
}
