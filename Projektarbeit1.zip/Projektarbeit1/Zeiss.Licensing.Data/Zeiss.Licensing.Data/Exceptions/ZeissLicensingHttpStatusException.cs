﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Exceptions
{
    /// <summary>
    /// Exception containing error information for well formatted logging, a Zeiss error code
    /// and an additional http status code for generating correct http responses.
    /// </summary>
    public class ZeissLicensingHttpStatusException : ZeissLicensingVerboseException
    {
        #region Constructors

        /// <inheritdoc />
        public ZeissLicensingHttpStatusException(Exception innerException, int errorCode, string messageMask, params object[] args)
            : base(innerException, errorCode, messageMask, args)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// StatusCode for resulting html response
        /// </summary>
        /// The default value is 500 that equals an internal server error.
        public virtual int StatusCode => 500;

        #endregion
    }
}
