﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Search pattern for filtering results. Possible values are:
    /// Exact: Retrieves records that match the search string exactly.
    /// Like: Retrieves records for which the search string appears anywhere in the field.
    /// Normal: Retrieves records where the value begins with the given search string.
    /// </summary>
    public enum SearchPattern
    {
        Exact,
        Like,
        Normal
    }
}
