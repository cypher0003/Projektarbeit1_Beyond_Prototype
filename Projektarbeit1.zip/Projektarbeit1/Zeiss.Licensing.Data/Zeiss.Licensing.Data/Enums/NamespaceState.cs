﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Namespace state
    /// </summary>
    public enum NamespaceState
    {
        /// <summary>
        /// The state is changed to DEPLOYED when an entitlement is created with products belonging to the namespace.
        /// </summary>
        DEPLOYED,

        /// <summary>
        /// A namespace is initially created in the DRAFT stage
        /// </summary>
        DRAFT
    }
}
