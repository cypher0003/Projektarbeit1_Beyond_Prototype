﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Locking mode
    /// </summary>
    public enum LockingMode
    {
        /// <summary>
        /// None (0)
        /// </summary>
        NONE = 0,

        /// <summary>
        /// Hostname (8)
        /// </summary>
        HOSTNAME = 8,

        /// <summary>
        /// Mac (10)
        /// </summary>
        MAC = 10,

        /// <summary>
        /// Custom (400)
        /// </summary>
        CUSTOM = 400,

        /// <summary>
        /// UUID (2000)
        /// </summary>
        UUID = 2000,

        /// <summary>
        /// PC (3014)
        /// </summary>
        PC = 3014,

        /// <summary>
        /// FNE (9000)
        /// </summary>
        FNE = 9000,

        /// <summary>
        /// VISUMAX (9001)
        /// </summary>
        VISUMAX = 9001,

        /// <summary>
        /// DUBLIN (9002)
        /// </summary>
        DUBLIN = 9002,

        /// <summary>
        /// Lease (9003)
        /// </summary>
        LEASE = 9003
    }
}
