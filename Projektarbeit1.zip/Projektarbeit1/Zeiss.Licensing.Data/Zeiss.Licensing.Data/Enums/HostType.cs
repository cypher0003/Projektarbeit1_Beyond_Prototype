﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    // Migrated from CommonTypes
    public enum HostType
    {
        NotApplicable = 0,
        VisanteImageExport = 1,
        CirrusResearchExport = 2,
        GdxReviewSoftware = 3,
        VisanteDesktopSoftware = 4,
        HFAII = 5,
        StratusReviewStation = 6,
        AtlasReviewStation = 7,
        MatrixConnect = 8,
        HFA2ISeries = 9,
        VisanteInstrumentSoftware = 10,
        Atlas9000 = 11,
        CirrusHDOct = 12,
        GdxInstrumentSoftware = 13,
        Matrix800 = 14,
        StratusOCT = 15,
        CirrusReviewStation = 16
    }
}
