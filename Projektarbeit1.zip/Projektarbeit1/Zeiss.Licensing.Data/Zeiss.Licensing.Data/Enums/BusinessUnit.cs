﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    // Migrated from CommonTypes
    public enum BusinessUnit
    {
        IMT = 1,
        MED = 2,
        MIC = 3,
        NONE = 5,
        MEDD = 6,
        MEDO = 7,
        MEDJ = 8,
        OSS = 9,
        VTS = 10,
        MEDDJ = 11,
        COP = 12,
        MEDM = 13,
        MEDCN = 14
    }
}
