﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Actions that the role can perform on the resource.
    /// V: The role has View permissions on the resource.
    /// VE: The role has View and Edit permissions on the resource.
    /// VEA: The role has View, Edit, and Add permissions on the resource.
    /// VEAD: The role has View, Edit, Add, and Delete permissions on the resource.
    /// </summary>
    public enum PermissionAction
    {
        V,
        VE,
        VEA,
        VEAD
    }
}
