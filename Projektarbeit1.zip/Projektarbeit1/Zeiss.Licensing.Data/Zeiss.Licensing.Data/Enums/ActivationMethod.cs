﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    public enum ActivationMethod
    {
        /// <summary>
        /// SAOT (Specify at Order Time): 
        /// Indicates that the activation method will be specified when creating an entitlement. 
        /// The SAOT activation type is referred to as Define in Entitlement in the EMS portal.
        /// </summary>
        SAOT,

        /// <summary>
        /// The provided quantity can be consumed in multiple activations, and each activation will consume a specified fixed quantity. 
        /// Fixed quantity is 1, by default.
        /// </summary>
        FIXED,

        /// <summary>
        /// The provided quantity can be consumed in multiple activations.
        /// </summary>
        PARTIAL,

        /// <summary>
        /// The entire quantity will be consumed in one activation.
        /// </summary>
        FULL,

        /// <summary>
        /// An unlimited number of activations can be performed for the product.
        /// </summary>
        UNLIMITED
    }
}
