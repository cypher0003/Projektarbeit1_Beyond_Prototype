﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    // Migrated from CommonTypes
    public enum OrderType
    {
        BETA = 1,
        EMERGENCY = 2,
        EVALUATION = 3,
        LOAN = 4,
        INTERNAL = 5,
        NFR = 6,
        STANDARD = 7,
        TRIAL = 8,
        SMA = 9,
        EDUCATIONAL = 10,
        PILOT = 11
    }
}
