﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    public enum ActivationState
    {
        /// <summary>
        /// License has been generated.
        /// </summary>
        ACTIVATED,

        /// <summary>
        /// The entitlement has been modified, and the activation is available for renewal.
        /// </summary>
        RENEW_AVAILABLE,

        /// <summary>
        /// Activation has been renewed.
        /// </summary>
        RENEWED,

        /// <summary>
        /// Permission ticket has been generated. Revocation has been initiated.
        /// </summary>
        REVOCATION_IN_PROGRESS,

        /// <summary>
        /// The revocation ticket has been uploaded. The confirmation to re-credit/reject the revocation is pending.
        /// </summary>
        REVOKE_CONFIRMATION_PENDING,

        /// <summary>
        /// Revocation has been done successfully. The revocation credit (if any) is added to the total activation credit of the customer.
        /// </summary>
        REVOKE_CONFIRMED,

        /// <summary>
        /// License has been revoked and regenerated to host on another machine.
        /// </summary>
        REHOSTED,

        /// <summary>
        /// License expired
        /// </summary>
        EXPIRED
    }
}
