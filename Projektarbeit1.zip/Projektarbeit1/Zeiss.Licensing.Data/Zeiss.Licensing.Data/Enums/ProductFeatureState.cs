﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    public enum ProductFeatureState
    {
        /// <summary>
        /// Order taker can decide to include or exclude the feature. By default, the feature is included. (Default)
        /// </summary>
        Optional_DefaultOn,

        /// <summary>
        /// Order taker can decide to include or exclude the feature. By default, the feature is excluded.
        /// </summary>
        Optional_DefaultOff,

        /// <summary>
        /// Order taker cannot change the value. The feature will always be included.
        /// </summary>
        Mandatory
    }
}
