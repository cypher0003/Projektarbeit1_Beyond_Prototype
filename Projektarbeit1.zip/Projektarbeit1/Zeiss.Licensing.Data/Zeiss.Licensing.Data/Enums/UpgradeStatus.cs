﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Upgrade status
    /// </summary>
    public enum UpgradeStatus
    {
        /// <summary>
        /// Activation for UpgradeProductKey (contains no licenseskey)
        /// </summary>
        ActivatedUpgrade,

        /// <summary>
        /// Item which has been "revoked" during upgrade and cannot be revoked
        /// </summary>
        Upgraded,

        /// <summary>
        /// Default, for activated licenses
        /// </summary>
        Empty
    }
}
