﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Account type
    /// </summary>
    public enum AccountType
    {
        /// <summary>
        /// User
        /// </summary>
        User,

        /// <summary>
        /// Super user
        /// </summary>
        SuperUser,

        /// <summary>
        /// No email user
        /// </summary>
        NoEmailUser,

        /// <summary>
        /// Service account
        /// </summary>
        Service,

        /// <summary>
        /// Alias account
        /// </summary>
        Alias
    }
}
