﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    public enum ProductState
    {
        /// <summary>
        /// Initial state in which a product is first created. In this state, you can edit or delete the product. Entitlements cannot be created for a DRAFT product. However, you can create test entitlements for a DRAFT product.
        /// </summary>
        DRAFT,

        /// <summary>
        /// Represents active products. In this state, you can create entitlements for the product. However, updating or disabling a feature or changing features associated with the product is not allowed.
        /// </summary>
        ENABLE,

        /// <summary>
        /// Represents obsolete products. In this state, you cannot edit or delete the product. Also, the product cannot be associated with entitlements. You can enable the product again if required.
        /// </summary>
        DISABLE
    }
}
