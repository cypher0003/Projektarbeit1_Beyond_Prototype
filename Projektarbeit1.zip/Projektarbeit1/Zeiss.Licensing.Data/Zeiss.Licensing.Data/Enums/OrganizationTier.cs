﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Enum for organization tier
    /// </summary>
    public enum OrganizationTier
    {
        /// <summary>
        /// End customer
        /// </summary>
        EndCustomer,

        /// <summary>
        /// SSC2
        /// </summary>
        SSC2,

        /// <summary>
        /// SSC1
        /// </summary>
        SSC1,

        /// <summary>
        /// Distributor
        /// </summary>
        Distributor,

        /// <summary>
        /// Factory
        /// </summary>
        Factory,
    }
}
