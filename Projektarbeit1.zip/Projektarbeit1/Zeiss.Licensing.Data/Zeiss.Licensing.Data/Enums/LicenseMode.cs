﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Lincese mode enum
    /// </summary>
    public enum LicenseMode
    {
        Undefined = 0,
        Thales_Standalone,

        //Floating
        Thales_Network,
        Thales_Connected,
        Thales_StandaloneLease,

        //Floating
        Thales_NetworkLease,
        FlexNet_FNPTrustedStorage,
        FlexNet_FNPCertificate,
        FlexNet_FNE,
        DublinLegacy,
        Visumax,

        // Upgrade
        Upgrade,

        Thales_CloudLM
    }
}
