﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    public enum ProductType
    {
        /// <summary>
        /// A versionless product contains a collection of features of different license models across enforcements.
        /// You can create multiple variants for a versionless product. 
        /// A versionless product acts as a template from which the definition of variants can be derived.
        /// </summary>
        PARENT,

        /// <summary>
        /// Variant of the versionless product where the features included are a subset of the features included in the versionless product.
        /// A versionless product and all its variants have the same name.
        /// You can create several variants for a versionless product by providing a different version for each variant.
        /// </summary>
        CHILD,

        /// <summary>
        /// Any product that is not categorized as a versionless product or variant is marked as default.
        /// This also helps to maintain backward compatibility with all products created in Sentinel EMS version 4.1 and earlier where the concept of versionless products and variants had not been introduced.
        /// You can specify multiple comma-separated values.
        /// </summary>
        DEFAULT
    }
}
