﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Additional grants
    /// </summary>
    public enum AdditionalGrant
    {
        /// <summary>
        /// Grant to change quantity at an enabled product key
        /// </summary>
        Entitlement_ChangeQuantity,

        /// <summary>
        /// Override Policy rehost/return
        /// </summary>
        OverridePolicy,

        /// <summary>
        /// Allow to change Sales organization
        /// </summary>
        AllowChangeOfOrganizationSalesOrg,

        /// <summary>
        /// Allow a partner user to edit entitlement's partner set
        /// </summary>
        Partner_AllowEditPartnerset,

        /// <summary>
        /// Grant to allow test entitlements
        /// </summary>
        Entitlement_AllowTest,

        /// <summary>
        /// Grant to allow to see the info button
        /// </summary>
        AllowViewObjectInfo,

        /// <summary>
        /// Grant to allow to manage named users in view mode
        /// </summary>
        ManageNamedUsers
    }
}
