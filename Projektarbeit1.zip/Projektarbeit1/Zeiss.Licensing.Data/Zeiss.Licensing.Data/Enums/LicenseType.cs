﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Enum for license types
    /// </summary>
    public enum LicenseType
    {
        UNDEFINED = 0,
        DONGLE = 1,
        EMBEDDED = 2,
        FLOATING = 3,
        NODELOCKED = 4,
        NODELOCKED_VM = 5,
        FLOATING_GLOBAL = 6,
        FLOATING_PLANT = 7,
        SERVERBASED_PC = 8,
        CONCURRENT = 9,
        SINGLE = 10,
        COUNTED_PERPETUAL = 11
    }
}
