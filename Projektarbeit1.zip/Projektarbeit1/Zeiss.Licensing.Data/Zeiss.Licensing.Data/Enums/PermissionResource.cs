﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Resource on which role permissions are defined. Possible values are:
    /// CM: Denotes the Customer Management module.
    /// CPM: Denotes the Channel Partner Management module.
    /// DM: Denotes the Download Management module.
    /// EM: Denotes the Entitlement Management module.
    /// LMM: Denotes the License Model Management module.
    /// RM: Denotes the Report Management module.
    /// </summary>
    public enum PermissionResource
    {
        CM,
        CPM,
        DM,
        EM,
        LMM,
        RM
    }
}
