﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.Enums
{
    public enum JobStatus
    {
        Draft,
        Ready,
        Running,
        Paused,
        Failed,
        Finished,
        Blocked,
        Cancelled
    }
}
