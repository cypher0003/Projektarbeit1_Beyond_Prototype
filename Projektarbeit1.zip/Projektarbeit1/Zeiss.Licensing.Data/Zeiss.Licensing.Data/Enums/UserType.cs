﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// User Type; Default: STANDARD
    /// </summary>
    [Obsolete("Use AccountType instead")]
    public enum UserType
    {
        /// <summary>
        /// ADMIN: A user with administrative rights.
        /// </summary>
        ADMIN,

        /// <summary>
        /// SERVICE_ACCOUNT: A service account is created for a user who can access the Sentinel EMS resources for third-party integrated systems.
        /// A service account cannot be authenticated through the Sentinel EMS portal and can only be authenticated using the Sentinel EMS REST API.
        /// </summary>
        SERVICE_ACCOUNT,

        /// <summary>
        /// STANDARD: A standard user, for whom you must define the role to specify the rights.
        /// </summary>
        STANDARD
    }
}
