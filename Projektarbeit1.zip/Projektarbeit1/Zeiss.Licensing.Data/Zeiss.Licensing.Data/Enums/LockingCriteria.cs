﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.Enums
{
    /// <summary>
    /// Enum shows the lock criteria from EMS
    /// </summary>
    [Flags]
    public enum LockingCriteria
    {
        //0000 0000 0000 0000 0000
        None = 0,

        //0000 0000 0000 0000 0001
        IdProm = 1,

        //0000 0000 0000 0000 0010
        IpAddress = 2,

        //0000 0000 0000 0000 0100
        DiskId = 4,

        //0000 0000 0000 0000 1000
        HostName = 8,

        //0000 0000 0000 0001 0000
        EthernetAddress = 16,

        //0000 0000 0000 1000 0000
        ComputerId = 128,

        //0000 0000 0001 0000 0000
        StandardCustom = 256,

        //0000 0000 0100 0000 0000
        ExtendedCustom = 1024,

        //0000 0000 1000 0000 0000
        HardDiskSerial = 2048,

        //0000 0001 0000 0000 0000
        CpuInfoString = 4096,

        //0000 0010 0000 0000 0000
        Uuid = 8192
    }
}
