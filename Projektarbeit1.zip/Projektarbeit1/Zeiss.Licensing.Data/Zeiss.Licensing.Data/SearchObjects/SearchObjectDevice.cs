﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The device search object
    /// </summary>
    public class SearchObjectDevice : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// FriendlyName of the device
        /// </summary>
        public string FriendlyName { get; set; }

        /// <summary>
        /// Lock code
        /// </summary>
        public string LockCode { get; set; }

        /// <summary>
        /// OrganizationId of the device.
        /// </summary>
        public string OrganizationId { get; set; }

        /// <summary>
        /// Host type of the device
        /// </summary>
        [Obsolete("Use DeviceType instead")]
        public string HostType { get; set; }

        /// <summary>
        /// Device type id
        /// </summary>
        public string DeviceTypeId { get; set; }

        /// <summary>
        /// Device type name
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// Factory organization number
        /// </summary>
        public string FactoryNumber { get; set; }

        /// <summary>
        /// Distributor organization number
        /// </summary>
        public string DistributorNumber { get; set; }

        /// <summary>
        /// SSC1 organization number
        /// </summary>
        public string SSC1Number { get; set; }

        /// <summary>
        /// SSC2 organization number
        /// </summary>
        public string SSC2Number { get; set; }

        /// <summary>
        /// EndCustomer organization number
        /// </summary>
        public string EndCustomerNumber { get; set; }

        #endregion
    }
}
