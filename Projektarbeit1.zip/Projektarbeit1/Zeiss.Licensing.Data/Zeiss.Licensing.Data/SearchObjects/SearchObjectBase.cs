﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// SearchObject base class 
    /// </summary>
    public class SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Starting index of the returned records. Default: 0
        /// </summary>
        public int? PageStartIndex { get; set; }

        /// <summary>
        /// Number of records to return per page. Default: 200
        /// </summary>
        public int? PageSize { get; set; }

        /// <summary>
        /// Search pattern for filtering results. 
        /// </summary>
        public SearchPattern? SearchPattern { get; set; }

        /// <summary>
        /// Sort by descending, otherwise sort by ascending 
        /// </summary>
        public bool SortDescending { get; set; }

        /// <summary>
        /// Whether to user load more
        /// </summary>
        public bool UseLoadMore { get; set; }

        /// <summary>
        /// Whether to restart load more
        /// </summary>
        public bool RestartLoadMore { get; set; }

        #endregion
    }
}
