﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The user search object
    /// </summary>
    public class SearchObjectUser : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// First name of the user
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Last name of the user
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// E-Mail of the user.
        /// </summary>
        public string EMail { get; set; }

        /// <summary>
        /// The organization id
        /// </summary>
        public string OrganizationId { get; set; }

        /// <summary>
        /// The organization number
        /// </summary>
        public string OrganizationNumber { get; set; }

        /// <summary>
        /// The organization name
        /// </summary>
        public string OrganizationName { get; set; }

        #endregion
    }
}
