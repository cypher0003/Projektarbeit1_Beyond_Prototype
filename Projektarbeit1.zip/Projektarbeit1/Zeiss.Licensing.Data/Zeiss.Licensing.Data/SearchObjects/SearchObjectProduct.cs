﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The product search object
    /// </summary>
    public class SearchObjectProduct : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Name of the product.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Version of the product.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Name of the license model
        /// </summary>
        public string LicenseModelName { get; set; }

        /// <summary>
        /// Name of the product family, which represents a group of products derived from a common product platform.
        /// </summary>
        public string Family { get; set; }

        /// <summary>
        /// Name of the business group
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// Materialnumber
        /// </summary>
        public string Materialnumber { get; set; }

        /// <summary>
        /// Variant name
        /// </summary>
        public string VariantName { get; set; }

        /// <summary>
        /// Variant product rate plan charge name
        /// </summary>
        public string VariantProductRatePlanChargeName { get; set; }

        /// <summary>
        /// Global id
        /// </summary>
        public string GlobalId { get; set; }

        #endregion
    }
}
