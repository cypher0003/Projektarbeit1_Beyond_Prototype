﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace Zeiss.Licensing.Data.SearchObjects
{
    public class SearchObjectHistory : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// The underlying object type
        /// </summary>
        public string ObjectType { get; set; }

        /// <summary>
        /// The underlying object id
        /// </summary>
        public string ObjectId { get; set; }

        /// <summary>
        /// The message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Additional note
        /// </summary>
        public string Note { get; set; }

        /// <summary>
        /// The date
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// The executed action
        /// </summary>
        public string Action { get; set; }

        /// <summary>
        /// The user who is responsible for the action
        /// </summary>
        public string User { get; set; }

        #endregion
    }
}
