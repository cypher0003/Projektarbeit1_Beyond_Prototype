﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The organization search object
    /// </summary>
    public class SearchObjectOrganization : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Name of the organization
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Number of the organization. External identifier in EMS.
        /// </summary>
        public string Number { get; set; }

        /// <summary>
        /// The ID.
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Sales organization
        /// </summary>
        public string SalesOrganization { get; set; }

        /// <summary>
        /// The organization type
        /// </summary>
        public OrganizationType? OrganizationType { get; set; }

        /// <summary>
        /// City
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Country
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// State
        /// </summary>
        public OrganizationState? State { get; set; } = null;

        #endregion
    }
}
