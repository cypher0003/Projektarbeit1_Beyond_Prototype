﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    public class SearchObjectJob : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Id (Record id)
        /// </summary>
        public string Id { get; set; }

        public int? JobId { get; set; }

        public string Name { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public int? PredecessorId { get; set; }

        public JobStatus? Status { get; set; }

        public int? UserId { get; set; }

        public string StatusMessage { get; set; }

        public DateTime? PlannedStartDate { get; set; }

        public string Description { get; set; }

        public DateTime? Created { get; set; }

        public DateTime? Modified { get; set; }

        #endregion
    }
}
