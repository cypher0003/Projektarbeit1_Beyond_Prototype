﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The entitlement search object
    /// </summary>
    public class SearchObjectEntitlement : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// A unique friendly name for the entitlement. If not provided, Sentinel EMS automatically generates the eId after creating an entitlement.
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Sales order
        /// </summary>
        public string SalesOrder { get; set; }

        /// <summary>
        /// Product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// Product material number
        /// </summary>
        public string ProductMaterialNumber { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string Productname { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string Productversion { get; set; }

        /// <summary>
        /// Product variant id
        /// </summary>
        public string ProductVariantId { get; set; }

        /// <summary>
        /// State of the entitlement.
        /// </summary>
        public EntitlementState? State { get; set; }

        /// <summary>
        /// Factory organization number
        /// </summary>
        public string FactoryNumber { get; set; }

        /// <summary>
        /// Distributor organization number
        /// </summary>
        public string DistributorNumber { get; set; }

        /// <summary>
        /// SSC1 organization number
        /// </summary>
        public string SSC1Number { get; set; }

        /// <summary>
        /// SSC2 organization number
        /// </summary>
        public string SSC2Number { get; set; }

        /// <summary>
        /// Endcustomer organization number
        /// </summary>
        public string EndcustomerNumber { get; set; }

        /// <summary>
        /// Creation date from
        /// </summary>
        public DateTime? CreationDateFrom { get; set; }

        /// <summary>
        /// Creation date to
        /// </summary>
        public DateTime? CreationDateTo { get; set; }

        /// <summary>
        /// The subscription end date
        /// </summary>
        public DateTime? SubscriptionEndDate { get; set; }

        /// <summary>
        /// The subscription number
        /// </summary>
        public string SubscriptionNumber { get; set; }

        /// <summary>
        /// Rate plan name
        /// </summary>
        public string RatePlanName { get; set; }

        /// <summary>
        /// Rate plan Id
        /// </summary>
        [Obsolete("Not used")]
        public string RatePlanId { get; set; }

        /// <summary>
        /// The first name of license recipient
        /// </summary>
        public string LicenseRecipientFirstName { get; set; }

        /// <summary>
        /// The last name of license recipient
        /// </summary>
        public string LicenseRecipientLastName { get; set; }

        /// <summary>
        /// The email of license recipient
        /// </summary>
        public string LicenseRecipientEmail { get; set; }

        /// <summary>
        /// The language
        /// </summary>
        public string Language { get; set; }

        /// <summary>
        /// The entitlement type
        /// </summary>
        public EntitlementType? EntitlementType { get; set; }

        /// <summary>
        /// SerialNumber of device, productkey intended for
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Get only entitlement which have available quantity left
        /// </summary>
        public bool? EntitlementsWithAvailableQuantity { get; set; }

        /// <summary>
        /// Product family
        /// </summary>
        public string ProductFamily { get; set; }

        #endregion
    }
}
