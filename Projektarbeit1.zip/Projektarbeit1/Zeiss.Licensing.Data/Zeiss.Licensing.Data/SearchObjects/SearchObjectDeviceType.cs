﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.SearchObjects
{
    public class SearchObjectDeviceType : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// The id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// The name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The prefix
        /// </summary>
        public string Prefix { get; set; }

        /// <summary>
        /// Whether is server
        /// </summary>
        public bool? IsServer { get; set; }

        /// <summary>
        /// Whether is creatable on activation
        /// </summary>
        public bool? CreatableOnActivation { get; set; }

        /// <summary>
        /// Whether enhance device id
        /// </summary>
        public bool? EnhanceDeviceId { get; set; }

        /// <summary>
        /// Allow demo license
        /// </summary>
        public bool? AllowDemoLicense { get; set; }

        /// <summary>
        /// Whether is enabled
        /// </summary>
        public bool? Enabled { get; set; }

        /// <summary>
        /// The business group
        /// </summary>
        public string Businessgroup { get; set; }

        #endregion
    }
}
