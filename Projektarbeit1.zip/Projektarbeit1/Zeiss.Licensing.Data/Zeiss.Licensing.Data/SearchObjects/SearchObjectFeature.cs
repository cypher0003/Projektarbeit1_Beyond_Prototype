﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The feature search object
    /// </summary>
    public class SearchObjectFeature : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Name of the product.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Version of the product.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Name of the license model
        /// </summary>
        public string LicenseModelName { get; set; }

        /// <summary>
        /// Name of the business group
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// DisplayName
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// Global id
        /// </summary>
        public string GlobalId { get; set; }

        #endregion
    }
}
