﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    public class SearchObjectProductVariant : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Businessgroup
        /// </summary>
        public string Businessgroup { get; set; }

        /// <summary>
        /// The product rate plan charge id
        /// </summary>
        public string ProductRatePlanChargeId { get; set; }

        /// <summary>
        /// The product rate plan charge name
        /// </summary>
        public string ProductRatePlanChargeName { get; set; }

        /// <summary>
        /// The product rate plan charge description
        /// </summary>
        public string ProductRatePlanChargeDescription { get; set; }

        /// <summary>
        /// The product rate plan id
        /// </summary>
        public string ProductRatePlanId { get; set; }

        /// <summary>
        /// The product rate plan name
        /// </summary>
        public string ProductRatePlanName { get; set; }

        /// <summary>
        /// The product rate plan description
        /// </summary>
        public string ProductRatePlanDescription { get; set; }

        /// <summary>
        /// Additional notes
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// The product id
        /// </summary>
        public string ProductId { get; set; }

        /// <summary>
        /// The state
        /// </summary>
        public ProductVariantState? State { get; set; }

        /// <summary>
        /// The license model
        /// </summary>
        public string LicenseModel { get; set; }

        /// <summary>
        /// The additional license model
        /// </summary>
        public string LicenseModelAdditional { get; set; }

        /// <summary>
        /// The product variant type
        /// </summary>
        public ProductVariantType? Type { get; set; }

        /// <summary>
        /// The material number
        /// </summary>
        public string Materialnumber { get; set; }

        /// <summary>
        /// Device type id
        /// </summary>
        public string DeviceTypeId { get; set; }

        /// <summary>
        /// Device type name
        /// </summary>
        public string DeviceTypeName { get; set; }

        /// <summary>
        /// Additional Device type id
        /// </summary>
        public string DeviceTypeIdAdditional { get; set; }

        /// <summary>
        /// Additional Device type name
        /// </summary>
        public string DeviceTypeNameAdditional { get; set; }

        /// <summary>
        /// Global id
        /// </summary>
        public string GlobalId { get; set; }

        #endregion
    }
}
