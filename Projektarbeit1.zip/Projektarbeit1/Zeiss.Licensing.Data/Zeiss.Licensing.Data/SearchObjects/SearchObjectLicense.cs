﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The license search object
    /// </summary>
    public class SearchObjectLicense : SearchObjectBase
    {
        #region Properties

        /// <summary>
        /// Product key
        /// </summary>
        public string ProductKey { get; set; }

        /// <summary>
        /// Activation id
        /// </summary>
        public string ActivationtId { get; set; }

        /// <summary>
        /// A unique friendly name for the entitlement.
        /// </summary>
        public string EntitlementId { get; set; }

        /// <summary>
        /// Fulfillment id
        /// </summary>
        [Obsolete("Use ActivationId")]
        public string FulfillmentId { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product version
        /// </summary>
        public string ProductVersion { get; set; }

        /// <summary>
        /// Product material number
        /// </summary>
        public string ProductMaterialNumber { get; set; }

        /// <summary>
        /// Customer organization number
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Creation date from
        /// </summary>
        public DateTime? CreationDateFrom { get; set; }

        /// <summary>
        /// Creation date to
        /// </summary>
        public DateTime? CreationDateTo { get; set; }

        /// <summary>
        /// The device id
        /// </summary>
        public string DeviceId { get; set; }

        /// <summary>
        /// The device name
        /// </summary>
        public string DeviceName { get; set; }

        /// <summary>
        /// Serial number
        /// </summary>
        public string SerialNumber { get; set; }

        /// <summary>
        /// Factory organization number
        /// </summary>
        public string FactoryNumber { get; set; }

        /// <summary>
        /// Distributor organization number
        /// </summary>
        public string DistributorNumber { get; set; }

        /// <summary>
        /// SSC1 organization number
        /// </summary>
        public string SSC1Number { get; set; }

        /// <summary>
        /// SSC2 organization number
        /// </summary>
        public string SSC2Number { get; set; }

        /// <summary>
        /// EndCustomer organization number
        /// </summary>
        public string EndCustomerNumber { get; set; }

        /// <summary>
        /// Is test activation
        /// </summary>
        public bool? IsTest { get; set; }

        /// <summary>
        /// Sort properties
        /// </summary>
        public SortPropertyLicense SortProperty { get; set; } = SortPropertyLicense.None;

        #endregion
    }
}
