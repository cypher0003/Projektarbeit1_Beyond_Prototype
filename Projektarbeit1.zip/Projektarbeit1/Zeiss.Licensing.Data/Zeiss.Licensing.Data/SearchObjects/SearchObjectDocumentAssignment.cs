﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The document assignment search object
    /// </summary>
    public class SearchObjectDocumentAssignment : SearchObjectBase
    {
        #region Properties

        public string BusinessGroup { get; set; }

        public string ProductFamily { get; set; }

        public string ProductId { get; set; }

        public string ProductVariantId { get; set; }

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTo { get; set; }

        public DocumentAssignmentState? State { get; set; }

        #endregion
    }
}
