﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;

namespace Zeiss.Licensing.Data.SearchObjects
{
    /// <summary>
    /// The document search object
    /// </summary>
    public class SearchObjectDocument : SearchObjectBase
    {
        #region Properties

        public string BusinessGroup { get; set; }

        public string ProductFamily { get; set; }

        public string Name { get; set; }

        public DocumentState? State { get; set; }

        #endregion
    }
}
