﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Text.Json;
using System.Text.Json.Serialization;

namespace Zeiss.Licensing.Data.Constants
{
    public static class JsonConstants
    {
        #region Properties

        /// <summary>
        /// Default JsonSerializerOptions
        /// - Null values are ignored
        /// - Camel case is used
        /// - Json is pretty printed
        /// </summary>
        public static JsonSerializerOptions JsonSerializerOptions { get; } =
            new JsonSerializerOptions
            {
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };

        #endregion
    }
}
