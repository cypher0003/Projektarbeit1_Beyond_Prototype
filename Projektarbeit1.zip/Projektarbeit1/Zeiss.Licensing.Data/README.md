# Zeiss.Licensing.Data

## Description
    
NuGet to provide data transfer objects for all services.
    
## General information
    
| Info          | Value                                                                                        |
| ------------- | -------------------------------------------------------------------------------------------- |
| Status        | Deployed                                                                                     |
| Documentation | [DevOps Wiki](https://dev.azure.com/ZEISSgroup/SWL/_wiki/wikis/Developer%20Guide/61847/Data) |

