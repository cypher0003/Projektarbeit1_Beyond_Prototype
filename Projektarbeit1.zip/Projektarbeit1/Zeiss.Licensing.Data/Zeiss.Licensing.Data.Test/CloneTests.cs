﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.Test;

[TestClass]
public class CloneTests
{
    #region Fields

    private const string _NAME = "Name";
    private const string _VERSION = "1.0";
    private const string _ID = "1234";

    #endregion

    #region Methods

    [TestMethod]
    public void Product_Clone_OK()
    {
        var product = new Product { Name = _NAME, Version = _VERSION, Id = _ID };
        var clone = (Product)product.Clone();
        Assert.IsNotNull(clone);
        Assert.AreEqual(_NAME, clone.Name);
        Assert.AreEqual(_VERSION, clone.Version);
        Assert.AreEqual(_ID, clone.Id);
    }

    [TestMethod]
    public void Feature_Clone_OK()
    {
        var feature = new Feature { Name = _NAME, Version = _VERSION, Id = _ID };
        var clone = (Feature)feature.Clone();
        Assert.IsNotNull(clone);
        Assert.AreEqual(_NAME, clone.Name);
        Assert.AreEqual(_VERSION, clone.Version);
        Assert.AreEqual(_ID, clone.Id);
    }

    [TestMethod]
    public void LicenseModel_Clone_OK()
    {
        var licenseModel = new LicenseModel { Name = _NAME, Id = _ID };
        var clone = (LicenseModel)licenseModel.Clone();
        Assert.IsNotNull(clone);
        Assert.AreEqual(_NAME, clone.Name);
        Assert.AreEqual(_ID, clone.Id);
    }

    [TestMethod]
    public void ProductFamily_Clone_OK()
    {
        var productFamily = new ProductFamily { Name = _NAME };
        var clone = (ProductFamily)productFamily.Clone();
        Assert.IsNotNull(clone);
        Assert.AreEqual(_NAME, clone.Name);
    }

    [TestMethod]
    public void ProductVariant_Clone_OK()
    {
        var productVariant = new ProductVariant { Name = _NAME, Version = _VERSION, Id = _ID };
        var clone = (ProductVariant)productVariant.Clone();
        Assert.IsNotNull(clone);
        Assert.AreEqual(_NAME, clone.Name);
        Assert.AreEqual(_VERSION, clone.Version);
        Assert.AreEqual(_ID, clone.Id);
    }

    [TestMethod]
    public void Product_Clone_Original_Not_Changed()
    {
        var product = new Product { Name = _NAME, Version = _VERSION, Id = _ID };
        product.ProductVariants = new List<ProductVariant> { new() { Name = _NAME } };
        var clone = (Product)product.Clone();
        Assert.IsNotNull(clone);
        clone.Name += _NAME;
        clone.ProductVariants.Add(new() { Name = _NAME + _VERSION });
        Assert.AreNotEqual(product.Name, clone.Name);
        Assert.AreNotEqual(product.ProductVariants.Count, clone.ProductVariants.Count);
        clone.ProductVariants.RemoveAt(0);
        Assert.AreNotEqual(product.ProductVariants[0].Name, clone.ProductVariants[0].Name);
    }

    [TestMethod]
    public void Feature_Clone_Original_Not_Changed()
    {
        var feature = new Feature { Name = _NAME, Version = _VERSION, Id = _ID };
        var clone = (Feature)feature.Clone();
        clone.LicenseModels.Add(new RefLicenseModel { Name = _NAME });
        Assert.IsNotNull(clone);
        clone.Name += _NAME;
        Assert.AreNotEqual(feature.Name, clone.Name);
        Assert.AreNotEqual(feature.LicenseModels.Count, clone.LicenseModels.Count);
    }

    [TestMethod]
    public void LicenseModel_Clone_Original_Not_Changed()
    {
        var licenseModel = new LicenseModel { Name = _NAME, Id = _ID };
        var clone = (LicenseModel)licenseModel.Clone();
        Assert.IsNotNull(clone);
        clone.Name += _NAME;
        Assert.AreNotEqual(licenseModel.Name, clone.Name);
        clone.SentinelRMSNetworkProperties = new LicenseModelPropertiesSentinelRMSNetwork();
        Assert.AreNotSame(licenseModel.SentinelRMSNetworkProperties, clone.SentinelRMSNetworkProperties);
    }

    [TestMethod]
    public void ProductFamily_Clone_Original_Not_Changed()
    {
        var productFamily = new ProductFamily { Name = _NAME };
        var clone = (ProductFamily)productFamily.Clone();
        Assert.IsNotNull(clone);
        clone.Name += _NAME;
        Assert.AreNotEqual(productFamily.Name, clone.Name);
    }

    [TestMethod]
    public void ProductVariant_Clone_Original_Not_Changed()
    {
        var productVariant = new ProductVariant { Name = _NAME, Version = _VERSION, Id = _ID };
        var clone = (ProductVariant)productVariant.Clone();
        Assert.IsNotNull(clone);
        clone.Name += _NAME;
        Assert.AreNotEqual(productVariant.Name, clone.Name);
        clone.UpgradeRules .Add(new());
        Assert.AreNotEqual(productVariant.UpgradeRules.Count, clone.UpgradeRules.Count);
    }

    #endregion
}
