﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Exceptions;
using Zeiss.Licensing.Data.Helpers;
using Zeiss.Licensing.Data.Models;
using Zeiss.Licensing.Data.TransferObjects;
using HostType = Zeiss.Licensing.Data.Models.HostType;

namespace Zeiss.Licensing.Data.Test;

[TestClass]
public class UnitTest1
{
    #region Fields

    private const string _MATERIAL_NUMBER = "123456789123456789";

    #endregion

    #region Methods

    [TestMethod]
    public void CanCloneUser()
    {
        var user = new User
        {
            FirstName = "test",
            AccountType = AccountType.SuperUser,
            AllowedAliases = new List<string>
            {
                "Test"
            },
            Roles = new List<Role>
            {
                new Role
                {
                    Name = "test"
                }
            },
            Modules = new List<Module>
            {
                new Module
                {
                    Name = "test"
                }
            }
        };

        var cloned = (User)user.Clone();
        Assert.AreNotEqual(user, cloned);
        Assert.AreNotEqual(user.Roles, cloned.Roles);
        Assert.AreNotEqual(user.Modules, cloned.Modules);
        Assert.AreNotEqual(user.AllowedAliases, cloned.AllowedAliases);
        Assert.AreEqual(user.FirstName, cloned.FirstName);
        Assert.AreEqual(user.AccountType, cloned.AccountType);

        for (var i = 0; i < user.AllowedAliases.Count; i++)
        {
            Assert.AreEqual(user.AllowedAliases[i], cloned.AllowedAliases[i]);
        }

        for (var i = 0; i < user.Roles.Count; i++)
        {
            Assert.AreEqual(user.Roles[i].Name, cloned.Roles[i].Name);
        }

        for (var i = 0; i < user.Modules.Count; i++)
        {
            Assert.AreEqual(user.Modules[i].Name, cloned.Modules[i].Name);
        }
    }

    [TestMethod]
    public void TestEMSAppSettingsNameAttribute()
    {
        var refProduct = new RefProduct { Id = "jkhkh", Name = "Name5", Version = "Version5" };
        var ref2 = (RefProduct)refProduct.Clone();
        ref2.Name = "Name XXX";

        var productFeature = new ProductFeature
        {
            Count = 3, Feature = new RefFeature { Id = "RefFId1", Name = "RefeatN", Version = "ReffV" },
            Id = "ProdFeatId2", LicenseModel = new RefLicenseModel { Id = "RefLMID1", Name = "RLMName" }
        };

        var pfClone = (ProductFeature)productFeature.Clone();
        pfClone.Feature.Name = "Clone";

        var prod = new Product
        {
            ActivationMethod = ActivationMethod.PARTIAL,
            ProductFeatures = new List<ProductFeature> { productFeature, pfClone }
        };

        var pClone = (Product)prod.Clone();

        var host = new HostType();

        var attrs = Attribute.GetCustomAttributes(host.GetType()); // Reflection.  

        // Displaying output.  
        foreach (var attr in attrs)
        {
            if (attr is EMSAppSettingsRecordNameAttribute)
            {
                var a = (EMSAppSettingsRecordNameAttribute)attr;

                var Name = a.GetName();
            }
        }
    }

    [TestMethod]
    public void TestProductVariantClone()
    {
        var productVariant = new ProductVariant
        {
            Name = "Test",
            Version = "1.0",
            Businessgroup = "CIT",
            UpgradeRules = new List<UpgradeRule>
            {
                CreateUpdateRule()
            }
        };

        var productVariantClone = (ProductVariant)productVariant.Clone();

        Assert.AreEqual(productVariant.Version, productVariantClone.Version);
        Assert.AreEqual(productVariant.UpgradeRules[0].ValidationList[0].Name, productVariantClone.UpgradeRules[0].ValidationList[0].Name);
        Assert.AreEqual(productVariant.UpgradeRules[0].OutputProductVariant.Name, productVariantClone.UpgradeRules[0].OutputProductVariant.Name);
    }

    [TestMethod]
    public void TestUserClone()
    {
        var user = new User
        {
            FirstName = "Test",
            LastName = "TestNach",
            OrganizationName = "orgnaem"
        };

        var userClone = (User)user.Clone();
        userClone.FirstName = "fursfd";

        Assert.AreEqual(user.OrganizationName, userClone.OrganizationName);
    }

    [TestMethod]
    public void TestRoleClone()
    {
        var role = new Role
        {
            Businessgroup = "BG",
            AdditionalGrants = new Dictionary<string, bool> { { "quantity", true }, { "Order", false } }
        };

        var roleClone = (Role)role.Clone();

        Assert.AreEqual(role.Businessgroup, roleClone.Businessgroup);
    }

    [TestMethod]
    public void TestException()
    {
        var error = new Error
        {
            Message = "Test",
            Code = "123",
            InnerError = new Error
            {
                Message = "InnerTest",
                Code = "Inner123",
                InnerError = new Error
                {
                    Message = "InnerInnerTest",
                    Code = "InnerInner123"
                }
            }
        };

        Exception ex = new ZeissLicensingException(error);
    }

    [TestMethod]
    public void RefProductVariant_Set_MaterialNumber_OK()
    {
        var productVariant = new RefProductVariant
        {
            Id = "1",
            Name = "TestProductVariant",
            Version = "1.0",
            MaterialNumber = _MATERIAL_NUMBER
        };

        Assert.AreEqual(_MATERIAL_NUMBER, productVariant.MaterialNumber);
        Assert.AreEqual("678912-3456-789", productVariant.FormattedMaterialNumber);
    }

    [TestMethod]
    public void RefProductVariant_Set_MaterialNumberFormatted_OK()
    {
        var productVariant = new RefProductVariant
        {
            Id = "1",
            Name = "TestProductVariant",
            Version = "1.0",
            MaterialNumber = _MATERIAL_NUMBER
        };

        var newMaterialNumber = "987654321987654321";

        productVariant.FormattedMaterialNumber = newMaterialNumber;

        Assert.AreEqual(newMaterialNumber, productVariant.MaterialNumber);
        Assert.AreEqual("432198-7654-321", productVariant.FormattedMaterialNumber);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentOutOfRangeException))]
    public void RefProductVariant_Set_MaterialNumber_TooLong()
    {
        const string materialNumberTooLong = "123456789123456789123456";

        _ = new RefProductVariant
        {
            Id = "1",
            Name = "TestProductVariant",
            Version = "1.0",
            MaterialNumber = materialNumberTooLong
        };
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentOutOfRangeException))]
    public void RefProductVariant_Set_MaterialNumber_NotNumeric()
    {
        const string materialNumberNotNumeric = "ABC456789123456789";

        _ = new RefProductVariant
        {
            Id = "1",
            Name = "TestProductVariant",
            Version = "1.0",
            MaterialNumber = materialNumberNotNumeric
        };
    }

    [TestMethod]
    public void RefProductVariant_Clone_OK()
    {
        const string materialNumber = "123456789123456789";

        var productVariant = new RefProductVariant
        {
            Id = "1",
            Name = "TestProductVariant",
            Version = "1.0",
            MaterialNumber = materialNumber
        };

        var clonedProductVariant = (RefProductVariant)productVariant.Clone();

        Assert.AreEqual(productVariant.Id, clonedProductVariant.Id);
        Assert.AreEqual(productVariant.Name, clonedProductVariant.Name);
        Assert.AreEqual(productVariant.Version, clonedProductVariant.Version);
        Assert.AreEqual(productVariant.MaterialNumber, clonedProductVariant.MaterialNumber);
        Assert.AreEqual(productVariant.FormattedMaterialNumber, clonedProductVariant.FormattedMaterialNumber);
    }

    private static UpgradeRule CreateUpdateRule()
    {
        return new UpgradeRule
        {
            ValidationList = new List<RefProductVariant>
            {
                new RefProductVariant
                {
                    Name = "RefProductVariant1",
                    Version = "1.0",
                },
                new RefProductVariant
                {
                    Name = "RefProductVariant2",
                    Version = "2.0",
                }
            },
            OutputProductVariant = new RefProductVariant
            {
                Name = "OutputVariant1",
                Version = "10.0",
            },
            InnerUpgradeRules = new List<UpgradeRule>
            {
                new UpgradeRule
                {
                    ValidationList = new List<RefProductVariant>
                    {
                        new RefProductVariant
                        {
                            Name = "RefProductVariant1.1",
                            Version = "1.1",
                        },
                        new RefProductVariant
                        {
                            Name = "RefProductVariant2.2",
                            Version = "2.2",
                        }
                    }
                },
                new UpgradeRule
                {
                    ValidationList = new List<RefProductVariant>
                    {
                        new RefProductVariant
                        {
                            Name = "RefProductVariant3.3",
                            Version = "1.3",
                        },
                        new RefProductVariant
                        {
                            Name = "RefProductVariant4.4",
                            Version = "2.4",
                        }
                    }
                },
            }
        };
    }

    #endregion
}
