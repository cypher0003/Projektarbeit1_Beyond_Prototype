﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Data.Test;

[TestClass]
public class UpgradeRuleUnitTest
{
    #region Methods

    [TestMethod]
    public void And_ValidationList_Empty_InnerRule_NULL_InputList_NULL()
    {
        var rule = new UpgradeRule();
        rule.Validate(null);

        Assert.AreEqual(0, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void And_ValidationList_Empty_InnerRule_NULL_InputList_Empty()
    {
        var rule = new UpgradeRule();
        rule.Validate(new List<RefProductVariant>());

        Assert.AreEqual(0, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void And_ValidationList_Empty_InnerRule_NULL_InputList_Not_Empty()
    {
        var rule = new UpgradeRule();
        rule.Validate(new List<RefProductVariant> { CreateProductVariant("1") });

        Assert.AreEqual(0, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void Or_ValidationList_Empty_InnerRule_NULL_InputList_NULL()
    {
        var rule = new UpgradeRule { CompareOperator = UpgradeCompareOperator.Or };
        rule.Validate(null);

        Assert.AreEqual(0, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void Or_ValidationList_Empty_InnerRule_NULL_InputList_Empty()
    {
        var rule = new UpgradeRule { CompareOperator = UpgradeCompareOperator.Or };
        rule.Validate(new List<RefProductVariant>());

        Assert.AreEqual(0, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void Or_ValidationList_Empty_InnerRule_NULL_InputList_Not_Empty()
    {
        var rule = new UpgradeRule { CompareOperator = UpgradeCompareOperator.Or };
        rule.Validate(new List<RefProductVariant> { CreateProductVariant("1") });

        Assert.AreEqual(0, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void And_ValidationList_Not_Empty_InnerRule_NULL_InputList_Not_Empty_OK()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule();
        productVariantList.ForEach(rule.ValidationList.Add);

        rule.Validate(productVariantList);

        Assert.AreEqual(productVariantList.Count, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void And_ValidationList_Not_Empty_InnerRule_Not_NULL_InputList_Not_Empty_OK()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule();
        productVariantList.ForEach(rule.ValidationList.Add);

        var innerUpgradeRule = new UpgradeRule
        {
            CompareOperator = UpgradeCompareOperator.Or
        };

        productVariantList.ForEach(innerUpgradeRule.ValidationList.Add);

        rule.InnerUpgradeRules.Add(innerUpgradeRule);

        rule.Validate(productVariantList);

        Assert.AreEqual(productVariantList.Count, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void And_ValidationList_Not_Empty_InnerRule_NULL_InputList_Not_Empty_Fail()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule();
        productVariantList.ForEach(rule.ValidationList.Add);

        productVariantList.RemoveAt(0);

        Assert.AreEqual(4, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);

        Assert.IsFalse(rule.Validate(productVariantList));
    }

    [TestMethod]
    public void Or_ValidationList_Not_Empty_InnerRule_NULL_InputList_Not_Empty_OK()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule { CompareOperator = UpgradeCompareOperator.Or };
        productVariantList.ForEach(rule.ValidationList.Add);

        productVariantList.RemoveAt(0);
        productVariantList.RemoveAt(0);

        rule.Validate(productVariantList);

        Assert.AreEqual(4, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void Or_ValidationList_Not_Empty_InnerRule_Not_NULL_InputList_Not_Empty_OK()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule { CompareOperator = UpgradeCompareOperator.Or };
        productVariantList.ForEach(rule.ValidationList.Add);

        var innerUpgradeRule = new UpgradeRule();
        innerUpgradeRule.CompareOperator = UpgradeCompareOperator.And;
        productVariantList.ForEach(innerUpgradeRule.ValidationList.Add);

        rule.InnerUpgradeRules.Add(innerUpgradeRule);

        productVariantList.RemoveAt(0);
        productVariantList.RemoveAt(0);

        rule.Validate(productVariantList);

        Assert.AreEqual(4, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    public void Or_ValidationList_Not_Empty_InnerRule_NULL_InputList_Not_Empty_Fail()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule { CompareOperator = UpgradeCompareOperator.Or };
        productVariantList.ForEach(rule.ValidationList.Add);

        productVariantList.Clear();
        productVariantList.Add(CreateProductVariant("5"));

        Assert.IsFalse(rule.Validate(productVariantList));

        Assert.AreEqual(4, rule.ValidationList.Count);
        Assert.IsNull(rule.OutputProductVariant);
    }

    [TestMethod]
    [DataRow(UpgradeCompareOperator.And, true, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.And, true, "1", "2")]
    [DataRow(UpgradeCompareOperator.And, false, "1")]
    [DataRow(UpgradeCompareOperator.And, false, "2")]
    [DataRow(UpgradeCompareOperator.And, false, "3")]
    [DataRow(UpgradeCompareOperator.And, false)]
    [DataRow(UpgradeCompareOperator.Or, true, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.Or, true, "1", "2")]
    [DataRow(UpgradeCompareOperator.Or, true, "1")]
    [DataRow(UpgradeCompareOperator.Or, true, "2")]
    [DataRow(UpgradeCompareOperator.Or, false, "3")]
    [DataRow(UpgradeCompareOperator.Or, false)]
    public void ValidateUpgradeRule(UpgradeCompareOperator compareOperator, bool validationSuccessful, params string[] ids)
    {
        var rule = new UpgradeRule
        {
            CompareOperator = compareOperator
        };

        rule.ValidationList.AddRange(CreateProductVariantList(new List<string> { "1", "2" }));

        var productVariantList = CreateProductVariantList(ids);

        var validationResult = rule.Validate(productVariantList);

        Assert.IsTrue(validationResult == validationSuccessful);
    }

    [TestMethod]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.And, true, "1", "2", "3", "4")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.And, true, "1", "2", "3", "4", "5")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.And, false, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.And, false, "1", "3", "4")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.And, false, "1", "3")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.And, false)]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, true, "1", "2", "3", "4")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, true, "1", "2", "3", "4", "5")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, true, "1", "2", "4")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, true, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, false, "1", "3", "4")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, false, "1", "3")]
    [DataRow(UpgradeCompareOperator.And, UpgradeCompareOperator.Or, false)]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "1", "2", "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "1", "2", "3", "4", "5")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "1", "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "2", "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "1", "2", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, true, "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, false, "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, false, "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.And, false)]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "2", "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "2", "3", "4", "5")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "2", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "2", "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "2", "3", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "2")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "2", "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "2", "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "1")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "2")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "3")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, true, "4")]
    [DataRow(UpgradeCompareOperator.Or, UpgradeCompareOperator.Or, false)]
    public void ValidateInnerUpgradeRule(UpgradeCompareOperator ruleOperator, UpgradeCompareOperator innerRuleOperator, bool validationSuccessful, params string[] ids)
    {
        var rule = new UpgradeRule
        {
            CompareOperator = ruleOperator
        };

        rule.ValidationList.AddRange(CreateProductVariantList(new List<string> { "1", "2" }));

        var innerUpgradeRule = new UpgradeRule
        {
            CompareOperator = innerRuleOperator
        };

        innerUpgradeRule.ValidationList.AddRange(CreateProductVariantList(new List<string> { "3", "4" }));

        rule.InnerUpgradeRules.Add(innerUpgradeRule);

        var productVariantList = CreateProductVariantList(ids);

        var validationResult = rule.Validate(productVariantList);

        Assert.IsTrue(validationResult == validationSuccessful);
    }

    [TestMethod]
    public void UpgradeRule_ToString()
    {
        var productVariantList = CreateProductVariantList(new List<string>
        {
            "1", "2", "3", "4"
        });

        var rule = new UpgradeRule();
        productVariantList.ForEach(rule.ValidationList.Add);

        var innerUpgradeRule = new UpgradeRule
        {
            CompareOperator = UpgradeCompareOperator.Or
        };

        productVariantList.ForEach(innerUpgradeRule.ValidationList.Add);

        rule.InnerUpgradeRules.Add(innerUpgradeRule);
        rule.InnerUpgradeRules.Add(innerUpgradeRule);

        var upgradeRuleAsString = rule.ToString();

        Assert.IsFalse(string.IsNullOrEmpty(upgradeRuleAsString));
        Assert.AreEqual(rule.InnerUpgradeRules.Count, upgradeRuleAsString.Count(c => c == '('));
        Assert.AreEqual(rule.InnerUpgradeRules.Count, upgradeRuleAsString.Count(c => c == ')'));
    }

    private static RefProductVariant CreateProductVariant(string id)
    {
        return new RefProductVariant
        {
            Id = id,
            Name = "Test product variant " + id,
            Version = "1.0",
            MaterialNumber = "000000000000000000"
        };
    }

    private static List<RefProductVariant> CreateProductVariantList(IEnumerable<string> ids)
    {
        return ids.Select(CreateProductVariant).ToList();
    }

    #endregion
}
