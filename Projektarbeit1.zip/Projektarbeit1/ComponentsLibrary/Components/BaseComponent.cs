﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Interfaces;
using Microsoft.Extensions.Logging;
using System.Reflection;
using System.Resources;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace ComponentsLibrary.Components;

/// <summary>
/// Base data for components
/// </summary>
public class BaseComponent : RefreshTokenComponent, IDisposable
{
    #region Constructors

    /// <summary>
    /// Dispose - remove eventhandler
    /// </summary>
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        NavHelper!.NavItemClicked -= NavHelper_NavItemClickedNew;
    }

    #endregion

    #region Properties

    [CascadingParameter]
    public Error? ErrorHandler { get; set; }

    /// <summary>
    /// Flag: Read Only
    /// </summary>
    public bool IsReadOnly { get; set; } = true;

    /// <summary>
    /// Flag: View Grant given
    /// </summary>
    [Parameter]
    public bool IsUserViewGranted { get; set; } = false;

    /// <summary>
    /// Flag: Edit Grant given
    /// </summary>
    [Parameter]
    public bool IsUserEditGranted { get; set; } = false;

    /// <summary>
    /// Flag: Add Grant given
    /// </summary>
    [Parameter]
    public bool IsUserAddGranted { get; set; } = false;

    /// <summary>
    /// Flag: Delete Grant given
    /// </summary>
    [Parameter]
    public bool IsUserDeleteGranted { get; set; } = false;

    /// <summary>
    /// Flag: View Object Info Grant given
    /// </summary>
    public bool IsUserViewObjectInfoGranted { get; set; } = false;

    /// <summary>
    /// Flag: Show delete dialog
    /// </summary>
    public bool ShowDeleteDialog { get; set; }

    /// <summary>
    /// Flag: Show list of search results otherwise details
    /// </summary>
    public bool IsListVisible { get; set; } = true;

    /// <summary>
    /// Flag: Edit disable
    /// </summary>
    public bool IsEditDisable { get; set; } = true;

    /// <summary>
    /// Flag: Loading more
    /// </summary>
    public bool LoadingMore { get; set; } = false;

    /// <summary>
    /// Flag: Loading more ended
    /// </summary>
    public bool LoadMoreEnded { get; set; } = true;

    /// <summary>
    /// Flag: Search visible
    /// </summary>
    public bool IsSearchVisible { get; set; } = true;

    /// <summary>
    /// Flag: Show Search Organization Dialog
    /// </summary>
    public bool ShowSearchOrganizationDialog { get; set; }

    /// <summary>
    /// Flag: Show Search Dialog. Can be used for a search dialog in the component
    /// </summary>
    public bool ShowSearchDialog { get; set; }

    /// <summary>
    /// Flag Show action column
    /// </summary>
    [Parameter]
    public bool ShowActionColumn { get; set; }

    /// <summary>
    /// Flag: Loading search
    /// </summary>
    public bool LoadingSearch { get; set; } = false;

    /// <summary>
    /// Flag: Saving search
    /// </summary>
    public bool IsSaving { get; set; }

    /// <summary>
    /// Flag: Loading search
    /// </summary>
    public bool IsLoading { get; set; }

    /// <summary>
    /// Flag Superuser
    /// </summary>
    public bool IsSuperUser { get; set; } = false;

    /// <summary>
    /// Flag AdminBusinessGroup
    /// </summary>
    public bool IsAdminBusinessGroup => !string.IsNullOrWhiteSpace(AdminBusinessGroup);

    /// <summary>
    /// AdminBusinessGroup
    /// </summary>
    public string AdminBusinessGroup { get; set; } = string.Empty;

    /// <summary>
    /// Search total count
    /// </summary>
    public int SearchTotalCount { get; set; } = 0;

    /// <summary>
    /// Invalid count
    /// </summary>
    public int InvalidCount { get; set; } = 0;

    /// <summary>
    /// Unauthorized count
    /// </summary>
    public int UnauthorizedCount { get; set; } = 0;

    /// <summary>
    /// Show page Size
    /// </summary>
    public int ShowPageSize { get; set; }

    /// <summary>
    /// Current page of datagrid
    /// </summary>
    public int CurrentPage { get; set; } = 1;

    /// <summary>
    /// Is load more disabled
    /// </summary>
    public virtual bool IsLoadMoreDisable => LoadMoreEnded;

    /// <summary>
    /// Selected search mode value
    /// </summary>
    public int SelectedSearchModeValue { get; set; }

    /// <summary>
    /// Saved Search mode value
    /// </summary>
    public int SavedSearchModeValue { get; set; }

    /// <summary>
    /// Current user
    /// </summary>
    public User? CurrentUser { get; set; }

    /// <summary>
    /// Error text
    /// </summary>
    public string ErrorZeissLicensingText { get; set; } = string.Empty;

    /// <summary>
    /// Search organization name
    /// </summary>
    public string SearchOrganization { get; set; } = string.Empty;

    /// <summary>
    /// Search Organization Dialog
    /// </summary>
    public SearchOrganizationDialog? SearchOrganizationDialog { get; set; }

    /// <summary>
    /// List of search modes
    /// </summary>
    public IEnumerable<SelectModel> SearchModeList { get; set; } = new List<SelectModel>();

    /// <summary>
    /// List of organization types
    /// </summary>
    public List<SelectModel> OrganizationTypeList { get; set; } = new List<SelectModel>();

    /// <summary>
    /// Selected organization type
    /// </summary>
    public int SelectedOrganizationTypeValue { get; set; } = 1;

    /// <summary>
    /// Selected device type id
    /// </summary>
    public string SelectedDeviceTypeId { get; set; } = string.Empty;

    /// <summary>
    /// Selected device type id
    /// </summary>
    public DeviceType? SelectedDeviceType
    {
        get { return DeviceTypes.FirstOrDefault(c => c.Id == SelectedDeviceTypeId); }
    }

    /// <summary>
    /// Download status color
    /// </summary>
    public Color DownloadStatusColor { get; set; } = Color.Success;

    /// <summary>
    /// Snackbar
    /// </summary>
    public SnackBarException SnackbarException { get; set; } = null!;

    /// <summary>
    /// Info dialog
    /// </summary>
    public InfoDialog? InfoDialog { get; set; }

    /// <summary>
    /// List of business groups
    /// </summary>
    public List<string> BusinessGroups { get; set; } = new List<string>();

    /// <summary>
    /// List of business groups with empty entry -> optional
    /// </summary>
    public List<string> BusinessGroupsWithEmpty { get; set; } = new List<string>();

    /// <summary>
    /// List of device types
    /// </summary>
    public List<DeviceType> DeviceTypes { get; set; } = new List<DeviceType>();

    /// <summary>
    /// Navigation item route
    /// </summary>
    public string NavItemRoute { get; set; } = string.Empty;

    /// <summary>
    /// Flag: Has nav item route
    /// </summary>
    public bool HasNavItemRoute { get; set; }

    /// <summary>
    /// User client
    /// </summary>
    [Inject]
    public IUserClient UserClient { get; set; } = null!;

    /// <summary>
    /// NavHelper
    /// </summary>
    [Inject]
    public INavHelper NavHelper { get; set; } = null!;

    /// <summary>
    /// Product client
    /// </summary>
    [Inject]
    public IProductClient ProductClient { get; set; } = null!;

    /// <summary>
    /// Application settings client
    /// </summary>
    [Inject]
    public IAppSettingClient AppSettingClient { get; set; } = null!;

    /// <summary>
    /// Logger
    /// </summary>
    [Inject]
    protected ILogger Logger { get; set; } = null!;

    /// <summary>
    /// Last used items provider
    /// </summary>
    [Inject]
    protected ILastUsedItemProvider LastUsedItemProvider { get; set; } = null!;

    /// <summary>
    /// Device type client
    /// </summary>
    [Inject]
    internal IDeviceTypeClient DeviceTypeClient { get; set; } = null!;

    #endregion

    #region Methods

    /// <summary>
    /// Set list visible, if nav item is clicked
    /// </summary>
    /// <param name="navItemroute">Name of nav item route</param>
    public void NavHelper_NavItemClickedNew(string navItemroute)
    {
        if (navItemroute == NavItemRoute)
        {
            IsListVisible = true;

            InvokeAsync(StateHasChanged);
        }
    }

    /// <summary>
    /// Search mode changed
    /// </summary>
    /// <param name="searchObject">Search object</param>
    /// <param name="newValue">new Search mode</param>
    public void OnSelectedSearchModeChanged(SearchObjectBase searchObject, int newValue)
    {
        try
        {
            SelectedSearchModeValue = newValue;
            searchObject.SearchPattern = (SearchPattern)newValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Trim text in SearchObject
    /// </summary>
    public void TrimSearchObject<T>(T searchObject)
    {
        try
        {
            var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var p in properties)
            {
                // Only work with strings
                if (p.PropertyType != typeof(string))
                {
                    continue;
                }

                // If not writable then cannot null it; if not readable then cannot check it's value
                if (!p.CanWrite || !p.CanRead)
                {
                    continue;
                }

                var mget = p.GetGetMethod(false);
                var mset = p.GetSetMethod(false);

                // Get and set methods have to be public
                if (mget == null)
                {
                    continue;
                }

                if (mset == null)
                {
                    continue;
                }

                var val = (string?)p.GetValue(searchObject, null);

                if (!string.IsNullOrWhiteSpace(val))
                {
                    val = val.Trim();
                    p.SetValue(searchObject, val, null);
                }
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Show the loading Icon
    /// </summary>
    /// <param name="load">Flag: True=Show Icon</param>
    public void SetLoading(bool load)
    {
        try
        {
            LoadingSearch = load;

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Initialization
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            List<string> listText = new();
            ResourceManager resourceManager = new(typeof(OrganizationResource));

            foreach (OrganizationType orgType in Enum.GetValues(typeof(OrganizationType)))
            {
                var text = resourceManager.GetString("ORGTYPE" + orgType.ToString().ToUpper());

                if (text != null)
                {
                    listText.Add(text);
                }
            }

            OrganizationTypeList = Enumerable.Range(1, listText.Count).Select(x => new SelectModel { Text = listText[x - 1], Value = x - 1 }).ToList();

            List<string> searchModes = new();
            resourceManager = new ResourceManager(typeof(SharedResource));

            foreach (SearchPattern pattern in Enum.GetValues(typeof(SearchPattern)))
            {
                var text = resourceManager.GetString("SEARCHMODE" + pattern.ToString().ToUpper());

                if (text != null)
                {
                    searchModes.Add(text);
                }
            }

            SearchModeList = Enumerable.Range(1, searchModes.Count).Select(x => new SelectModel { Text = searchModes[x - 1], Value = x - 1 });
            SelectedSearchModeValue = 2;

            if (null != NavHelper && HasNavItemRoute)
            {
                NavHelper!.NavItemClicked += NavHelper_NavItemClickedNew;
            }

            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    protected virtual void OnSelectOrgButtonClicked()
    {
        try
        {
            ShowSearchOrganizationDialog = true;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Show Organization delete dialog
    /// </summary>
    protected virtual async Task OnDeleteOrgButtonClicked()
    {
        try
        {
            ShowSearchOrganizationDialog = false;
            SearchOrganization = string.Empty;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    protected virtual void OnSelectOrganizationOKClick(object organization)
    {
        try
        {
            ShowSearchOrganizationDialog = false;
            SearchOrganization = OrganizationHelper.GetOrganizationText((Organization)organization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Load device types       
    /// </summary>
    protected virtual async Task LoadDeviceTypes()
    {
        try
        {
            DeviceTypes.Clear();
            PartialList<DeviceType> partialList = await DeviceTypeClient!.GetDeviceTypes(null);
            DeviceTypes = partialList.List;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Load device types       
    /// </summary>
    protected virtual async Task LoadBusinessGroups()
    {
        try
        {
            List<string> lBg = await ProductClient!.GetBusinessgroups();
            BusinessGroups = lBg.Distinct().ToList();
            BusinessGroupsWithEmpty.Add(string.Empty);
            BusinessGroupsWithEmpty.AddRange(BusinessGroups);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Load saved search modes and find the component-entry to preselect search mode
    /// </summary>
    /// <returns></returns>
    protected virtual async Task GetSavedSearchMode()
    {
        try
        {
            if (null == CurrentUser)
            {
                CurrentUser = await UserClient!.Authenticate();
            }

            if (null != CurrentUser && CurrentUser.SearchModes.TryGetValue(GetType().Name, out var mode) && Enum.TryParse(mode, out SearchPattern search))
            {
                SelectedSearchModeValue = SavedSearchModeValue = (int)search;
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Businessgroup selection changed
    /// </summary>
    /// <param name="searchObject">Search object</param>
    /// <param name="newValue">New value</param>
    protected void BusinessGroupValueChangedHandler(SearchObjectBase searchObject, string newValue)
    {
        try
        {
            if (searchObject is SearchObjectFeature feature)
            {
                feature.Businessgroup = newValue;
            }

            if (searchObject is SearchObjectProduct product)
            {
                product.Businessgroup = newValue;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected virtual async Task OnSearchClicked()
    {
        try
        {
            if (SelectedSearchModeValue != SavedSearchModeValue && null != CurrentUser)
            {
                _ = await UserClient!.UpdateSearchModes(CurrentUser.Id, (GetType().Name, ((SearchPattern)SelectedSearchModeValue).ToString()));
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Entitlement details discard button clicked
    /// </summary>
    protected virtual void OnDetailsDiscardButtonClicked()
    {
        try
        {
            IsListVisible = true;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Creates last used item
    /// </summary>
    /// <param name="id">Id</param>
    /// <param name="name">Name to display</param>
    /// <param name="type">Type</param>
    /// <param name="typeName">Name of type</param>
    /// <returns></returns>
    protected void CreateLastUsedItem(string id, string name, string type, string typeName)
    {
        try
        {
            if (null != LastUsedItemProvider)
            {
                LastUsedItem lastUsedItem = new()
                {
                    ObjectId = id,
                    ObjectName = name,
                    ObjectType = type,
                    ObjectTypeName = typeName
                };

                LastUsedItemProvider.AddItem(lastUsedItem);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
