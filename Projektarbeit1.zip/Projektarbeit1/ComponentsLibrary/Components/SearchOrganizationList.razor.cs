#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchOrganizationList : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback SelectedOrganizationChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool ShowEnable { get; set; } = false;

    /// <summary>
    /// Selected organization
    /// </summary>
    public Organization SelectedOrganization { get; set; } = new Organization();

    public SearchObjectOrganization SearchObjectOrganization { get; set; } = new SearchObjectOrganization();

    private List<Organization> Organizations { get; set; } = new List<Organization>();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectOrganization">Search object of organization</param>
    public async Task UpdateList(SearchObjectOrganization searchObjectOrganization)
    {
        try
        {
            LoadMoreEnded = !searchObjectOrganization.RestartLoadMore;
            Organizations.Clear();
            await UpdateDataList(searchObjectOrganization);

            if (Organizations.Any())
            {
                OnSelectedOrganizationChanged(Organizations[0]);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectOrganization">Search object of organization</param>
    public async Task UpdateDataList(SearchObjectOrganization searchObjectOrganization)
    {
        try
        {
            await SearchStarted.InvokeAsync(true);
            SearchObjectOrganization = searchObjectOrganization;
            searchObjectOrganization.PageSize = Convert.ToInt32(configuration["PageSize"]);

            if (!ShowEnable)
            {
                searchObjectOrganization.State = OrganizationState.ENABLE;
            }

            // Trim Strings of SearchObject
            TrimSearchObject(searchObjectOrganization);
            PartialList<Organization> partialList = await organizationClient.GetOrganizations(searchObjectOrganization);
            Organizations.AddRange(partialList.List);
            LoadMoreEnded = partialList.TotalCount <= partialList.PageIndex * partialList.PageSize;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await SearchStarted.InvokeAsync(false);
        }
    }

    /// <summary>
    /// Remove organization from list
    /// </summary>
    /// <param name = "organization">Organization to be removed</param>
    public void RemoveOrganization(Organization organization)
    {
        try
        {
            if (Organizations.Contains(organization))
            {
                Organizations.Remove(organization);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save organization to list
    /// </summary>
    /// <param name = "origOrg">Original organization(Update)</param>
    /// <param name = "org">Organization to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveOrganization(Organization origOrg, Organization org, bool isAdd)
    {
        try
        {
            if (isAdd)
            {
                Organizations.Insert(0, org);
                SelectedOrganization = org;
            }
            else
            {
                var idxOrig = Organizations.IndexOf(origOrg);

                if (idxOrig >= 0)
                {
                    Organizations.Insert(idxOrig, org);
                    Organizations.Remove(origOrg);
                }

                SelectedOrganization = org;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clear result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            Organizations.Clear();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectOrganization.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object? org, ActionType actionType)
    {
        try
        {
            if (null != org && SelectedOrganization != (Organization)org)
            {
                OnSelectedOrganizationChanged((Organization)org);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectOrganization.UseLoadMore = true;
            SearchObjectOrganization.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectOrganization);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected organization changed
    /// </summary>
    private void OnSelectedOrganizationChanged(Organization organization)
    {
        try
        {
            if (organization != SelectedOrganization)
            {
                SelectedOrganization = organization;
                SelectedOrganizationChanged.InvokeAsync(organization);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
