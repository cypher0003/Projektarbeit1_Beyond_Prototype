﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.ViewModels;
using Microsoft.Extensions.Logging;

namespace ComponentsLibrary.Components;

public partial class CollapseLockmode
{
    #region Properties

    [Parameter]
    public CollapseLockmodeViewModel CollapseLockmodeVM { get; set; } = new CollapseLockmodeViewModel();

    [Parameter]
    public EventCallback ActivateClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    [Parameter]
    public EventCallback<CollapseLockmodeViewModel> CollapseClicked { get; set; }

    [Parameter]
    public EventCallback<string> ManualActivationExceptionThrown { get; set; }

    [Parameter]
    public EventCallback<string> ManualActivationSuccessful { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Activate Button clicked
    /// </summary>
    private async Task OnActivateButtonClicked()
    {
        var canActivate = true;

        try
        {
            // mandatory input
            if (!CollapseLockmodeVM.SplitProductKeyVMs.Any(c => c.EntitlementSplitInfoItem.Quantity > 0))
            {
                string text = LIC["NOPRODUCTKEYWITHQUANTITY"];
                await ManualActivationExceptionThrown.InvokeAsync(text);
                canActivate = false;
                return;
            }

            IsLoading = true;
            CollapseLockmodeVM.ActivationRequest.ItemIdsWithQuantity = new Dictionary<string, int>();

            foreach (var pk in CollapseLockmodeVM.SplitProductKeyVMs.Where(c => c.EntitlementSplitInfoItem.Quantity > 0))
            {
                CollapseLockmodeVM.ActivationRequest.ItemIdsWithQuantity.Add(pk.ProductKeyId, pk.EntitlementSplitInfoItem.Quantity);
            }

            CollapseLockmodeVM.ActivationRequest.SerialNumber = CollapseLockmodeVM.SerialNumber;
            CollapseLockmodeVM.ActivationRequest.LockCriterion = CollapseLockmodeVM.LockCriterion;

            if (await ActivationHelper.Activate<CollapseLockmode>(CollapseLockmodeVM.ActivationRequest, activationClient, JSRuntime, logger))
            {
                await ManualActivationSuccessful.InvokeAsync(LIC["ACTIVATIONDOWNLOADOK"]);
            }
        }
        catch (Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ActivationHelper.TimeStamp + ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, EX);
            await ManualActivationExceptionThrown.InvokeAsync(ErrorZeissLicensingText);

            logger.LogError("{err}. ActivationRequest: {jso}", ErrorZeissLicensingText, JsonHelper.GetJSON(CollapseLockmodeVM.ActivationRequest));
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ActivationHelper.TimeStamp + ex.Message;
            await ManualActivationExceptionThrown.InvokeAsync(ErrorZeissLicensingText);

            logger.LogError("{err}. ActivationRequest: {jso}", ErrorZeissLicensingText, JsonHelper.GetJSON(CollapseLockmodeVM.ActivationRequest));
        }
        finally
        {
            if (canActivate)
            {
                IsLoading = false;
                StateHasChanged();
                await ActivateClicked.InvokeAsync("Activate");
            }
        }
    }

    /// <summary>
    /// Discard button clicked
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        CollapseLockmodeVM.Visible = false;
        DiscardClicked.InvokeAsync("Discard");
    }

    /// <summary>
    /// Collapse button clicked
    /// </summary>
    private void CollapseVisible()
    {
        CollapseClicked.InvokeAsync(CollapseLockmodeVM);
    }

    /// <summary>
    /// Split value changed
    /// </summary>
    private void OnSplitValueChanged()
    {
        StateHasChanged();
    }

    /// <summary>
    /// Set available 
    /// </summary>
    private void OnSetAvailableQuantity()
    {
        foreach (var splitProductKeyViewModel in CollapseLockmodeVM.SplitProductKeyVMs)
        {
            var maxAvailableQuantity = splitProductKeyViewModel.AllowMultipleActivation
                ? splitProductKeyViewModel.AvailableQuantity
                : splitProductKeyViewModel.AvailableQuantity > 0
                    ? 1
                    : 0;

            splitProductKeyViewModel.EntitlementSplitInfoItem.Quantity = maxAvailableQuantity;
        }
    }

    #endregion
}
