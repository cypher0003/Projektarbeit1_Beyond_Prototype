﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public static class ComponentDefaults
{
    #region Fields

    /// <summary>
    /// Materialnumber length
    /// </summary>
    public const int MATERIALNUMBER_LENGTH = 18;

    #endregion
}
