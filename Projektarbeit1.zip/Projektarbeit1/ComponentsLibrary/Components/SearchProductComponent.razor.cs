#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchProductComponent : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback SelectedProductChanged { get; set; }

    [Parameter]
    public EventCallback<List<Product>> SelectedProductsChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public Organization SelectedOrganization { get; set; } = new Organization();

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public Product SelectedProduct { get; set; } = new Product();

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsMultiselect { get; set; } = false;

    /// <summary>
    /// Selected products
    /// </summary>
    public List<Product> SelectedProducts { get; set; } = new();


    private SearchObjectProduct SearchObjectProduct { get; set; } = new SearchObjectProduct();

    private SearchProductList? SearchProductList { get; set; }

    private SearchProductMask? SearchProductMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Remove product from list
    /// </summary>
    /// <param name = "product">Product to be removed</param>
    public void RemoveProduct(Product product)
    {
        try
        {
            SearchProductList!.RemoveProduct(product);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save product to list
    /// </summary>
    /// <param name = "origProduct">Original product(Update)</param>
    /// <param name = "product">Product to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveProduct(Product origProduct, Product product, bool isAdd)
    {
        try
        {
            SearchProductList!.SaveProduct(origProduct, product, isAdd);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectProduct = new SearchObjectProduct
            {
                SearchPattern = SearchPattern.Normal
            };
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchProduct">Search object to load products</param>
    private async Task OnMaskSearchClicked(object searchProduct)
    {
        try
        {
            // List component loads products
            SearchObjectProduct = (SearchObjectProduct)searchProduct;
            await SearchProductList!.UpdateList(SearchObjectProduct);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected product has changed
    /// </summary>
    private void OnSelectedProductChanged(Product selProduct)
    {
        try
        {
            SelectedProduct = selProduct;
            SelectedProductChanged.InvokeAsync(selProduct);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected product has changed
    /// </summary>
    private void OnSelectedProductsChanged(List<Product> selProducts)
    {
        try
        {
            SelectedProducts = selProducts;
            SelectedProductsChanged.InvokeAsync(selProducts);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        try
        {
            SearchProductMask!.SetLoading((bool)showLoading);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
