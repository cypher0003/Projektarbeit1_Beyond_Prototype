#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class HistoryComponent : BaseComponent
{
    #region Properties

    public HistoryType HistoryType { get; set; } = HistoryType.User;

    public string Id { get; set; } = string.Empty;

    public string ShowId { get; set; } = string.Empty;

    private List<History> Historys { get; set; } = new List<History>();

    #endregion

    #region Methods

    /// <summary>
    /// Reset data
    /// </summary>
    /// <param name = "id">Id</param>
    /// <param name = "showId">Id shown in caption</param>
    /// <param name = "historyType">History Type (e.g. Entitlement, Product, ...)</param>
    public async Task Reset(string id, string showId, HistoryType historyType)
    {
        Id = id;
        ShowId = showId;
        HistoryType = historyType;
        DataGridReadDataEventArgs<History> eArgs = new(DataGridReadDataMode.Paging, null, null, 1, ShowPageSize, 1, 1);
        await OnReadData(eArgs);
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            ShowPageSize = Convert.ToInt32(configuration["ShowPageSize"]);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Load page wise
    /// </summary>
    /// <param name = "e"></param>
    /// <returns></returns>
    private async Task OnReadData(DataGridReadDataEventArgs<History> e)
    {
        try
        {
            IsLoading = true;
            Historys = new List<History>();
            StateHasChanged();
            PartialList<History> partialList = new();

            if (!string.IsNullOrWhiteSpace(Id))
            {
                switch (HistoryType)
                {
                    case HistoryType.Entitlement:
                        partialList = await historyClient.GetEntitlementHistory(Id, e.Page, e.PageSize);
                        break;
                    case HistoryType.License:
                        partialList = await historyClient.GetLicenseHistory(Id, e.Page, e.PageSize);
                        break;
                    case HistoryType.Product:
                        partialList = await historyClient.GetProductHistory(Id, e.Page, e.PageSize);
                        break;
                    case HistoryType.Productvariant:
                        partialList = await historyClient.GetProductVariantHistory(Id, e.Page, e.PageSize);
                        break;
                    case HistoryType.User:
                        partialList = await historyClient.GetUserHistory(Id, e.Page, e.PageSize);
                        break;
                    case HistoryType.Device:
                        partialList = await historyClient.GetDeviceHistory(Id, e.Page, e.PageSize);
                        break;
                }

                IsLoading = false;
                Historys = partialList.List;
                SearchTotalCount = partialList.TotalCount;
                StateHasChanged();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    #endregion
}
