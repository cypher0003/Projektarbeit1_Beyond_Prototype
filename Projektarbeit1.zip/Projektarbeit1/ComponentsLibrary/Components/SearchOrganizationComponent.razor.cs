#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchOrganizationComponent
{
    #region Properties

    [Parameter]
    public EventCallback<Organization> SelectedOrganizationChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public Organization SelectedOrganization { get; set; } = new Organization();

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool ShowEnable { get; set; } = false;

    private SearchObjectOrganization SearchObjectOrganization { get; set; } = new SearchObjectOrganization();

    private SearchOrganizationList? SearchOrganizationList { get; set; }

    private SearchOrganizationMask? SearchOrganizationMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Remove Organization from list
    /// </summary>
    /// <param name = "organization">Organization to be removed</param>
    public void RemoveOrganization(Organization organization)
    {
        try
        {
            SearchOrganizationList!.RemoveOrganization(organization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save organization to list
    /// </summary>
    /// <param name = "origOrganization">Original organization(Update)</param>
    /// <param name = "organization">Organization to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveOrganization(Organization origOrganization, Organization organization, bool isAdd)
    {
        try
        {
            SearchOrganizationList!.SaveOrganization(origOrganization, organization, isAdd);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectOrganization = new SearchObjectOrganization
            {
                SearchPattern = SearchPattern.Normal
            };
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchOrganization">Search object to load organizations</param>
    private async Task OnSearchClickedOrgComp(object searchOrganization)
    {
        try
        {
            // List component loads organizations
            SearchObjectOrganization = (SearchObjectOrganization)searchOrganization;
            await SearchOrganizationList!.UpdateList(SearchObjectOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected organization has changed
    /// </summary>
    private void OnSelectedOrganizationChanged(object selOrganization)
    {
        try
        {
            SelectedOrganization = (Organization)selOrganization;
            SelectedOrganizationChanged.InvokeAsync(SelectedOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        SearchOrganizationMask!.SetLoading((bool)showLoading);
    }

    #endregion
}
