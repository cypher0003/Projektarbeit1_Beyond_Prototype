#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchUserComponent : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback SelectedUserChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsCurrentUserSuperUser { get; set; } = false;

    public User SelectedUser { get; set; } = new User();

    private SearchObjectUser SearchObjectUser { get; set; } = new SearchObjectUser();

    private SearchUserList? SearchUserList { get; set; }

    private SearchUserMask? SearchUserMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Remove User from list
    /// </summary>
    /// <param name = "user">User to be removed</param>
    public void RemoveUser(User user)
    {
        SearchUserList!.RemoveUser(user);
    }

    /// <summary>
    /// Save user to list
    /// </summary>
    /// <param name = "origUser">Original user(Update)</param>
    /// <param name = "user">User to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveUser(User origUser, User user, bool isAdd)
    {
        SearchUserList!.SaveUser(origUser, user, isAdd);
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        SearchObjectUser = new SearchObjectUser
        {
            SearchPattern = SearchPattern.Normal
        };
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object tupleObj)
    {
        try
        {
            ActionClicked.InvokeAsync(tupleObj);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        try
        {
            SearchUserMask!.SetLoading((bool)showLoading);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchUser">Search object to load users</param>
    private async Task SearchClicked(object searchUser)
    {
        // List component loads users
        SearchObjectUser = (SearchObjectUser)searchUser;
        await SearchUserList!.UpdateList(SearchObjectUser);
    }

    /// <summary>
    /// Selected user has changed
    /// </summary>
    private void OnSelectedUserChanged(object selUser)
    {
        SelectedUser = (User)selUser;
        SelectedUserChanged.InvokeAsync(selUser);
    }

    #endregion
}
