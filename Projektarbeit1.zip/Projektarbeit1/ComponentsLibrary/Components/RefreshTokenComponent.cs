﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Auth;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.IdentityModel.Tokens.Jwt;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ComponentsLibrary.Components;

public class RefreshTokenComponent : ComponentBase
{
    #region Fields

    private DateTime lastUserAction = new();

    #endregion

    #region Properties

    [Inject]
    private Zeiss.Licensing.Data.HttpClientProvider.IHttpClientProvider? HttpClientProvider { get; set; }

    [Inject]
    private BlazorServerAuthStateCache? Cache { get; set; }

    #endregion

    #region Methods

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        var x = DateTime.Now - lastUserAction;

        if (x.TotalSeconds > 10)
        {
            lastUserAction = DateTime.Now;

            var handler = new JwtSecurityTokenHandler();

            var provider = (HttpClientProvider?)HttpClientProvider;

            if (provider != null && provider.IDToken != null && provider.IDToken != "")
            {
                var JwtIDToken = handler.ReadToken(provider.IDToken) as JwtSecurityToken;

                if (JwtIDToken != null)
                {
                    var oid = JwtIDToken.Claims.FirstOrDefault(c => c.Type == "oid")?.Value;
                    oid ??= string.Empty;

                    if (null != Cache && Cache.HasObjectId(oid))
                    {
                        var data = Cache.Get(oid);
                        data.LastUserAction = DateTime.UtcNow;
                    }
                }
            }
        }

        await base.OnAfterRenderAsync(firstRender);
    }

    #endregion
}
