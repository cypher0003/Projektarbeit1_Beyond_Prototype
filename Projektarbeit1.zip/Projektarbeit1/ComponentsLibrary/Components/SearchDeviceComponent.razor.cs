#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchDeviceComponent : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback SelectedDeviceChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool ShowDeletedDevices { get; set; } = true;

    public Device SelectedDevice { get; set; } = new Device();

    private SearchObjectDevice SearchObjectDevice { get; set; } = new SearchObjectDevice();

    private SearchDeviceList SearchDeviceList { get; set; } = new SearchDeviceList();

    private SearchDeviceMask SearchDeviceMask { get; set; } = new SearchDeviceMask();

    #endregion

    #region Methods

    /// <summary>
    /// Remove device from list
    /// </summary>
    /// <param name = "device">Device to be removed</param>
    public void RemoveDevice(Device device)
    {
        try
        {
            SearchDeviceList.RemoveDevice(device);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save device to list
    /// </summary>
    /// <param name = "origDevice">Original device(Update)</param>
    /// <param name = "device">Device to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveDevice(Device origDevice, Device device, bool isAdd)
    {
        try
        {
            SearchDeviceList.SaveDevice(origDevice, device, isAdd);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            SearchDeviceList.ClearList();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Set DeviceType
    /// </summary>
    /// <param name = "deviceTypeId">Device type id</param>
    public void SetSelectedDeviceTypeId(string deviceTypeId)
    {
        try
        {
            SearchDeviceMask.SetSelectedDeviceTypeId(deviceTypeId);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectDevice = new SearchObjectDevice();
            SearchObjectDevice.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchDevice">Search object to load devices</param>
    private async Task OnMaskSearchClicked(object searchDevice)
    {
        try
        {
            // List component loads devices
            SearchObjectDevice = (SearchObjectDevice)searchDevice;
            await SearchDeviceList.UpdateList(SearchObjectDevice);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected device has changed
    /// </summary>
    private void OnSelectedDeviceChanged(object selDevice)
    {
        try
        {
            SelectedDevice = (Device)selDevice;
            SelectedDeviceChanged.InvokeAsync(selDevice);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        try
        {
            SearchDeviceMask.SetLoading((bool)showLoading);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
