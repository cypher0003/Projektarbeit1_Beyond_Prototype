#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchDeviceMask : BaseComponent

{
    #region Properties

    [Parameter]
    public EventCallback SearchClicked { get; set; }

    public SearchObjectDevice SearchObjectDevice { get; set; } = new SearchObjectDevice();

    #endregion

    #region Methods

    /// <summary>
    /// Set DeviceType
    /// </summary>
    /// <param name = "deviceTypeId">Device type id</param>
    public void SetSelectedDeviceTypeId(string deviceTypeId)
    {
        try
        {
            SelectedDeviceTypeId = deviceTypeId;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            SearchObjectDevice = new SearchObjectDevice();
            await base.OnInitializedAsync();
            await base.GetSavedSearchMode();
            SearchObjectDevice.SearchPattern = (SearchPattern)SelectedSearchModeValue;
            await base.LoadDeviceTypes();
            DeviceTypes.Insert(0, new DeviceType());
            SelectedDeviceTypeId = DeviceTypes.First().Id;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    /// <param name = "customerType"></param>
    protected override async Task OnDeleteOrgButtonClicked()
    {
        try
        {
            await base.OnDeleteOrgButtonClicked();
            SearchObjectDevice.OrganizationId = string.Empty;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            SearchObjectDevice.UseLoadMore = true;
            SearchObjectDevice.RestartLoadMore = true;
            SearchObjectDevice.DeviceTypeId = SelectedDeviceType?.Id;
            SearchObjectDevice.DeviceTypeName = SelectedDeviceType?.Name;
            await SearchClicked.InvokeAsync(SearchObjectDevice);
            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(object organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick((Organization)organization);
            SearchObjectDevice.OrganizationId = ((Organization)organization).Id;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Discard button pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        try
        {
            ShowSearchOrganizationDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
