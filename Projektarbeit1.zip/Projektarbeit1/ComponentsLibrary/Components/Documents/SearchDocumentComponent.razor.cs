#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.ViewModels.Documents;

namespace ComponentsLibrary.Components.Documents;

public partial class SearchDocumentComponent
{
    #region Properties

    [Parameter]
    public EventCallback<DocumentViewModel> SelectedDocumentViewModelChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    public DocumentViewModel SelectedDocumentViewModel { get; set; } = new DocumentViewModel(new Document());

    private SearchDocumentList SearchDocumentList { get; set; } = new SearchDocumentList();

    #endregion

    #region Methods

    /// <summary>
    /// Remove documentViewModel from list
    /// </summary>
    /// <param name = "documentViewModel">DocumentViewModel to be removed</param>
    public async Task DeleteDocumentViewModel(DocumentViewModel documentViewModel)
    {
        try
        {
            await SearchDocumentList.DeleteDocumentViewModel(documentViewModel);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save documentViewModel to list
    /// </summary>
    /// <param name = "documentViewModel">DocumentViewModel to be saved</param>
    public async Task SaveDocument(DocumentViewModel documentViewModel)
    {
        try
        {
            await SearchDocumentList.SaveDocument(documentViewModel);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            SearchDocumentList.ClearList();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    public async Task UpdateList(SearchObjectDocument searchObjectDocument)
    {
        try
        {
            // List component loads devices
            await SearchDocumentList.UpdateList(searchObjectDocument);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    public void SetSelectedDocument(string documentId)
    {
        SearchDocumentList.SetSelectedDocument(documentId);
    }


    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected documentViewModel has changed
    /// </summary>
    private void OnSelectedDocumentViewModelChanged(DocumentViewModel selectedDocumentViewModel)
    {
        try
        {
            SelectedDocumentViewModel = selectedDocumentViewModel;
            SelectedDocumentViewModelChanged.InvokeAsync(selectedDocumentViewModel);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
