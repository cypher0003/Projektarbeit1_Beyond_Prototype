#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.ObjectModel;
using ComponentsLibrary.ViewModels.Documents;

namespace ComponentsLibrary.Components.Documents;

public partial class SearchDocumentList
{
    #region Properties

    [Parameter]
    public EventCallback<DocumentViewModel> SelectedDocumentViewModelChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    private ObservableCollection<DocumentViewModel> DocumentViewModels { get; set; } = new();

    private DocumentViewModel SelectedDocumentViewModel { get; set; } = new DocumentViewModel(new Document());

    private SearchObjectDocument SearchObjectDocument { get; set; } = new();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectDocument">Search object of device</param>
    public async Task UpdateList(SearchObjectDocument searchObjectDocument)
    {
        try
        {
            LoadMoreEnded = !searchObjectDocument.RestartLoadMore;
            DocumentViewModels.Clear();
            await UpdateDataList(searchObjectDocument);

            if (DocumentViewModels.Any())
            {
                OnSelectedDocumentViewModelChanged(DocumentViewModels.First());
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectDocument">Search object of device</param>
    public async Task UpdateDataList(SearchObjectDocument? searchObjectDocument)
    {
        try
        {
            if (IsSuperUser || CurrentUser.Roles.Any(c => c.GrantDocument >= GrantType.View))
            {
                if (null == searchObjectDocument)
                {
                    SelectedDocumentViewModel = new DocumentViewModel(new Document());
                    DocumentViewModels = new ObservableCollection<DocumentViewModel>();
                }
                else
                {
                    IsLoading = true;
                    await SearchStarted.InvokeAsync(true);

                    // Trim all Strings
                    TrimSearchObject(searchObjectDocument);
                    SearchObjectDocument = searchObjectDocument;
                    searchObjectDocument.PageSize = Convert.ToInt32(Configuration["PageSize"]);

                    // Trim Strings of SearchObject
                    TrimSearchObject(searchObjectDocument);
                    PartialList<Document> partialList = await DocumentClient.GetDocuments(searchObjectDocument);

                    foreach (var document in partialList.List)
                    {
                        DocumentViewModels.Add(new DocumentViewModel(document));
                    }

                    LoadMoreEnded = partialList.TotalCount <= partialList.PageIndex * partialList.PageSize;
                    StateHasChanged();
                }
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await SearchStarted.InvokeAsync(false);
            IsLoading = false;
        }
    }

    /// <summary>
    /// Remove DocumentViewModel from list
    /// </summary>
    /// <param name = "documentViewModel">DocumentViewModel to be removed</param>
    public async Task DeleteDocumentViewModel(DocumentViewModel documentViewModel)
    {
        try
        {
            if (DocumentViewModels.Contains(documentViewModel))
            {
                DocumentViewModels.Remove(documentViewModel);
            }

            await DocumentClient.DeleteDocument(documentViewModel.Document);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Save device to list
    /// </summary>
    /// <param name = "documentViewModel">Device to be saved</param>
    public async Task SaveDocument(DocumentViewModel documentViewModel)
    {
        try
        {
            documentViewModel.SaveToModel();

            if (string.IsNullOrWhiteSpace(documentViewModel.Document.Id))
            {
                documentViewModel.UpdateDocument(await DocumentClient.AddDocument(documentViewModel.Document));
                DocumentViewModels.Insert(0, documentViewModel);
            }
            else
            {
                await DocumentClient.UpdateDocument(documentViewModel.Document);
            }

            SelectedDocumentViewModel = documentViewModel;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
            throw;
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            DocumentViewModels = new ObservableCollection<DocumentViewModel>();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    public void SetSelectedDocument(string documentId)
    {
        var document = DocumentViewModels.SingleOrDefault(c => c.Document.Id == documentId);

        if (null != document)
        {
            SelectedDocumentViewModel = document;
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await UserClient.Authenticate();

            SearchObjectDocument.SearchPattern = SearchPattern.Normal;
            SearchObjectDocument.UseLoadMore = true;
            SearchObjectDocument.RestartLoadMore = true;
            LoadingMore = true;
            StateHasChanged();
            await UpdateList(SearchObjectDocument);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(DocumentViewModel? documentViewModel, ActionType actionType)
    {
        try
        {
            if (null != documentViewModel && SelectedDocumentViewModel != documentViewModel)
            {
                OnSelectedDocumentViewModelChanged(documentViewModel);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// More  Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectDocument.UseLoadMore = true;
            SearchObjectDocument.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectDocument);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private void OnSelectedDocumentViewModelChanged(DocumentViewModel? selectedDocumentViewModel)
    {
        try
        {
            if (null != selectedDocumentViewModel && selectedDocumentViewModel != SelectedDocumentViewModel)
            {
                SelectedDocumentViewModel = selectedDocumentViewModel;
                SelectedDocumentViewModelChanged.InvokeAsync(selectedDocumentViewModel);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
