#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchUserMask : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback SearchClicked { get; set; }

    [Parameter]
    public SearchObjectUser SearchObjectUser { get; set; } = new SearchObjectUser();

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            await base.OnInitializedAsync();
            await base.GetSavedSearchMode();
            SearchObjectUser.SearchPattern = (SearchPattern)SelectedSearchModeValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            SearchObjectUser.UseLoadMore = true;
            SearchObjectUser.RestartLoadMore = true;
            await SearchClicked.InvokeAsync(SearchObjectUser);
            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    /// <param name = "customerType"></param>
    protected override async Task OnDeleteOrgButtonClicked()
    {
        try
        {
            await base.OnDeleteOrgButtonClicked();
            SearchObjectUser.OrganizationId = string.Empty;
            SearchObjectUser.OrganizationName = string.Empty;
            SearchObjectUser.OrganizationNumber = string.Empty;
            SearchOrganization = string.Empty;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(object organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick((Organization)organization);
            SearchObjectUser.OrganizationId = ((Organization)organization).Id;
            SearchObjectUser.OrganizationName = ((Organization)organization).Name;
            SearchObjectUser.OrganizationNumber = ((Organization)organization).Number;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Discard button pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        try
        {
            ShowSearchOrganizationDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
