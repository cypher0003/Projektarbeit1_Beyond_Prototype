#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchProductVariantMask : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback<SearchObjectProductVariant> SearchClicked { get; set; }

    public SearchObjectProductVariant SearchObjectProductVariant { get; set; } = new SearchObjectProductVariant();

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            SearchObjectProductVariant = new SearchObjectProductVariant();
            await base.OnInitializedAsync();
            await base.GetSavedSearchMode();
            SearchObjectProductVariant.SearchPattern = (SearchPattern)SelectedSearchModeValue;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            SearchObjectProductVariant.Materialnumber = SearchObjectProductVariant.Materialnumber?.Replace("-", "");

            if (!string.IsNullOrWhiteSpace(SearchObjectProductVariant.Materialnumber) &&
                (SearchObjectProductVariant.SearchPattern == SearchPattern.Normal || SearchObjectProductVariant.SearchPattern == SearchPattern.Exact))
            {
                SearchObjectProductVariant.Materialnumber = SearchObjectProductVariant.Materialnumber.PadLeft(ComponentDefaults.MATERIALNUMBER_LENGTH, '0');
            }

            SearchObjectProductVariant.UseLoadMore = true;
            SearchObjectProductVariant.RestartLoadMore = true;
            await SearchClicked.InvokeAsync(SearchObjectProductVariant);
            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
