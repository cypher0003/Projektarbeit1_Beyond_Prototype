﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchUserList : BaseComponent
{
    #region Fields

    private List<Organization> OrganizationsCache = new();

    #endregion

    #region Properties

    [Parameter]
    public EventCallback SelectedUserChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsCurrentUserSuperUser { get; set; } = false;

    public SearchObjectUser SearchObjectUser { get; set; } = new SearchObjectUser();

    public UserViewModel SelectedUserVM { get; set; } = new UserViewModel(new User());

    private List<UserViewModel> UserVMs { get; set; } = new List<UserViewModel>();

    private bool IsUserHimself => SelectedUserVM?.Id == CurrentUser?.Id && null != SelectedUserVM && !IsCurrentUserSuperUser;

    private string SelectedPublisherFilter { get; set; } = string.Empty;

    private string SelectedAdminBusinessFilter { get; set; } = string.Empty;

    private string SelectedEnabledFilter { get; set; } = string.Empty;

    private List<string> AdminBusinessGroups { get; set; } = new List<string>();

    private List<string> Publishers { get; set; } = new List<string>();

    private List<string> StatusList { get; set; } = new List<string>();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name="searchObjectUser">Search object of device</param>
    public async Task UpdateList(SearchObjectUser searchObjectUser)
    {
        try
        {
            LoadMoreEnded = !searchObjectUser.RestartLoadMore;
            UserVMs.Clear();
            await UpdateDataList(searchObjectUser);

            if (UserVMs.Any())
            {
                OnSelectedUserChanged(UserVMs.First());
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name="searchObjectUser">Search object of user</param>
    public async Task UpdateDataList(SearchObjectUser? searchObjectUser)
    {
        try
        {
            if (null == searchObjectUser)
            {
                SelectedUserVM = new UserViewModel(new User());
                UserVMs = new List<UserViewModel>();
            }
            else
            {
                IsLoading = true;

                // Reset temp vars
                AdminBusinessGroups.Clear();
                StatusList.Clear();

                await SearchStarted.InvokeAsync(true);

                SearchObjectUser = searchObjectUser;

                // Load all
                searchObjectUser.PageSize = 1000000;

                // Trim Strings of SearchObject
                TrimSearchObject(searchObjectUser);
                PartialList<User> partialList = await userClient.GetUsers(searchObjectUser);

                foreach (var user in partialList.List)
                {
                    UserViewModel userVm = new(user);
                    await SetOrganizations(userVm, user);

                    if (!string.IsNullOrWhiteSpace(userVm.AdminBusinessgroup) && !AdminBusinessGroups.Contains(userVm.AdminBusinessgroup))
                    {
                        AdminBusinessGroups.Add(userVm.AdminBusinessgroup);
                    }

                    if (!StatusList.Contains(userVm.Enabled))
                    {
                        StatusList.Add(userVm.Enabled);
                    }

                    UserVMs.Add(userVm);
                }

                StateHasChanged();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await SearchStarted.InvokeAsync(false);
            IsLoading = false;
        }
    }

    /// <summary>
    /// Remove user from list
    /// </summary>
    /// <param name="user">User to be removed</param>
    public void RemoveUser(User user)
    {
        var userVM = UserVMs.FirstOrDefault(c => c.Id == user.Id);

        if (null != userVM && UserVMs.Contains(userVM))
        {
            UserVMs.Remove(userVM);
        }
    }

    /// <summary>
    /// Save user to list
    /// </summary>
    /// <param name="origUser">Original user(Update)</param>
    /// <param name="user">User to be saved</param>
    /// <param name="isAdd">Flag, if Add or Update</param>
    public void SaveUser(User origUser, User user, bool isAdd)
    {
        if (isAdd)
        {
            UserViewModel userVM = new(user);
            UserVMs.Insert(0, userVM);
            SelectedUserVM = userVM;
        }
        else
        {
            UserViewModel userVM = new(user);
            var origUserVM = UserVMs.FirstOrDefault(c => c.Id == origUser.Id);

            if (origUserVM != null)
            {
                var idxOrig = UserVMs.IndexOf(origUserVM);

                if (idxOrig >= 0)
                {
                    UserVMs.Insert(idxOrig, userVM);
                    UserVMs.Remove(origUserVM);
                }
            }

            SelectedUserVM = userVM;
        }
    }


    /// <summary> 
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            CurrentUser = await userClient.Authenticate();
            SearchObjectUser.SearchPattern = SearchPattern.Normal;

            Publishers.Add(SharedResource.CHANNELPARTNER);
            Publishers.Add(SharedResource.PUBLISHER);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object? userVM, ActionType actionType, AccountType accountType = AccountType.User, PersonType personType = PersonType.Publisher)
    {
        try
        {
            if (null != userVM && SelectedUserVM != (UserViewModel)userVM)
            {
                OnSelectedUserChanged((UserViewModel)userVM);
            }

            // Check if user is editable
            if ((!IsEditDisable && (actionType == ActionType.Edit || actionType == ActionType.Delete)) || actionType == ActionType.Add || actionType == ActionType.View)
            {
                Tuple<ActionType, AccountType, PersonType> tuple = new(actionType, accountType, personType);
                ActionClicked.InvokeAsync(tuple);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Set organizations
    /// </summary>
    /// <param name="userVm">User VM</param>
    /// <param name="user">User</param>
    private async Task SetOrganizations(UserViewModel userVm, User user)
    {
        try
        {
            if (!user.IsPublisher)
            {
                List<string> names = new();

                foreach (var number in user.OrganizationNumbers)
                {
                    var foundOrg = OrganizationsCache.FirstOrDefault(c => c.Number == number);

                    if (null == foundOrg)
                    {
                        foundOrg = await organizationClient.GetByNumber(number);
                        OrganizationsCache.Add(foundOrg);
                    }

                    names.Add(foundOrg.Name);
                }

                userVm.Organizations = string.Join(", ", names);
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Selected user changed
    /// </summary>
    private void OnSelectedUserChanged(UserViewModel seluserVM)
    {
        try
        {
            if (null != seluserVM && seluserVM != SelectedUserVM)
            {
                SelectedUserVM = seluserVM;
                IsEditDisable = SelectedUserVM.Id == CurrentUser?.Id && !IsCurrentUserSuperUser;
                SelectedUserChanged.InvokeAsync(seluserVM.User);

                if (IsUserHimself)
                {
                    SnackbarException!.ShowMessage(L["USERHIMSELF"]);
                }
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
