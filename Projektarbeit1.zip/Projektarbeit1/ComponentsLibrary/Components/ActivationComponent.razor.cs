#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Blazorise.Components;
using Blazorise;
using Zeiss.Licensing.Data.TransferObjects.V1;

namespace ComponentsLibrary.Components;

public partial class ActivationComponent : BaseComponent
{
    #region Fields

    private Alert _ErrorZeissLicensingManualAlert = new();
    private Alert _DownloadManualAlert = new();

    #endregion

    #region Properties

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    [Parameter]
    public EventCallback ManualActivationSuccessful { get; set; }


    public Entitlement Entitlement { get; set; } = new();

    private ActivationViewModel ActivationVM { get; set; } = new();

    #endregion

    #region Methods

    /// <summary>
    /// Show activation component
    /// </summary>
    /// <param name="entitlement">Entitlement</param>
    /// <param name="deviceTypeId">Device type id</param>
    public async Task ShowActivation(Entitlement entitlement, string deviceTypeId)
    {
        Entitlement = entitlement;

        ActivationVM = new ActivationViewModel
        {
            IsEntitlementActivation = true,
            ProductKey = Entitlement.EntitlementId,
            ShowManualAlert = false,
            IsManualLoading = true,
            IsActivationMode = true
        };

        SelectedDeviceTypeId = deviceTypeId;

        await LoadDeviceTypes();
        ActivationVM.ValidationErrorText = DeviceHelper.CreateValidationErrorText(SelectedDeviceType);

        StateHasChanged();

        await ShowActivatableItems(new List<string> { entitlement.EntitlementId });
        ActivationVM.IsManualLoading = false;
        StateHasChanged();
    }

    /// <summary>
    /// Shows the activatable items
    /// </summary>
    /// <param name="itemIds"></param>
    /// <param name="deviceName"></param>
    /// <param name="getActivatableItemsResponse"></param>
    /// <returns></returns>
    public async Task ShowActivatableItems(string itemIds, string deviceName, GetActivatableItemsResponse getActivatableItemsResponse)
    {
        ActivationVM = new ActivationViewModel
        {
            IsEntitlementActivation = false,
            ProductKey = itemIds,
            ShowManualAlert = false,
            IsManualLoading = false,
            IsActivationMode = true,
            ActivationRequest = new ActivationRequest
            {
                DeviceName = deviceName
            }
        };

        await ShowActivatableItems(itemIds.Split(',').ToList(), getActivatableItemsResponse);
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingManualAlert.Show();
        }
    }

    /// <summary>
    /// Shows the activatable items
    /// </summary>
    /// <param name="pks">List of product keys/entitlement ids</param>
    /// <param name="getActivatableItemsResponse"></param>
    /// <returns></returns>
    private async Task ShowActivatableItems(List<string> pks, GetActivatableItemsResponse? getActivatableItemsResponse = null)
    {
        await _ErrorZeissLicensingManualAlert.Hide();

        ActivationVM.ListOfCollapseVMs.Clear();

        getActivatableItemsResponse ??= await ActivationClient.GetActivatableItems(pks);

        // Any activatable items ?
        if (null != getActivatableItemsResponse.ActivatableItems && getActivatableItemsResponse.ActivatableItems.Count > 0)
        {
            var groupedLockingModeList = getActivatableItemsResponse.ActivatableItems
                                                                    .GroupBy(c => c.LockingMode)
                                                                    .ToList();

            if (groupedLockingModeList.Count > 0)
            {
                ActivationVM.IsActivationMode = true;

                foreach (var group in groupedLockingModeList)
                {
                    CollapseLockmodeViewModel collapseLockModeVM = new()
                    {
                        ActivationRequest = ActivationVM.ActivationRequest,
                        LockCriterion = group.Key,
                        IsEntitlementActivation = ActivationVM.IsEntitlementActivation
                    };

                    collapseLockModeVM.FillProductKeys(group);
                    ActivationVM.ListOfCollapseVMs.Add(collapseLockModeVM);
                }

                ActivationVM.ListOfCollapseVMs.Last().Visible = true;
                StateHasChanged();
            }
        }
        else
        {
            throw new ArgumentException(LicenseResource.MANUALACTIVATIONNOACTIVATABLEITEMS);
        }
    }

    private void ValidateDeviceName(ValidatorEventArgs e)
    {
        e.Status = DeviceHelper.ValidateDeviceName(e.Value?.ToString(), SelectedDeviceType);

        // Change state of activation if changed
        ActivationVM.SetStateOfInvalidName(e.Status == ValidationStatus.Error);
    }

    /// <summary>
    /// Discard button clicked
    /// </summary>
    private async Task OnDiscardClicked()
    {
        try
        {
            await _ErrorZeissLicensingManualAlert.Hide();
            ActivationVM.ProductKey = string.Empty;
            ActivationVM.ActivationRequest = new ActivationRequest();
            ActivationVM.IsActivationMode = false;
            ActivationVM.ListOfCollapseVMs.Clear();
            await DiscardClicked.InvokeAsync();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Activate button of lockMode clicked
    /// </summary>
    private async Task OnActivateClicked()
    {
        try
        {
            if (ActivationVM.IsEntitlementActivation)
            {
                // Refresh Available quantity
                PartialList<Entitlement> list = await EntitlementClient.GetEntitlements(new SearchObjectEntitlement
                {
                    EntitlementId = Entitlement.EntitlementId.Trim(),
                    SearchPattern = SearchPattern.Exact
                });

                if (list.List.Count > 0)
                {
                    Entitlement = list.List[0];
                }
            }
        }
        catch (Exception ex)
        {
            ActivationVM.ErrorZeissLicensingManualText = ex.Message;
            await _ErrorZeissLicensingManualAlert.Show();
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Exception thrown at manual activation
    /// </summary>
    private void OnManualActivationExceptionThrown(string errorZeissLicensingText)
    {
        try
        {
            ActivationVM.ErrorZeissLicensingManualText = errorZeissLicensingText;
            _ErrorZeissLicensingManualAlert.Show();
        }
        catch (Exception ex)
        {
            ActivationVM.ErrorZeissLicensingManualText = ex.Message;
            _ErrorZeissLicensingManualAlert.Show();
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Exception thrown at manual activation
    /// </summary>
    private async Task OnManualActivationSuccessful(string text)
    {
        try
        {
            ActivationVM.IsActivationMode = false;

            DownloadStatusColor = Color.Success;
            ActivationVM.DownloadManualText = text;
            ActivationVM.ShowManualAlert = true;
            await _DownloadManualAlert.Show();

            await ManualActivationSuccessful.InvokeAsync();
        }
        catch (Exception ex)
        {
            ActivationVM.ErrorZeissLicensingManualText = ex.Message;
            await _ErrorZeissLicensingManualAlert.Show();
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Collapse (header) clicked
    /// </summary>
    private void OnCollapseClicked(CollapseLockmodeViewModel collapseLockModeVM)
    {
        try
        {
            // Change visibility
            collapseLockModeVM.Visible = !collapseLockModeVM.Visible;

            if (collapseLockModeVM.Visible)
            {
                ActivationVM.ListOfCollapseVMs.ForEach(coll =>
                {
                    if (coll != collapseLockModeVM)
                    {
                        coll.Visible = false;
                    }
                });
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
