#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.ViewModels;

namespace ComponentsLibrary.Components;

public partial class SearchDeviceList : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback SelectedDeviceChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool ShowDeletedDevices { get; set; } = true;


    public Device SelectedDevice { get; set; } = new Device();

    public SearchObjectDevice SearchObjectDevice { get; set; } = new SearchObjectDevice();

    public override bool IsLoadMoreDisable => Devices.Count == 0 || base.IsLoadMoreDisable;

    private List<Device> Devices { get; set; } = new List<Device>();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectDevice">Search object of device</param>
    public async Task UpdateList(SearchObjectDevice searchObjectDevice)
    {
        try
        {
            LoadMoreEnded = !searchObjectDevice.RestartLoadMore;
            Devices.Clear();
            await UpdateDataList(searchObjectDevice);

            if (Devices.Any())
            {
                OnSelectedDeviceChanged(Devices[0]);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectDevice">Search object of device</param>
    public async Task UpdateDataList(SearchObjectDevice searchObjectDevice)
    {
        try
        {
            await SearchStarted.InvokeAsync(true);

            // Trim all Strings
            TrimSearchObject(searchObjectDevice);
            SearchObjectDevice = searchObjectDevice;
            searchObjectDevice.PageSize = Convert.ToInt32(configuration["PageSize"]);

            // Trim Strings of SearchObject
            TrimSearchObject(searchObjectDevice);
            PartialList<Device> partialList = await deviceClient.GetDevices(searchObjectDevice);
            var devices = ShowDeletedDevices ? partialList.List : partialList.List.Where(c => !c.IsDeleted).ToList();
            Devices.AddRange(devices);
            LoadMoreEnded = partialList.TotalCount <= partialList.PageIndex * partialList.PageSize;
            StateHasChanged();
            await SearchStarted.InvokeAsync(false);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Remove device from list
    /// </summary>
    /// <param name = "device">Device to be removed</param>
    public void RemoveDevice(Device device)
    {
        try
        {
            if (Devices.Contains(device))
            {
                Devices.Remove(device);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save device to list
    /// </summary>
    /// <param name = "origDevice">Original device(Update)</param>
    /// <param name = "device">Device to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveDevice(Device origDevice, Device device, bool isAdd)
    {
        try
        {
            if (isAdd)
            {
                Devices.Insert(0, device);
                SelectedDevice = device;
            }
            else
            {
                var idxOrig = Devices.IndexOf(origDevice);

                if (idxOrig >= 0)
                {
                    Devices.Insert(idxOrig, device);
                    Devices.Remove(origDevice);
                }
                else
                {
                    Devices.Add(device);
                }

                SelectedDevice = device;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            Devices = new List<Device>();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectDevice.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object? device, ActionType actionType)
    {
        try
        {
            if (null != device && SelectedDevice != (Device)device)
            {
                OnSelectedDeviceChanged((Device)device);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// More  Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectDevice.UseLoadMore = true;
            SearchObjectDevice.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectDevice);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected device changed
    /// </summary>
    /// <param name = "device">Device</param>
    private void OnSelectedDeviceChanged(Device device)
    {
        try
        {
            if (device != SelectedDevice)
            {
                SelectedDevice = device;
                SelectedDeviceChanged.InvokeAsync(device);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
