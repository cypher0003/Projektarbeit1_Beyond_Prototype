#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchProductList : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback<Product> SelectedProductChanged { get; set; }

    [Parameter]
    public EventCallback<List<Product>> SelectedProductsChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool OnlyEnabledProducts { get; set; } = false;

    [Parameter]
    public bool OnlyDraftEnabledProducts { get; set; } = false;

    [Parameter]
    public bool IsMultiselect { get; set; } = false;

    [Parameter]
    public bool ShowMaterialnumbers { get; set; } = false;


    /// <summary>
    /// Selected product
    /// </summary>
    public ProductViewModel SelectedProduct { get; set; } = new();

    /// <summary>
    /// Selected products
    /// </summary>
    public List<ProductViewModel> SelectedProducts { get; set; } = new();

    public SearchObjectProduct SearchObjectProduct { get; set; } = new SearchObjectProduct();

    public bool LoadingMaterialnumbers { get; set; }

    private List<ProductViewModel> ProductVMs { get; set; } = new List<ProductViewModel>();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectProduct">Search object of organization</param>
    public async Task UpdateList(SearchObjectProduct searchObjectProduct)
    {
        try
        {
            LoadMoreEnded = !searchObjectProduct.RestartLoadMore;
            ProductVMs.Clear();
            InvalidCount = 0;
            SearchTotalCount = 0;
            UnauthorizedCount = 0;

            await UpdateDataList(searchObjectProduct);

            if (ProductVMs.Any())
            {
                OnSelectedProductChanged(ProductVMs[0]);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectProduct">Search object of product</param>
    public async Task UpdateDataList(SearchObjectProduct searchObjectProduct)
    {
        try
        {
            await SearchStarted.InvokeAsync(true);
            SearchObjectProduct = searchObjectProduct;
            searchObjectProduct.PageSize = Convert.ToInt32(configuration["PageSize"]);

            // Trim Strings of SearchObject
            TrimSearchObject(searchObjectProduct);
            PartialList<Product> partialList = await productClient.GetProducts(searchObjectProduct);
            var prodList = partialList.List;

            if (OnlyDraftEnabledProducts)
            {
                prodList = prodList.Where(c => c.State == ProductState.ENABLE || c.State == ProductState.DRAFT).ToList();
            }

            if (OnlyEnabledProducts)
            {
                prodList = prodList.Where(c => c.State == ProductState.ENABLE).ToList();
            }

            ProductVMs.AddRange(prodList.Select(c => new ProductViewModel(c)));
            InvalidCount += partialList.InvalidCount;
            SearchTotalCount = partialList.TotalCount;
            UnauthorizedCount += partialList.UnauthorizedCount;
            LoadMoreEnded = partialList.IsLastPageIndex;
            StateHasChanged();

            // Load material numbers
            if (ShowMaterialnumbers)
            {
                LoadingMaterialnumbers = true;
                _ = LoadMaterialnumbers(prodList);
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await SearchStarted.InvokeAsync(false);
        }
    }

    /// <summary>
    /// Stop loading materialnumbers
    /// </summary>
    public void StopLoadingMaterialnumbers()
    {
        LoadingMaterialnumbers = false;
    }

    /// <summary>
    /// Remove product from list
    /// </summary>
    /// <param name = "product">Product to be removed</param>
    public void RemoveProduct(Product product)
    {
        try
        {
            var pvm = ProductVMs.First(c => c.Product == product);

            if (ProductVMs.Contains(pvm))
            {
                ProductVMs.Remove(pvm);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save product to list
    /// </summary>
    /// <param name = "origProduct">Original product(Update)</param>
    /// <param name = "product">Product to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveProduct(Product origProduct, Product product, bool isAdd)
    {
        try
        {
            ProductViewModel productViewModel = new(product);

            if (isAdd)
            {
                ProductVMs.Insert(0, productViewModel);
            }
            else
            {
                var originalProductViewModel = ProductVMs.FirstOrDefault(c => c.Product.Id == origProduct.Id);

                if (null != originalProductViewModel)
                {
                    var idxOrig = ProductVMs.IndexOf(originalProductViewModel);

                    if (idxOrig >= 0)
                    {
                        ProductVMs.Insert(idxOrig, productViewModel);
                        ProductVMs.Remove(originalProductViewModel);
                    }
                }
                else
                {
                    ProductVMs.Add(productViewModel);
                }
            }

            SelectedProduct = productViewModel;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears selection
    /// </summary>
    public void ClearSelection()
    {
        SelectedProduct = new ProductViewModel();
        SelectedProducts.Clear();
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectProduct.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object? product, ActionType actionType)
    {
        try
        {
            if (null != product && SelectedProduct != (ProductViewModel)product)
            {
                OnSelectedProductChanged((ProductViewModel)product);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectProduct.UseLoadMore = true;
            SearchObjectProduct.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectProduct);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Load materialnumbers
    /// </summary>
    /// <param name="prodList">List of products</param>
    private async Task LoadMaterialnumbers(List<Product> prodList)
    {
        foreach (var product in prodList)
        {
            if (LoadingMaterialnumbers)
            {
                try
                {
                    var prod = await productClient.GetById(product.Id);

                    if (prod.ProductVariants != null && prod.ProductVariants.Any())
                    {
                        var matNumbers = string.Join(",", prod.ProductVariants.Select(c => c.FormattedMaterialNumber));
                        ProductVMs.First(c => c.Product == product).MaterialNumbers = matNumbers;
                    }
                }
                catch (Exception)
                {
                    // Jump to next product
                }
            }
            else
            {
                break;
            }

            StateHasChanged();
        }
    }

    /// <summary>
    /// Selected product changed
    /// </summary>
    private void OnSelectedProductChanged(ProductViewModel productViewModel)
    {
        try
        {
            if (productViewModel == SelectedProduct)
            {
                return;
            }

            SelectedProduct = productViewModel;
            SelectedProductChanged.InvokeAsync(productViewModel.Product);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected products changed
    /// </summary>
    private void OnSelectedProductsChanged(List<ProductViewModel> productViewModels)
    {
        try
        {
            SelectedProducts = productViewModels;
            SelectedProductsChanged.InvokeAsync(productViewModels.Select(c => c.Product).ToList());
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
