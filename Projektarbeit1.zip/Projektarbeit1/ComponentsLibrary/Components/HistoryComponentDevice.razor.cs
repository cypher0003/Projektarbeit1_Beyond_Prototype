#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Blazorise;
using Blazorise.DataGrid;
using ComponentsLibrary.Dialogs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Zeiss.Licensing.Data.Models;
using Zeiss.Licensing.Data.Collections;

namespace ComponentsLibrary.Components;

public partial class HistoryComponentDevice
{
    #region Properties

    private List<DeviceHistory> Historys { get; } = new List<DeviceHistory>();

    private DateTime? GenerationDate { get; }

    #endregion
}
