#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SplitLineComponent : BaseComponent
{
    #region Properties

    [Parameter]
    public SplitProductKeyViewModel SplitProductKeyViewModel { get; set; } = new SplitProductKeyViewModel(new EntitlementProductKey());

    [Parameter]
    public EventCallback SplitValueChanged { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Value changed
    /// </summary>
    /// <param name = "value">Value</param>
    private void OnSplitValueChanged(int value)
    {
        try
        {
            SplitProductKeyViewModel.EntitlementSplitInfoItem.Quantity = value;
            SplitValueChanged.InvokeAsync(SplitProductKeyViewModel.EntitlementSplitInfoItem.Quantity);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
