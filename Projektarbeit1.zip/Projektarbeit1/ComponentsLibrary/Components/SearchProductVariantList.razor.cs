#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchProductVariantList : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback<ProductVariant> SelectedProductVariantChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool OnlyThalesEnforcement { get; set; }

    [Parameter]
    public IEnumerable<LicenseModel> LicenseModels { get; set; } = null!;

    public ProductVariant SelectedProductVariant { get; set; } = new();

    public SearchObjectProductVariant SearchObjectProductVariant { get; set; } = new();

    public override bool IsLoadMoreDisable => (!OnlyThalesEnforcement && ProductVariants.Count == 0) || base.IsLoadMoreDisable;

    private List<ProductVariant> ProductVariants { get; set; } = new();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectProductVariant">Search object of organization</param>
    public async Task UpdateList(SearchObjectProductVariant searchObjectProductVariant)
    {
        try
        {
            LoadMoreEnded = !searchObjectProductVariant.RestartLoadMore;
            ProductVariants.Clear();
            InvalidCount = 0;
            SearchTotalCount = 0;
            UnauthorizedCount = 0;

            await UpdateDataList(searchObjectProductVariant);

            if (ProductVariants.Any())
            {
                OnSelectedProductVariantChanged(ProductVariants[0]);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectProductVariant">Search object of product variant</param>
    public async Task UpdateDataList(SearchObjectProductVariant searchObjectProductVariant)
    {
        try
        {
            await SearchStarted.InvokeAsync(true);
            SearchObjectProductVariant = searchObjectProductVariant;
            searchObjectProductVariant.PageSize = Convert.ToInt32(Configuration["PageSize"]);

            // Trim Strings of SearchObject
            TrimSearchObject(searchObjectProductVariant);
            PartialList<ProductVariant> partialList = await ProductVariantClient.GetProductVariants(searchObjectProductVariant);
            var productVariantList = new List<ProductVariant>(partialList.List);

            if (OnlyThalesEnforcement)
            {
                productVariantList.Clear();

                foreach (var productVariant in partialList.List)
                {
                    var licenseModel = LicenseModels.SingleOrDefault(c => c.Name == productVariant.LicenseModel);

                    if (null != licenseModel && licenseModel.IsThales)
                    {
                        productVariantList.Add(productVariant);
                    }
                }
            }

            ProductVariants.AddRange(productVariantList);
            InvalidCount += partialList.InvalidCount;
            SearchTotalCount = partialList.TotalCount;
            UnauthorizedCount += partialList.UnauthorizedCount;
            LoadMoreEnded = partialList.IsLastPageIndex;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }

        await SearchStarted.InvokeAsync(false);
    }

    /// <summary>
    /// Remove product variant from list
    /// </summary>
    /// <param name = "productVariant">Product variant to be removed</param>
    public void RemoveProductVariant(ProductVariant productVariant)
    {
        try
        {
            if (ProductVariants.Contains(productVariant))
            {
                ProductVariants.Remove(productVariant);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save product variant to list
    /// </summary>
    /// <param name = "origProductVariant">Original product variant(Update)</param>
    /// <param name = "productVariant">Product variant to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveProductVariant(ProductVariant origProductVariant, ProductVariant productVariant, bool isAdd)
    {
        try
        {
            if (isAdd)
            {
                ProductVariants.Insert(0, productVariant);
            }
            else
            {
                var search = ProductVariants.FirstOrDefault(x => x.Id == origProductVariant.Id);

                if (null != search)
                {
                    var idxOrig = ProductVariants.IndexOf(search);

                    if (idxOrig >= 0)
                    {
                        ProductVariants.Insert(idxOrig, productVariant);
                        ProductVariants.Remove(search);
                    }
                }
                else
                {
                    ProductVariants.Add(productVariant);
                }
            }

            SelectedProductVariant = productVariant;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            ProductVariants = new List<ProductVariant>();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectProductVariant.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object? productVariant, ActionType actionType)
    {
        try
        {
            if (null != productVariant && SelectedProductVariant != (ProductVariant)productVariant)
            {
                OnSelectedProductVariantChanged((ProductVariant)productVariant);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectProductVariant.UseLoadMore = true;
            SearchObjectProductVariant.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectProductVariant);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected product variant changed
    /// </summary>
    private void OnSelectedProductVariantChanged(ProductVariant productVariant)
    {
        try
        {
            if (productVariant != SelectedProductVariant)
            {
                SelectedProductVariant = productVariant;
                SelectedProductVariantChanged.InvokeAsync(productVariant);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
