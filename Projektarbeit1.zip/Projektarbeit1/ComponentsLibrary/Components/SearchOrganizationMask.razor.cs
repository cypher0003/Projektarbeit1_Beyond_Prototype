﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchOrganizationMask : BaseOrganizationComponent
{
    #region Properties

    [Parameter]
    public EventCallback SearchClicked { get; set; }

    [Parameter]
    public bool ShowEnable { get; set; } = false;


    /// <summary>
    /// List of business groups with empty entry -> optional
    /// </summary>
    private List<string> StatesWithEmpty { get; set; } = new List<string>();

    private string SearchObjectOrganizationState { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            SearchObjectOrganization = new SearchObjectOrganization();
            await base.OnInitializedAsync();

            await base.GetSavedSearchMode();
            SearchObjectOrganization.SearchPattern = (SearchPattern)SelectedSearchModeValue;
            SearchObjectOrganization.State = null;
            OrganizationTypeList.Insert(0, new SelectModel { Value = -1, Text = "" });
            SelectedOrganizationTypeValue = -1;

            StatesWithEmpty.Add(string.Empty);
            StatesWithEmpty.Add(OrganizationState.ENABLE.ToString());
            StatesWithEmpty.Add(OrganizationState.DISABLE.ToString());
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            //SearchObjectOrganization.PageStartIndex = 1;
            SearchObjectOrganization.UseLoadMore = true;
            SearchObjectOrganization.RestartLoadMore = true;
            await SearchClicked.InvokeAsync(SearchObjectOrganization);

            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Organization type changed
    /// </summary>
    /// <param name="newValue">new value</param>
    private void SelectedOrganizationTypeHandler(int newValue)
    {
        try
        {
            SelectedOrganizationTypeValue = newValue;

            if (newValue < 0)
            {
                SearchObjectOrganization.OrganizationType = null;
            }
            else
            {
                SearchObjectOrganization.OrganizationType = (OrganizationType)newValue;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
