#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchProductVariantComponent : BaseComponent
{
    #region Properties

    [Parameter]
    public EventCallback<ProductVariant> SelectedProductVariantChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool OnlyThalesEnforcement { get; set; }

    [Parameter]
    public IEnumerable<LicenseModel> LicenseModels { get; set; } = null!;

    public ProductVariant SelectedProductVariant { get; set; } = new();

    private SearchObjectProductVariant SearchObjectProductVariant { get; set; } = new();

    private SearchProductVariantList? SearchProductVariantList { get; set; }

    private SearchProductVariantMask? SearchProductVariantMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Remove product from list
    /// </summary>
    /// <param name = "productVariant">ProductVariant to be removed</param>
    public void RemoveProductVariant(ProductVariant productVariant)
    {
        try
        {
            SearchProductVariantList!.RemoveProductVariant(productVariant);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save productVariant to list
    /// </summary>
    /// <param name = "origProductVariant">Original productVariant(Update)</param>
    /// <param name = "productVariant">ProductVariant to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveProductVariant(ProductVariant origProductVariant, ProductVariant productVariant, bool isAdd)
    {
        try
        {
            SearchProductVariantList!.SaveProductVariant(origProductVariant, productVariant, isAdd);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            SearchProductVariantList!.ClearList();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectProductVariant = new SearchObjectProductVariant
            {
                SearchPattern = SearchPattern.Normal
            };
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchProductVariant">Search object to load products</param>
    private async Task SearchClicked(object searchProductVariant)
    {
        try
        {
            // List component loads products
            SearchObjectProductVariant = (SearchObjectProductVariant)searchProductVariant;
            await SearchProductVariantList!.UpdateList(SearchObjectProductVariant);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected product has changed
    /// </summary>
    private void OnSelectedProductVariantChanged(ProductVariant selProductVariant)
    {
        try
        {
            SelectedProductVariant = selProductVariant;
            SelectedProductVariantChanged.InvokeAsync(selProductVariant);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        try
        {
            SearchProductVariantMask!.SetLoading((bool)showLoading);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
