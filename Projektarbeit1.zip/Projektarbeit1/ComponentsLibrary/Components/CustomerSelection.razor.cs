﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class CustomerSelection
{
    #region Fields

    private SearchOrganizationDialog? searchOrganizationDialog;

    #endregion

    #region Properties

    [Parameter]
    public CustomerSelectionModel CustomerSelectionModel { get; set; } = new CustomerSelectionModel();

    [Parameter]
    public EventCallback CustomerSelectioChanged { get; set; }

    [Parameter]
    public bool IsReadOnly { get; set; }

    [Parameter]
    public int FirstColumnSize { get; set; } = 4;

    private bool ShowSearchOrganizationDialog { get; set; }

    private CustomerSelectType SelectedCustomerSelectType { get; set; } = CustomerSelectType.Endcustomer;

    #endregion

    #region Methods

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    /// <param name="customerType"></param>
    private void OnSelectOrgButtonClicked(CustomerSelectType customerType)
    {
        SelectedCustomerSelectType = customerType;
        ShowSearchOrganizationDialog = true;
        searchOrganizationDialog!.ClearList();
    }

    /// <summary>
    /// Delete organization
    /// </summary>
    /// <param name="customerType"></param>
    private void OnDeleteOrgButtonClicked(CustomerSelectType customerType)
    {
        switch (customerType)
        {
            case CustomerSelectType.Factory:
                CustomerSelectionModel.FactoryText = string.Empty;
                CustomerSelectionModel.FactoryNumber = string.Empty;
                CustomerSelectionModel.Factory = null;
                break;
            case CustomerSelectType.Distributor:
                CustomerSelectionModel.DistributorText = string.Empty;
                CustomerSelectionModel.DistributorNumber = string.Empty;
                CustomerSelectionModel.Distributor = null;
                break;
            case CustomerSelectType.SSC1:
                CustomerSelectionModel.SSC1Text = string.Empty;
                CustomerSelectionModel.SSC1Number = string.Empty;
                CustomerSelectionModel.SSC1 = null;
                break;
            case CustomerSelectType.SSC2:
                CustomerSelectionModel.SSC2Text = string.Empty;
                CustomerSelectionModel.SSC2Number = string.Empty;
                CustomerSelectionModel.SSC2 = null;
                break;
            case CustomerSelectType.Endcustomer:
                CustomerSelectionModel.EndcustomerText = string.Empty;
                CustomerSelectionModel.EndcustomerNumber = string.Empty;
                CustomerSelectionModel.Endcustomer = null;
                break;
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(object organization)
    {
        ShowSearchOrganizationDialog = false;
        SetCustomerText((Organization)organization);

        CustomerSelectioChanged.InvokeAsync(CustomerSelectionModel);
    }

    /// <summary>
    /// Search Discard button pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        ShowSearchOrganizationDialog = false;
    }

    /// <summary>
    /// Set Text of selected customer type
    /// </summary>
    private void SetCustomerText(Organization organization)
    {
        switch (SelectedCustomerSelectType)
        {
            case CustomerSelectType.Factory:
                CustomerSelectionModel.FactoryText = OrganizationHelper.GetOrganizationText(organization);
                CustomerSelectionModel.FactoryNumber = organization.Number;
                CustomerSelectionModel.Factory = organization;
                break;
            case CustomerSelectType.Distributor:
                CustomerSelectionModel.DistributorText = OrganizationHelper.GetOrganizationText(organization);
                CustomerSelectionModel.DistributorNumber = organization.Number;
                CustomerSelectionModel.Distributor = organization;
                break;
            case CustomerSelectType.SSC1:
                CustomerSelectionModel.SSC1Text = OrganizationHelper.GetOrganizationText(organization);
                CustomerSelectionModel.SSC1Number = organization.Number;
                CustomerSelectionModel.SSC1 = organization;
                break;
            case CustomerSelectType.SSC2:
                CustomerSelectionModel.SSC2Text = OrganizationHelper.GetOrganizationText(organization);
                CustomerSelectionModel.SSC2Number = organization.Number;
                CustomerSelectionModel.SSC2 = organization;
                break;
            case CustomerSelectType.Endcustomer:
                CustomerSelectionModel.EndcustomerText = OrganizationHelper.GetOrganizationText(organization);
                CustomerSelectionModel.EndcustomerNumber = organization.Number;
                CustomerSelectionModel.Endcustomer = organization;
                break;
        }
    }

    #endregion
}
