﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

public partial class SearchProductMask : BaseComponent
{
    #region Fields

    private List<string> productFamilies = new();

    #endregion

    #region Properties

    [Parameter]
    public EventCallback SearchClicked { get; set; }

    public SearchObjectProduct SearchObjectProduct { get; set; } = new();

    private string SelectedTab { get; set; } = "products";

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            SearchObjectProduct = new SearchObjectProduct();
            await base.OnInitializedAsync();

            await base.LoadBusinessGroups();
            await base.GetSavedSearchMode();
            SearchObjectProduct.SearchPattern = (SearchPattern)SelectedSearchModeValue;

            productFamilies.Add(string.Empty);
            List<ProductFamily> prodFamilies = await AppSettingClient!.GetProductFamilies();

            foreach (var family in prodFamilies)
            {
                productFamilies.Add(family.Name);
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Search  Button clicked
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            if (SelectedTab == "variants")
            {
                SearchObjectProduct.Name = string.Empty;
                SearchObjectProduct.Version = string.Empty;
                SearchObjectProduct.Businessgroup = string.Empty;
                SearchObjectProduct.Family = string.Empty;
                SearchObjectProduct.Materialnumber = SearchObjectProduct.Materialnumber?.Replace("-", "");

                if (null != SearchObjectProduct.Materialnumber &&
                    (SearchObjectProduct.SearchPattern == SearchPattern.Normal || SearchObjectProduct.SearchPattern == SearchPattern.Exact))
                {
                    var cnt = SearchObjectProduct.Materialnumber.Length;
                    SearchObjectProduct.Materialnumber = SearchObjectProduct.Materialnumber.TrimStart('0');
                    var cntInsert = cnt - SearchObjectProduct.Materialnumber.Length > 5 ? cnt - SearchObjectProduct.Materialnumber.Length : 5;

                    for (var i = 0; i < cntInsert; i++)
                    {
                        SearchObjectProduct.Materialnumber = SearchObjectProduct.Materialnumber.Insert(0, "0");
                    }
                }
            }
            else
            {
                SearchObjectProduct.VariantName = string.Empty;
                SearchObjectProduct.Materialnumber = string.Empty;
                SearchObjectProduct.VariantProductRatePlanChargeName = string.Empty;
            }

            SearchObjectProduct.UseLoadMore = true;
            SearchObjectProduct.RestartLoadMore = true;
            await SearchClicked.InvokeAsync(SearchObjectProduct);

            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Tab changed
    /// </summary>
    /// <param name="name">Tab name</param>
    private void OnSelectedTabChanged(string name)
    {
        try
        {
            SelectedTab = name;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
