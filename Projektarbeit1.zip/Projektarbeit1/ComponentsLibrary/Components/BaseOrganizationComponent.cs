﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Components;

/// <summary>
/// Base component for organization components
/// </summary>
public class BaseOrganizationComponent : BaseComponent
{
    #region Fields

    /// <summary>
    /// Original organization at editing
    /// </summary>
    protected Organization editOriginalOrganization = new();

    #endregion

    #region Properties

    /// <summary>
    /// List of all countries
    /// </summary>
    protected List<CountryModel> CountryList { get; set; } = new List<CountryModel>();

    /// <summary>
    /// Selected country
    /// </summary>
    protected string SelectedCountry { get; set; } = string.Empty;

    /// <summary>
    /// Selcted organization
    /// </summary>
    protected Organization SelectedOrganization { get; set; } = new Organization();

    /// <summary>
    /// Flag: is new organization
    /// </summary>
    protected bool IsNewOrganization => string.IsNullOrWhiteSpace(SelectedOrganization.Id);

    /// <summary>
    /// SearchObject
    /// </summary>
    protected SearchObjectOrganization SearchObjectOrganization { get; set; } = new SearchObjectOrganization();

    #endregion

    #region Methods

    /// <summary>
    /// Initialization
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            CountryList.Add(new CountryModel { Code = "", Name = "" });
            CountryList.AddRange(CountryHelper.GetCountryList());

            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Country changed
    /// </summary>
    /// <param name="newVCountry">new country</param>
    protected void SelectedCountryChanged(string newCountry)
    {
        try
        {
            newCountry ??= string.Empty;

            if (null != newCountry)
            {
                SelectedCountry = newCountry;
                SelectedOrganization.Country = SelectedCountry;
                SearchObjectOrganization.Country = SelectedCountry;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
