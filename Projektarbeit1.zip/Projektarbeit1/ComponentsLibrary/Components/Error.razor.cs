#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Auth;
using ComponentsLibrary.Exceptions;
using ComponentsLibrary.Interfaces;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.Extensions.Logging;

namespace ComponentsLibrary.Components;

public partial class Error : RefreshTokenComponent
{
    #region Properties

    [CascadingParameter(Name = "EmergencyAuthorizationActive")]
    public bool IsEmergencyAuthorizationActive { get; set; }

    [Parameter]
    public RenderFragment? ChildContent { get; set; }

    public bool ShowDialog { get; set; }

    [Inject]
    private BlazorServerAuthStateCache? _cache { get; set; }

    [Inject]
    private IProtectedSessionStorageRepositoryHelper? _protectedSessionStorageRepositoryHelper { get; set; }

    private SnackBarException? SnackBarEx { get; set; }

    private SnackBarExpiredException? SnackBarExExpires { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Show error in SnackBar
    /// </summary>
    /// <param name = "ex">Exception</param>
    /// <returns></returns>
    public async Task<bool> ProcessError(Exception ex)
    {
        if (ex is ZeissLicensingExpiredTokenException)
        {
            Logger.LogError(ex, "Error:ProcessError - Type: {Type} Message: {Message}", ex.GetType(), ex.Message);

            if (IsEmergencyAuthorizationActive && null != _protectedSessionStorageRepositoryHelper && null != _cache)
            {
                await EmergencyHelper.EmergencyLogout(_protectedSessionStorageRepositoryHelper, _cache);
            }

            SnackBarExExpires?.ShowException(L["AUTHENTICATIONEXPIRED"]);
            return false;
        }

        SnackBarEx?.ShowException(ex.Message);

        return false;
    }


    /// <summary>
    /// Hide SnackbarException
    /// </summary>
    /// <param name = "arg">Argument</param>
    private void OnClosed(object arg)
    {
        if ((string)arg == AuthDefaults.LICENSE_EXPIRED)
        {
            NavigationManager.NavigateTo("/logout", true);
        }
    }

    #endregion
}
