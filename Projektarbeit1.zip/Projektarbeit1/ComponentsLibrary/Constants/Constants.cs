﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentsLibrary.Constants;

/// <summary>
/// General Constants
/// </summary>
public static class Constants
{
    #region Fields

    /// <summary>
    /// Textedit controls delay when text-binding
    /// </summary>
    public const int DELAY_TEXT_ON_KEYPRESS_INTERVAL = 800;

    #endregion
}
