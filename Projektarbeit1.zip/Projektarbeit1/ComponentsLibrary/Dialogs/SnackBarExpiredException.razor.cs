#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Blazorise.Snackbar;
using ComponentsLibrary.Auth;

namespace ComponentsLibrary.Dialogs;

public partial class SnackBarExpiredException
{
    #region Properties

    [Parameter]
    public EventCallback Closed { get; set; }

    private SnackbarStack? Snackbar { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Show the exception with the text
    /// </summary>
    /// <param name = "ex"></param>
    public void ShowException(string ex)
    {
        Snackbar!.PushAsync(ex, SnackbarColor.Danger, options =>
        {
            options.ShowCloseButton = true;
            options.Multiline = true;
        });
    }

    private void OnCloseClicked()
    {
        Closed.InvokeAsync(AuthDefaults.LICENSE_EXPIRED);
    }

    #endregion
}
