#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Dialogs;

public partial class SearchProductVariantDialog
{
    #region Fields

    private SearchProductVariantComponent _RefSearchProductVariantComponent = null!;

    #endregion

    #region Properties

    [Parameter]
    public bool ShowDialog { get; set; }

    [Parameter]
    public EventCallback<ProductVariant> OkClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    [Parameter]
    public bool OnlyThalesEnforcement { get; set; }

    [Parameter]
    public IEnumerable<LicenseModel> LicenseModels { get; set; } = null!;

    private SearchObjectProductVariant SearchObjectProductVariant { get; set; } = new();

    /// <summary>
    /// Selected product variant
    /// </summary>
    private ProductVariant SelectedProductVariant { get; set; } = new();

    #endregion

    #region Methods

    /// <summary>
    /// Parameters set
    /// </summary>
    protected override void OnParametersSet()
    {
        base.OnParametersSet();

        if (ShowDialog)
        {
            SelectedProductVariant = new ProductVariant();
        }
    }

    /// <summary>
    /// Selected product variant has changed
    /// </summary>
    private void OnSelectedProductVariantChanged(ProductVariant productVariant)
    {
        SelectedProductVariant = productVariant;
    }

    /// <summary>
    /// Hide Product Modal OK
    /// </summary>
    private void OnClickOK()
    {
        _RefSearchProductVariantComponent.ClearList();
        OkClicked.InvokeAsync(SelectedProductVariant);
    }

    /// <summary>
    /// Hide Product Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        _RefSearchProductVariantComponent.ClearList();
        DiscardClicked.InvokeAsync("Discard pressed");
    }

    #endregion
}
