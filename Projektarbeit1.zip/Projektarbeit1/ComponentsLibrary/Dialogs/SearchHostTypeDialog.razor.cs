#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using BaseComponent = ComponentsLibrary.Components.BaseComponent;

namespace ComponentsLibrary.Dialogs;

public partial class SearchHostTypeDialog : BaseComponent
{
    #region Fields

    private List<Zeiss.Licensing.Data.Models.HostType> Hosttypes = new List<Zeiss.Licensing.Data.Models.HostType>();

    #endregion

    #region Properties

    [Parameter]
    public bool ShowDialog
    {
        get => _ShowDialog;

        set
        {
            SelectedHostType = Hosttypes.FirstOrDefault() ?? new Zeiss.Licensing.Data.Models.HostType();
            _ShowDialog = value;
        }
    }

    [Parameter]
    public EventCallback OKClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    public Zeiss.Licensing.Data.Models.HostType SelectedHostType { get; set; } = new Zeiss.Licensing.Data.Models.HostType();

    private bool _ShowDialog { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            var hosttypesTask = appSettingClient.GetHostTypes();
            Hosttypes = await hosttypesTask;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Hide Organization Modal OK
    /// </summary>
    private void OnClickOK()
    {
        try
        {
            OKClicked.InvokeAsync(SelectedHostType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Organization Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            DiscardClicked.InvokeAsync("Discard pressed");
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
