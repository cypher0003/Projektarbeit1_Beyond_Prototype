#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Dialogs;

public partial class HistoryDialog
{
    #region Fields

    private Modal? modalHistory;
    private HistoryComponent? historyComponent;

    #endregion

    #region Properties

    [Parameter]
    public HistoryType HistoryType { get; set; } = HistoryType.User;

    public string Id { get; set; } = string.Empty;

    public string ShowId { get; set; } = string.Empty;

    private SnackBarException? SnackbarException { get; set; }

    private string ObjektType { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Show the history dialog
    /// </summary>
    /// <param name = "id">Id</param>
    /// <param name = "showId">Id shown in caption</param>
    /// <param name = "historyType">History Type (e.g. Entitlement, Product, ...)</param>
    public async Task ShowHistory(string id, string showId, HistoryType historyType)
    {
        try
        {
            Id = id;
            ShowId = showId;
            HistoryType = historyType;

            switch (HistoryType)
            {
                case HistoryType.Entitlement:
                    ObjektType = L["ENTITLEMENT"];
                    break;
                case HistoryType.License:
                    ObjektType = L["LICENSE"];
                    break;
                case HistoryType.Product:
                    ObjektType = L["PRODUCT"];
                    break;
                case HistoryType.Productvariant:
                    ObjektType = L["PRODUCTVARIANT"];
                    break;
                case HistoryType.User:
                    ObjektType = L["USER"];
                    break;
                case HistoryType.Device:
                    ObjektType = SharedResource.DEVICE;
                    break;
            }

            await modalHistory!.Show();
            await historyComponent!.Reset(id, showId, historyType);

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Organization Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            modalHistory!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
