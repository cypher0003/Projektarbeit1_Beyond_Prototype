#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Dialogs;

public partial class DialogOkDiscard
{
    #region Properties

    [Parameter]
    public string Status { get; set; } = string.Empty;

    [Parameter]
    public string Caption { get; set; } = string.Empty;

    [Parameter]
    public string Text { get; set; } = string.Empty;

    [Parameter]
    public EventCallback OnOkClick { get; set; }

    [Parameter]
    public EventCallback OnDiscardClick { get; set; }

    [Parameter]
    public EventCallback OnCloseClick { get; set; }

    [Parameter]
    public bool ShowDialog { get; set; }

    [Parameter]
    public bool ShowCheckBox { get; set; }

    [Parameter]
    public string CheckText { get; set; } = string.Empty;

    [Parameter]
    public bool Checked { get; set; }

    [Parameter]
    public bool IsLoading { get; set; }

    [Parameter]
    public bool ShowDiscard { get; set; } = true;

    internal bool CancelClose { get; set; } = true;

    #endregion

    #region Methods

    /// <summary>
    /// Hide Delete Modal OK
    /// </summary>
    private void OnClickOK()
    {
        OnOkClick.InvokeAsync(Text);
        CancelClose = false;
        ShowDialog = false;
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        OnDiscardClick.InvokeAsync("Discard pressed");
        CancelClose = false;
        ShowDialog = false;
    }

    /// <summary>
    /// Close dialog only on button click, not loosing focus
    /// </summary>
    private Task OnClosing(ModalClosingEventArgs e)
    {
        // just set Cancel to prevent modal from closing
        e.Cancel = CancelClose && e.CloseReason == CloseReason.FocusLostClosing;
        CancelClose = true;
        return Task.CompletedTask;
    }

    private void OnClickClose()
    {
        OnCloseClick.InvokeAsync(Text);
        CancelClose = false;
        ShowDialog = false;
    }

    #endregion
}
