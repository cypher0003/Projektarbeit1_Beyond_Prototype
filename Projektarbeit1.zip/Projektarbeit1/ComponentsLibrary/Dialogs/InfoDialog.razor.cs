#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Text.Json;

namespace ComponentsLibrary.Dialogs;

public partial class InfoDialog
{
    #region Fields

    private Modal? modalInfo;

    #endregion

    #region Properties

    private SnackBarException? SnackbarException { get; set; }

    private string Info { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Set info
    /// </summary>
    public void SetInfo<T>(T obj)
    {
        try
        {
            var seropt = new JsonSerializerOptions
            {
                //IgnoreNullValues = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase, WriteIndented = true, PropertyNameCaseInsensitive = true
            };

            Info = JsonSerializer.Serialize(obj, seropt);
            modalInfo!.Show();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Organization Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            modalInfo!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
