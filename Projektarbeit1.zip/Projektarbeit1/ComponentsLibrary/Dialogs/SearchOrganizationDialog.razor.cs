#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Dialogs;

public partial class SearchOrganizationDialog
{
    #region Properties

    [Parameter]
    public bool ShowDialog { get; set; }

    [Parameter]
    public EventCallback<Organization> OkClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    private SearchObjectOrganization SearchObjectOrganization { get; set; } = new SearchObjectOrganization();

    private Organization SelectedOrganization { get; set; } = new Organization();

    private SearchOrganizationList? SearchOrganizationList { get; set; }

    private SearchOrganizationMask? SearchOrganizationMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Clear result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            SearchOrganizationList!.ClearList();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchOrganization">Search object to load organizations</param>
    private async Task OnSearchClickedOrgDlg(object searchOrganization)
    {
        try
        {
            // List component loads organizations
            SearchObjectOrganization = (SearchObjectOrganization)searchOrganization;
            await SearchOrganizationList!.UpdateList(SearchObjectOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected o has changed
    /// </summary>
    private void OnSelectedOrganizationChanged(object selOrganization)
    {
        try
        {
            SelectedOrganization = (Organization)selOrganization;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Organization Modal OK
    /// </summary>
    private void OnClickOK()
    {
        try
        {
            OkClicked.InvokeAsync(SelectedOrganization);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Organization Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            DiscardClicked.InvokeAsync("Discard pressed");
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        try
        {
            SearchOrganizationMask!.SetLoading((bool)showLoading);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
