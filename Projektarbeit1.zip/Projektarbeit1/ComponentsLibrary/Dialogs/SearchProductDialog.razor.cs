#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.Dialogs;

public partial class SearchProductDialog
{
    #region Properties

    [Parameter]
    public bool ShowDialog { get; set; }

    [Parameter]
    public EventCallback OKClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    [Parameter]
    public bool OnlyEnabledProducts { get; set; } = false;

    [Parameter]
    public bool OnlyDraftEnabledProducts { get; set; } = false;

    [Parameter]
    public bool IsMultiselect { get; set; } = false;

    /// <summary>
    /// Selected products
    /// </summary>
    public List<Product> SelectedProducts { get; set; } = new();


    private SearchObjectProduct SearchObjectProduct { get; set; } = new SearchObjectProduct();

    /// <summary>
    /// Selected product
    /// </summary>
    private Product SelectedProduct { get; set; } = new Product();

    private SearchProductList? SearchProductList { get; set; }

    private SearchProductMask? SearchProductMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Parameters set
    /// </summary>
    protected override void OnParametersSet()
    {
        base.OnParametersSet();

        if (ShowDialog)
        {
            SelectedProduct = new Product();
            SelectedProducts.Clear();
            SearchProductList!.ClearSelection();
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchProduct">Search object to load products</param>
    private async Task OnSearchProductClicked(object searchProduct)
    {
        // List component loads products
        SearchObjectProduct = (SearchObjectProduct)searchProduct;
        await SearchProductList!.UpdateList(SearchObjectProduct);
    }

    /// <summary>
    /// Selected product has changed
    /// </summary>
    private void SelectedProductChanged(object selProduct)
    {
        SelectedProduct = (Product)selProduct;
    }

    /// <summary>
    /// Hide Product Modal OK
    /// </summary>
    private void OnClickOK()
    {
        SearchProductList!.StopLoadingMaterialnumbers();
        OKClicked.InvokeAsync(IsMultiselect ? SelectedProducts : SelectedProduct);
    }

    /// <summary>
    /// Hide Product Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        SearchProductList!.StopLoadingMaterialnumbers();
        DiscardClicked.InvokeAsync("Discard pressed");
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        SearchProductMask!.SetLoading((bool)showLoading);
    }

    /// <summary>
    /// Selected products changed
    /// </summary>
    private void OnSelectedProductsChanged(List<Product> selp)
    {
        try
        {
            if (null != selp)
            {
                SelectedProducts = selp;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
