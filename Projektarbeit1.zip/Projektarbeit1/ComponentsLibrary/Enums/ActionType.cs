﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentsLibrary.Enums;

/// <summary>
/// Action Type
/// </summary>
public enum ActionType
{
    /// <summary>
    /// Add
    /// </summary>
    Add,

    /// <summary>
    /// Delete
    /// </summary>
    Delete,

    /// <summary>
    /// Edit
    /// </summary>
    Edit,

    /// <summary>
    /// View
    /// </summary>
    View,

    /// <summary>
    /// Complete
    /// </summary>
    Complete,

    /// <summary>
    /// End of life
    /// </summary>
    EndOfLife,

    /// <summary>
    /// Add test object
    /// </summary>
    AddTest
}
