﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentsLibrary.Enums;

/// <summary>
/// Action Type
/// </summary>
public enum HistoryType
{
    /// <summary>
    /// Entitlement
    /// </summary>
    Entitlement,

    /// <summary>
    /// License
    /// </summary>
    License,

    /// <summary>
    /// Product
    /// </summary>
    Product,

    /// <summary>
    /// Productvariant
    /// </summary>
    Productvariant,

    /// <summary>
    /// User
    /// </summary>
    User,

    /// <summary>
    /// Device
    /// </summary>
    Device
}
