﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Resources;
using Zeiss.Licensing.Data.TransferObjects.V1;

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// ViewModel for Lockmode data
/// </summary>
public class CollapseLockmodeViewModel
{
    #region Properties

    public List<SplitProductKeyViewModel> SplitProductKeyVMs { get; set; } = new List<SplitProductKeyViewModel>();

    public ActivationRequest ActivationRequest { get; set; } = new ActivationRequest();

    public bool IsActivateDisabled => DeviceNameInvalid || !SplitProductKeyVMs.Any(c => c.EntitlementSplitInfoItem.Quantity > 0) || string.IsNullOrWhiteSpace(ActivationRequest.DeviceName);

    public bool IsBackDisabled { get; set; } = false;

    public bool Visible { get; set; } = false;

    /// <summary>
    /// Flag, if Activation started from entitlement
    /// </summary>
    public bool IsEntitlementActivation { get; set; }

    /// <summary>
    /// Serial number
    /// </summary>
    public string SerialNumber { get; set; } = string.Empty;

    /// <summary>
    /// Caption
    /// </summary>
    public string Caption { get; set; } = string.Empty;

    /// <summary>
    /// LockCriterion
    /// </summary>
    public string LockCriterion { get; set; } = string.Empty;

    /// <summary>
    /// Flag to disable activate button, if device name is invalid
    /// </summary>
    public bool DeviceNameInvalid { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Fill product keys
    /// </summary>
    /// <param name="group">Group of product keys with the same lock criterion</param>
    public void FillProductKeys(IGrouping<string, ActivatableItem> group)
    {
        foreach (var activatableItem in group.ToList())
        {
            SplitProductKeyViewModel spvm = new(activatableItem);
            spvm.EntitlementSplitInfoItem.Quantity = 1;
            SplitProductKeyVMs.Add(spvm);
        }

        ResourceManager resourceManager = new(typeof(LicenseResource));
        Caption = resourceManager.GetString("LOCKCRITERION" + group.Key.ToUpper()) ?? group.Key;
        Visible = false;
    }

    #endregion
}
