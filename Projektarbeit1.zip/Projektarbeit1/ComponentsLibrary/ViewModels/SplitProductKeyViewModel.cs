﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using Zeiss.Licensing.Data.TransferObjects.V1;

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// View Model for splitting
/// </summary>
public class SplitProductKeyViewModel
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="prodKey">Product key</param>
    public SplitProductKeyViewModel(EntitlementProductKey prodKey)
    {
        EntitlementProductKey = prodKey;
        EntitlementSplitInfoItem = new EntitlementSplitInfoItem { ProductKey = prodKey?.ProductKeyId, Quantity = 0 };
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="activatableItem">Activatable item</param>
    public SplitProductKeyViewModel(ActivatableItem activatableItem)
    {
        ActivatableItem = activatableItem;
        EntitlementSplitInfoItem = new EntitlementSplitInfoItem { ProductKey = activatableItem.ProductKey, Quantity = 0 };
        AllowMultipleActivation = activatableItem.AllowMultipleActivation;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Entitlement split info item
    /// </summary>
    public EntitlementSplitInfoItem EntitlementSplitInfoItem { get; set; }

    /// <summary>
    /// Allow multiple activation
    /// </summary>
    public bool AllowMultipleActivation { get; set; } = true;

    /// <summary>
    /// Product key id
    /// </summary>
    public string ProductKeyId
    {
        get
        {
            if (null != EntitlementProductKey)
            {
                return EntitlementProductKey.ProductKeyId;
            }

            if (null != ActivatableItem)
            {
                return ActivatableItem.ProductKey;
            }

            return string.Empty;
        }
        set
        {
            if (null != EntitlementProductKey)
            {
                EntitlementProductKey.ProductKeyId = value;
            }
            else if (null != ActivatableItem)
            {
                ActivatableItem.ProductKey = value;
            }
        }
    }

    /// <summary>
    /// Product name
    /// </summary>
    public string ProductName
    {
        get
        {
            if (null != EntitlementProductKey)
            {
                return EntitlementProductKey.Product?.Product?.Name ?? string.Empty;
            }

            if (null != ActivatableItem)
            {
                return ActivatableItem.ProductName;
            }

            return string.Empty;
        }
        set
        {
            if (null != EntitlementProductKey && null != EntitlementProductKey.Product.Product)
            {
                EntitlementProductKey.Product.Product.Name = value;
            }
            else if (null != ActivatableItem)
            {
                ActivatableItem.ProductName = value;
            }
        }
    }

    /// <summary>
    /// Product name
    /// </summary>
    public string ProductVersion
    {
        get
        {
            if (null != EntitlementProductKey)
            {
                return EntitlementProductKey.Product?.Product?.Version ?? string.Empty;
            }

            if (null != ActivatableItem)
            {
                return ActivatableItem.ProductVersion;
            }

            return string.Empty;
        }
        set
        {
            if (null != EntitlementProductKey && null != EntitlementProductKey.Product.Product)
            {
                if (null != EntitlementProductKey.Product?.Product?.Version)
                {
                    EntitlementProductKey.Product.Product.Version = value;
                }
            }
            else if (null != ActivatableItem)
            {
                ActivatableItem.ProductVersion = value;
            }
        }
    }

    /// <summary>
    /// Available quantity
    /// </summary>
    public int MaxAvailableQuantity
    {
        get
        {
            if (null != EntitlementProductKey)
            {
                return EntitlementProductKey.AvailableQuantity;
            }

            if (null != ActivatableItem)
            {
                return AllowMultipleActivation
                    ? ActivatableItem.AvailableQuantity
                    : ActivatableItem.AvailableQuantity > 0
                        ? 1
                        : 0;
            }

            return 0;
        }
    }

    /// <summary>
    /// Available quantity
    /// </summary>
    public int AvailableQuantity
    {
        get
        {
            if (null != EntitlementProductKey)
            {
                return EntitlementProductKey.AvailableQuantity;
            }

            if (null != ActivatableItem)
            {
                return ActivatableItem.AvailableQuantity;
            }

            return 0;
        }
        set
        {
            if (null != EntitlementProductKey)
            {
                EntitlementProductKey.AvailableQuantity = value;
            }
            else if (null != ActivatableItem)
            {
                ActivatableItem.AvailableQuantity = value;
            }
        }
    }

    /// <summary>
    /// Entitlement Product Key
    /// </summary>
    private EntitlementProductKey? EntitlementProductKey { get; }

    /// <summary>
    /// Activatable item
    /// </summary>
    private ActivatableItem? ActivatableItem { get; }

    #endregion
}
