﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// View model of product for searching
/// </summary>
public class ProductViewModel
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    public ProductViewModel()
    {
        Product = new();
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="product">Product</param>
    public ProductViewModel(Product product)
    {
        Product = product;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Product
    /// </summary>
    public Product Product { get; }

    /// <summary>
    /// Product name
    /// </summary>
    public string ProductName => Product.Name;

    /// <summary>
    /// Product version
    /// </summary>
    public string ProductVersion => Product.Version;

    /// <summary>
    /// Product family
    /// </summary>
    public string ProductFamily => Product.ProductFamily.Name;

    /// <summary>
    /// Product business group
    /// </summary>
    public string ProductBusinessgroup => Product.Businessgroup;

    /// <summary>
    /// Product state
    /// </summary>
    public string ProductState => Product.State.ToString();

    /// <summary>
    /// Materialnumbers
    /// </summary>
    public string MaterialNumbers { get; set; } = string.Empty;

    #endregion
}
