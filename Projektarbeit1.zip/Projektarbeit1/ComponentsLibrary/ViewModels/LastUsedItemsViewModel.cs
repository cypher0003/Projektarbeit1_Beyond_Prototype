﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zeiss.Licensing.Data.Models;

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// Last used item view model
/// </summary>
public class LastUsedItemsViewModel : ObservableObject
{
    #region Fields

    private const int MaxNumberLastUsedItems = 10;

    private ObservableCollection<LastUsedItemViewModel> _LastUsedItemViewModels = new ObservableCollection<LastUsedItemViewModel>();

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    public LastUsedItemsViewModel()
    {
        LastUsedItemViewModels.CollectionChanged += LastUsedItemViewModels_CollectionChanged;
    }

    #endregion

    #region Properties

    public ObservableCollection<LastUsedItemViewModel> LastUsedItemViewModels
    {
        get => _LastUsedItemViewModels;
        set => SetProperty(ref _LastUsedItemViewModels, value);
    }

    #endregion

    #region Methods

    /// <summary>
    /// Returns all last used items
    /// </summary>
    /// <returns></returns>
    public List<LastUsedItem> GetLastUsedItems()
    {
        return LastUsedItemViewModels.Select(c => c.LastUsedItem).ToList();
    }

    /// <summary>
    /// Add a last used item at top of the list
    /// </summary>
    /// <param name="lastUsedItem"></param>
    public void Add(LastUsedItem lastUsedItem)
    {
        if (null != lastUsedItem)
        {
            var lastUsedItemViewModel = new LastUsedItemViewModel(lastUsedItem);
            var existingLastUsedItem = LastUsedItemViewModels.FirstOrDefault(c => c.ObjectType == lastUsedItemViewModel.ObjectType && c.ObjectId == lastUsedItemViewModel.ObjectId);

            if (null == existingLastUsedItem)
            {
                LastUsedItemViewModels.Insert(0, lastUsedItemViewModel);

                if (LastUsedItemViewModels.Count > MaxNumberLastUsedItems)
                {
                    LastUsedItemViewModels.RemoveAt(MaxNumberLastUsedItems);
                }
            }
            else
            {
                LastUsedItemViewModels.Remove(existingLastUsedItem);
                LastUsedItemViewModels.Insert(0, lastUsedItemViewModel);
            }
        }
    }

    /// <summary>
    /// Fill list
    /// </summary>
    /// <param name="lastUsedItems"></param>
    public void FillList(List<LastUsedItem> lastUsedItems)
    {
        LastUsedItemViewModels.Clear();

        foreach (var item in lastUsedItems)
        {
            var lastUsedItemViewModel = new LastUsedItemViewModel(item);
            LastUsedItemViewModels.Add(lastUsedItemViewModel);
        }
    }

    private void LastUsedItemViewModels_CollectionChanged(object? sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
    {
        OnPropertyChanged("");
    }

    #endregion
}
