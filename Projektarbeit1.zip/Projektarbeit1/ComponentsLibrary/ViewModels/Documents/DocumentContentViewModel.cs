﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;

namespace ComponentsLibrary.ViewModels.Documents;

public class DocumentContentViewModel : ObservableObject
{
    #region Fields

    private string? _Content;
    private string _Language = string.Empty;
    private string _Name = string.Empty;
    private DocumentState _State;
    private bool _IsFileLoading;

    #endregion

    #region Constructors

    public DocumentContentViewModel(DocumentContent documentContent)
    {
        DocumentContent = documentContent;

        ReadFromModel();
    }

    #endregion

    #region Properties

    public DocumentContent DocumentContent { get; }

    public bool IsNewAdded { get; set; }

    public string? Content
    {
        get => _Content;
        set => SetProperty(ref _Content, value);
    }

    public string Language
    {
        get => _Language;
        set => SetProperty(ref _Language, value);
    }

    public string Name
    {
        get => _Name;
        set => SetProperty(ref _Name, value);
    }

    public DocumentState State
    {
        get => _State;
        set => SetProperty(ref _State, value);
    }

    public bool IsFileLoading
    {
        get => _IsFileLoading;
        set => SetProperty(ref _IsFileLoading, value);
    }

    #endregion

    #region Methods

    public void SaveToModel()
    {
        DocumentContent.Content = _Content;
        DocumentContent.Language = _Language;
        DocumentContent.Name = _Name;
        DocumentContent.State = _State;
    }

    public void ReadFromModel()
    {
        Content = DocumentContent.Content;
        Language = DocumentContent.Language;
        Name = DocumentContent.Name;
        State = DocumentContent.State;
    }

    #endregion
}
