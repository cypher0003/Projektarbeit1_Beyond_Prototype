﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace ComponentsLibrary.ViewModels.Documents;

public class DocumentViewModel : ObservableObject
{
    #region Fields

    private string _Businessgroup = string.Empty;
    private string _ProductFamily = string.Empty;
    private string _Name = string.Empty;
    private string _Description = string.Empty;
    private DocumentState _State = DocumentState.DRAFT;

    #endregion

    #region Constructors

    public DocumentViewModel(Document document)
    {
        Document = document;

        ReadFromModel();
    }

    #endregion

    #region Properties

    public Document Document { get; private set; }

    public ObservableCollection<DocumentContentViewModel> Contents { get; set; } = new ObservableCollection<DocumentContentViewModel>();

    public string Businessgroup
    {
        get => _Businessgroup;
        set => SetProperty(ref _Businessgroup, value);
    }

    public string ProductFamily
    {
        get => _ProductFamily;
        set => SetProperty(ref _ProductFamily, value);
    }

    public string Name
    {
        get => _Name;
        set => SetProperty(ref _Name, value);
    }

    public string Description
    {
        get => _Description;
        set => SetProperty(ref _Description, value);
    }

    public DocumentState State
    {
        get => _State;
        set => SetProperty(ref _State, value);
    }

    #endregion

    #region Methods

    public void UpdateDocument(Document document)
    {
        Document = document;

        ReadFromModel();
    }

    public void SaveToModel()
    {
        Document.Businessgroup = Businessgroup;
        Document.ProductFamily = ProductFamily;
        Document.Name = Name;
        Document.Description = Description;
        Document.State = State;

        Document.Contents.Clear();

        foreach (var documentContent in Contents)
        {
            documentContent.SaveToModel();
            Document.Contents.Add(documentContent.DocumentContent);
        }
    }

    public void ReadFromModel()
    {
        Businessgroup = Document.Businessgroup;
        ProductFamily = Document.ProductFamily;
        Name = Document.Name;
        Description = Document.Description;

        Contents.Clear();

        foreach (var documentContent in Document.Contents)
        {
            Contents.Add(new DocumentContentViewModel(documentContent));
        }

        State = Document.State;
    }

    #endregion
}
