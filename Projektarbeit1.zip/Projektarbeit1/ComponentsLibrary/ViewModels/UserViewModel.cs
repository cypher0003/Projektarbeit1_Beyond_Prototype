﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// ViewModel to display all user Data
/// </summary>
public class UserViewModel
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="user">User</param>
    public UserViewModel(User user)
    {
        User = user;

        // Organizations
        if (User.IsPublisher)
        {
            Organizations = User.OrganizationName;
        }
        else
        {
            Organizations = string.Join(", ", User.OrganizationNumbers);
        }

        // Roles
        Roles = string.Join(", ", User.Roles.Select(c => c.Name).ToList());

        // Modules
        Modules = string.Join(", ", User.Modules.Select(c => c.Name).ToList());

        // Productfamilies
        List<string> prodfam = new();

        foreach (var role in User.Roles)
        {
            prodfam.AddRange(role.ProductFamilies);
        }

        ProductFamilies = string.Join(", ", prodfam.Distinct());
    }

    #endregion

    #region Properties

    /// <summary>
    /// User
    /// </summary>
    public User User { get; }

    /// <summary>
    /// Id
    /// </summary>
    public string Id => User.Id;

    /// <summary>
    /// Name
    /// </summary>
    public string Name => User.Name;

    /// <summary>
    /// Email
    /// </summary>
    public string Email => User.Email;

    /// <summary>
    /// Publisher or ChannelPartner
    /// </summary>
    public string PublisherChannelPartner => User.IsPublisher ? SharedResource.PUBLISHER : SharedResource.CHANNELPARTNER;

    /// <summary>
    /// LastLogin
    /// </summary>
    public string LastLogin => User.LastLogin.Date.Equals(new DateTime(1, 1, 1)) ? "" : User.LastLogin.ToString("MM/dd/yyyy HH:mm:ss");

    /// <summary>
    /// Organization Name
    /// </summary>
    public string Organizations { get; set; }

    /// <summary>
    /// Roles
    /// </summary>
    public string Roles { get; }

    /// <summary>
    /// Modules
    /// </summary>
    public string Modules { get; }

    /// <summary>
    /// Product families
    /// </summary>
    public string ProductFamilies { get; }

    /// <summary>
    /// Admin Businessgroup
    /// </summary>
    public string AdminBusinessgroup => User.AdminBusinessGroup;

    /// <summary>
    /// Enabled
    /// </summary>
    public string Enabled => User.State == UserState.ENABLE ? SharedResource.ENABLE : SharedResource.DISABLE;

    #endregion
}
