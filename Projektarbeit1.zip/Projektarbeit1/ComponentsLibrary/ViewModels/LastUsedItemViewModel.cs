﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zeiss.Licensing.Data.Models;

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// Last used item view model
/// </summary>
public class LastUsedItemViewModel : ObservableObject
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="lastUsedItem">Last used item model</param>
    public LastUsedItemViewModel(LastUsedItem lastUsedItem)
    {
        LastUsedItem = lastUsedItem;
    }

    #endregion

    #region Properties

    public LastUsedItem LastUsedItem { get; }


    public string ObjectId
    {
        get => LastUsedItem.ObjectId;
        set => SetProperty(LastUsedItem.ObjectId, value, LastUsedItem, (l, o) => l.ObjectId = o);
    }

    public string ObjectName
    {
        get => LastUsedItem.ObjectName;
        set => SetProperty(LastUsedItem.ObjectName, value, LastUsedItem, (l, o) => l.ObjectName = o);
    }

    public string ObjectType
    {
        get => LastUsedItem.ObjectType;
        set => SetProperty(LastUsedItem.ObjectType, value, LastUsedItem, (l, o) => l.ObjectType = o);
    }

    public string ObjectTypeName
    {
        get => LastUsedItem.ObjectTypeName;
        set => SetProperty(LastUsedItem.ObjectTypeName, value, LastUsedItem, (l, o) => l.ObjectTypeName = o);
    }

    #endregion
}
