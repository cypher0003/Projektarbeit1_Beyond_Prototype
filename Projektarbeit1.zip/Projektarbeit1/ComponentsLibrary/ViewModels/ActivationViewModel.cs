﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace ComponentsLibrary.ViewModels;

/// <summary>
/// Activation view model
/// </summary>
public class ActivationViewModel
{
    #region Properties

    public ActivationRequest ActivationRequest { get; set; } = new ActivationRequest();

    public string ProductKey { get; set; } = string.Empty;

    public string DownloadManualText { get; set; } = string.Empty;

    public bool IsActivationMode { get; set; } = false;

    public bool IsNextDisabled { get; set; } = false;

    public bool IsCancelDisabled { get; set; } = false;

    public bool IsManualLoading { get; set; } = false;

    public bool IsEntitlementActivation { get; set; }

    public bool ShowManualAlert { get; set; } = false;


    public List<CollapseLockmodeViewModel> ListOfCollapseVMs { get; set; } = new List<CollapseLockmodeViewModel>();

    public string ErrorZeissLicensingManualText { get; set; } = string.Empty;

    public string ValidationErrorText { get; set; } = string.Empty;

    public bool IsNameInvalid { get; set; }

    #endregion

    #region Methods

    public void SetStateOfInvalidName(bool invalidName)
    {
        foreach (var collapseLockmodeViewModel in ListOfCollapseVMs)
        {
            collapseLockmodeViewModel.DeviceNameInvalid = invalidName;
        }
    }

    #endregion
}
