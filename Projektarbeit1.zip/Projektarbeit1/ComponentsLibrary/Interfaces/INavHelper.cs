﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComponentsLibrary.Interfaces;

/// <summary>
/// Interface Nave Helper
/// </summary>
public interface INavHelper
{
    #region Events

    /// <summary>
    /// Nav item is clicked event
    /// </summary>
    event Action<string>? NavItemClicked;

    #endregion

    #region Methods

    /// <summary>
    /// Nav item clicked
    /// </summary>
    /// <param name="route">route of item</param>
    void OnNavItemClicked(string route);

    #endregion
}
