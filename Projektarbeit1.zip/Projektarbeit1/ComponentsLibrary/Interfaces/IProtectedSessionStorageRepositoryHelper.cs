﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComponentsLibrary.Interfaces;

/// <summary>
/// Interface Nave Helper
/// </summary>
public interface IProtectedSessionStorageRepositoryHelper
{
    #region Methods

    /// <summary>
    /// Load email from storage
    /// </summary>
    Task LoadEmailAddress();

    /// <summary>
    /// Set email address and flag in storage
    /// </summary>
    /// <param name="emailAddress">Email address</param>
    /// <returns></returns>
    Task LoginWithEmailAddress(string emailAddress);

    /// <summary>
    /// Service login
    /// </summary>
    /// <param name="emailAddress">Email address</param>
    /// <returns></returns>
    Task ServiceLogin(string emailAddress);

    /// <summary>
    /// Delete email from storage
    /// </summary>
    Task DeleteEmailAddress();

    /// <summary>
    /// Check if Emergency login is used
    /// </summary>
    /// <returns>True: emergency login</returns>
    Task<bool> IsEmergencyLoggedIn();

    /// <summary>
    /// Check if service login is used
    /// </summary>
    /// <returns>True: service login</returns>
    Task<bool> IsServiceLoggedIn();

    #endregion
}
