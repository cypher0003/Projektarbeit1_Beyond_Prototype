﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComponentsLibrary.Auth;

public class BlazorServerAuthStateCache
{
    #region Fields

    private readonly ConcurrentDictionary<string, BlazorServerAuthData> Cache
        = new ConcurrentDictionary<string, BlazorServerAuthData>();

    private readonly ILogger<BlazorServerAuthStateCache> _logger;

    #endregion

    #region Constructors

    public BlazorServerAuthStateCache(ILogger<BlazorServerAuthStateCache> logger)
    {
        _logger = logger;
    }

    #endregion

    #region Methods

    public bool HasObjectId(string objectId)
    {
        return Cache.ContainsKey(objectId);
    }

    public void Add(string objectId, DateTimeOffset expiration, string idToken, string accessToken, string refreshToken, DateTimeOffset refreshAt)
    {
        _logger.LogDebug($"AUTH: Caching oid: {objectId}");

        var data = new BlazorServerAuthData
        {
            ObjectId = objectId,
            Expiration = expiration,
            IdToken = idToken,
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            RefreshAt = refreshAt,
            LastUserAction = DateTime.UtcNow,
        };

        Cache.AddOrUpdate(objectId, data, (k, v) => data);
    }

    /// <summary>
    /// Get BlazorServerAuthData
    /// </summary>
    /// <param name="objectId">Object id</param>
    /// <returns></returns>
    public BlazorServerAuthData Get(string objectId)
    {
        Cache.TryGetValue(objectId, out var data);
        return data!;
    }

    /// <summary>
    /// Remove BlazorServerAuthData
    /// </summary>
    /// <param name="objectId">Object id</param>
    public void Remove(string objectId)
    {
        _logger.LogDebug($"AUTH: Removing oid from cache: {objectId}");
        Cache.TryRemove(objectId, out _);
    }

    #endregion
}
