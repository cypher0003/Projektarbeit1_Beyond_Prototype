﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComponentsLibrary.Auth;

public static class AuthDefaults
{
    #region Fields

    public const string OBJECT_IDENTIFIER_CLAIM = "http://schemas.microsoft.com/identity/claims/objectidentifier";
    public const string OBJECT_IDENTIFIER_CLAIM_EMERGANCY = "http://schemas.microsoft.com/identity/claims/tenantid";
    public const int REVALIDATION_INTERVAL = 10;
    public const int AUTOMATIC_LOGOUT_TIMEOUT = 30;

    /// <summary>
    /// License expired
    /// </summary>
    public const string LICENSE_EXPIRED = "LicenseExpired";

    #endregion
}
