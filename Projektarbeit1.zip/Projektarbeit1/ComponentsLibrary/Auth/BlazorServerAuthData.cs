﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComponentsLibrary.Auth;

public class BlazorServerAuthData
{
    #region Properties

    public string ObjectId { get; set; } = string.Empty;

    public DateTimeOffset Expiration { get; set; }

    public string IdToken { get; set; } = string.Empty;

    public string AccessToken { get; set; } = string.Empty;

    public string RefreshToken { get; set; } = string.Empty;

    public DateTimeOffset RefreshAt { get; set; }

    public DateTime LastUserAction { get; set; }

    #endregion
}
