﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace ComponentsLibrary.Models;

public class CountryModel
{
    #region Properties

    /// <summary>
    /// Name of country
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Code (Alpha-2 code) of country
    /// </summary>
    public string Code { get; set; } = string.Empty;

    #endregion
}
