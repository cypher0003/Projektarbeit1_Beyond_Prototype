﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace ComponentsLibrary.Models;

/// <summary>
/// Class for all data selecting several organizations/customers
/// </summary>
public class CustomerSelectionModel
{
    #region Properties

    /// <summary>
    /// Factory text
    /// </summary>
    public string FactoryText { get; set; } = string.Empty;

    /// <summary>
    /// Distributor text
    /// </summary>
    public string DistributorText { get; set; } = string.Empty;

    /// <summary>
    /// SSC1 text
    /// </summary>
    public string SSC1Text { get; set; } = string.Empty;

    /// <summary>
    /// SSC2 text
    /// </summary>
    public string SSC2Text { get; set; } = string.Empty;

    /// <summary>
    /// EndCustomer text
    /// </summary>
    public string EndcustomerText { get; set; } = string.Empty;

    /// <summary>
    /// Factory number
    /// </summary>
    public string FactoryNumber { get; set; } = string.Empty;

    /// <summary>
    /// Distributor number
    /// </summary>
    public string DistributorNumber { get; set; } = string.Empty;

    /// <summary>
    /// SSC1 number
    /// </summary>
    public string SSC1Number { get; set; } = string.Empty;

    /// <summary>
    /// SSC2 number
    /// </summary>
    public string SSC2Number { get; set; } = string.Empty;

    /// <summary>
    /// EndCustomer number
    /// </summary>
    public string EndcustomerNumber { get; set; } = string.Empty;

    /// <summary>
    /// Factory
    /// </summary>
    public RefOrganization? Factory { get; set; }

    /// <summary>
    /// Distributor
    /// </summary>
    public RefOrganization? Distributor { get; set; }

    /// <summary>
    /// SSC1
    /// </summary>
    public RefOrganization? SSC1 { get; set; }

    /// <summary>
    /// SSC2
    /// </summary>
    public RefOrganization? SSC2 { get; set; }

    /// <summary>
    /// EndCustomer
    /// </summary>
    public RefOrganization? Endcustomer { get; set; }

    #endregion
}
