﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;

namespace ComponentsLibrary.Models;

/// <summary>
/// Model for selection, e.g. Dropdownlist
/// </summary>
public class SelectModel
{
    #region Properties

    /// <summary>
    /// Value 
    /// </summary>
    public int Value { get; set; }

    /// <summary>
    /// Text
    /// </summary>
    public string Text { get; set; } = string.Empty;

    #endregion
}
