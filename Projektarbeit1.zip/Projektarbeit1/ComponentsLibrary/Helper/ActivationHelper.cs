﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;


namespace ComponentsLibrary.Helper;

public static class ActivationHelper
{
    #region Properties

    public static string TimeStamp => $"[{DateTime.Now:MM/dd/yyyy HH:mm:ss}] ";

    #endregion

    #region Methods

    /// <summary>
    /// Active product keys and/or entitlement ids
    /// </summary>
    /// <param name="activationRequest">Activation request</param>
    /// <param name="activationClient">activation client</param>
    /// <param name="JSRuntime">JSRuntime</param>
    /// <param name="logger"></param>
    /// <returns></returns>
    public static async Task<bool> Activate<T>(ActivationRequest activationRequest, IActivationClient activationClient, IJSRuntime JSRuntime, ILogger<T> logger)
    {
        var activationResponse = await activationClient.Activate(activationRequest);

        foreach (var item in activationResponse.Licenses)
        {
            var filename = $"{item.FileName}.{item.Extension}";
            var LicenseString = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(item.LicenseString));

            logger.LogDebug($"{TimeStamp} Save ActivateResponse({filename}) Start");

            if (item.Extension == "bin")
            {
                var byteArr = Convert.FromBase64String(LicenseString);
                await FileHelper.SaveBinaryFile(JSRuntime, filename, byteArr);
            }
            else
            {
                await FileHelper.SaveFile(JSRuntime, filename, LicenseString);
            }

            logger.LogDebug($"{TimeStamp} Save ActivateResponse({filename}) End");
        }

        return activationResponse.Licenses.Count > 0;
    }

    #endregion
}
