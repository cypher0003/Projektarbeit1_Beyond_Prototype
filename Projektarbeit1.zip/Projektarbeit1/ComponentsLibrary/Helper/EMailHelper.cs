﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace ComponentsLibrary.Helper;

/// <summary>
/// Email Helper 
/// </summary>
public static class EMailHelper
{
    #region Methods

    /// <summary>
    /// Validate eMail addresses
    /// </summary>
    /// <param name="email">Email address</param>
    /// <returns>True: email corrct</returns>
    public static bool IsEmailValid(string email)
    {
        return Regex.IsMatch(email, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$");
    }

    #endregion
}
