﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Exceptions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using Zeiss.Licensing.Backend.Logic.Interfaces;
using Zeiss.Licensing.Backend.WebServiceClient.Helper;
using Zeiss.Licensing.Data.HttpClientProvider;
using Microsoft.AspNetCore.Components;
using ComponentsLibrary.Auth;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using ComponentsLibrary.Interfaces;
using System.Text;

namespace ComponentsLibrary.Helper;

/// <summary>
/// Http Client provider class
/// </summary>
public class HttpClientProvider : IHttpClientProvider
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="configuration"><Configuration/param>
    /// <param name="logger">logger</param>
    /// <paramref name="cache">Authentication cache</paramref>
    public HttpClientProvider(
        IConfiguration configuration,
        ILogger logger,
        BlazorServerAuthStateCache cache,
        IProtectedSessionStorageRepositoryHelper protectedSessionStorageRepositoryHelper,
        IKeyVaultProvider keyVaultProvider)
    {
        Configuration = configuration;
        Logger = logger;
        Cache = cache;
        _protectedSessionStorageRepositoryHelper = protectedSessionStorageRepositoryHelper;
        _keyVaultProvider = keyVaultProvider;
    }

    #endregion

    #region Properties

    public string IDToken { get; set; } = string.Empty;

    public string RefreshToken { get; set; } = string.Empty;

    public bool IsEmergencyAuthorizationActive { get; set; }

    private BlazorServerAuthStateCache Cache { get; }

    private IConfiguration Configuration { get; }

    private ILogger Logger { get; }

    private IProtectedSessionStorageRepositoryHelper _protectedSessionStorageRepositoryHelper { get; }

    private IKeyVaultProvider _keyVaultProvider { get; }

    #endregion

    #region Methods

    /// <summary>
    /// Get Http Client 
    /// </summary>
    /// <param name="httpClientType">Type</param>
    /// <returns>New HttpClient</returns>
    public HttpClient GetHttpClient(EHttpClientType httpClientType)
    {
        throw new NotImplementedException();
    }

    /// <summary>
    /// Get Http Client 
    /// </summary>
    /// <param name="httpClientType">Type</param>
    /// <returns>New HttpClient</returns>
    public async Task<HttpClient> GetHttpClientAsync(EHttpClientType httpClientType)
    {
        HttpClient newHttpClient = new();
        var protectedSessionStorageRepositoryHelper = (ProtectedSessionStorageRepositoryHelper)_protectedSessionStorageRepositoryHelper;

        var baseUrl = string.Empty;
        var isEmergencyLoggedIn = false;
        var isServiceLoggedIn = false;

        if (IsEmergencyAuthorizationActive)
        {
            isEmergencyLoggedIn = await protectedSessionStorageRepositoryHelper.IsEmergencyLoggedIn();
            isServiceLoggedIn = await protectedSessionStorageRepositoryHelper.IsServiceLoggedIn();
        }

        if (isServiceLoggedIn)
        {
            var key = await _keyVaultProvider.GetKeyVaultSecret("EmergencyAuthorizationKey");
            newHttpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", key);
        }
        else if (isEmergencyLoggedIn)
        {
            await protectedSessionStorageRepositoryHelper.LoadEmailAddress();
            var emailaddress = protectedSessionStorageRepositoryHelper.EmailAddress;

            if (Cache.HasObjectId(emailaddress))
            {
                var data = Cache.Get(emailaddress);

                // Expired ?
                var mins = data.Expiration.Subtract(DateTime.UtcNow).TotalMinutes;

                // 5 min left for following processes
                var invalid = mins < 5.0;

                if (invalid && httpClientType != EHttpClientType.User)
                {
                    throw new ZeissLicensingExpiredTokenException();
                }

                var basicAuth = string.Empty;

                if (data != null)
                {
                    basicAuth = data.IdToken;
                }

                newHttpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", basicAuth);
            }
        }
        else
        {
            newHttpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", IDToken);
        }

        // not logged in and want to activate
        JwtSecurityTokenHandler jwtSecurityTokenHandler = new();

        if (!(string.IsNullOrWhiteSpace(IDToken) && httpClientType == EHttpClientType.Activation) && jwtSecurityTokenHandler.CanReadToken(IDToken))
        {
            var token = jwtSecurityTokenHandler.ReadJwtToken(IDToken);
            var mins = token.ValidTo.Subtract(DateTime.UtcNow).TotalMinutes;

            // 5 min left for following processes
            var invalid = mins < 5.0;

            if (invalid && httpClientType != EHttpClientType.User)
            {
                throw new ZeissLicensingExpiredTokenException();
            }

            var oid = token.Claims.FirstOrDefault(c => c.Type == "oid")?.Value;
            oid ??= string.Empty;

            if (null != Cache && Cache.HasObjectId(oid))
            {
                var data = Cache.Get(oid);
                data.LastUserAction = DateTime.UtcNow;
            }
        }

        switch (httpClientType)
        {
            case EHttpClientType.Product:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlProduct"];
                break;
            case EHttpClientType.Entitlement:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlEntitlement"];
                break;
            case EHttpClientType.User:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlUser"];
                break;
            case EHttpClientType.Organization:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlOrganization"];
                break;
            case EHttpClientType.AppSetting:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlAppSetting"];
                break;
            case EHttpClientType.Report:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlReport"];
                break;
            case EHttpClientType.Device:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlDevice"];
                break;
            case EHttpClientType.License:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlLicense"];
                break;
            case EHttpClientType.Order:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlOrder"];
                break;
            case EHttpClientType.Activation:
                baseUrl = Configuration.GetSection("Endpoint")["baseUrlFunctionApps"];
                newHttpClient.DefaultRequestHeaders.Authorization = null;
                newHttpClient.DefaultRequestHeaders.Add("api-version", "1.0");
                var key = await _keyVaultProvider.GetKeyVaultSecret("SWLServicesSubscriptionKey");
                newHttpClient.DefaultRequestHeaders.Add("x-functions-key", key);
                break;
            case EHttpClientType.ESBSAPCore:
            case EHttpClientType.ESBMail:
            case EHttpClientType.EMS:
            case EHttpClientType.ESBSD:
            case EHttpClientType.ZeissIdDevice:
            case EHttpClientType.ZeissIdRead:
                throw new NotImplementedException();
        }

        newHttpClient.BaseAddress = new Uri(baseUrl);

        return newHttpClient;
    }

    #endregion
}
