﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Auth;
using ComponentsLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ComponentsLibrary.Helper;

/// <summary>
/// Emrgency helper
/// </summary>
public static class EmergencyHelper
{
    #region Methods

    /// <summary>
    /// Emergency logout
    /// </summary>
    /// <param name="_protectedSessionStorageRepositoryHelper">Storage</param>
    /// <param name="_cache">Cache</param>
    /// <returns></returns>
    public static async Task EmergencyLogout(IProtectedSessionStorageRepositoryHelper _protectedSessionStorageRepositoryHelper, BlazorServerAuthStateCache _cache)
    {
        var emailaddress = ((ProtectedSessionStorageRepositoryHelper)_protectedSessionStorageRepositoryHelper).EmailAddress;

        if (!string.IsNullOrWhiteSpace(emailaddress) && _cache.HasObjectId(emailaddress))
        {
            _cache.Remove(emailaddress);
        }

        await _protectedSessionStorageRepositoryHelper.DeleteEmailAddress();
    }

    #endregion
}
