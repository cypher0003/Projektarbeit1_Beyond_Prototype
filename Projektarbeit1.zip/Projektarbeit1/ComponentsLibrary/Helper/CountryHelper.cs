﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Models;
using ResourceLibrary.Resources;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Resources;
using System.Linq;

namespace ComponentsLibrary.Helper;

public static class CountryHelper
{
    #region Methods

    /// <summary>
    /// Get country codes list
    /// </summary>
    /// <returns>Country codes list</returns>
    public static List<CountryModel> GetCountryList()
    {
        var countryModels = new List<CountryModel>();

        var resourceManager = new ResourceManager(typeof(CountryCodes));
        var resourceSet = resourceManager.GetResourceSet(CultureInfo.CurrentUICulture, true, true);

        if (null != resourceSet)
        {
            foreach (DictionaryEntry entry in resourceSet)
            {
                countryModels.Add(new CountryModel { Code = entry.Key.ToString() ?? string.Empty, Name = entry.Value?.ToString() ?? string.Empty });
            }
        }

        countryModels = countryModels.OrderBy(c => c.Name).ToList();

        return countryModels;
    }

    /// <summary>
    /// Get Country by code
    /// </summary>
    /// <param name="code">Code of country</param>
    /// <returns>Country</returns>
    public static string GetCountryByCode(string code)
    {
        try
        {
            var resourceManager = new ResourceManager(typeof(CountryCodes));
            return resourceManager.GetString(code) ?? string.Empty;
        }
        catch (Exception)
        {
            return string.Empty;
        }
    }

    #endregion
}
