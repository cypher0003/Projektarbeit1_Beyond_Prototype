﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.JSInterop;


namespace ComponentsLibrary.Helper;

public static class FileHelper
{
    #region Methods

    /// <summary>
    /// Save file
    /// </summary>
    /// <param name="fileName">Filename</param>
    /// <param name="content">Content</param>
    public static async Task SaveFile(IJSRuntime jsRuntime, string fileName, string content)
    {
        await jsRuntime.InvokeAsync<object>(
            "FileSaveAs",
            fileName,
            content
        );
    }

    /// <summary>
    /// Save binary file
    /// </summary>
    /// <param name="fileName">Filename</param>
    /// <param name="data">Data</param>
    public static async Task SaveBinaryFile(IJSRuntime jsRuntime, string fileName, byte[] data)
    {
        await jsRuntime.InvokeAsync<object>(
            "BinaryFileSaveAs",
            fileName,
            Convert.ToBase64String(data)
        );
    }

    #endregion
}
