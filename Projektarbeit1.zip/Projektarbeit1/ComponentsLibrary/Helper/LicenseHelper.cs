﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Zeiss.Licensing.Data.Models;
using ResourceLibrary.Resources;
using Microsoft.JSInterop;
using System.Threading.Tasks;
using System.Linq;
using Zeiss.Licensing.Data.TransferObjects;

namespace ComponentsLibrary.Helper;

/// <summary>
/// Helper class for licenses, e.g. saving
/// </summary>
public static class LicenseHelper
{
    #region Methods

    /// <summary>
    /// Save license depending on license type/extension
    /// </summary>
    /// <param name="license">License</param>
    /// <param name="jsRuntime">js Runtime</param>
    public static async Task SaveLicenseFile(Activation license, IJSRuntime jsRuntime)
    {
        var filename = string.IsNullOrWhiteSpace(license.ActivatonProductKey) ? LicenseResource.DOWNLOADDEFAULTFILENAME : license.ActivatonProductKey;
        var ext = license.LicenseFileExtension;
        var ext2 = ext.StartsWith(".") ? ext : "." + ext;
        ext = string.IsNullOrWhiteSpace(ext) ? ".zlic" : ext2;
        filename += ext;

        switch (ext)
        {
            case ".bin":
                var newBytes = Convert.FromBase64String(license.LicenseKey);
                await FileHelper.SaveBinaryFile(jsRuntime, filename, newBytes);
                break;
            default:
                await FileHelper.SaveFile(jsRuntime, filename, license.LicenseKey);
                break;
        }
    }

    /// <summary>
    /// Save license depending on license type/extension
    /// </summary>
    /// <param name="licenseKey">License key</param>
    /// <param name="extension">Extension</param>
    /// <param name="filename">Filename</param>
    /// <param name="jsRuntime">js Runtime</param>
    /// <returns></returns>
    public static async Task SaveConsolidatedLicenseFile(DeviceLicenseResponse deviceLicenseResponse, IJSRuntime jsRuntime)
    {
        foreach (var licenseFile in deviceLicenseResponse.LicenseFiles)
        {
            var ext = licenseFile.Extension.StartsWith(".") ? licenseFile.Extension : "." + licenseFile.Extension;
            var extension = string.IsNullOrWhiteSpace(licenseFile.Extension) ? ".zlic" : ext;
            var filename = licenseFile.FileName + extension;

            switch (extension)
            {
                case ".bin":
                    var newBytes = Convert.FromBase64String(licenseFile.LicenseString);
                    await FileHelper.SaveBinaryFile(jsRuntime, filename, newBytes);
                    break;
                default:
                    await FileHelper.SaveFile(jsRuntime, filename, licenseFile.LicenseString);
                    break;
            }
        }
    }

    #endregion
}
