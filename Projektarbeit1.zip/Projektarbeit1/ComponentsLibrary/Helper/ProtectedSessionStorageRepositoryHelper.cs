﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;

namespace ComponentsLibrary.Helper;

public class ProtectedSessionStorageRepositoryHelper : IProtectedSessionStorageRepositoryHelper
{
    #region Fields

    private const string EMAILADDRESS = "emailaddress";
    private const string ISLOGGEDINFLAG = "isloggedinflag";
    private const string ISSERVICELOGGEDINFLAG = "isserviceloggedinflag";

    #endregion

    #region Constructors

    public ProtectedSessionStorageRepositoryHelper(ProtectedSessionStorage protectedSessionStorage)
    {
        ProtectedSessionStore = protectedSessionStorage;
    }

    #endregion

    #region Properties

    public string EmailAddress { get; set; } = string.Empty;

    /// <summary>
    /// Login flag
    /// </summary>
    private bool IsLoggedIn { get; set; }

    private ProtectedSessionStorage ProtectedSessionStore { get; }

    private bool IsLoadedFromStorage { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Check if Emergency login is used
    /// </summary>
    /// <returns>True: emergency login</returns>
    public async Task<bool> IsEmergencyLoggedIn()
    {
        try
        {
            var result = await ProtectedSessionStore.GetAsync<bool>(ISLOGGEDINFLAG);

            if (result.Success)
            {
                IsLoggedIn = result.Value;
            }
            else
            {
                IsLoggedIn = false;
            }
        }
        catch (Exception)
        {
            IsLoggedIn = false;
        }

        return IsLoggedIn;
    }

    /// <summary>
    /// Check if service login is used
    /// </summary>
    /// <returns>True: service login</returns>
    public async Task<bool> IsServiceLoggedIn()
    {
        try
        {
            var result = await ProtectedSessionStore.GetAsync<bool>(ISSERVICELOGGEDINFLAG);

            if (result.Success)
            {
                return true;
            }

            return false;
        }
        catch (Exception)
        {
            return false;
        }
    }

    /// <summary>
    /// Load email from storage
    /// </summary>
    public async Task LoadEmailAddress()
    {
        if (!IsLoadedFromStorage)
        {
            var result = await ProtectedSessionStore.GetAsync<string>(EMAILADDRESS);

            if (result.Success)
            {
                IsLoadedFromStorage = true;
                EmailAddress = string.IsNullOrWhiteSpace(result.Value) ? string.Empty : result.Value;
            }
            else
            {
                EmailAddress = string.Empty;
            }
        }
    }

    /// <summary>
    /// Set email address and flag in storage
    /// </summary>
    /// <param name="emailAddress">Email address</param>
    public async Task LoginWithEmailAddress(string emailAddress)
    {
        EmailAddress = emailAddress;
        await ProtectedSessionStore.SetAsync(EMAILADDRESS, EmailAddress);
        await ProtectedSessionStore.SetAsync(ISLOGGEDINFLAG, true);
        await ProtectedSessionStore.DeleteAsync(ISSERVICELOGGEDINFLAG);
        IsLoggedIn = true;
    }

    /// <summary>
    /// Service login: just store email address, not logged in
    /// </summary>
    /// <param name="emailAddress">Email address</param>
    public async Task ServiceLogin(string emailAddress)
    {
        EmailAddress = emailAddress;
        await ProtectedSessionStore.SetAsync(EMAILADDRESS, EmailAddress);
        await ProtectedSessionStore.SetAsync(ISSERVICELOGGEDINFLAG, true);
    }

    /// <summary>
    /// Delete email from storage
    /// </summary>
    public async Task DeleteEmailAddress()
    {
        IsLoadedFromStorage = false;
        EmailAddress = string.Empty;
        await ProtectedSessionStore.DeleteAsync(EMAILADDRESS);
        await ProtectedSessionStore.DeleteAsync(ISLOGGEDINFLAG);
        IsLoggedIn = false;
    }

    #endregion
}
