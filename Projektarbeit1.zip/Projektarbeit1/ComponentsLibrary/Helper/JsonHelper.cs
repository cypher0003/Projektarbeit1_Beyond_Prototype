﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace ComponentsLibrary.Helper;

public static class JsonHelper
{
    #region Methods

    /// <summary>
    /// Create JSON of Object
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="obj">object</param>
    /// <returns>JSON-String</returns>
    public static string GetJSON<T>(T obj)
    {
        var ret = string.Empty;

        try
        {
            var seropt = new JsonSerializerOptions
            {
                //IgnoreNullValues = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true,
                PropertyNameCaseInsensitive = true
            };

            ret = JsonSerializer.Serialize(obj, seropt);
        }
        catch (Exception)
        {
            ret = string.Empty;
        }

        return ret;
    }

    #endregion
}
