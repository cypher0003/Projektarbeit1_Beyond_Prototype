﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Text.RegularExpressions;

namespace ComponentsLibrary.Helper;

public static class DeviceHelper
{
    #region Methods

    /// <summary>
    /// Validate the device name add entering text
    /// </summary>
    /// <param></param>
    /// <param name="deviceName">Name of the device to be validated</param>
    /// <param name="deviceType">Device type</param>
    /// <returns>Validation status</returns>
    public static ValidationStatus ValidateDeviceName(string? deviceName, DeviceType? deviceType)
    {
        if (string.IsNullOrEmpty(deviceName))
        {
            return ValidationStatus.None;
        }

        if (string.IsNullOrEmpty(deviceType?.Validation))
        {
            return ValidationStatus.None;
        }

        var m = Regex.Match(deviceName, deviceType.Validation);
        return m.Success ? ValidationStatus.Success : ValidationStatus.Error;
    }

    /// <summary>
    /// Creates the error text, if the device name is invalid
    /// </summary>
    /// <param name="selectedDeviceType">Device type with the validation string</param>
    /// <returns>Error text or empty text if no validation</returns>
    public static string CreateValidationErrorText(DeviceType? selectedDeviceType)
    {
        if (!string.IsNullOrWhiteSpace(selectedDeviceType?.Validation))
        {
            var start = selectedDeviceType.Validation.StartsWith("^") ? 1 : 0;
            var length = (selectedDeviceType.Validation.EndsWith("$") ? selectedDeviceType.Validation.Length - 1 : selectedDeviceType.Validation.Length) - start;
            var validationArg = selectedDeviceType.Validation.Substring(start, length);
            return string.Format(SharedResource.DEVICENAMEVALIDATIONERROR, validationArg);
        }

        return string.Empty;
    }

    #endregion
}
