﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Zeiss.Licensing.Data.Models;

namespace ComponentsLibrary.Helper;

public static class OrganizationHelper
{
    #region Methods

    /// <summary>
    /// Get text of the selected organization
    /// </summary>
    /// <returns>text of the selected organization</returns>
    public static string GetOrganizationText(RefOrganization organization)
    {
        if (null != organization)
        {
            var number = string.IsNullOrWhiteSpace(organization.Number) ? string.Empty : $"[{organization.Number}]";
            return $"{organization.Name} {number}";
        }

        return string.Empty;
    }

    #endregion
}
