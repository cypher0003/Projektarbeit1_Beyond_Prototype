﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ComponentsLibrary.Helper;

/// <summary>
/// Helper methods around the product
/// </summary>
public static class ProductHelper
{
    #region Methods

    /// <summary>
    /// 
    /// </summary>
    /// <returns>Country codes list</returns>
    public static bool CheckMaterialnumber(string materialNumber)
    {
        var countHyphen = materialNumber.Count(c => c == '-');

        var regex = countHyphen switch
        {
            1 => new Regex(@"^([0-9]{0,6}[\-]?[0-9]{0,4}[\-]?[0-9]{3})$"),
            2 => new Regex(@"^([0-9]{0,6}[\-]?[0-9]{4}[\-]?[0-9]{3})$"),
            _ => new Regex(@"^([0-9]{0,6}[\-]?[0-9]{0,4}[\-]?[0-9]{0,3})$"),
        };

        return regex.IsMatch(materialNumber);
    }

    #endregion
}
