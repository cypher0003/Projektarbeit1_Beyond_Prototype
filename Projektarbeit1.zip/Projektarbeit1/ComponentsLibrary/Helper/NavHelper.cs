﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Interfaces;


namespace ComponentsLibrary.Helper;

public class NavHelper : INavHelper
{
    #region Events

    /// <summary>
    /// Nav item is clicked event
    /// </summary>
    public event Action<string>? NavItemClicked;

    #endregion

    #region Methods

    /// <summary>
    /// Nav item clicked
    /// </summary>
    /// <param name="route">route of item</param>
    public void OnNavItemClicked(string route)
    {
        NavItemClicked?.Invoke(route);
    }

    #endregion
}
