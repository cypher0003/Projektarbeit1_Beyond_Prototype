﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;
using ComponentsLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zeiss.Licensing.Backend.WebServiceClient.Clients;

namespace ComponentsLibrary.Provider;

public class LastUsedItemsProvider : ObservableObject, ILastUsedItemProvider
{
    #region Fields

    private readonly Zeiss.Licensing.Backend.WebServiceClient.Interfaces.IUserClient _UserClient;

    private LastUsedItemsViewModel _LastUsedItemsViewModel = new LastUsedItemsViewModel();
    private User _CurrentUser = new User();

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="userClient">UserClient</param>
    public LastUsedItemsProvider(Zeiss.Licensing.Backend.WebServiceClient.Interfaces.IUserClient userClient)
    {
        _UserClient = userClient;
    }

    #endregion

    #region Properties

    public LastUsedItemsViewModel LastUsedItemsViewModel
    {
        get => _LastUsedItemsViewModel;
        set => SetProperty(ref _LastUsedItemsViewModel, value);
    }

    public User CurrentUser
    {
        get => _CurrentUser;
        set => SetProperty(ref _CurrentUser, value);
    }

    #endregion

    #region Methods

    /// <summary>
    /// Add last used item
    /// </summary>
    /// <param name="lastUsedItem">Last used item</param>
    /// <returns></returns>
    public void AddItem(LastUsedItem lastUsedItem)
    {
        LastUsedItemsViewModel.Add(lastUsedItem);
        _ = SaveLastUsedItems(lastUsedItem);
    }

    /// <summary>
    /// Add a list of last used items without saving
    /// </summary>
    /// <param name="user"></param>
    public void SetUser(User user)
    {
        CurrentUser = user;
        LastUsedItemsViewModel.FillList(user.LastUsedItems);
    }

    /// <summary>
    /// Returns the icon of the object type of the last used item
    /// </summary>
    /// <param name="lastUsedItemViewModel">Last used item</param>
    /// <returns></returns>
    public string GetIcon(LastUsedItemViewModel lastUsedItemViewModel)
    {
        var iconName = string.Empty;

        switch (lastUsedItemViewModel.ObjectType.ToLower())
        {
            case "entitlements":
                iconName = "zi-tutorial";
                break;
            case "licenses":
                iconName = "zi-documents";
                break;
            case "device":
                iconName = "zi-sbu-research-microscopy-solutions";
                break;
            case "products":
                iconName = "zi-camera-lenses";
                break;
            case "products/productvariants":
                iconName = "zi-popup-zoom-lightbox_1";
                break;
            default:
                iconName = "";
                break;
        }

        return iconName;
    }

    private async Task SaveLastUsedItems(LastUsedItem lastUsedItem)
    {
        List<LastUsedItem> allLastUsedItems = await _UserClient.AddLastUsedItem(CurrentUser.Id, lastUsedItem);
        LastUsedItemsViewModel.FillList(allLastUsedItems);
    }

    #endregion
}
