﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Zeiss.Licensing.Data.Exceptions;

namespace ComponentsLibrary.Exceptions;

public class ZeissLicensingExpiredTokenException : ZeissLicensingException
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    public ZeissLicensingExpiredTokenException()
    {
    }

    #endregion
}
