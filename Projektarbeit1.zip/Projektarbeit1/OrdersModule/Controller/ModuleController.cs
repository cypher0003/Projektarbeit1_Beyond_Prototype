﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Backend.UI.DataTypes;

namespace Zeiss.Licensing.Backend.UI.OrdersModule;

/// <summary>
/// Orders Module Controller
/// </summary>
public class ModuleController : IModuleController
{
    #region Methods

    /// <summary>
    /// Get Module
    /// </summary>
    /// <param name="user">User</param>
    /// <returns>Module</returns>
    public DataTypes.Module? GetModule(User user)
    {
        DataTypes.Module? retValue = null;

        if (user.AccountType == AccountType.SuperUser || user.Modules.Any(c => c.Name == "Orders"))
        {
            retValue = new DataTypes.Module("Orders", SharedResource.ORDERS, "zi-online-shop"); //zi-apply
        }

        return retValue;
    }

    #endregion
}
