﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace OrdersModule.Enums;

/// <summary>
/// Enum of all customers which can be added an organization
/// </summary>
public enum CustomerSelectType
{
    Endcustomer,
    SoldTo,
    ShipTo,
    SalesRep,
    SalesMan
}
