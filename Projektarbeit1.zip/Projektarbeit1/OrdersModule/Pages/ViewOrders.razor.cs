#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace OrdersModule.Pages;

public partial class ViewOrders
{
    #region Fields

    private string selectedTab = "header";

    private bool isReadOnly = true;
    private bool isEditEnabled = false;
    private bool isAddEnabled = true;
    private bool isDeleteEnabled = false;
    private bool isEditGranted = false;
    private bool isAddGranted = false;
    private bool isDeleteGranted = false;

    //Dialogs / Messageboxes
    private Alert? errorZeissLicensingAlert;
    private Modal? modalrefSelectOrder;

    #endregion

    #region Properties

    private Order SelectedOrder { get; set; } = new Order();

    private Order SelectedSelectOrder { get; set; } = new Order();

    private OrderPosition SelectedOrderPosition { get; set; } = new OrderPosition();

    private Enums.CustomerSelectType SelectedCustomerSelectType { get; set; } = Enums.CustomerSelectType.Endcustomer;

    private OrderPosition EditOriginalOrderPosition { get; set; } = new OrderPosition();

    private List<Order> SelectableOrders { get; set; } = new List<Order>();

    private long LoadOrderNumber { get; set; }

    private long ProcessOrderNumber { get; set; }

    private string EndcustomerText { get; set; } = string.Empty;

    private string SoldToText { get; set; } = string.Empty;

    private string ShipToText { get; set; } = string.Empty;

    private string SalesRepText { get; set; } = string.Empty;

    private string SalesManText { get; set; } = string.Empty;

    private bool IsAddPosition { get; set; }

    #endregion

    #region Methods

    protected override Task OnAfterRenderAsync(bool firstRender)
    {
        return base.OnAfterRenderAsync(firstRender);
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await userClient.Authenticate();
            isAddGranted = CurrentUser.AccountType    == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantOrder >= GrantType.Add);
            isDeleteGranted = CurrentUser.AccountType == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantOrder >= GrantType.Delete);
            isEditGranted = CurrentUser.AccountType   == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantOrder >= GrantType.Edit);
            SelectedOrder.Positions = new List<OrderPosition>();
            SelectedOrderPosition = new OrderPosition();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Tab Changed
    /// </summary>
    /// <param name = "name">Tab name</param>
    private void OnSelectedTabChanged(string name)
    {
        selectedTab = name;
    }

    /// <summary>
    /// Load button pressed
    /// </summary>
    private async Task OnLoadButtonClicked()
    {
        try
        {
            List<Order> listOfOrders = await orderClient.GetBySalesorderNumber(LoadOrderNumber.ToString());
            SelectableOrders = listOfOrders.OrderByDescending(c => c.CreationDate).ToList();

            if (SelectableOrders.Count > 0)
            {
                SelectedOrder = listOfOrders.First();

                if (SelectableOrders.Count > 1)
                {
                    SelectedSelectOrder = SelectedOrder;
                    await modalrefSelectOrder!.Show();
                }
                else
                {
                    UpdateCustomers();
                    StateHasChanged();
                }

                selectedTab = "header";
                ProcessOrderNumber = LoadOrderNumber;
            }
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await errorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// New button pressed
    /// </summary>
    private void OnNewButtonClicked()
    {
        SelectedOrder = new Order();
        ProcessOrderNumber = 0;
        selectedTab = "header";
        UpdateCustomers();
        StateHasChanged();
    }

    /// <summary>
    /// Process order button pressed
    /// </summary>
    private async Task OnProcessOrderClicked()
    {
        try
        {
            SelectedOrder.SalesorderNumber = ProcessOrderNumber.ToString();
            await orderClient.Add(SelectedOrder);
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            await errorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Update customer text fields
    /// </summary>
    private void UpdateCustomers()
    {
        EndcustomerText = OrganizationHelper.GetOrganizationText(SelectedOrder.EndCustomer);
        SoldToText = OrganizationHelper.GetOrganizationText(SelectedOrder.SoldTo);
        ShipToText = OrganizationHelper.GetOrganizationText(SelectedOrder.ShipTo);
        SalesRepText = OrganizationHelper.GetOrganizationText(SelectedOrder.SalesRepresentative);
        SalesManText = OrganizationHelper.GetOrganizationText(SelectedOrder.SalesMan);
    }

    /// <summary>
    /// Hide select order ok
    /// </summary>
    private void HideModalSelectOrderOK()
    {
        SelectedOrder = SelectedSelectOrder;
        UpdateCustomers();
        StateHasChanged();
        modalrefSelectOrder!.Hide();
    }

    /// <summary>
    /// Hide select order discard
    /// </summary>
    private void HideModalSelectOrderDiscard()
    {
        SelectedOrder = new Order();
        UpdateCustomers();
        StateHasChanged();
        modalrefSelectOrder!.Hide();
    }

    /// <summary>
    /// SMAPortal check change
    /// </summary>
    /// <param name = "isChecked">check state</param>
    private void OnSMAPortalCheckedChanged(bool isChecked)
    {
        SelectedOrder.SMAPortalProcess = isChecked;
        StateHasChanged();
    }

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    /// <param name = "customerType"></param>
    private void OnSelectOrgButtonClicked(Enums.CustomerSelectType customerType)
    {
        SelectedCustomerSelectType = customerType;
        ShowSearchOrganizationDialog = true;
    }

    /// <summary>
    /// Search organization OK pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(object organization)
    {
        ShowSearchOrganizationDialog = false;
        SetCustomerText((Organization)organization);
    }

    /// <summary>
    /// Search organization Discard pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        ShowSearchOrganizationDialog = false;
    }

    /// <summary>
    /// Delete organization
    /// </summary>
    /// <param name = "customerType"></param>
    private void OnDeleteOrgButtonClicked(Enums.CustomerSelectType customerType)
    {
        switch (customerType)
        {
            case Enums.CustomerSelectType.Endcustomer:
                EndcustomerText = string.Empty;
                SelectedOrder.EndCustomer = null;
                break;
            case Enums.CustomerSelectType.SoldTo:
                SoldToText = string.Empty;
                SelectedOrder.SoldTo = null;
                break;
            case Enums.CustomerSelectType.ShipTo:
                ShipToText = string.Empty;
                SelectedOrder.ShipTo = null;
                break;
            case Enums.CustomerSelectType.SalesRep:
                SalesRepText = string.Empty;
                SelectedOrder.SalesRepresentative = null;
                break;
            case Enums.CustomerSelectType.SalesMan:
                SalesManText = string.Empty;
                SelectedOrder.SalesMan = null;
                break;
        }
    }

    /// <summary>
    /// Set Text of selected customer type
    /// </summary>
    private void SetCustomerText(Organization organization)
    {
        switch (SelectedCustomerSelectType)
        {
            case Enums.CustomerSelectType.Endcustomer:
                EndcustomerText = OrganizationHelper.GetOrganizationText(organization);
                SelectedOrder.EndCustomer = organization;
                break;
            case Enums.CustomerSelectType.SoldTo:
                SoldToText = OrganizationHelper.GetOrganizationText(organization);
                SelectedOrder.SoldTo = organization;
                break;
            case Enums.CustomerSelectType.ShipTo:
                ShipToText = OrganizationHelper.GetOrganizationText(organization);
                SelectedOrder.ShipTo = organization;
                break;
            case Enums.CustomerSelectType.SalesRep:
                SalesRepText = OrganizationHelper.GetOrganizationText(organization);
                SelectedOrder.SalesRepresentative = organization;
                break;
            case Enums.CustomerSelectType.SalesMan:
                SalesManText = OrganizationHelper.GetOrganizationText(organization);
                SelectedOrder.SalesMan = organization;
                break;
        }
    }

    /// <summary>
    /// Selected order posiiton changed
    /// </summary>
    private void OnSelectedOrderPositionChanged(OrderPosition selp)
    {
        if (null != selp)
        {
            SelectedOrderPosition = selp;
        }

        EndEdit();
    }

    /// <summary>
    /// Edit button pressed
    /// </summary>
    private void OnEditButtonClicked()
    {
        IsAddPosition = false;
        EditOriginalOrderPosition = SelectedOrderPosition;
        SelectedOrderPosition = (OrderPosition)EditOriginalOrderPosition.Clone();
        StartEdit();
    }

    /// <summary>
    /// Add button pressed
    /// </summary>
    private void OnAddButtonClicked()
    {
        IsAddPosition = true;
        EditOriginalOrderPosition = SelectedOrderPosition;
        SelectedOrderPosition = new OrderPosition();
        StartEdit();
    }

    /// <summary>
    /// Delete button pressed
    /// </summary>
    private void OnDeleteButtonClicked()
    {
        if (SelectedOrder.Positions.Contains(SelectedOrderPosition))
        {
            ShowDeleteDialog = true;
        }
    }

    /// <summary>
    /// Delete Dialog OK
    /// </summary>
    private void OnDeleteOK()
    {
        try
        {
            SelectedOrder.Positions.Remove(SelectedOrderPosition);
            SelectedOrderPosition = new OrderPosition();
            ShowDeleteDialog = false;
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            errorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Delete Dialog Discard
    /// </summary>
    private void OnDeleteDiscard()
    {
        ShowDeleteDialog = false;
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private void OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            var idxOrig = SelectedOrder.Positions.IndexOf(EditOriginalOrderPosition);

            if (idxOrig < 0)
            {
                SelectedOrder.Positions.Add(SelectedOrderPosition);
            }
            else
            {
                SelectedOrder.Positions.Insert(IsAddPosition ? idxOrig + 1 : idxOrig, SelectedOrderPosition);

                if (!IsAddPosition)
                {
                    SelectedOrder.Positions.Remove(EditOriginalOrderPosition);
                }
            }

            EndEdit();
            errorZeissLicensingAlert!.Hide();
            StateHasChanged();
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, E);
            errorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            errorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        EndEdit();

        if (null != EditOriginalOrderPosition)
        {
            SelectedOrderPosition = EditOriginalOrderPosition;
        }
        else
        {
            SelectedOrderPosition = new OrderPosition();
        }

        // Empty selection
        if (string.IsNullOrWhiteSpace(SelectedOrder.Id))
        {
            isDeleteEnabled = false;
            isEditEnabled = false;
        }
    }

    /// <summary>
    /// Start editing/adding
    /// </summary>
    private void StartEdit()
    {
        isReadOnly = false;
        isAddEnabled = false;
        isDeleteEnabled = false;
        isEditEnabled = false;
    }

    /// <summary>
    /// End editing/adding
    /// </summary>
    private void EndEdit()
    {
        isReadOnly = true;
        isAddEnabled = isAddGranted;
        isDeleteEnabled = isDeleteGranted;
        isEditEnabled = isEditGranted;
        errorZeissLicensingAlert!.Hide();
    }

    #endregion
}
