﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Backend.UI.DataTypes;

namespace Zeiss.Licensing.Backend.UI.UserModule;

public class ModuleController : IModuleController
{
    #region Methods

    public DataTypes.Module? GetModule(User user)
    {
        DataTypes.Module? retValue = null;

        if (user.AccountType == AccountType.SuperUser || user.Modules.Any(c => c.Name == "User"))
        {
            retValue = new DataTypes.Module("user", SharedResource.USERS, "zi-group-workshops");

            retValue.AddSubmodule(SharedResource.ROLES, "Roles", "zi-equipment");
        }

        return retValue;
    }

    #endregion
}
