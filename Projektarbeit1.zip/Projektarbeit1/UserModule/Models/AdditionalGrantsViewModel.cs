﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Resources;

namespace UserModule.Models;

/// <summary>
/// Viewmodel for the additional grants dictionary entries
/// </summary>
public class AdditionalGrantsViewModel
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="grantName">Name</param>
    /// <param name="grantChecked">Flag if granted</param>
    public AdditionalGrantsViewModel(string grantName, bool grantChecked)
    {
        GrantChecked = grantChecked;
        GrantName = grantName;
        var resourceManager = new ResourceManager(typeof(SharedResource));
        GrantDisplayName = resourceManager.GetString("ADDITIONALGRANT" + GrantName.ToUpper()) ?? GrantName;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Flag, if the additional grant is checked
    /// </summary>
    public bool GrantChecked { get; set; }

    /// <summary>
    /// Name of the additional grant
    /// </summary>
    public string GrantName { get; set; }

    /// <summary>
    /// Display Name of the additional grant
    /// </summary>
    public string GrantDisplayName { get; set; }

    #endregion
}
