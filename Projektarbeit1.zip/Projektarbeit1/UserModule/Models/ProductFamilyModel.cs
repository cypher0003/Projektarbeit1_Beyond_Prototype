﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace UserModule.Pages;

/// <summary>
/// Class productfamily
/// </summary>
public class ProductFamilyModel
{
    #region Properties

    /// <summary>
    /// Selected
    /// </summary>
    public bool Selected { get; set; }

    /// <summary>
    /// Productfamily
    /// </summary>
    public ProductFamily Module { get; set; } = new ProductFamily();

    #endregion
}
