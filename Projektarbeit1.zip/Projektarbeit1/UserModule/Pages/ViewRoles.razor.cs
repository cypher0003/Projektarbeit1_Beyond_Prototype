#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using UserModule.Models;

namespace UserModule.Pages;

public partial class ViewRoles
{
    #region Fields

    private Alert? errorZeissLicensingAlert;
    private Modal? modalrefAddFamily;
    private DataGrid<ProductFamily>? dgRoleSelectedFamilies;

    #endregion

    #region Properties

    private List<ProductFamily> AllFamilies { get; set; } = new List<ProductFamily>();

    private List<ProductFamily> SelectedFamilies { get; set; } = new List<ProductFamily>();

    private List<ProductFamily> FilteredFamilies { get; set; } = new List<ProductFamily>();

    private List<AdditionalGrantsViewModel> AdditionalGrantsVMs { get; set; } = new List<AdditionalGrantsViewModel>();

    private Role SelectedRole { get; set; } = new Role();

    private Role EditOriginalRole { get; set; } = new Role();

    private ProductFamily AddSelectedProductFamily { get; set; } = new ProductFamily();

    private List<string> GrantTypeNames { get; set; } = new List<string>();

    private SearchRoleList? SearchRoleList { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            GrantTypeNames = Enum.GetNames(typeof(GrantType)).ToList();
            AllFamilies = await appSettingClient.GetProductFamilies();

            // grants
            CurrentUser = await userClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Any(c => c.GrantRole >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantRole >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantRole >= GrantType.Edit);
            IsUserViewGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantRole >= GrantType.View);

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);

            SelectedRole = new Role();

            HasNavItemRoute = true;
            NavItemRoute = "user/Roles";

            await base.OnInitializedAsync();

            await base.LoadBusinessGroups();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            errorZeissLicensingAlert!.Hide();

            switch (action)
            {
                case ActionType.Add:
                    EditOriginalRole = SelectedRole;

                    SelectedRole = new Role
                    {
                        Businessgroup = BusinessGroups.FirstOrDefault(),
                        GrantLicenseModel = GrantType.View,
                        GrantModule = GrantType.View,
                        GrantNamespace = GrantType.View
                    };

                    foreach (var name in Enum.GetNames(typeof(AdditionalGrant)))
                    {
                        SelectedRole.AdditionalGrants.Add(name, false);
                    }

                    SelectedFamilies = new List<ProductFamily>();
                    FilteredFamilies = AllFamilies.Where(c => c.Businessgroup == SelectedRole.Businessgroup).ToList();
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    EditOriginalRole = SelectedRole;
                    SelectedRole = (Role)EditOriginalRole.Clone();
                    FilteredFamilies = AllFamilies.Where(c => c.Businessgroup == SelectedRole.Businessgroup).ToList();
                    SelectedFamilies = SelectedRole.ProductFamilies.Select(c => new ProductFamily { Businessgroup = SelectedRole.Businessgroup, Name = c }).ToList();
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    EditOriginalRole = SelectedRole;
                    SelectedFamilies = SelectedRole.ProductFamilies.Select(c => new ProductFamily { Businessgroup = SelectedRole.Businessgroup, Name = c }).ToList();
                    break;
            }

            CreateAdditionalGrantList(SelectedRole);
            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Creates the entries for the additional grants grid
    /// </summary>
    /// <param name = "role"></param>
    private void CreateAdditionalGrantList(Role role)
    {
        AdditionalGrantsVMs = new List<AdditionalGrantsViewModel>();

        foreach (KeyValuePair<string, bool> additionalGrant in role.AdditionalGrants)
        {
            AdditionalGrantsVMs.Add(new AdditionalGrantsViewModel(additionalGrant.Key, additionalGrant.Value));
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnFamilyActionClicked(object? family, object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            errorZeissLicensingAlert!.Hide();

            switch (action)
            {
                case ActionType.Add:
                    modalrefAddFamily!.Show();
                    break;
                case ActionType.Delete:
                    if (null != family)
                    {
                        SelectedFamilies.Remove((ProductFamily)family);
                    }

                    break;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected family added
    /// </summary>
    private void OnAddFamilyOK(object obj)
    {
        try
        {
            if (!SelectedFamilies.Any(c => c.Name == AddSelectedProductFamily.Name))
            {
                SelectedFamilies.Add(AddSelectedProductFamily);
            }

            CurrentPage = (SelectedFamilies.Count + dgRoleSelectedFamilies!.PageSize - 1) / dgRoleSelectedFamilies!.PageSize;
            modalrefAddFamily!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected role changed
    /// </summary>
    private void OnSelectedRoleChanged(object selr)
    {
        try
        {
            if (null != selr)
            {
                SelectedRole = (Role)selr;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected business group changed
    /// </summary>
    private void OnSelectedBusinessGroupChanged(object obj)
    {
        try
        {
            if (null != obj)
            {
                SelectedFamilies.Clear();
                SelectedRole.Businessgroup = (string)obj;
                FilteredFamilies = AllFamilies.Where(c => c.Businessgroup == SelectedRole.Businessgroup).ToList();
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            var isAdd = false;
            SelectedRole.ProductFamilies.Clear();
            SelectedRole.ProductFamilies = SelectedFamilies.Select(c => c.Name).ToList();

            // Additional grants
            foreach (var additionalGrantsViewModel in AdditionalGrantsVMs)
            {
                if (SelectedRole.AdditionalGrants.TryGetValue(additionalGrantsViewModel.GrantName, out var isChecked))
                {
                    SelectedRole.AdditionalGrants[additionalGrantsViewModel.GrantName] = additionalGrantsViewModel.GrantChecked;
                }
            }

            if (string.IsNullOrWhiteSpace(SelectedRole.Id))
            {
                SelectedRole = await userClient.Add(SelectedRole);
                isAdd = true;
            }
            else
            {
                SelectedRole = await userClient.Update(SelectedRole);
            }

            SearchRoleList!.SaveRole(EditOriginalRole, SelectedRole, isAdd);
            IsListVisible = true;
            StateHasChanged();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await errorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await errorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            if (null != EditOriginalRole)
            {
                SelectedRole = EditOriginalRole;
            }
            else
            {
                SelectedRole = new Role();
            }

            IsListVisible = true;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Delete Modal OK
    /// </summary>
    private async Task HideModalDeleteOK()
    {
        try
        {
            await userClient.Delete(SelectedRole);
            SearchRoleList!.RemoveRole(SelectedRole);
            SelectedRole = new Role();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            ShowDeleteDialog = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private void HideModalDeleteDiscard()
    {
        try
        {
            ShowDeleteDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            InfoDialog!.SetInfo(SelectedRole);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
