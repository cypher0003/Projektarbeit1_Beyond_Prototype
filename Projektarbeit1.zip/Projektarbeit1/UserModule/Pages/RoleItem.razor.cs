#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace UserModule.Pages;

public partial class RoleItem
{
    #region Properties

    [Parameter]
    public RoleModel Model { get; set; } = new RoleModel();

    [Parameter]
    public EventCallback<bool> StatusChanged { get; set; }

    [Parameter]
    public bool IsReadonly { get; set; }

    #endregion

    #region Methods

    private async Task OnSelectedChanged(bool isChecked)
    {
        Model.Selected = isChecked;
        await StatusChanged.InvokeAsync(isChecked);
    }

    #endregion
}
