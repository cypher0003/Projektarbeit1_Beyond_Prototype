﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using UserModule.Models;

namespace UserModule.Pages;

public partial class ViewUser
{
    #region Fields

    protected List<ModuleModel> _Modules = new()
    {
        new ModuleModel
        {
            Selected = false,
            Module = new Module
            {
                Displayname = "Licenses",
                Name = "Licenses"
            }
        },
        new ModuleModel
        {
            Selected = false,
            Module = new Module
            {
                Displayname = "Features",
                Name = "Features"
            }
        }
    };

    protected List<RoleModel> _Roles = new()
    {
        new RoleModel
        {
            Selected = false,
            Module = new Role
            {
                Name = "Role 1"
            }
        },
        new RoleModel
        {
            Selected = false,
            Module = new Role
            {
                Name = "Role 2"
            }
        }
    };

    private List<Module> _AllModules = new();

    private List<Role> _AllRoles = new();
    private Alert? _ErrorZeissLicensingAlert;
    private DataGrid<Organization>? _DgUserOrganizations;

    #endregion

    #region Properties

    public bool ShowSearchPartnerOrganizationDialog { get; set; }

    private List<Module> AllModules
    {
        get => _AllModules;
        set
        {
            _AllModules = value;

            ModulesChanged();
        }
    }

    private List<Role> AllRoles
    {
        get => _AllRoles;
        set
        {
            _AllRoles = value;

            RolesChanged();
        }
    }

    private List<Organization> ListOfPartnerOrganizations { get; } = new List<Organization>();

    private User SelectedUser { get; set; } = new User();

    private User EditOriginalUser { get; set; } = new User();

    private List<Alias> ListOfAliases { get; set; } = new List<Alias>();

    private PersonType SelectedUserPersonType { get; set; } = PersonType.Publisher;

    private bool IsAdded { get; set; } = true;

    private bool CanChangeOrganization { get; set; }

    private SearchUserComponent? RefSearchUserComponent { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            var allModulesTask = appSettingClient.GetModules();
            var allRolesTask = userClient.GetRoles();

            // grants
            CurrentUser = await userClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            AdminBusinessGroup = CurrentUser.AdminBusinessGroup;
            CanChangeOrganization = IsSuperUser;

            if (CurrentUser.IsPublisher)
            {
                var currentOrganization = await organizationClient.GetByNumber(CurrentUser.OrganizationNumber);
                CanChangeOrganization = IsSuperUser || currentOrganization.OrganizationType == OrganizationType.Publisher;
            }

            IsUserAddGranted = CurrentUser.AccountType    == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.Add);
            IsUserDeleteGranted = CurrentUser.AccountType == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.Delete);
            IsUserEditGranted = CurrentUser.AccountType   == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.Edit);
            IsUserViewGranted = CurrentUser.AccountType   == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.View);

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);

            AllModules = await allModulesTask;
            AllRoles = await allRolesTask;

            HasNavItemRoute = true;
            NavItemRoute = "user";

            await base.OnInitializedAsync();
            await base.LoadBusinessGroups();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    protected void OnModuleItemStatusChanged(bool isChecked)
    {
        try
        {
            if (SelectedUser.Modules == null)
            {
                SelectedUser.Modules = new List<Module>();
            }
            else
            {
                SelectedUser.Modules.Clear();
            }

            foreach (var item in _Modules)
            {
                if (item.Selected)
                {
                    SelectedUser.Modules.Add(item.Module);
                }
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    protected void OnRoleItemStatusChanged(bool isChecked)
    {
        try
        {
            if (SelectedUser.Roles == null)
            {
                SelectedUser.Roles = new List<Role>();
            }
            else
            {
                SelectedUser.Roles.Clear();
            }

            foreach (var item in _Roles)
            {
                if (item.Selected)
                {
                    SelectedUser.Roles.Add(item.Module);
                }
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private async Task OnActionClicked(object tupleObj)
    {
        try
        {
            var tuple = (Tuple<ActionType, AccountType, PersonType>)tupleObj;
            var action = tuple.Item1;
            var isListVisible = false;
            IsReadOnly = false;
            ListOfPartnerOrganizations.Clear();

            switch (action)
            {
                case ActionType.Add:
                    EditOriginalUser = SelectedUser;

                    SelectedUser = new User
                    {
                        AccountType = tuple.Item2
                    };

                    SelectedUserPersonType = tuple.Item3;
                    ListOfAliases = new List<Alias>();
                    ModulesChanged();
                    RolesChanged();

                    if (SelectedUserPersonType == PersonType.Publisher)
                    {
                        SelectedUser.OrganizationId = CurrentUser!.OrganizationId;
                        SelectedUser.OrganizationName = CurrentUser!.OrganizationName;
                        SelectedUser.OrganizationNumber = CurrentUser!.OrganizationNumber;
                        SearchOrganization = SelectedUser.OrganizationName;
                    }

                    IsAdded = true;
                    break;
                case ActionType.Edit:
                    EditOriginalUser = SelectedUser;
                    SelectedUser = (User)EditOriginalUser.Clone();
                    await LoadPartnerOrganizations();
                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    EditOriginalUser = SelectedUser;
                    await LoadPartnerOrganizations();
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Load Partner organizations
    /// </summary>
    private async Task LoadPartnerOrganizations()
    {
        try
        {
            if (!SelectedUser.IsPublisher)
            {
                foreach (var item in SelectedUser.OrganizationNumbers)
                {
                    var org = await organizationClient.GetByNumber(item);

                    if (null != org)
                    {
                        ListOfPartnerOrganizations.Add(org);
                    }
                }

                StateHasChanged();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Selected user changed
    /// </summary>
    private void OnSelectedUserChanged(object selu)
    {
        try
        {
            if (null != selu)
            {
                SelectedUser = (User)selu;

                ListOfAliases = new List<Alias>();

                foreach (var alias in SelectedUser.AllowedAliases)
                {
                    ListOfAliases.Add(new Alias { AliasName = alias });
                }

                SelectedUserPersonType = SelectedUser.IsPublisher ? PersonType.Publisher : PersonType.CustomerPartner;
                ListOfPartnerOrganizations.Clear();
                IsAdded = false;

                if (SelectedUser.IsPublisher)
                {
                    SearchOrganization = SelectedUser.OrganizationName;
                }

                ModulesChanged();

                RolesChanged();
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;
            StateHasChanged();

            SelectedUser.AllowedAliases.Clear();

            foreach (var item in ListOfAliases)
            {
                if (!string.IsNullOrWhiteSpace(item.AliasName))
                {
                    SelectedUser.AllowedAliases.Add(item.AliasName);
                }
            }

            SelectedUser.OrganizationNumbers.Clear();

            foreach (var org in ListOfPartnerOrganizations)
            {
                if (!string.IsNullOrWhiteSpace(org.Number))
                {
                    SelectedUser.OrganizationNumbers.Add(org.Number);
                }
            }

            if (IsAdded)
            {
                SelectedUser = await userClient.Add(SelectedUser);
            }
            else
            {
                SelectedUser = await userClient.Update(SelectedUser);
            }

            RefSearchUserComponent!.SaveUser(EditOriginalUser, SelectedUser, IsAdded);

            await _ErrorZeissLicensingAlert!.Hide();

            IsListVisible = true;

            StateHasChanged();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            _ErrorZeissLicensingAlert!.Hide();

            if (null != EditOriginalUser)
            {
                SelectedUser = EditOriginalUser;
            }
            else
            {
                SelectedUser = new User();
            }

            ModulesChanged();

            RolesChanged();

            IsListVisible = true;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// State changed
    /// </summary>
    /// <param name="isChecked">Checked state</param>
    private void OnStateChanged(bool isChecked)
    {
        try
        {
            if (SelectedUser != null)
            {
                SelectedUser.State = isChecked ? UserState.ENABLE : UserState.DISABLE;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }


    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    /// <param name="customerType"></param>
    private void OnDeleteSearchOrgButtonClicked()
    {
        try
        {
            SelectedUser.OrganizationId = string.Empty;
            SelectedUser.OrganizationName = string.Empty;
            SelectedUser.OrganizationNumber = string.Empty;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(object organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick((Organization)organization);
            SelectedUser.OrganizationId = ((Organization)organization).Id;
            SelectedUser.OrganizationName = ((Organization)organization).Name;
            SelectedUser.OrganizationNumber = ((Organization)organization).Number;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Discard button pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        try
        {
            ShowSearchOrganizationDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnSearchPartnerOrganizationOKClick(object organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick((Organization)organization);
            ListOfPartnerOrganizations.Add((Organization)organization);
            CurrentPage = (ListOfPartnerOrganizations.Count + _DgUserOrganizations!.PageSize - 1) / _DgUserOrganizations!.PageSize;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
        finally
        {
            ShowSearchPartnerOrganizationDialog = false;
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnOrganizationActionClicked(object? organization, object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            _ErrorZeissLicensingAlert!.Hide();

            switch (action)
            {
                case ActionType.Add:
                    ShowSearchPartnerOrganizationDialog = true;
                    break;
                case ActionType.Delete:
                    if (null != organization)
                    {
                        ListOfPartnerOrganizations.Remove((Organization)organization);
                    }

                    break;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            InfoDialog!.SetInfo(SelectedUser);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Businessgroup selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void BusinessGroupValueChangedHandler(object newValue)
    {
        try
        {
            SelectedUser.AdminBusinessGroup = (string)newValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private bool SelectedUserContainsModule(string module)
    {
        try
        {
            return SelectedUser?.Modules.Count(x => x.Name == module) > 0;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
            return false;
        }
    }

    private void ModulesChanged()
    {
        try
        {
            _Modules.Clear();

            foreach (var item in AllModules)
            {
                _Modules.Add(
                    new ModuleModel
                    {
                        Module = item,
                        Selected = SelectedUser != null && SelectedUserContainsModule(item.Name)
                    }
                );
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private bool SelectedUserContainsRole(string roleId)
    {
        try
        {
            return SelectedUser?.Roles.Count(x => x.Id == roleId) > 0;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
            return false;
        }
    }

    private void RolesChanged()
    {
        try
        {
            _Roles.Clear();

            foreach (var item in AllRoles)
            {
                _Roles.Add(
                    new RoleModel
                    {
                        Module = item,
                        Selected = SelectedUser != null && SelectedUserContainsRole(item.Id)
                    }
                );
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private async Task OnDuplicateClicked()
    {
        try
        {
            EditOriginalUser = SelectedUser;

            var duplicatedUser = (User)SelectedUser.Clone();
            CleanDuplicatedUser(duplicatedUser);

            OnSelectedUserChanged(duplicatedUser);
            await LoadPartnerOrganizations();

            IsAdded = true;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private void CleanDuplicatedUser(User duplicatedUser)
    {
        duplicatedUser.FirstName = string.Empty;
        duplicatedUser.LastName = string.Empty;
        duplicatedUser.UserId = string.Empty;
        duplicatedUser.AccountId = string.Empty;
        duplicatedUser.InvitationId = string.Empty;
        duplicatedUser.Email = string.Empty;
        duplicatedUser.Id = string.Empty;
        duplicatedUser.LastLogin = new DateTime();

        duplicatedUser.SearchModes.Clear();
        duplicatedUser.LastUsedItems.Clear();
    }

    #endregion
}
