#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace UserModule.Pages;

public partial class SearchRoleList
{
    #region Properties

    [Parameter]
    public EventCallback SelectedRoleChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    /// <summary>
    /// Selected role
    /// </summary>
    public Role SelectedRole { get; set; } = new Role();

    private List<Role> Roles { get; set; } = new List<Role>();

    #endregion

    #region Methods

    /// <summary>
    /// Remove role from list
    /// </summary>
    /// <param name = "role">Role to be removed</param>
    public void RemoveRole(Role role)
    {
        try
        {
            if (Roles.Contains(role))
            {
                Roles.Remove(role);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save role to list
    /// </summary>
    /// <param name = "origRole">Original role(Update)</param>
    /// <param name = "role">Role to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveRole(Role origRole, Role role, bool isAdd)
    {
        try
        {
            if (isAdd)
            {
                Roles.Insert(0, role);
                SelectedRole = role;
            }
            else
            {
                var idxOrig = Roles.IndexOf(origRole);

                if (idxOrig >= 0)
                {
                    Roles.Insert(idxOrig, role);
                    Roles.Remove(origRole);
                }

                SelectedRole = role;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clear list
    /// </summary>
    public void ClearList()
    {
        try
        {
            Roles.Clear();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            IsLoading = true;
            Roles = await userClient.GetRoles();
            IsLoading = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object? obj, ActionType actionType)
    {
        try
        {
            if (null != obj && SelectedRole != (Role)obj)
            {
                OnSelectedRoleChanged((Role)obj);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected role changed
    /// </summary>
    private void OnSelectedRoleChanged(Role selobj)
    {
        try
        {
            if (null != selobj && selobj != SelectedRole)
            {
                SelectedRole = selobj;
                SelectedRoleChanged.InvokeAsync(selobj);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private string StringListToString(List<string> list)
    {
        var ret = string.Empty;

        try
        {
            foreach (var item in list)
            {
                ret = ret + item + " ;";
            }

            if (ret.EndsWith(" ;"))
            {
                ret = ret.Substring(0, ret.Length - 1);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }

        return ret;
    }

    #endregion
}
