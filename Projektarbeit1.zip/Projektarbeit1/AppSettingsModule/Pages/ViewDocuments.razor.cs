#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Components.Documents;
using ComponentsLibrary.Exceptions;
using ComponentsLibrary.ViewModels.Documents;
using ResourceLibrary.Helper;
using Zeiss.Licensing.Data.Exceptions;

namespace AppSettingsModule.Pages;

public partial class ViewDocuments
{
    #region Fields

    private Alert? _ErrorZeissLicensingAlert;

    private List<ProductFamily> _ProductFamilies = new();
    private List<ProductFamily> _ProductFamiliesEdit = new();

    #endregion

    #region Properties

    /// <summary>
    /// List of document states
    /// </summary>
    public IEnumerable<SelectModel> DocumentStateList { get; set; } = new List<SelectModel>();

    /// <summary>
    /// Selected document state
    /// </summary>
    public int SelectedDocumentStateValue { get; set; } = 0;

    private bool ShowContentDialog { get; set; }

    private DocumentViewModel SelectedDocumentViewModel { get; set; } = new(new Document());

    private DocumentContentViewModel SelectedDocumentContentViewModel { get; set; } = new DocumentContentViewModel(new DocumentContent());


    private SearchDocumentComponent? SearchDocumentComponent { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            var productFamiliesTask = AppSettingClient!.GetProductFamilies(false);

            // grants
            CurrentUser = await UserClient!.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Any(c => c.GrantDocument >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantDocument >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantDocument >= GrantType.Edit);
            IsUserViewGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantDocument >= GrantType.View);

            _ProductFamilies = await productFamiliesTask;

            // Variant state list
            List<string> listText = new();

            foreach (DocumentState varState in Enum.GetValues(typeof(DocumentState)))
            {
                listText.Add(P["DOCUMENTSTATE" + varState.ToString().ToUpper()]);
            }

            DocumentStateList = Enumerable.Range(1, listText.Count).Select(x => new SelectModel { Text = listText[x - 1], Value = x - 1 });

            HasNavItemRoute = true;
            NavItemRoute = "AppSettings/Documents";

            IsLoading = true;
            StateHasChanged();
            IsLoading = false;

            await base.OnInitializedAsync();
            await base.LoadBusinessGroups();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    private void OnSelectedDocumentViewModelChanged(DocumentViewModel selecteDocumentViewModel)
    {
        if (null != selecteDocumentViewModel)
        {
            SelectedDocumentViewModel = selecteDocumentViewModel;
        }
    }

    private void OnSelectedDocumentContentViewModelChanged(DocumentContentViewModel selectedDocumentContentViewModel)
    {
        if (null != selectedDocumentContentViewModel)
        {
            SelectedDocumentContentViewModel = selectedDocumentContentViewModel;
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private async Task OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            SelectedDocumentStateValue = (int)SelectedDocumentViewModel.State;

            switch (action)
            {
                case ActionType.Add:
                    SelectedDocumentViewModel = new DocumentViewModel(new Document());
                    SelectedDocumentViewModel.Businessgroup = BusinessGroups.FirstOrDefault() ?? string.Empty;
                    SelectedDocumentStateValue = 0;
                    FilterProductFamiliesWithEmptyEntry();
                    break;

                case ActionType.Delete:
                    isListVisible = true;
                    ShowDeleteDialog = true;
                    break;
                case ActionType.Edit:
                    FilterProductFamiliesWithEmptyEntry(false);

                    if (SelectedDocumentViewModel.Contents.Count > 0)
                    {
                        SelectedDocumentContentViewModel = SelectedDocumentViewModel.Contents.First();
                    }

                    break;
                case ActionType.View:
                    IsReadOnly = true;
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
            IsListVisible = true;
        }
        finally
        {
            IsLoading = false;
            StateHasChanged();
        }
    }

    private void FilterProductFamiliesWithEmptyEntry(bool selectFirst = true)
    {
        _ProductFamiliesEdit = _ProductFamilies.Where(c => c.Businessgroup == SelectedDocumentViewModel.Businessgroup).ToList();

        _ProductFamiliesEdit.Insert(0, new ProductFamily
        {
            Name = "",
            Businessgroup = ""
        });

        if (selectFirst)
        {
            SelectedDocumentViewModel.ProductFamily = _ProductFamiliesEdit.First().Name;
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private async Task OnContentActionClicked(DocumentContentViewModel? documentContentViewModel, ActionType actionType)
    {
        try
        {
            if (null != documentContentViewModel && SelectedDocumentContentViewModel != documentContentViewModel)
            {
                OnSelectedDocumentContentViewModelChanged(documentContentViewModel);
            }

            switch (actionType)
            {
                case ActionType.Add:
                    SelectedDocumentContentViewModel = new DocumentContentViewModel(new DocumentContent()) { IsNewAdded = true };
                    ShowContentDialog = true;
                    break;
                case ActionType.Delete:
                    SelectedDocumentViewModel.Contents.Remove(SelectedDocumentContentViewModel);

                    if (SelectedDocumentViewModel.Contents.Count > 0)
                    {
                        SelectedDocumentContentViewModel = SelectedDocumentViewModel.Contents.First();
                        StateHasChanged();
                    }

                    break;
                case ActionType.Edit:
                    ShowContentDialog = true;
                    break;
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Delete Dialog OK
    /// </summary>
    private async Task OnDeleteOK()
    {
        try
        {
            await _ErrorZeissLicensingAlert!.Hide();

            await SearchDocumentComponent!.DeleteDocumentViewModel(SelectedDocumentViewModel);

            ShowDeleteDialog = false;
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Save button pressed
    /// </summary>
    private async Task OnSaveButtonClicked()
    {
        try
        {
            IsSaving = true;

            await SearchDocumentComponent!.SaveDocument(SelectedDocumentViewModel);

            await _ErrorZeissLicensingAlert!.Hide();
            IsListVisible = true;

            StateHasChanged();
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ExceptionHelper.GetErrorTextOfResource(ex, E);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Discard button pressed
    /// </summary>
    private void OnDiscardButtonClicked()
    {
        try
        {
            SelectedDocumentViewModel.ReadFromModel();

            IsListVisible = true;

            _ErrorZeissLicensingAlert!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Businessgroup selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void BusinessGroupValueChangedHandler(string newValue)
    {
        try
        {
            SelectedDocumentViewModel.Businessgroup = newValue;
            FilterProductFamiliesWithEmptyEntry();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// ProductFamily selection changed
    /// </summary>
    /// <param name="newValue">New value</param>
    private void ProductFamilyValueChangedHandler(string? newValue)
    {
        try
        {
            SelectedDocumentViewModel.ProductFamily = newValue ?? string.Empty;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Document State changed
    /// </summary>
    /// <param name="newValue">new value</param>
    private void OnSelectedDocumentStateChanged(int newValue)
    {
        try
        {
            SelectedDocumentStateValue = newValue;
            SelectedDocumentViewModel.State = (DocumentState)newValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    private void OnDocumentContentOkClicked(DocumentContentViewModel documentContentViewModel)
    {
        if (string.IsNullOrWhiteSpace(documentContentViewModel.DocumentContent.Id) && documentContentViewModel.IsNewAdded)
        {
            SelectedDocumentViewModel.Contents.Add(documentContentViewModel);
            documentContentViewModel.IsNewAdded = false;
        }

        ShowContentDialog = false;
    }

    private void OnDocumentContentDiscardClicked()
    {
        ShowContentDialog = false;
    }

    /// <summary>
    /// Download button pressed
    /// </summary>
    private async Task OnDownloadButtonClicked(DocumentContentViewModel? documentContentViewModel)
    {
        try
        {
            if (null != documentContentViewModel && SelectedDocumentContentViewModel != documentContentViewModel)
            {
                OnSelectedDocumentContentViewModelChanged(documentContentViewModel);
            }

            if (null != SelectedDocumentContentViewModel)
            {
                DocumentContent? documentContent;

                if (string.IsNullOrWhiteSpace(SelectedDocumentContentViewModel.DocumentContent.Id))
                {
                    documentContent = SelectedDocumentContentViewModel.DocumentContent;
                }
                else
                {
                    var document = await DocumentClient.GetDocument(SelectedDocumentViewModel.Document.Id, true, SelectedDocumentContentViewModel.DocumentContent.Id);
                    documentContent = document.Contents.FirstOrDefault(c => c.Id == SelectedDocumentContentViewModel.DocumentContent.Id);
                }

                if (null != documentContent)
                {
                    var blob = Convert.FromBase64String(documentContent.Content);

                    await FileHelper.SaveBinaryFile(JSRuntime, documentContent.Name, blob);

                    string downloadText = LIC["DOWNLOADOK"];
                    SnackbarException!.ShowMessage(downloadText);
                }
            }
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Exception)
        {
            string downloadText = LIC["DOWNLOADERROR"];
            SnackbarException!.ShowException(downloadText);
        }
    }

    #endregion
}
