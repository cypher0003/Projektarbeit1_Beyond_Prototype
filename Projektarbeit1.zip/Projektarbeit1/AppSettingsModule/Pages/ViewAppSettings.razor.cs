#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace AppSettingsModule.Pages;

public partial class ViewAppSettings
{
    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await UserClient.Authenticate();
            IsUserAddGranted = CurrentUser.AccountType    == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.Add);
            IsUserDeleteGranted = CurrentUser.AccountType == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.Delete);
            IsUserEditGranted = CurrentUser.AccountType   == AccountType.SuperUser || CurrentUser.Roles.Any(c => c.GrantUser >= GrantType.Edit);
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    #endregion
}
