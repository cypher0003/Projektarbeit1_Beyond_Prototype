#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.ViewModels.Documents;

namespace AppSettingsModule.Components;

public partial class DocumentContentDialog
{
    #region Properties

    [Parameter]
    public bool ShowDialog { get; set; }

    [Parameter]
    public EventCallback<DocumentContentViewModel> OkClicked { get; set; }

    [Parameter]
    public EventCallback DiscardClicked { get; set; }

    [Parameter]
    public DocumentContentViewModel DocumentContentViewModel { get; set; } = new(new());

    /// <summary>
    /// List of document states
    /// </summary>
    public IEnumerable<SelectModel> DocumentStateList { get; set; } = new List<SelectModel>();

    /// <summary>
    /// Selected product variant state
    /// </summary>
    public int SelectedDocumentStateValue { get; set; } = 0;

    private string FileName { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        // Variant state list
        List<string> listText = new();

        foreach (DocumentState varState in Enum.GetValues(typeof(DocumentState)))
        {
            listText.Add(P["DOCUMENTSTATE" + varState.ToString().ToUpper()]);
        }

        DocumentStateList = Enumerable.Range(1, listText.Count).Select(x => new SelectModel { Text = listText[x - 1], Value = x - 1 });
    }

    /// <summary>
    /// Parameters set
    /// </summary>
    protected override void OnParametersSet()
    {
        FileName = string.Empty;
        SelectedDocumentStateValue = (int)DocumentContentViewModel.State;
        DocumentContentViewModel.IsFileLoading = string.IsNullOrWhiteSpace(DocumentContentViewModel.Name);
        base.OnParametersSet();
    }

    /// <summary>
    /// Hide Product Modal OK
    /// </summary>
    private void OnClickOK()
    {
        DocumentContentViewModel.SaveToModel();
        OkClicked.InvokeAsync(DocumentContentViewModel);
    }

    /// <summary>
    /// Hide Product Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        DocumentContentViewModel.ReadFromModel();
        ShowDialog = false;
        DiscardClicked.InvokeAsync();
    }

    /// <summary>
    /// SelectFile
    /// </summary>
    /// <param name="e">File changed event args</param>
    /// <returns></returns>
    private async Task OnFileEditChanged(FileChangedEventArgs e)
    {
        try
        {
            foreach (var file in e.Files)
            {
                FileName = file.Name;
                DocumentContentViewModel.Name = FileName;
                DocumentContentViewModel.IsFileLoading = true;

                using (var stream = new MemoryStream())
                {
                    await file.WriteToStreamAsync(stream);

                    stream.Seek(0, SeekOrigin.Begin);
                    stream.Capacity = (int)stream.Length;
                    DocumentContentViewModel.Content = Convert.ToBase64String(stream.GetBuffer());
                }

                DocumentContentViewModel.IsFileLoading = false;
            }
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Document State changed
    /// </summary>
    /// <param name="newValue">new value</param>
    private void OnSelectedDocumentStateChanged(int newValue)
    {
        try
        {
            SelectedDocumentStateValue = newValue;
            DocumentContentViewModel.State = (DocumentState)newValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
