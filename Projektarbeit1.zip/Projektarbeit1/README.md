# Zeiss.Licensing.Backend.UI

## Description
    
Provides frontend for SWL services.
    
## General information
    
| Info   | Value    |
| ------ | -------- |
| Status | Deployed |

