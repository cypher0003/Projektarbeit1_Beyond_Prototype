﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Data.Exceptions;

namespace Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions;

/// <summary>
/// Exception, if Product has Draft productvariants 
/// </summary>
[Serializable]
public class ZeissLicensingNamedUserLimitExceededException : ZeissLicensingException
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    public ZeissLicensingNamedUserLimitExceededException()
        : base(ExceptionResource.NAMEDUSERLIMITEXCEEDED, "")
    {
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="message">Message</param>
    /// <param name="errorCode">Error code</param>
    public ZeissLicensingNamedUserLimitExceededException(string message, string errorCode) : base(message, errorCode)
    {
    }

    #endregion
}
