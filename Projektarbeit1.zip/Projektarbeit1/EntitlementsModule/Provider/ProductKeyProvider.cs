﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.ViewModels;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace Zeiss.Licensing.Backend.UI.EntitlementsModule.Provider;

public class ProductKeyProvider
{
    #region Fields

    private readonly IProductClient _productClient;

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="productClient">Product client</param>
    /// <param name="entitlementClient">Entitlement client</param>
    public ProductKeyProvider(IProductClient productClient)
    {
        _productClient = productClient;
    }

    #endregion

    #region Methods

    public async Task<List<ProductVariant>> GetListProdVars(string prodId)
    {
        var prod = await _productClient.GetById(prodId);

        List<ProductVariant> ret = prod.ProductVariants;
        return ret;
    }

    /// <summary>
    /// Updates Data 
    /// </summary>
    public async Task Update(EntitlementProductKeyViewModel entitlementProductKeyViewModel)
    {
        // Product
        if (null != entitlementProductKeyViewModel.EntitlementProductKey.Product)
        {
            entitlementProductKeyViewModel.ProductText = entitlementProductKeyViewModel.EntitlementProductKey.Product.Product.Name;
            entitlementProductKeyViewModel.ProductVersion = entitlementProductKeyViewModel.EntitlementProductKey.Product.Product.Version;

            var refproduct = entitlementProductKeyViewModel.EntitlementProductKey.Product.Product;

            if (null != refproduct)
            {
                var product = await _productClient.GetById(refproduct.Id);

                if (null != product)
                {
                    entitlementProductKeyViewModel.EntitlementProductKey.Product.Product = product;
                }
            }
        }

        // Product variants
        entitlementProductKeyViewModel.ReadFromModel();
    }

    /// <summary>
    /// Updates product key with product data
    /// </summary>
    /// <param name="product">product</param>
    /// <param name="entitlementProductKeyVievModel">Entitlement Productkey ViewModel</param>
    /// <param name="licenseModels">List of license models</param>
    /// <param name="checkEnabledProductvariants">Flag, if productvariants are all enabled</param>
    public async Task UpdateProduct(Product product, EntitlementProductKeyViewModel entitlementProductKeyVievModel, List<LicenseModel> licenseModels, bool checkEnabledProductvariants)
    {
        if (null == entitlementProductKeyVievModel.EntitlementProductKey.Product)
        {
            entitlementProductKeyVievModel.EntitlementProductKey.Product = new EntitlementProduct();
        }

        entitlementProductKeyVievModel.EntitlementProductKey.Product.Product = product;

        // Load all product data
        await Update(entitlementProductKeyVievModel);

        if (checkEnabledProductvariants && !((Product)entitlementProductKeyVievModel.EntitlementProductKey.Product.Product).ProductVariants.Any(c => c.State == ProductVariantState.ENABLED))
        {
            throw new Exceptions.ZeissLicensingDraftProductvariantsException();
        }

        entitlementProductKeyVievModel.EntitlementProductKey.Product.Features.Clear();

        LicenseModel? licenseModel = null;
        var prodVar = ((Product)entitlementProductKeyVievModel.EntitlementProductKey.Product.Product).ProductVariants.FirstOrDefault();

        if (null != prodVar && !string.IsNullOrWhiteSpace(prodVar.LicenseModel))
        {
            licenseModel = licenseModels.FirstOrDefault(c => c.Name == prodVar.LicenseModel);
        }

        foreach (var productFeature in product.ProductFeatures)
        {
            if (null == licenseModel)
            {
                licenseModel = licenseModels.FirstOrDefault(c => c.Name == productFeature.LicenseModel.Name);
            }

            (var durationInDays, var start) = entitlementProductKeyVievModel.GetLicenseInfo(licenseModel);

            // if default in product variant, then use this value
            if (null != prodVar && (prodVar.DefaultDuration ?? 0) > 0)
            {
                // if default Duration is set, use this
                durationInDays = prodVar.DefaultDuration;
            }

            entitlementProductKeyVievModel.EntitlementProductKey.Product.Features.Add(new EntitlementProductFeature
            {
                Count = productFeature.Count,
                Feature = productFeature.Feature,
                LicenseModel = new EntitlementProductFeatureLicenseModel
                {
                    LicenseModel = productFeature.LicenseModel,
                    StartDate = start,
                    DurationInDays = durationInDays,
                    EndDate = null
                }
            });
        }

        entitlementProductKeyVievModel.EntitlementProductKey.ProductVariantId = prodVar?.Id;
    }

    /// <summary>
    /// ProductVariant has changed
    /// </summary>
    /// <param name="prodVariant">Product variant has changed</param>
    /// <param name="entitlementProductKeyVievModel">Entitlement viewmodel</param>
    /// <param name="licModels">All license models</param>
    public void UpdateProductVariant(ProductVariant prodVariant, EntitlementProductKeyViewModel entitlementProductKeyVievModel, List<LicenseModel> licModels)
    {
        var licModel = licModels.FirstOrDefault(c => c.Name == prodVariant.LicenseModel);
        entitlementProductKeyVievModel.SetLicenseModel(licModel, entitlementProductKeyVievModel.EntitlementProductKey.ProductVariantId != prodVariant.Id, prodVariant);

        entitlementProductKeyVievModel.CurrentProductVariant = prodVariant;
        entitlementProductKeyVievModel.EntitlementProductKey.ProductVariantId = prodVariant.Id;

        // Policy
        if (null != licModel)
        {
            entitlementProductKeyVievModel.EntitlementProductKey.NumberOfRehosts = licModel.NumberOfRehosts;
            entitlementProductKeyVievModel.EntitlementProductKey.PeriodOfRehosts = licModel.PeriodOfRehosts;
            entitlementProductKeyVievModel.EntitlementProductKey.NumberOfReturns = licModel.NumberOfReturns;
            entitlementProductKeyVievModel.EntitlementProductKey.PeriodOfReturns = licModel.PeriodOfReturns;
        }

        // no license modle or NOT Thales_Connected
        entitlementProductKeyVievModel.IsUseNamedUser = false;
        var licenseModel = licModels.FirstOrDefault(c => c.Name == prodVariant.LicenseModel);

        if (null != licenseModel)
        {
            if (licenseModel.IsConnected)
            {
                entitlementProductKeyVievModel.EntitlementProductKey.TotalQuantity = 1;

                if (null == entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties)
                {
                    entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties = new NamedUsersProperties();
                }

                if (entitlementProductKeyVievModel.EntitlementProductKey.State == EntitlementProductKeyState.Draft)
                {
                    entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties.ConcurrencyCriteria = entitlementProductKeyVievModel.CurrentProductVariant.NamedUsersConcurrencyCriteria;
                    entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties.LimitNamedUsersAssignment = entitlementProductKeyVievModel.CurrentProductVariant.LimitNamedUserAssignment;
                    entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties.UseNamedUsers = entitlementProductKeyVievModel.CurrentProductVariant.UseNamedUsers;
                }

                entitlementProductKeyVievModel.IsUseNamedUser = entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties.UseNamedUsers &&
                                                                entitlementProductKeyVievModel.EntitlementProductKey.State == EntitlementProductKeyState.Enable;
            }
            else
            {
                entitlementProductKeyVievModel.EntitlementProductKey.NamedUsersProperties = null;
            }
        }
    }

    #endregion
}
