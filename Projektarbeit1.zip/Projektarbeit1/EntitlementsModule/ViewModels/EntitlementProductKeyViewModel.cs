﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Collections.ObjectModel;
using System.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace EntitlementsModule.ViewModels;

/// <summary>
/// Entitlement product key and 
/// </summary>
public class EntitlementProductKeyViewModel : ObservableObject
{
    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    public EntitlementProductKeyViewModel()
    {
        EntitlementProductKey = new EntitlementProductKey();
        ProductText = string.Empty;
        ProductVersion = string.Empty;
        EntitlementProductKey.StartDate = DateTime.SpecifyKind(DateTime.Today, DateTimeKind.Unspecified);
        EntitlementProductKey.EndDate = null;
        EntitlementProductKeyNeverExpires = true;
        NamedUsers = new ObservableCollection<NamedUserViewModel>();
    }

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="prodKey">Product key</param>
    public EntitlementProductKeyViewModel(EntitlementProductKey prodKey)
    {
        EntitlementProductKey = prodKey;
        ProductText = string.Empty;
        ProductVersion = string.Empty;
        NamedUsers = new ObservableCollection<NamedUserViewModel>();

        if (null != prodKey.NamedUsersProperties)
        {
            ConcurrencyLimit = prodKey.NamedUsersProperties.ConcurrencyLimit;
            IsUseNamedUser = prodKey.NamedUsersProperties.UseNamedUsers;
        }
    }

    #endregion

    #region Properties

    /// <summary>
    /// License Enddate selected value
    /// </summary>
    public int LicenseEndDateSelectedValue { get; set; } = 0;

    /// <summary>
    /// List of product variants
    /// </summary>
    public List<ProductVariant> ProductVariantList { get; set; } = new List<ProductVariant>();

    /// <summary>
    /// Current Product variant
    /// </summary>
    public ProductVariant CurrentProductVariant { get; set; } = new ProductVariant();

    /// <summary>
    /// Entitlement Product Key
    /// </summary>
    public EntitlementProductKey EntitlementProductKey { get; set; }

    /// <summary>
    /// License date, if LicenseMode = 1 or 2
    /// </summary>
    public EntitlementProductFeatureLicenseModel? LicenseDate { get; set; }

    /// <summary>
    /// Flag, if ProductKey has License date
    /// </summary>
    public bool HasLicenseDate => null != LicenseDate;

    /// <summary>
    /// Product variant name
    /// </summary>
    public string ProductVariantName
    {
        get
        {
            var pv = ProductVariantList.FirstOrDefault(c => c.Id == EntitlementProductKey.ProductVariantId);
            var ret = pv?.Name ?? string.Empty;
            return ret;
        }
    }

    /// <summary>
    /// Product variant Materialnumber
    /// </summary>
    public string ProductVariantMaterialnumber
    {
        get
        {
            var ret = CurrentProductVariant?.FormattedMaterialNumber;
            return ret ?? string.Empty;
        }
    }

    /// <summary>
    /// Product text
    /// </summary>
    public string ProductText { get; set; }

    /// <summary>
    /// product version
    /// </summary>
    public string ProductVersion { get; set; }

    /// <summary>
    /// Flag: Product key never expires 
    /// </summary>
    public bool EntitlementProductKeyNeverExpires { get; set; } = false;

    /// <summary>
    /// Start from activation date
    /// </summary>
    public bool StartFromActivationDate { get; set; } = false;

    /// <summary>
    /// Disable StartFromActivationDate
    /// </summary>
    public bool IsStartFromActivationDateDisabled { get; set; } = false;

    /// <summary>
    /// Test entitlement
    /// </summary>
    public bool IsTestEntitlement { get; set; } = false;

    /// <summary>
    /// Is completely Loaded
    /// </summary>
    public bool IsCompletelyLoaded { get; set; } = true;

    /// <summary>
    /// Has error at loading
    /// </summary>
    public bool HasErrorByLoading { get; set; } = false;

    /// <summary>
    /// Flag: True: Named User handling
    /// </summary>
    public bool IsUseNamedUser { get; set; }

    /// <summary>
    /// Concurrency limit
    /// </summary>
    public int ConcurrencyLimit
    {
        get
        {
            if (null != EntitlementProductKey.NamedUsersProperties)
            {
                return EntitlementProductKey.NamedUsersProperties.ConcurrencyLimit;
            }

            return 0;
        }
        set
        {
            if (null != EntitlementProductKey.NamedUsersProperties)
            {
                EntitlementProductKey.NamedUsersProperties.ConcurrencyLimit = value;
            }
        }
    }

    /// <summary>
    /// List Named users
    /// </summary>
    public ObservableCollection<NamedUserViewModel> NamedUsers { get; set; }

    public bool IsUpgrade => EntitlementProductKey.IsUpgrade;

    #endregion

    #region Methods

    /// <summary>
    /// Never Expire changed
    /// </summary>
    /// <param name="isChecked">check Never expires</param>
    public void NeverExpiresProductKeyCheckedChanged(bool isChecked)
    {
        EntitlementProductKeyNeverExpires = isChecked;

        if (isChecked)
        {
            // Enddate -> null, disabled
            EntitlementProductKey.EndDate = null;
            EntitlementProductKey.DurationInDays = null;
        }
        else
        {
            // Enddate enabled
            EntitlementProductKey.EndDate = DateTime.Today.AddYears(1);
        }
    }

    /// <summary>
    /// Start from activation date changes
    /// </summary>
    /// <param name="isChecked">check Never expires</param>
    public void StartFromActivationDateChanged(bool isChecked)
    {
        StartFromActivationDate = isChecked;

        if (isChecked && null != LicenseDate)
        {
            // Startdate -> null
            LicenseDate.StartDate = null;
        }
    }

    /// <summary>
    /// Save data to EntitlementProductKey
    /// </summary>
    public void Save(List<LicenseModel> licenseModels)
    {
        if (null != EntitlementProductKey.Product)
        {
            foreach (var entitlementProductFeature in EntitlementProductKey.Product.Features)
            {
                entitlementProductFeature.LicenseModel.StartDate = LicenseDate?.StartDate;
                entitlementProductFeature.LicenseModel.DurationInDays = LicenseEndDateSelectedValue == 1 ? LicenseDate?.DurationInDays : null;
                entitlementProductFeature.LicenseModel.EndDate = LicenseEndDateSelectedValue        == 2 ? LicenseDate?.EndDate : null;
            }

            // Check required Serial number
            if (CurrentProductVariant.SerialNumberRequired && string.IsNullOrWhiteSpace(EntitlementProductKey.SerialNumber))
            {
                var text = string.Format(ExceptionResource.SERIALNUMBERREQUIREDMISSING, EntitlementProductKey.Product.Product.Name,
                    CurrentProductVariant.Name);

                throw new Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions.ZeissLicensingRequiredSerialnumberException(text, "");
            }

            // Named Users
            var licenseModel = GetCurrentLicenseModel(licenseModels);

            if (null != licenseModel && licenseModel.IsConnected)
            {
                EntitlementProductKey.TotalQuantity = 1;
            }
        }
    }

    public LicenseModel? GetCurrentLicenseModel(List<LicenseModel> licenseModels)
    {
        return licenseModels.FirstOrDefault(c => c.Name == CurrentProductVariant.LicenseModel);
    }

    /// <summary>
    /// Set license model
    /// </summary>
    /// <param name="licModel">License model</param>
    /// <param name="prodVariant">product variant</param>
    public void SetLicenseModel(LicenseModel? licModel, bool useLicenseValues, ProductVariant prodVariant)
    {
        // LicensDate depends on the product variant
        if (licModel != null &&
            (licModel.LicenseMode == LicenseMode.Thales_Standalone      ||
             licModel.LicenseMode == LicenseMode.Thales_Network         ||
             licModel.LicenseMode == LicenseMode.FlexNet_FNE            ||
             licModel.LicenseMode == LicenseMode.FlexNet_FNPCertificate ||
             licModel.LicenseMode == LicenseMode.FlexNet_FNPTrustedStorage))
        {
            if (null == LicenseDate)
            {
                LicenseDate = new EntitlementProductFeatureLicenseModel();
            }

            UpdateLicenseDate(licModel, useLicenseValues, prodVariant);

            StartFromActivationDate = LicenseDate.StartDate == null;

            IsStartFromActivationDateDisabled = licModel.LicenseMode == LicenseMode.FlexNet_FNE            ||
                                                licModel.LicenseMode == LicenseMode.FlexNet_FNPCertificate ||
                                                licModel.LicenseMode == LicenseMode.FlexNet_FNPTrustedStorage;
        }
        else
        {
            LicenseDate = null;
        }
    }

    /// <summary>
    /// Read values
    /// </summary>
    public void ReadFromModel()
    {
        EntitlementProductKeyNeverExpires = null == EntitlementProductKey.EndDate;

        ProductVariantList = new List<ProductVariant>();

        if (null != EntitlementProductKey?.Product && EntitlementProductKey.Product.Product is Product && null != ((Product)EntitlementProductKey.Product.Product).ProductVariants)
        {
            if (IsTestEntitlement)
            {
                ProductVariantList = ((Product)EntitlementProductKey.Product.Product).ProductVariants.Where(c => c.State == ProductVariantState.ENABLED || c.State == ProductVariantState.DRAFT).ToList();
            }
            else
            {
                ProductVariantList = ((Product)EntitlementProductKey.Product.Product).ProductVariants.Where(c => c.State == ProductVariantState.ENABLED).ToList();
            }
        }
    }

    /// <summary>
    /// Get Duration in Days and StartDate from LicenseModel
    /// </summary>
    /// <param name="name">LicenseModel name</param>
    /// <returns>Duration in days and startdate</returns>
    public (int?, DateTime?) GetLicenseInfo(LicenseModel? licenseModel)
    {
        int? duration = null;
        DateTime? start = null;

        if (null != licenseModel)
        {
            switch (licenseModel.LicenseMode)
            {
                case LicenseMode.FlexNet_FNE:
                    duration = licenseModel.FNEProperties.DurationInDays;
                    break;
                case LicenseMode.FlexNet_FNPCertificate:
                    duration = licenseModel.FNPCertificateProperties.DurationInDays;
                    break;
                case LicenseMode.Thales_Connected:
                    duration = licenseModel.SentinelRMSConnectedProperties.DurationInDays;
                    break;
                case LicenseMode.Thales_CloudLM:
                    duration = licenseModel.SentinelRmsCloudLmProperties.DurationInDays;
                    break;
                case LicenseMode.Thales_Network:
                    duration = licenseModel.SentinelRMSNetworkProperties.DurationInDays;
                    start = licenseModel.SentinelRMSNetworkProperties.StartDate;
                    break;
                case LicenseMode.Thales_NetworkLease:
                    duration = licenseModel.SentinelRMSNetworkLeaseProperties.DurationInDays;
                    break;
                case LicenseMode.Thales_Standalone:
                    duration = licenseModel.SentinelRMSStandaloneProperties.DurationInDays;
                    start = licenseModel.SentinelRMSStandaloneProperties.StartDate;
                    break;
                case LicenseMode.Thales_StandaloneLease:
                    duration = licenseModel.SentinelRMSStandaloneLeaseProperties.DurationInDays;
                    break;
            }
        }

        return (duration, start);
    }

    public void AddNamedUsers(List<string> namedUsers)
    {
        NamedUsers.CollectionChanged -= NamedUsers_CollectionChanged;

        foreach (var namedUser in namedUsers)
        {
            var namedUserViewModel = new NamedUserViewModel { Name = namedUser };
            namedUserViewModel.PropertyChanged += NamedUserViewModel_PropertyChanged;
            NamedUsers.Add(namedUserViewModel);
        }

        NamedUsers.CollectionChanged += NamedUsers_CollectionChanged;
    }

    /// <summary>
    /// Update LicenseDate
    /// </summary>
    /// <param name="licModel">License Model</param>
    /// <param name="useLicenseValues">Flag if using license values</param>
    /// <param name="prodVariant">Product variant</param>
    private void UpdateLicenseDate(LicenseModel? licModel, bool useLicenseValues, ProductVariant prodVariant)
    {
        (var durationInDays, var start) = GetLicenseInfo(licModel);

        LicenseDate!.StartDate = useLicenseValues ? start : EntitlementProductKey.Product.Features[0].LicenseModel.StartDate;
        LicenseDate.DurationInDays = useLicenseValues ? durationInDays : EntitlementProductKey.Product.Features[0].LicenseModel.DurationInDays;

        if (useLicenseValues && (prodVariant.DefaultDuration ?? 0) > 0)
        {
            // if default Duration is set, use this
            LicenseDate.DurationInDays = prodVariant.DefaultDuration;
        }

        LicenseDate.EndDate = useLicenseValues ? null : EntitlementProductKey.Product.Features[0].LicenseModel.EndDate;

        LicenseEndDateSelectedValue = 0;

        if (null != LicenseDate.DurationInDays && null == LicenseDate.EndDate)
        {
            LicenseEndDateSelectedValue = 1;
        }

        if (null == LicenseDate.DurationInDays && null != LicenseDate.EndDate)
        {
            LicenseEndDateSelectedValue = 2;
        }
    }

    private void NamedUserViewModel_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        OnPropertyChanged();
    }

    private void NamedUsers_CollectionChanged(object? sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
    {
        OnPropertyChanged();
    }

    #endregion
}
