﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace EntitlementsModule.ViewModels;

internal class EntitlementSearchMaskViewModel : ObservableObject
{
    #region Fields

    private string _ProductFamily = string.Empty;

    #endregion

    #region Constructors

    public EntitlementSearchMaskViewModel()
    {
        AvailList.Add(new SelectModel { Text = SharedResource.ALL, Value = 0 });
        AvailList.Add(new SelectModel { Text = EntitlementResource.ONLYAVAILABLEQUANTITY, Value = 1 });
        AvailList.Add(new SelectModel { Text = EntitlementResource.NOAVAILABLEQUANTITY, Value = 2 });

        string[] entitlementStates = { EntitlementResource.EMPTY, SharedResource.DRAFT, EntitlementResource.COMPLETED, EntitlementResource.DISABLED, EntitlementResource.CLOSED };
        EntitlementStateList = entitlementStates.Select((s, i) => new SelectModel { Text = s, Value = i });
    }

    #endregion

    #region Properties

    public string ProductFamily
    {
        get => _ProductFamily;
        set => SetProperty(ref _ProductFamily, value);
    }

    public List<ProductFamily> ProductFamilies { get; set; } = new List<ProductFamily>();

    public List<SelectModel> AvailList { get; } = new();

    public IEnumerable<SelectModel> EntitlementStateList { get; }

    #endregion

    #region Methods

    public async Task LoadProductFamilies(IAppSettingClient appSettingClient)
    {
        ProductFamilies = await appSettingClient.GetProductFamilies(false);
        ProductFamilies.Insert(0, new ProductFamily { Businessgroup = string.Empty, Name = string.Empty });
    }

    #endregion
}
