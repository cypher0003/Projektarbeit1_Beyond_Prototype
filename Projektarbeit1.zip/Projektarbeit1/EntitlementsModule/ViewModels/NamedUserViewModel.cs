﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;

namespace EntitlementsModule.ViewModels;

public class NamedUserViewModel : ObservableObject
{
    #region Fields

    private string _Name = string.Empty;

    #endregion

    #region Properties

    public string Name
    {
        get => _Name;
        set => SetProperty(ref _Name, value);
    }

    #endregion
}
