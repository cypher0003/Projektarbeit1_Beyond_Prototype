﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using CommunityToolkit.Mvvm.ComponentModel;

namespace EntitlementsModule.ViewModels;

public class EntitlementViewModel : ObservableObject
{
    #region Constructors

    public EntitlementViewModel()
    {
        List<string> listText = new() { EntitlementResource.LICENSEENDDATENEVEREXPIRES, EntitlementResource.LICENSEENDDATEDURATION, EntitlementResource.LICENSEENDDATEENDDATE };
        LicenseEndDateTypeList = listText.Select((s, i) => new SelectModel { Text = s, Value = i });
    }

    #endregion

    #region Properties

    public bool OnlyEnabledProducts { get; set; } = true;

    public bool OnlyDraftEnabledProducts { get; set; } = true;


    public string OKText { get; set; } = string.Empty;

    public string SaveText { get; set; } = string.Empty;

    public bool EntitlementNeverExpires { get; set; } = false;

    public bool ShowSearchDialog { get; set; }

    public bool ShowCertificatePopup { get; set; }

    public bool ShowSendCertificatePopup { get; set; }

    public bool IsCertificateBtnDisabled { get; set; } = true;

    public bool IsAdded { get; set; } = true;

    public bool AddingEntitlementProductKey { get; set; } = false;

    public bool StatusDraftEnabled { get; set; } = false;

    public bool StatusCompleteEnabled { get; set; } = false;

    public bool StatusCloseEnabled { get; set; } = false;

    public bool StatusDisableEnabled { get; set; } = false;

    public bool ShowOKDialog { get; set; } = false;

    public bool ShowSaveDialog { get; set; } = false;

    public bool ProductKeysLoaded { get; set; } = false;

    public bool IsCertificateLoading { get; set; } = false;

    public bool IsClosedHidden { get; set; } = true;

    public bool IsUserEditQuantityGranted { get; set; }

    public bool IsUserManageNamedUsersGranted { get; set; }

    public bool IsUserTestEntitlementGranted { get; set; } = false;

    // Flags for saving before actions: activate, certificate
    public bool IsActionCertificate { get; set; } = false;

    public bool IsActionActivate { get; set; } = false;

    public bool IsActionMail { get; set; } = false;

    public bool IsActionDiscard { get; set; } = false;

    public bool IsMultiselect { get; set; } = false;

    public Entitlement SelectedEntitlement { get; set; } = new Entitlement();

    public Entitlement EditOriginalEntitlement { get; set; } = new Entitlement();

    public EntitlementProductKeyViewModel SelectedEntitlementProductKeyVM { get; set; } = new EntitlementProductKeyViewModel();

    public List<EntitlementProductKeyViewModel> EntitlementProductKeyVMs { get; set; } = new List<EntitlementProductKeyViewModel>();

    public CustomerSelectionModel CustomerEditSelectionModel { get; set; } = new CustomerSelectionModel();

    public List<LicenseModel> LicenseModels { get; set; } = new List<LicenseModel>();

    /// <summary>
    /// List of enddate types
    /// </summary>
    public IEnumerable<SelectModel> LicenseEndDateTypeList { get; set; }

    public string EndDateText => LicenseEndDateTypeList.ElementAt(SelectedEntitlementProductKeyVM.LicenseEndDateSelectedValue).Text;

    public bool ShowNamedUser
    {
        get
        {
            var licenseModel = LicenseModels.FirstOrDefault(c => c.Name == SelectedEntitlementProductKeyVM.CurrentProductVariant.LicenseModel);
            return null != licenseModel && licenseModel.IsConnected;
        }
    }


    public bool IsActivateEnabled => EntitlementProductKeyVMs.Any(c => c.EntitlementProductKey.AvailableQuantity > 0) && ProductKeysLoaded;

    public bool HasNamedUserChanges { get; set; }

    #endregion

    #region Methods

    public void SetGrants(User user)
    {
        IsUserEditQuantityGranted = user.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.Entitlement_ChangeQuantity.ToString()]);
        IsUserTestEntitlementGranted = user.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.Entitlement_AllowTest.ToString()]);
        IsUserManageNamedUsersGranted = user.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.ManageNamedUsers.ToString()]);
    }

    public void EntitlementProductKeyViewModel_PropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        HasNamedUserChanges = true;
    }

    internal void SetProductEnableStates()
    {
        OnlyDraftEnabledProducts = SelectedEntitlement.IsTest == true;
        OnlyEnabledProducts = SelectedEntitlement.IsTest      != true;
    }

    #endregion
}
