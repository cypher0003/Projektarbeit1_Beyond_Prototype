﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Resources;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace EntitlementsModule.ViewModels;

public class SplitComponentViewModel
{
    #region Fields

    private EntitlementSplitInfo _EntitlementSplitInfo = new();

    private IEntitlementClient _EntitlementClient = null!;

    #endregion

    #region Properties

    public List<SplitProductKeyViewModel> SplitProductKeyVMs { get; set; } = new();

    public Entitlement Entitlement { get; set; } = new();

    public int SelectedOrganizationTierValue { get; set; } = 0;

    public bool IsSeparateEntitlementsDisabled =>
        SelectedOrganizationTierValue == (int)OrganizationTier.EndCustomer          ||
        string.IsNullOrWhiteSpace(_EntitlementSplitInfo.ReceiverOrganizationNumber) ||
        SplitProductKeyVMs.Count                                         == 0       ||
        SplitProductKeyVMs.Sum(c => c.EntitlementSplitInfoItem.Quantity) <= 1;

    public IEnumerable<SelectModel> OrganizationTierListAll { get; set; } = new List<SelectModel>();

    public List<SelectModel> OrganizationTierList { get; set; } = new();

    public bool CanSplit => SplitProductKeyVMs.Exists(c => c.EntitlementSplitInfoItem.Quantity > 0) && !string.IsNullOrWhiteSpace(_EntitlementSplitInfo.ReceiverOrganizationNumber);

    public bool SeparateEntitlements
    {
        get => _EntitlementSplitInfo.SeparateEntitlements;
        set => _EntitlementSplitInfo.SeparateEntitlements = value;
    }

    #endregion

    #region Methods

    public void Init(Entitlement entitlement, IEntitlementClient entitlementClient)
    {
        Entitlement = entitlement;
        SplitProductKeyVMs.Clear();
        OrganizationTierList.Clear();
        _EntitlementSplitInfo = new EntitlementSplitInfo();
        _EntitlementSplitInfo.Items = new List<EntitlementSplitInfoItem>();
        SelectedOrganizationTierValue = 0;
        _EntitlementClient = entitlementClient;

        var selectModels = new List<SelectModel>();
        var resourceManager = new ResourceManager(typeof(OrganizationResource));

        foreach (OrganizationTier orgTier in Enum.GetValues(typeof(OrganizationTier)))
        {
            var text = resourceManager.GetString("ORGTIER" + orgTier.ToString().ToUpper());

            if (text != null)
            {
                selectModels.Add(new SelectModel { Text = text, Value = (int)orgTier });
            }
        }

        OrganizationTierListAll = selectModels.ToArray();

        // Select Tiers
        if (string.IsNullOrWhiteSpace(Entitlement.EndCustomer?.Number))
        {
            OrganizationTierList.Add(OrganizationTierListAll.Single(c => c.Value == (int)OrganizationTier.EndCustomer));
        }

        if (string.IsNullOrWhiteSpace(Entitlement.SSC2Number))
        {
            OrganizationTierList.Add(OrganizationTierListAll.Single(c => c.Value == (int)OrganizationTier.SSC2));
        }

        if (string.IsNullOrWhiteSpace(Entitlement.SSC1Number))
        {
            OrganizationTierList.Add(OrganizationTierListAll.Single(c => c.Value == (int)OrganizationTier.SSC1));
        }

        if (string.IsNullOrWhiteSpace(Entitlement.DistributorNumber))
        {
            OrganizationTierList.Add(OrganizationTierListAll.Single(c => c.Value == (int)OrganizationTier.Distributor));
        }

        if (string.IsNullOrWhiteSpace(Entitlement.FactoryNumber))
        {
            OrganizationTierList.Add(OrganizationTierListAll.Single(c => c.Value == (int)OrganizationTier.Factory));
        }

        if (OrganizationTierList.Any())
        {
            _EntitlementSplitInfo.ReceiverOrganizationTier = (OrganizationTier)OrganizationTierList[0].Value;
        }

        foreach (var item in entitlement.ProductKeys)
        {
            SplitProductKeyVMs.Add(new SplitProductKeyViewModel(item));
        }
    }

    /// <summary>
    /// Looks, if there are product keys with quantity > 0 and adds them to entitlementInfo object.
    /// This will be then sent to the entitlement service.
    /// </summary>
    /// <returns></returns>
    public async Task<string> TrySplit()
    {
        if (!CanSplit)
        {
            return string.Empty;
        }

        _EntitlementSplitInfo.Items.AddRange(SplitProductKeyVMs.Where(item => item.EntitlementSplitInfoItem.Quantity > 0).Select(item => item.EntitlementSplitInfoItem));
        var newEntitlement = await _EntitlementClient.Split(Entitlement.EntitlementId, _EntitlementSplitInfo);
        return null != newEntitlement ? newEntitlement.EntitlementId : string.Empty;
    }

    public void ClearOrganization()
    {
        _EntitlementSplitInfo.ReceiverOrganizationNumber = string.Empty;
    }

    public void SetOrganizationTierValue(int newValue)
    {
        SelectedOrganizationTierValue = newValue;
        _EntitlementSplitInfo.ReceiverOrganizationTier = (OrganizationTier)newValue;

        // if changed to end customer, then uncheck separate in entitlements
        if (newValue == (int)OrganizationTier.EndCustomer)
        {
            _EntitlementSplitInfo.SeparateEntitlements = false;
        }
    }

    public void SetOrganization(Organization organization)
    {
        _EntitlementSplitInfo.ReceiverOrganizationNumber = organization.Number;
    }

    #endregion
}
