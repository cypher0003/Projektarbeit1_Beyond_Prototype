﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.ViewModels;
using Microsoft.JSInterop;

namespace EntitlementsModule.Pages;

public partial class ViewEntitlements
{
    #region Fields

    //Dialogs / Messageboxes
    private Alert? _ErrorZeissLicensingAlert;
    private SendCertificatesPopup? _SendCertificatesPopup;
    private HistoryDialog? _HistoryDialog;
    private SplitDialog? _SplitDialog;
    private InfoDialog? _InfoDialog;
    private ActivatePopup? _ActivatePopup;
    private DataGrid<EntitlementProductKeyViewModel>? _DatGridProductKeys;

    #endregion

    #region Properties

    [Parameter]
    public string? EntitlementId { get; set; } = string.Empty;

    public bool IsProdKeyDetailsReadOnly => IsReadOnly || 0 == EntitlementVM.EntitlementProductKeyVMs.Count;

    public bool IsStartFromActivationDateDisabled => IsReadOnly || EntitlementVM.SelectedEntitlementProductKeyVM.IsStartFromActivationDateDisabled;


    private EntitlementViewModel EntitlementVM { get; } = new EntitlementViewModel();

    private SearchEntitlementComponent? SearchEntitlementComponent { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Activate closed
    /// </summary>
    public async Task OnSplitClosed(string eId)
    {
        try
        {
            if (!string.IsNullOrEmpty(eId))
            {
                EntitlementVM.SelectedEntitlement = (await entitlementClient.GetEntitlements(new SearchObjectEntitlement { EntitlementId = EntitlementVM.SelectedEntitlement.EntitlementId, SearchPattern = SearchPattern.Exact })).List.First();
                EntitlementVM.EditOriginalEntitlement = EntitlementVM.SelectedEntitlement;
                await PrepareDetails();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            // grants
            CurrentUser = await UserClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Any(c => c.GrantEntitlement >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantEntitlement >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantEntitlement >= GrantType.Edit);
            IsUserViewGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantEntitlement >= GrantType.View);

            IsUserViewObjectInfoGranted = CurrentUser.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.AllowViewObjectInfo.ToString()]);
            EntitlementVM.SetGrants(CurrentUser);

            IsLoading = !string.IsNullOrWhiteSpace(EntitlementId);

            if (IsLoading)
            {
                StateHasChanged();
            }

            EntitlementVM.LicenseModels = await productClient.GetLicenseModels();

            HasNavItemRoute = true;
            NavItemRoute = "Entitlements";

            await base.OnInitializedAsync();

            OnSelectedEntitlementChanged(EntitlementVM.SelectedEntitlement);
            IsLoading = false;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Parameter set
    /// </summary>
    /// <returns></returns>
    protected override async Task OnParametersSetAsync()
    {
        if (!string.IsNullOrWhiteSpace(EntitlementId))
        {
            EntitlementVM.SelectedEntitlement = new Entitlement { EntitlementId = EntitlementId };
            await OnActionClicked(ActionType.View);
        }
    }

    /// <summary>
    /// Entitlement details discard button clicked
    /// </summary>
    protected override void OnDetailsDiscardButtonClicked()
    {
        try
        {
            if (CheckChangesSaving())
            {
                // Save ?
                EntitlementVM.SaveText = L["SAVEENTITLEMENTBEFOREDISCARD"].Value.Replace("\\n", System.Environment.NewLine);
                EntitlementVM.ShowSaveDialog = true;
                EntitlementVM.IsActionDiscard = true;
            }
            else
            {
                Discard();
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    private void Discard()
    {
        _ErrorZeissLicensingAlert!.Hide();

        base.OnDetailsDiscardButtonClicked();

        if (string.IsNullOrWhiteSpace(EntitlementVM.SelectedEntitlement.Id))
        {
            EntitlementVM.SelectedEntitlement = EntitlementVM.EditOriginalEntitlement;
        }
    }

    /// <summary>
    /// Button clicked
    /// </summary>
    private async Task OnActionClicked(object actionType)
    {
        try
        {
            var action = (ActionType)actionType;
            var isListVisible = false;
            IsReadOnly = false;
            PartialList<Entitlement> list;

            switch (action)
            {
                case ActionType.Add:
                case ActionType.AddTest:
                    EntitlementVM.IsClosedHidden = true;
                    EntitlementVM.EditOriginalEntitlement = EntitlementVM.SelectedEntitlement;
                    AddEntitlement();
                    EntitlementVM.SelectedEntitlement.IsTest = action                                                          == ActionType.AddTest;
                    EntitlementVM.SelectedEntitlementProductKeyVM.IsTestEntitlement = EntitlementVM.SelectedEntitlement.IsTest == true;
                    EntitlementVM.SetProductEnableStates();
                    break;
                case ActionType.Delete:
                    isListVisible = true;
                    EntitlementVM.OKText = E["DELETEENTITLEMENT"];
                    EntitlementVM.ShowOKDialog = true;
                    break;
                case ActionType.Edit:
                    IsLoading = true;
                    EntitlementVM.IsClosedHidden = true;
                    list = await entitlementClient.GetEntitlements(new SearchObjectEntitlement { EntitlementId = EntitlementVM.SelectedEntitlement.EntitlementId, SearchPattern = SearchPattern.Exact });

                    if (list.List.Count > 0)
                    {
                        OnSelectedEntitlementChanged(list.List.First());
                    }

                    EntitlementVM.EditOriginalEntitlement = EntitlementVM.SelectedEntitlement;
                    EntitlementVM.SelectedEntitlement = (Entitlement)EntitlementVM.EditOriginalEntitlement.Clone();
                    _ = PrepareDetails();
                    CreateLastUsedItem(EntitlementVM.SelectedEntitlement.EntitlementId, EntitlementVM.SelectedEntitlement.EntitlementId, SharedResource.ROUTEENTITLEMENTS, SharedResource.ENTITLEMENT);
                    break;
                case ActionType.View:
                    IsLoading = true;
                    EntitlementVM.IsClosedHidden = true;
                    EntitlementVM.ProductKeysLoaded = false;
                    list = await entitlementClient.GetEntitlements(new SearchObjectEntitlement { EntitlementId = EntitlementVM.SelectedEntitlement.EntitlementId, SearchPattern = SearchPattern.Exact });

                    if (list.List.Count > 0)
                    {
                        OnSelectedEntitlementChanged(list.List.First());
                    }

                    IsReadOnly = true;
                    EntitlementVM.EditOriginalEntitlement = EntitlementVM.SelectedEntitlement;
                    _ = PrepareDetails();
                    CreateLastUsedItem(EntitlementVM.SelectedEntitlement.EntitlementId, EntitlementVM.SelectedEntitlement.EntitlementId, SharedResource.ROUTEENTITLEMENTS, SharedResource.ENTITLEMENT);
                    break;
            }

            IsListVisible = isListVisible;
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
            IsListVisible = true;
        }
        finally
        {
            IsLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Add
    /// </summary>
    private void AddEntitlement()
    {
        try
        {
            EntitlementVM.CustomerEditSelectionModel = new CustomerSelectionModel();

            EntitlementVM.SelectedEntitlement = new Entitlement
            {
                StartDate = DateTime.SpecifyKind(DateTime.Today, DateTimeKind.Unspecified),
                EndDate = null,
                State = EntitlementState.Draft
            };

            SetSelectedEntitlementStates();
            EntitlementVM.SelectedEntitlementProductKeyVM = new EntitlementProductKeyViewModel();
            EntitlementVM.SelectedEntitlementProductKeyVM.EntitlementProductKey.StartDate = DateTime.SpecifyKind(DateTime.Today, DateTimeKind.Unspecified);
            EntitlementVM.EntitlementProductKeyVMs.Clear();
            EntitlementVM.EntitlementNeverExpires = true;
            EntitlementVM.IsAdded = true;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Certificate show tabs button pressed
    /// </summary>
    private async Task OnCertificateShowTabsButtonClicked()
    {
        try
        {
            EntitlementVM.IsCertificateLoading = true;

            if (CheckChangesSaving())
            {
                // Save ?
                EntitlementVM.SaveText = L["SAVEENTITLEMENTFORCERTIFICATE"].Value.Replace("\\n", System.Environment.NewLine);
                EntitlementVM.ShowSaveDialog = true;
                EntitlementVM.IsActionCertificate = true;
            }
            else
            {
                await GetCertificate();
            }
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            EntitlementVM.IsCertificateLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Certificate
    /// </summary>
    private async Task SaveEntitlementBeforeAction()
    {
        try
        {
            EntitlementVM.ShowSaveDialog = false;
            StateHasChanged();

            // Save entilement first, because of current changes
            if (EntitlementVM.IsActionCertificate)
            {
                await SaveDetails();
                await PrepareDetails();

                await GetCertificate();
            }
            else if (EntitlementVM.IsActionActivate)
            {
                await SaveDetails();
                await PrepareDetails();

                await _ActivatePopup!.ShowActivate(EntitlementVM.SelectedEntitlement, EntitlementVM.EntitlementProductKeyVMs);
            }
            else if (EntitlementVM.IsActionMail)
            {
                await SaveDetails();
                await PrepareDetails();

                await _SendCertificatesPopup!.CreateEmail(EntitlementVM.SelectedEntitlement);
            }
            else if (EntitlementVM.IsActionDiscard)
            {
                await SaveDetails();
                Discard();
            }
        }
        finally
        {
            EntitlementVM.IsActionActivate = false;
            EntitlementVM.IsActionCertificate = false;
            EntitlementVM.IsActionMail = false;
            EntitlementVM.IsActionDiscard = false;
        }
    }

    /// <summary>
    /// Certificate
    /// </summary>
    private async Task GetCertificate()
    {
        try
        {
            string title = E["CERTIFICATE"];

            // Reports:
            List<ReportResponse> reportResponses = await entitlementClient.GetCertificateReports(EntitlementVM.SelectedEntitlement.EntitlementId);

            var idx = 1;

            foreach (var report in reportResponses)
            {
                if (report.ReportFormatType == ReportFormatType.PDF)
                {
                    var filename = reportResponses.Count > 1 ? $"{EntitlementVM.SelectedEntitlement.EntitlementId}_{idx++}.pdf" : $"{EntitlementVM.SelectedEntitlement.EntitlementId}.pdf";
                    var tempBytes = Convert.FromBase64String(report.Report);
                    await JSRuntime.InvokeAsync<object>("savePdf", filename, tempBytes);
                }
                else
                {
                    var win = await JSRuntime.InvokeAsync<object?>("openInNewTab", report.Report, title, Guid.NewGuid().ToString());

                    if (null == win)
                    {
                        SnackbarException.ShowException(L["ALLOWPOPUPS"]);
                        break;
                    }
                }
            }
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            EntitlementVM.IsCertificateLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Certificate Email button pressed
    /// </summary>
    private async Task OnCertificateSendEmailButtonClicked()
    {
        try
        {
            if (CheckChangesSaving())
            {
                // Save ?
                EntitlementVM.SaveText = SharedResource.SAVEENTITLEMENTFOREMAIL.Replace("\\n", System.Environment.NewLine);
                EntitlementVM.ShowSaveDialog = true;
                EntitlementVM.IsActionMail = true;
            }
            else
            {
                await _SendCertificatesPopup!.CreateEmail(EntitlementVM.SelectedEntitlement);
            }
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
    }

    /// <summary>
    /// Checks, if Entitlement has changes and has to be saved before action
    /// </summary>
    /// <returns>True: has changes</returns>
    private bool CheckChangesSaving()
    {
        var oldJson = JsonHelper.GetJSON(EntitlementVM.EditOriginalEntitlement);
        var currentJson = JsonHelper.GetJSON(EntitlementVM.SelectedEntitlement);
        string oldPKsJson;

        if (!EntitlementVM.IsClosedHidden)
        {
            oldPKsJson = JsonHelper.GetJSON<List<EntitlementProductKey>>(EntitlementVM.EditOriginalEntitlement.ProductKeys);
        }
        else
        {
            oldPKsJson = JsonHelper.GetJSON<List<EntitlementProductKey>>(EntitlementVM.EditOriginalEntitlement.ProductKeys.Where(c => c.State != EntitlementProductKeyState.Closed).ToList());
        }

        var currentPKsJson = JsonHelper.GetJSON(EntitlementVM.EntitlementProductKeyVMs.Select(c => c.EntitlementProductKey).ToList());

        return oldJson != currentJson || oldPKsJson != currentPKsJson || EntitlementVM.HasNamedUserChanges;
    }

    /// <summary>
    /// Reset button enable states
    /// </summary>
    private void ResetStates()
    {
        try
        {
            EntitlementVM.StatusCloseEnabled = false;
            EntitlementVM.StatusCompleteEnabled = false;
            EntitlementVM.StatusDisableEnabled = false;
            EntitlementVM.StatusDraftEnabled = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Set possible states of the selected entitlement
    /// </summary>
    private void SetSelectedEntitlementStates()
    {
        try
        {
            ResetStates();

            switch (EntitlementVM.SelectedEntitlement.State)
            {
                case EntitlementState.Draft:
                    EntitlementVM.StatusDraftEnabled = true;
                    EntitlementVM.StatusCompleteEnabled = true;
                    break;
                case EntitlementState.Enable:
                    EntitlementVM.StatusCloseEnabled = true;
                    EntitlementVM.StatusDisableEnabled = true;
                    EntitlementVM.StatusCompleteEnabled = true;
                    break;
                case EntitlementState.Disable:
                    EntitlementVM.StatusCloseEnabled = true;
                    EntitlementVM.StatusCompleteEnabled = true;
                    EntitlementVM.StatusDisableEnabled = true;
                    break;
                case EntitlementState.Closed:
                    break;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Draft button pressed
    /// </summary>
    private void OnDraftButtonClicked()
    {
        try
        {
            _ErrorZeissLicensingAlert!.Hide();
            EntitlementVM.SelectedEntitlement.State = EntitlementState.Draft;
            StateHasChanged();
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
    }

    /// <summary>
    /// Complete button pressed
    /// </summary>
    private void OnCompleteButtonClicked()
    {
        try
        {
            _ErrorZeissLicensingAlert!.Hide();
            EntitlementVM.SelectedEntitlement.State = EntitlementState.Enable;
            StateHasChanged();
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
    }

    /// <summary>
    /// Close button pressed
    /// </summary>
    private void OnCloseButtonClicked()
    {
        try
        {
            EntitlementVM.OKText = E["CLOSEENTITLEMENT"];
            EntitlementVM.ShowOKDialog = true;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Disable button pressed
    /// </summary>
    private void OnDisableButtonClicked()
    {
        try
        {
            _ErrorZeissLicensingAlert!.Hide();
            EntitlementVM.SelectedEntitlement.State = EntitlementState.Disable;
            StateHasChanged();
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
    }

    /// <summary>
    /// Check, if product key can be enabled
    /// </summary>
    /// <param name="entitlementProductKeyViewModel">Product key</param>
    /// <returns>True: Product key can be enabled</returns>
    private bool CanEnableProductKey(EntitlementProductKeyViewModel entitlementProductKeyViewModel)
    {
        var ret = false;

        try
        {
            ret = EntitlementVM.SelectedEntitlement.State                    == EntitlementState.Enable &&
                  entitlementProductKeyViewModel.EntitlementProductKey.State == EntitlementProductKeyState.Disable;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }

        return ret;
    }

    /// <summary>
    /// Check, if product key can be disabled
    /// </summary>
    /// <param name="entitlementProductKeyViewModel">Product key</param>
    /// <returns>True: Product key can be disabled</returns>
    private bool CanDisableProductKey(EntitlementProductKeyViewModel entitlementProductKeyViewModel)
    {
        var ret = false;

        try
        {
            ret = EntitlementVM.SelectedEntitlement.State                    == EntitlementState.Enable &&
                  entitlementProductKeyViewModel.EntitlementProductKey.State == EntitlementProductKeyState.Enable;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }

        return ret;
    }

    /// <summary>
    /// Check, if product key can be deleted
    /// </summary>
    /// <param name="entitlementProductKeyViewModel">Product key</param>
    /// <returns>True: Product key can be deleted</returns>
    private bool CanDeleteProductKey(EntitlementProductKeyViewModel entitlementProductKeyViewModel)
    {
        var ret = false;

        try
        {
            ret = (EntitlementVM.SelectedEntitlement.State == EntitlementState.Draft || EntitlementVM.SelectedEntitlement.State == EntitlementState.Enable) && entitlementProductKeyViewModel.EntitlementProductKey.State == EntitlementProductKeyState.Draft;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }

        return ret;
    }

    /// <summary>
    /// Selected entitlement has changed
    /// </summary>
    /// <param name="entitlement"></param>
    private void OnSelectedEntitlementChanged(object? entitlement)
    {
        try
        {
            if (null != entitlement)
            {
                EntitlementVM.SelectedEntitlement = (Entitlement)entitlement;
                EntitlementVM.SetProductEnableStates();
                EntitlementVM.SelectedEntitlementProductKeyVM = new EntitlementProductKeyViewModel();
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnNamedUserActionClicked(object? namedUser, object actionType)
    {
        try
        {
            var action = (ActionType)actionType;

            switch (action)
            {
                case ActionType.Add:
                    EntitlementVM.SelectedEntitlementProductKeyVM.NamedUsers.Insert(0, new NamedUserViewModel());
                    break;
                case ActionType.Delete:
                    if (null != namedUser)
                    {
                        EntitlementVM.SelectedEntitlementProductKeyVM.NamedUsers.Remove((NamedUserViewModel)namedUser);
                    }

                    break;
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected entitlement has changed
    /// </summary>
    /// <param name="enddateType"></param>
    private void OnLicenseEndDateChanged(int enddateType)
    {
        try
        {
            EntitlementVM.SelectedEntitlementProductKeyVM.LicenseEndDateSelectedValue = enddateType;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Prepare details
    /// </summary>
    private async Task PrepareDetails()
    {
        try
        {
            EntitlementVM.CustomerEditSelectionModel = new CustomerSelectionModel();

            EntitlementVM.ProductKeysLoaded = false;
            EntitlementVM.HasNamedUserChanges = false;
            StateHasChanged();

            var number = string.IsNullOrWhiteSpace(EntitlementVM.SelectedEntitlement.DistributorNumber) ? string.Empty : $"[{EntitlementVM.SelectedEntitlement.DistributorNumber}]";
            EntitlementVM.CustomerEditSelectionModel.DistributorText = $"{EntitlementVM.SelectedEntitlement.DistributorName} {number}";

            if (!string.IsNullOrEmpty(EntitlementVM.SelectedEntitlement.DistributorNumber))
            {
                EntitlementVM.CustomerEditSelectionModel.Distributor = new RefOrganization
                {
                    Name = EntitlementVM.SelectedEntitlement.DistributorName,
                    Number = EntitlementVM.SelectedEntitlement.DistributorNumber
                };
            }

            EntitlementVM.CustomerEditSelectionModel.EndcustomerText = OrganizationHelper.GetOrganizationText(EntitlementVM.SelectedEntitlement.EndCustomer);

            if (EntitlementVM.SelectedEntitlement.EndCustomer != null)
            {
                EntitlementVM.CustomerEditSelectionModel.Endcustomer = EntitlementVM.SelectedEntitlement.EndCustomer;
            }

            number = string.IsNullOrWhiteSpace(EntitlementVM.SelectedEntitlement.FactoryNumber) ? string.Empty : $"[{EntitlementVM.SelectedEntitlement.FactoryNumber}]";
            EntitlementVM.CustomerEditSelectionModel.FactoryText = $"{EntitlementVM.SelectedEntitlement.FactoryName} {number}";

            if (!string.IsNullOrEmpty(EntitlementVM.SelectedEntitlement.FactoryNumber))
            {
                EntitlementVM.CustomerEditSelectionModel.Factory = new RefOrganization
                {
                    Name = EntitlementVM.SelectedEntitlement.FactoryName,
                    Number = EntitlementVM.SelectedEntitlement.FactoryNumber
                };
            }

            number = string.IsNullOrWhiteSpace(EntitlementVM.SelectedEntitlement.SSC1Number) ? string.Empty : $"[{EntitlementVM.SelectedEntitlement.SSC1Number}]";
            EntitlementVM.CustomerEditSelectionModel.SSC1Text = $"{EntitlementVM.SelectedEntitlement.SSC1Name} {number}";

            if (!string.IsNullOrEmpty(EntitlementVM.SelectedEntitlement.SSC1Number))
            {
                EntitlementVM.CustomerEditSelectionModel.SSC1 = new RefOrganization
                {
                    Name = EntitlementVM.SelectedEntitlement.SSC1Name,
                    Number = EntitlementVM.SelectedEntitlement.SSC1Number
                };
            }

            number = string.IsNullOrWhiteSpace(EntitlementVM.SelectedEntitlement.SSC2Number) ? string.Empty : $"[{EntitlementVM.SelectedEntitlement.SSC2Number}]";
            EntitlementVM.CustomerEditSelectionModel.SSC2Text = $"{EntitlementVM.SelectedEntitlement.SSC2Name} {number}";

            if (!string.IsNullOrEmpty(EntitlementVM.SelectedEntitlement.SSC2Number))
            {
                EntitlementVM.CustomerEditSelectionModel.SSC2 = new RefOrganization
                {
                    Name = EntitlementVM.SelectedEntitlement.SSC2Name,
                    Number = EntitlementVM.SelectedEntitlement.SSC2Number
                };
            }

            EntitlementVM.EntitlementNeverExpires = !EntitlementVM.SelectedEntitlement.EndDate.HasValue;

            EntitlementVM.IsCertificateBtnDisabled = true;
            EntitlementVM.IsAdded = false;

            await _ErrorZeissLicensingAlert!.Hide();

            SetSelectedEntitlementStates();

            EntitlementVM.IsClosedHidden = true;
            await FillProductKeyList();

            EntitlementVM.ProductKeysLoaded = true;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Fills the list of product key VMs
    /// </summary>
    private async Task FillProductKeyList()
    {
        try
        {
            EntitlementVM.EntitlementProductKeyVMs = new List<EntitlementProductKeyViewModel>();

            #region fill ProductKeyVMs with empty dummys to "paint" table in right size from beginning

            foreach (var entitlementProductKey in EntitlementVM.SelectedEntitlement.ProductKeys)
            {
                if ((EntitlementVM.IsClosedHidden && entitlementProductKey.State != EntitlementProductKeyState.Closed) || !EntitlementVM.IsClosedHidden)
                {
                    EntitlementProductKeyViewModel entitlementProductKeyViewModel = new(entitlementProductKey)
                    {
                        IsTestEntitlement = EntitlementVM.SelectedEntitlement.IsTest == true,
                        IsCompletelyLoaded = false
                    };

                    entitlementProductKeyViewModel.PropertyChanged += EntitlementVM.EntitlementProductKeyViewModel_PropertyChanged;

                    EntitlementVM.EntitlementProductKeyVMs.Add(entitlementProductKeyViewModel);
                }
            }

            StateHasChanged();

            #endregion

            #region fill dummy ProductKeyVMs

            foreach (var entitlementProductKey in EntitlementVM.SelectedEntitlement.ProductKeys)
            {
                if ((EntitlementVM.IsClosedHidden && entitlementProductKey.State != EntitlementProductKeyState.Closed) || !EntitlementVM.IsClosedHidden)
                {
                    var entitlementProductKeyViewModel = EntitlementVM.EntitlementProductKeyVMs.FirstOrDefault(x => x.EntitlementProductKey.Id == entitlementProductKey.Id);

                    if (entitlementProductKeyViewModel != null)
                    {
                        try
                        {
                            entitlementProductKeyViewModel.CurrentProductVariant = await productVarientClient.GetProductVariantById(entitlementProductKey.ProductVariantId);

                            await productKeyProvider.Update(entitlementProductKeyViewModel);
                            var prodVar = entitlementProductKeyViewModel.ProductVariantList.FirstOrDefault(c => c.Id == entitlementProductKeyViewModel.EntitlementProductKey.ProductVariantId);

                            if (null != prodVar)
                            {
                                productKeyProvider.UpdateProductVariant(prodVar, entitlementProductKeyViewModel, EntitlementVM.LicenseModels);
                            }

                            if (null != entitlementProductKeyViewModel.EntitlementProductKey.NamedUsersProperties)
                            {
                                List<string> namedUsers = await entitlementClient.GetNamedUsers(entitlementProductKeyViewModel.EntitlementProductKey.ProductKeyId);
                                entitlementProductKeyViewModel.AddNamedUsers(namedUsers);
                            }
                        }
                        catch (Exception ex)
                        {
                            SnackbarException.ShowException(ex.Message);
                            entitlementProductKeyViewModel.HasErrorByLoading = true;
                        }
                        finally
                        {
                            entitlementProductKeyViewModel.IsCompletelyLoaded = true;
                        }
                    }
                }

                StateHasChanged();
            }

            #endregion

            if (EntitlementVM.EntitlementProductKeyVMs.Count > 0)
            {
                await OnSelectedEntitlementProductKeyChanged(EntitlementVM.EntitlementProductKeyVMs.First());
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete Entitlement
    /// </summary>
    private async Task DeleteEntitlement()
    {
        try
        {
            await entitlementClient.Delete(EntitlementVM.SelectedEntitlement);
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
    }

    /// <summary>
    /// OK-Dialog OK
    /// </summary>
    private async Task OnOKDialogOK(object choice)
    {
        try
        {
            await _ErrorZeissLicensingAlert!.Hide();

            if (E["DELETEENTITLEMENT"] == (string)choice)
            {
                await DeleteEntitlement();
                SearchEntitlementComponent!.RemoveEntitlement(EntitlementVM.SelectedEntitlement);
            }
            else if (E["CLOSEENTITLEMENT"] == (string)choice)
            {
                EntitlementVM.SelectedEntitlement.State = EntitlementState.Closed;
                StateHasChanged();
            }

            EntitlementVM.ShowOKDialog = false;
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
            StateHasChanged();
        }
    }

    /// <summary>
    /// Customer selection changes
    /// </summary>
    /// <param name="isChecked">check state</param>
    private void OnNeverExpiresCheckedChanged(bool isChecked)
    {
        try
        {
            EntitlementVM.EntitlementNeverExpires = isChecked;

            if (isChecked)
            {
                // Enddate -> null, disabled
                EntitlementVM.SelectedEntitlement.EndDate = null;
                EntitlementVM.SelectedEntitlement.DurationInDays = null;
            }
            else
            {
                // Enddate enabled
                EntitlementVM.SelectedEntitlement.EndDate = DateTime.Today.AddYears(1);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Customer selection changes
    /// </summary>
    /// <param name="isChecked">check state</param>
    private async Task OnClosedHiddenCheckChanged(bool isChecked)
    {
        try
        {
            EntitlementVM.IsClosedHidden = isChecked;
            var listNew = EntitlementVM.EntitlementProductKeyVMs.Where(c => string.IsNullOrWhiteSpace(c.EntitlementProductKey.ProductKeyId)).ToList();
            await FillProductKeyList();
            EntitlementVM.EntitlementProductKeyVMs.AddRange(listNew);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Add selected product key
    /// </summary>
    private void OnAddProductKeyClicked()
    {
        try
        {
            EntitlementVM.AddingEntitlementProductKey = true;
            EntitlementVM.IsMultiselect = true;
            EntitlementVM.ShowSearchDialog = true;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Delete selected product key
    /// </summary>
    private async Task OnDeleteProductKeyClicked(EntitlementProductKeyViewModel entitlementProductKeyViewModel)
    {
        try
        {
            if (EntitlementVM.SelectedEntitlementProductKeyVM != entitlementProductKeyViewModel)
            {
                await OnSelectedEntitlementProductKeyChanged(entitlementProductKeyViewModel);
            }

            EntitlementVM.EntitlementProductKeyVMs.Remove(EntitlementVM.SelectedEntitlementProductKeyVM);

            if (EntitlementVM.EntitlementProductKeyVMs.Count > 0)
            {
                await OnSelectedEntitlementProductKeyChanged(EntitlementVM.EntitlementProductKeyVMs.First());
            }
            else
            {
                EntitlementVM.SelectedEntitlementProductKeyVM = new EntitlementProductKeyViewModel();
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected entitlement product key has changed
    /// </summary>
    /// <param name="entitlementProductKeyVM">Selected product key</param>
    private async Task OnSelectedEntitlementProductKeyChanged(EntitlementProductKeyViewModel entitlementProductKeyVM)
    {
        try
        {
            if (EntitlementVM.EntitlementProductKeyVMs.Count > 0 && EntitlementVM.EntitlementProductKeyVMs.Contains(entitlementProductKeyVM))
            {
                EntitlementVM.SelectedEntitlementProductKeyVM = entitlementProductKeyVM;
                await productKeyProvider.Update(EntitlementVM.SelectedEntitlementProductKeyVM);
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Product Variant changed
    /// </summary>
    /// <param name="prodVar"></param>
    private void OnEntitlementProductKeyVariantChanged(object prodVar)
    {
        try
        {
            var prodVariant = EntitlementVM.SelectedEntitlementProductKeyVM.ProductVariantList.FirstOrDefault(c => c.Id == (string)prodVar);

            if (prodVariant != null)
            {
                productKeyProvider.UpdateProductVariant(prodVariant, EntitlementVM.SelectedEntitlementProductKeyVM, EntitlementVM.LicenseModels);
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search product OK pressed
    /// </summary>
    private async Task OnSearchOKClick(object productList)
    {
        try
        {
            EntitlementVM.ShowSearchDialog = false;

            List<Product> products = new();

            if (productList.GetType() == typeof(Product))
            {
                products.Add((Product)productList);
            }
            else if (productList.GetType() == typeof(List<Product>))
            {
                products.AddRange((List<Product>)productList);
            }

            var oldSelectedEntitlementProductKeyVM = EntitlementVM.SelectedEntitlementProductKeyVM;

            foreach (var product in products)
            {
                if (EntitlementVM.AddingEntitlementProductKey)
                {
                    EntitlementVM.SelectedEntitlementProductKeyVM = new EntitlementProductKeyViewModel
                    {
                        IsTestEntitlement = EntitlementVM.SelectedEntitlement.IsTest == true
                    };

                    EntitlementVM.EntitlementProductKeyVMs.Add(EntitlementVM.SelectedEntitlementProductKeyVM);
                }

                try
                {
                    await productKeyProvider.UpdateProduct(product, EntitlementVM.SelectedEntitlementProductKeyVM, EntitlementVM.LicenseModels, EntitlementVM.SelectedEntitlement.IsTest != true);
                    var prodVar = EntitlementVM.SelectedEntitlementProductKeyVM.ProductVariantList.FirstOrDefault(c => c.Id == EntitlementVM.SelectedEntitlementProductKeyVM.EntitlementProductKey.ProductVariantId);

                    if (null != prodVar)
                    {
                        productKeyProvider.UpdateProductVariant(prodVar, EntitlementVM.SelectedEntitlementProductKeyVM, EntitlementVM.LicenseModels);
                    }
                }
                catch (Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions.ZeissLicensingDraftProductvariantsException)
                {
                    EntitlementVM.EntitlementProductKeyVMs.Remove(EntitlementVM.SelectedEntitlementProductKeyVM);
                    EntitlementVM.SelectedEntitlementProductKeyVM = oldSelectedEntitlementProductKeyVM;
                    var text = string.Format(ExceptionResource.NOENABLEDPRODUCTVARIANTS, product.Name);
                    SnackbarException.ShowException(text);
                }
            }

            await OnSelectedEntitlementProductKeyChanged(EntitlementVM.SelectedEntitlementProductKeyVM);
            CurrentPage = (EntitlementVM.EntitlementProductKeyVMs.Count + _DatGridProductKeys!.PageSize - 1) / _DatGridProductKeys!.PageSize;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            EntitlementVM.AddingEntitlementProductKey = false;
        }
    }

    /// <summary>
    /// Search product Discard pressed
    /// </summary>
    private void OnSearchDiscardClick()
    {
        try
        {
            EntitlementVM.ShowSearchDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Select product pressed
    /// </summary>
    private void OnSelectProductClicked()
    {
        try
        {
            EntitlementVM.AddingEntitlementProductKey = false;
            EntitlementVM.IsMultiselect = false;
            EntitlementVM.ShowSearchDialog = true;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Customer selection changes
    /// </summary>
    /// <param name="isChecked">check state</param>
    private void OnNeverExpiresProductKeyCheckedChanged(bool isChecked)
    {
        try
        {
            EntitlementVM.SelectedEntitlementProductKeyVM.NeverExpiresProductKeyCheckedChanged(isChecked);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Start from activation date changes
    /// </summary>
    /// <param name="isChecked">check start from activation date</param>
    private void OnStartFromActivationDateChanged(bool isChecked)
    {
        try
        {
            EntitlementVM.SelectedEntitlementProductKeyVM.StartFromActivationDateChanged(isChecked);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement details save button clicked
    /// </summary>
    private async Task OnDetailsSaveButtonClicked()
    {
        try
        {
            await SaveDetails();
            EntitlementVM.EditOriginalEntitlement = EntitlementVM.SelectedEntitlement;

            await _ErrorZeissLicensingAlert!.Hide();
            IsListVisible = true;
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Entitlement details save button clicked
    /// </summary>
    private async Task OnDetailsSaveStayButtonClicked()
    {
        try
        {
            await SaveDetails();
            await PrepareDetails();

            await _ErrorZeissLicensingAlert!.Hide();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            StateHasChanged();
        }
    }

    /// <summary>
    /// Entitlement details save
    /// </summary>
    private async Task SaveDetails()
    {
        try
        {
            // Check NamedUser Configuration 
            CheckNamedUserConfiguration();

            IsSaving = true;
            StateHasChanged();

            if (!IsReadOnly)
            {
                // Customers data
                SaveCustomersData();

                EntitlementVM.SelectedEntitlement.ProductKeys.Clear();

                foreach (var entitlementProductKeyViewModel in EntitlementVM.EntitlementProductKeyVMs)
                {
                    entitlementProductKeyViewModel.Save(EntitlementVM.LicenseModels);
                    EntitlementVM.SelectedEntitlement.ProductKeys.Add(entitlementProductKeyViewModel.EntitlementProductKey);
                }

                if (EntitlementVM.IsAdded)
                {
                    EntitlementVM.SelectedEntitlement = await entitlementClient.Add(EntitlementVM.SelectedEntitlement);
                    CreateLastUsedItem(EntitlementVM.SelectedEntitlement.EntitlementId, EntitlementVM.SelectedEntitlement.EntitlementId, SharedResource.ROUTEENTITLEMENTS, SharedResource.ENTITLEMENT);
                }
                else
                {
                    EntitlementVM.SelectedEntitlement = await entitlementClient.Update(EntitlementVM.SelectedEntitlement);
                }
            }

            // Named Users
            if (EntitlementVM.IsUserManageNamedUsersGranted)
            {
                var idx = 0;

                foreach (var entitlementProductKey in EntitlementVM.SelectedEntitlement.ProductKeys)
                {
                    if (null != entitlementProductKey.NamedUsersProperties && EntitlementVM.HasNamedUserChanges)
                    {
                        var entitlementProductKeyViewModel = EntitlementVM.EntitlementProductKeyVMs[idx];
                        var entitlementProductKeyLicenseModel = entitlementProductKeyViewModel.GetCurrentLicenseModel(EntitlementVM.LicenseModels);

                        if (null != entitlementProductKeyLicenseModel && entitlementProductKeyLicenseModel.LicenseMode == LicenseMode.Thales_CloudLM)
                        {
                            SnackbarException.ShowException(EntitlementResource.NAMEDUSERSNOTSUPPORTEDFORCLOUDLM);
                            continue;
                        }

                        var namedUsers = entitlementProductKeyViewModel.NamedUsers.Where(c => !string.IsNullOrWhiteSpace(c.Name)).Select(x => x.Name).Distinct().ToList();

                        await entitlementClient.SaveNamedUsers(entitlementProductKey.ProductKeyId, namedUsers);
                    }

                    idx++;
                }
            }

            SearchEntitlementComponent!.SaveEntitlement(EntitlementVM.EditOriginalEntitlement, EntitlementVM.SelectedEntitlement, EntitlementVM.IsAdded);
            EntitlementVM.EditOriginalEntitlement = (Entitlement)EntitlementVM.SelectedEntitlement.Clone();
        }
        catch (Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions.ZeissLicensingRequiredSerialnumberException)
        {
            throw;
        }
        catch (Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions.ZeissLicensingNamedUserLimitExceededException)
        {
            throw;
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException ex)
        {
            ErrorZeissLicensingText = ResourceLibrary.Helper.ExceptionHelper.GetErrorTextOfResource(ex, Ex);
            await _ErrorZeissLicensingAlert!.Show();

            throw;
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
        finally
        {
            IsSaving = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Save customer data
    /// </summary>
    private void SaveCustomersData()
    {
        if (null != EntitlementVM.CustomerEditSelectionModel.Distributor)
        {
            EntitlementVM.SelectedEntitlement.DistributorName = EntitlementVM.CustomerEditSelectionModel.Distributor.Name;
            EntitlementVM.SelectedEntitlement.DistributorNumber = EntitlementVM.CustomerEditSelectionModel.Distributor.Number;
        }
        else
        {
            EntitlementVM.SelectedEntitlement.DistributorName = string.Empty;
            EntitlementVM.SelectedEntitlement.DistributorNumber = string.Empty;
        }

        EntitlementVM.SelectedEntitlement.EndCustomer = EntitlementVM.CustomerEditSelectionModel.Endcustomer;

        if (null != EntitlementVM.CustomerEditSelectionModel.Factory)
        {
            EntitlementVM.SelectedEntitlement.FactoryName = EntitlementVM.CustomerEditSelectionModel.Factory.Name;
            EntitlementVM.SelectedEntitlement.FactoryNumber = EntitlementVM.CustomerEditSelectionModel.Factory.Number;
        }
        else
        {
            EntitlementVM.SelectedEntitlement.FactoryName = string.Empty;
            EntitlementVM.SelectedEntitlement.FactoryNumber = string.Empty;
        }

        if (null != EntitlementVM.CustomerEditSelectionModel.SSC1)
        {
            EntitlementVM.SelectedEntitlement.SSC1Name = EntitlementVM.CustomerEditSelectionModel.SSC1.Name;
            EntitlementVM.SelectedEntitlement.SSC1Number = EntitlementVM.CustomerEditSelectionModel.SSC1.Number;
        }
        else
        {
            EntitlementVM.SelectedEntitlement.SSC1Name = string.Empty;
            EntitlementVM.SelectedEntitlement.SSC1Number = string.Empty;
        }

        if (null != EntitlementVM.CustomerEditSelectionModel.SSC2)
        {
            EntitlementVM.SelectedEntitlement.SSC2Name = EntitlementVM.CustomerEditSelectionModel.SSC2.Name;
            EntitlementVM.SelectedEntitlement.SSC2Number = EntitlementVM.CustomerEditSelectionModel.SSC2.Number;
        }
        else
        {
            EntitlementVM.SelectedEntitlement.SSC2Name = string.Empty;
            EntitlementVM.SelectedEntitlement.SSC2Number = string.Empty;
        }
    }

    /// <summary>
    /// Check named user configuration
    /// </summary>
    private void CheckNamedUserConfiguration()
    {
        foreach (var entitlementProductKeyVM in EntitlementVM.EntitlementProductKeyVMs.Where(c => null != c.EntitlementProductKey.NamedUsersProperties))
        {
            if (entitlementProductKeyVM.EntitlementProductKey.NamedUsersProperties.LimitNamedUsersAssignment &&
                entitlementProductKeyVM.NamedUsers.Count > entitlementProductKeyVM.EntitlementProductKey.NamedUsersProperties.NumberOfNamedUsers)
            {
                var text = string.Format(ExceptionResource.NAMEDUSERLIMITEXCEEDED, entitlementProductKeyVM.EntitlementProductKey.ProductKeyId);
                throw new Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions.ZeissLicensingNamedUserLimitExceededException(text, "");
            }

            if (entitlementProductKeyVM.ConcurrencyLimit < 1)
            {
                var text = string.Format(ExceptionResource.NAMEDUSERTOOLOWQUANTITY, entitlementProductKeyVM.EntitlementProductKey.ProductKeyId);
                throw new Zeiss.Licensing.Backend.UI.EntitlementsModule.Exceptions.ZeissLicensingNamedUserLimitExceededException(text, "");
            }
        }
    }

    /// <summary>
    /// Entitlement history button clicked
    /// </summary>
    private async Task OnHistoryButtonClicked()
    {
        try
        {
            await _HistoryDialog!.ShowHistory(EntitlementVM.SelectedEntitlement.Id, EntitlementVM.SelectedEntitlement.EntitlementId, HistoryType.Entitlement);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnSplitButtonClicked()
    {
        try
        {
            _SplitDialog!.ShowSplit(EntitlementVM.SelectedEntitlement, CurrentUser);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement split button clicked
    /// </summary>
    private void OnShowInfo()
    {
        try
        {
            _InfoDialog!.SetInfo(EntitlementVM.SelectedEntitlement);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Activate button clicked
    /// </summary>
    private async Task OnActivate()
    {
        try
        {
            EntitlementVM.IsCertificateLoading = true;

            if (CheckChangesSaving())
            {
                // Save ?
                EntitlementVM.SaveText = L["SAVEENTITLEMENTBEFOREACTIVATE"].Value.Replace("\\n", System.Environment.NewLine);
                EntitlementVM.ShowSaveDialog = true;
                EntitlementVM.IsActionActivate = true;
            }
            else
            {
                await _ActivatePopup!.ShowActivate(EntitlementVM.SelectedEntitlement, EntitlementVM.EntitlementProductKeyVMs);
            }
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
        finally
        {
            EntitlementVM.IsCertificateLoading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Activate closed
    /// </summary>
    private async Task OnCloseClicked()
    {
        try
        {
            EntitlementVM.SelectedEntitlement = (await entitlementClient.GetEntitlements(new SearchObjectEntitlement
                { EntitlementId = EntitlementVM.SelectedEntitlement.EntitlementId, SearchPattern = SearchPattern.Exact })).List[0];

            // Set EditOriginalEntitlement again, because quantity of product key has changed after activation - no other changes, and so there are no user changes
            EntitlementVM.EditOriginalEntitlement = EntitlementVM.SelectedEntitlement;

            await PrepareDetails();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Get License expiration date
    /// </summary>
    /// <param name="entitlementProductKeyViewModel">Product key</param>
    /// <returns></returns>
    private string GetLicenseDateExpiration(EntitlementProductKeyViewModel entitlementProductKeyViewModel)
    {
        string licExp = E["PERMANENT"];
        var licenseDate = entitlementProductKeyViewModel.LicenseDate;

        if (entitlementProductKeyViewModel.LicenseEndDateSelectedValue == 2 && null != licenseDate?.EndDate)
        {
            licExp = $"{licenseDate.EndDate?.ToString("MM/dd/yyyy")}";
        }

        if (entitlementProductKeyViewModel.LicenseEndDateSelectedValue == 1 && null != licenseDate?.DurationInDays)
        {
            if (null == licenseDate.StartDate)
            {
                licExp = $"{licenseDate.DurationInDays} {L["DAYS"]}";
            }
            else
            {
                var end = licenseDate.StartDate.Value.AddDays(licenseDate.DurationInDays.Value);
                licExp = $"{end:MM/dd/yyyy}";
            }
        }

        return licExp;
    }

    /// <summary>
    /// Styling of not enabled product key
    /// </summary>
    /// <param name="entitlementProductKeyVM">product key</param>
    /// <param name="styling">Styling</param>
    private void OnRowStyling(EntitlementProductKeyViewModel entitlementProductKeyVM, DataGridRowStyling styling)
    {
        if (entitlementProductKeyVM.EntitlementProductKey.State == EntitlementProductKeyState.Disable ||
            entitlementProductKeyVM.EntitlementProductKey.State == EntitlementProductKeyState.Closed)
        {
            styling.Style = "color: lightgrey;";
        }
    }

    /// <summary>
    /// Styling of not enabled product key, selected row
    /// </summary>
    /// <param name="entitlementProductKeyVM">product key</param>
    /// <param name="styling">Styling</param>
    private void OnSelectedRowStyling(EntitlementProductKeyViewModel entitlementProductKeyVM, DataGridRowStyling styling)
    {
        if (entitlementProductKeyVM.EntitlementProductKey.State == EntitlementProductKeyState.Disable ||
            entitlementProductKeyVM.EntitlementProductKey.State == EntitlementProductKeyState.Closed)
        {
            styling.Style = "color: grey;";
        }
    }

    private void OnSaveDiscard()
    {
        try
        {
            EntitlementVM.ShowSaveDialog = false;
            StateHasChanged();

            if (EntitlementVM.IsActionDiscard)
            {
                Discard();
            }
        }
        finally
        {
            EntitlementVM.IsActionActivate = false;
            EntitlementVM.IsActionCertificate = false;
            EntitlementVM.IsActionMail = false;
            EntitlementVM.IsActionDiscard = false;
        }
    }

    private void OnSaveClose()
    {
        EntitlementVM.ShowSaveDialog = false;
        StateHasChanged();
    }

    #endregion
}
