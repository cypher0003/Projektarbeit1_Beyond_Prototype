#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.ViewModels;

namespace EntitlementsModule.Pages;

public partial class SearchEntitlementList
{
    #region Properties

    [Parameter]
    public EventCallback SelectedEntitlementChanged { get; set; }

    [Parameter]
    public EventCallback SearchStarted { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsUserTestEntilementGranted { get; set; } = false;

    public SearchObjectEntitlement SearchObjectEntitlement { get; set; } = new SearchObjectEntitlement();

    public override bool IsLoadMoreDisable => Entitlements.Count == 0 || base.IsLoadMoreDisable;


    private List<Entitlement> Entitlements { get; set; } = new List<Entitlement>();

    private Entitlement SelectedEntitlement { get; set; } = new Entitlement();

    private string SelectedTestFilter { get; set; } = string.Empty;

    private List<string> TestList { get; set; } = new List<string>();

    #endregion

    #region Methods

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectEntitlement">Search object of entitlement</param>
    public async Task UpdateList(SearchObjectEntitlement searchObjectEntitlement)
    {
        try
        {
            LoadMoreEnded = !searchObjectEntitlement.RestartLoadMore;
            Entitlements.Clear();
            InvalidCount = 0;
            SearchTotalCount = 0;
            UnauthorizedCount = 0;

            await UpdateDataList(searchObjectEntitlement);

            if (Entitlements.Any())
            {
                OnSelectedEntitlementChanged(Entitlements.First());
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Remove entitlement from list
    /// </summary>
    /// <param name = "entitlement">Entitlement to be removed</param>
    public void RemoveEntitlement(Entitlement entitlement)
    {
        try
        {
            if (Entitlements.Contains(entitlement))
            {
                Entitlements.Remove(entitlement);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save entitlement to list
    /// </summary>
    /// <param name = "origEntitlement">Original entitlement(Update)</param>
    /// <param name = "entitlement">Entitlement to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveEntitlement(Entitlement origEntitlement, Entitlement entitlement, bool isAdd)
    {
        try
        {
            if (isAdd)
            {
                Entitlements.Insert(0, entitlement);
                SelectedEntitlement = entitlement;
            }
            else
            {
                var foundEntitlement = Entitlements.FirstOrDefault(c => c.EntitlementId == origEntitlement.EntitlementId);

                if (foundEntitlement != null)
                {
                    var idxOrig = Entitlements.IndexOf(foundEntitlement);

                    if (idxOrig >= 0)
                    {
                        Entitlements.Insert(idxOrig, entitlement);
                        Entitlements.Remove(foundEntitlement);
                    }
                }
                else
                {
                    Entitlements.Add(entitlement);
                }

                SelectedEntitlement = entitlement;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            Entitlements = new List<Entitlement>();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }


    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectEntitlement.SearchPattern = SearchPattern.Normal;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Action Button clicked
    /// </summary>
    private void OnActionClicked(object? entitlement, ActionType actionType)
    {
        try
        {
            if (null != entitlement && SelectedEntitlement != (Entitlement)entitlement)
            {
                OnSelectedEntitlementChanged((Entitlement)entitlement);
            }

            ActionClicked.InvokeAsync(actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// More Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectEntitlement.UseLoadMore = true;
            SearchObjectEntitlement.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectEntitlement);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectEntitlement">Search object of entitlement</param>
    private async Task UpdateDataList(SearchObjectEntitlement searchObjectEntitlement)
    {
        try
        {
            if (null == searchObjectEntitlement)
            {
                SelectedEntitlement = new Entitlement();
                Entitlements = new List<Entitlement>();
            }
            else
            {
                TestList.Clear();

                await SearchStarted.InvokeAsync(true);
                SearchObjectEntitlement = searchObjectEntitlement;
                searchObjectEntitlement.PageSize = Convert.ToInt32(configuration["PageSize"]);

                // Trim Strings of SearchObject
                TrimSearchObject(searchObjectEntitlement);
                PartialList<Entitlement> partialList = await entitlementClient.GetEntitlements(searchObjectEntitlement);
                Entitlements.AddRange(partialList.List);
                InvalidCount += partialList.InvalidCount;
                SearchTotalCount = partialList.TotalCount;
                UnauthorizedCount += partialList.UnauthorizedCount;
                LoadMoreEnded = partialList.IsLastPageIndex;

                if (Entitlements.Any(c => c.IsTest == true))
                {
                    TestList.Add(E["TEST"]);
                }

                StateHasChanged();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            await SearchStarted.InvokeAsync(false);
        }
    }

    /// <summary>
    /// Selected entitlement has changed
    /// </summary>
    /// <param name = "entitlement"></param>
    private void OnSelectedEntitlementChanged(Entitlement entitlement)
    {
        try
        {
            if (null != entitlement && entitlement != SelectedEntitlement)
            {
                SelectedEntitlement = entitlement;
                SelectedEntitlementChanged.InvokeAsync(entitlement);
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
