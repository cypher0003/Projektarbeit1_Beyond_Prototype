﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.ViewModels;

namespace EntitlementsModule.Pages;

public partial class SplitComponent
{
    #region Properties

    [Parameter]
    public EventCallback<bool> ValuesChanged { get; set; }

    public SplitComponentViewModel SplitComponentViewModel { get; set; } = new SplitComponentViewModel();

    #endregion

    #region Methods

    /// <summary>
    /// Show the split dialog
    /// </summary>
    /// <param name="entitlement">Entitlement</param>
    public void ShowSplit(Entitlement entitlement)
    {
        try
        {
            SplitComponentViewModel.Init(entitlement, EntitlementClient);
            SearchOrganization = string.Empty;

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Show the split dialog
    /// </summary>
    public async Task<string> Split()
    {
        return await SplitComponentViewModel.TrySplit();
    }

    /// <summary>
    /// Show Organization selection dialog
    /// </summary>
    protected override async Task OnDeleteOrgButtonClicked()
    {
        try
        {
            await base.OnDeleteOrgButtonClicked();
            SplitComponentViewModel.ClearOrganization();
            await ValuesChanged.InvokeAsync(SplitComponentViewModel.CanSplit);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search mode changed
    /// </summary>
    /// <param name="newValue">new mode</param>
    private void SelectedOrganizationTierValueChangedHandler(int newValue)
    {
        try
        {
            SplitComponentViewModel.SetOrganizationTierValue(newValue);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search OK button pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(Organization organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick(organization);
            SplitComponentViewModel.SetOrganization(organization);
            ValuesChanged.InvokeAsync(SplitComponentViewModel.CanSplit);
        }
        catch (Exception ex)

        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Discard button pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        try
        {
            ShowSearchOrganizationDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Value changed
    /// </summary>
    private void OnSplitValueChanged()
    {
        try
        {
            if (SplitComponentViewModel.IsSeparateEntitlementsDisabled && SplitComponentViewModel.SeparateEntitlements)
            {
                SplitComponentViewModel.SeparateEntitlements = false;
            }

            ValuesChanged.InvokeAsync(SplitComponentViewModel.CanSplit);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
