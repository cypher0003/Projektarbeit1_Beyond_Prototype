#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace EntitlementsModule.Pages;

public partial class SearchEntitlementComponent
{
    #region Properties

    [Parameter]
    public EventCallback SelectedEntitlementChanged { get; set; }

    [Parameter]
    public EventCallback ActionClicked { get; set; }

    [Parameter]
    public bool IsViewGranted { get; set; } = true;

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    [Parameter]
    public bool IsUserTestEntilementGranted { get; set; } = false;

    public Entitlement SelectedEntitlement { get; set; } = new Entitlement();

    private SearchObjectEntitlement SearchObjectEntitlement { get; set; } = new SearchObjectEntitlement();

    private SearchEntitlementList? SearchEntitlementList { get; set; }

    private SearchEntitlementMask? SearchEntitlementMask { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Remove entitlement from list
    /// </summary>
    /// <param name = "entitlement">Entitlement to be removed</param>
    public void RemoveEntitlement(Entitlement entitlement)
    {
        try
        {
            SearchEntitlementList!.RemoveEntitlement(entitlement);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Save entitlement to list
    /// </summary>
    /// <param name = "origEntitlement">Original entitlement(Update)</param>
    /// <param name = "entitlement">Entitlement to be saved</param>
    /// <param name = "isAdd">Flag, if Add or Update</param>
    public void SaveEntitlement(Entitlement origEntitlement, Entitlement entitlement, bool isAdd)
    {
        try
        {
            SearchEntitlementList!.SaveEntitlement(origEntitlement, entitlement, isAdd);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Clears the result list
    /// </summary>
    public void ClearList()
    {
        try
        {
            SearchEntitlementList!.ClearList();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Initialize
    /// </summary>
    /// <returns></returns>
    protected override void OnInitialized()
    {
        try
        {
            SearchObjectEntitlement = new SearchObjectEntitlement
            {
                SearchPattern = SearchPattern.Normal
            };
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// View Button clicked
    /// </summary>
    private void OnActionClicked(object actionType)
    {
        try
        {
            ActionClicked.InvokeAsync((ActionType)actionType);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search Button clicked
    /// </summary>
    /// <param name = "searchEntitlement">Search object to load entitlements</param>
    private async Task SearchClicked(object searchEntitlement)
    {
        try
        {
            // List component loads entitlements
            SearchObjectEntitlement = (SearchObjectEntitlement)searchEntitlement;
            await SearchEntitlementList!.UpdateList(SearchObjectEntitlement);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Selected entitlement has changed
    /// </summary>
    private void OnSelectedEntitlementChanged(object selEntitlement)
    {
        try
        {
            SelectedEntitlement = (Entitlement)selEntitlement;
            SelectedEntitlementChanged.InvokeAsync(SelectedEntitlement);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search finished
    /// </summary>
    private void OnSearchStarted(object showLoading)
    {
        try
        {
            SearchEntitlementMask!.SetLoading((bool)showLoading);
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
