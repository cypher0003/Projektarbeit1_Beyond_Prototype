﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.ViewModels;

namespace EntitlementsModule.Pages;

public partial class ActivatePopup
{
    #region Fields

    /// <summary>
    /// Modal Reference
    /// </summary>
    private Modal? _ModalActivate;

    private Alert? _ErrorZeissLicensingAlert;

    private ActivationComponent? _RefActivationComponent;

    #endregion

    #region Properties

    [Parameter]
    public EventCallback ClosedClicked { get; set; }

    [Parameter]
    public bool IsEditGranted { get; set; } = true;

    [Parameter]
    public bool IsAddGranted { get; set; } = true;

    [Parameter]
    public bool IsDeleteGranted { get; set; } = true;

    #endregion

    #region Methods

    /// <summary>
    /// Show the split dialog
    /// </summary>
    /// <param name="entitlement">Entitlement</param>
    /// <param name="entitlementProductKeyViewModels">List of product keys</param>
    public async Task ShowActivate(Entitlement entitlement, List<EntitlementProductKeyViewModel> entitlementProductKeyViewModels)
    {
        try
        {
            var deviceTypeIdOfProdKeys = string.Empty;

            foreach (var item in entitlementProductKeyViewModels)
            {
                if (item.EntitlementProductKey.State == EntitlementProductKeyState.Enable && item.EntitlementProductKey.AvailableQuantity > 0)
                {
                    if (!string.IsNullOrWhiteSpace(deviceTypeIdOfProdKeys) && deviceTypeIdOfProdKeys != item.CurrentProductVariant.DeviceTypeId)
                    {
                        throw new Exception(E["DIFFERENTDEVICETYPES"]);
                    }

                    deviceTypeIdOfProdKeys = item.CurrentProductVariant.DeviceTypeId;
                }
            }

            await _ModalActivate!.Show();

            await _RefActivationComponent!.ShowActivation(entitlement, deviceTypeIdOfProdKeys);

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        try
        {
            await base.OnInitializedAsync();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            _ModalActivate!.Hide();
            ClosedClicked.InvokeAsync("Closed");
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    #endregion
}
