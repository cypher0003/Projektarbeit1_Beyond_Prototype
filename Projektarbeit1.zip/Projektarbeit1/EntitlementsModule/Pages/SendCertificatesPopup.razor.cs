#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Backend.WebServiceClient.Models;

namespace EntitlementsModule.Pages;

public partial class SendCertificatesPopup
{
    #region Fields

    /// <summary>
    /// Modal Reference
    /// </summary>
    private Alert? errorZeissLicensingAlert;

    private Validations? validations;

    #endregion

    #region Properties

    [Parameter]
    public EventCallback OnDiscardClick { get; set; }

    [Parameter]
    public bool ShowDialog { get; set; }

    private Entitlement Entitlement { get; set; } = new Entitlement();

    private string ReceipientEmail { get; set; } = string.Empty;

    private string Subject { get; set; } = string.Empty;

    private string EmailBody { get; set; } = string.Empty;

    private int CertificateCount { get; set; } = 0;

    private bool DisableSendBtn { get; set; }

    private bool SendingMail { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Creates the tabs by the loaded certificates
    /// </summary>
    /// <param name = "entitlement">Entitlement</param>
    public async Task CreateEmail(Entitlement entitlement)
    {
        try
        {
            await errorZeissLicensingAlert!.Hide();
            DisableSendBtn = false;
            Entitlement = entitlement;
            ReceipientEmail = Entitlement.LicenseRecipientEmail;
            Subject = string.Empty;
            EmailBody = string.Empty;
            CertificateCount = 0;
            ShowDialog = true;
            StateHasChanged();
            var mailTemplate = await entitlementClient.GetEmailTemplate(Entitlement.EntitlementId);

            if (string.IsNullOrEmpty(mailTemplate.Subject))
            {
                Subject = $"{E["EMAILSUBJECT"]} {Entitlement.EntitlementId}";
            }
            else
            {
                Subject = mailTemplate.Subject;
            }

            EmailBody = mailTemplate.Body;
            CertificateCount = mailTemplate.AttachmentCount;
            StateHasChanged();
            await validations!.ValidateAll();
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Exception ex)
        {
            DisableSendBtn = true;
            StateHasChanged();
            ErrorZeissLicensingText = ex.Message;
            await errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Send Mail and close popup
    /// </summary>
    private async Task OnClickSendMail()
    {
        try
        {
            SendingMail = true;
            await entitlementClient.SendCertificateMail(Entitlement.EntitlementId, new SendMailRequest { Recipients = ReceipientEmail.Split(";", StringSplitOptions.RemoveEmptyEntries).Select(c => c.Trim()).ToList(), Subject = Subject });
            SendingMail = false;

            // Close after sending mail
            ShowDialog = false;
        }
        catch (ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException ex)
        {
            SendingMail = false;
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Exception ex)
        {
            SendingMail = false;
            ErrorZeissLicensingText = ex.Message;
            await errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            ShowDialog = false;
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Leaving Email textedit
    /// </summary>
    /// <param name = "focusEventArgs">Focus event args</param>
    private void OnFocusOutEmail(Microsoft.AspNetCore.Components.Web.FocusEventArgs focusEventArgs)
    {
        try
        {
            validations!.ValidateAll();
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            errorZeissLicensingAlert!.Show();
        }
    }

    /// <summary>
    /// Validate Email
    /// </summary>
    /// <param name = "e">Validate event args</param>
    private void ValidateEmail(ValidatorEventArgs e)
    {
        try
        {
            var emails = Convert.ToString(e.Value);

            if (string.IsNullOrWhiteSpace(emails))
            {
                e.Status = ValidationStatus.None;
            }
            else
            {
                foreach (var email in emails.Split(";").ToList())
                {
                    e.Status = EMailHelper.IsEmailValid(email.Trim()) ? ValidationStatus.Success : ValidationStatus.Error;

                    if (e.Status != ValidationStatus.Success)
                    {
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            errorZeissLicensingAlert!.Show();
        }
    }

    #endregion
}
