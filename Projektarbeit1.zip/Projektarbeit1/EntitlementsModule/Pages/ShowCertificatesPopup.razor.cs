#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

namespace EntitlementsModule.Pages;

public partial class ShowCertificatesPopup
{
    #region Fields

    /// <summary>
    /// Modal Reference
    /// </summary>
    private Alert? errorZeissLicensingAlert;

    #endregion

    #region Properties

    [Parameter]
    public EventCallback OnDiscardClick { get; set; }

    [Parameter]
    public bool ShowDialog { get; set; }

    private string EntitlementId { get; set; } = string.Empty;

    private Dictionary<string, string> ListCertificates { get; set; } = new Dictionary<string, string>();

    private string SelectedTab { get; set; } = "1";

    #endregion

    #region Methods

    /// <summary>
    /// Creates the tabs by the loaded certificates
    /// </summary>
    /// <param name = "entitlementId">Entitlement Id</param>
    public async Task CreateTabByEID(string entitlementId)
    {
        try
        {
            SelectedTab = "1";
            EntitlementId = entitlementId;
            ListCertificates = new Dictionary<string, string>();
            ShowDialog = true;
            StateHasChanged();
            List<string> list = await entitlementClient.GetCertificates(EntitlementId);
            var idx = 1;

            foreach (var item in list)
            {
                ListCertificates.Add(idx++.ToString(), item);
                //// New Browser-Tabs
                //await JSRuntime.InvokeAsync<object>("open", "navigate", "_blank");
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Hide Delete Modal OK
    /// </summary>
    private void OnClickDownload()
    {
        var idx = 1;

        foreach (var item in ListCertificates)
        {
            var filename = $"{EntitlementId}_{idx++}.html";
            FileHelper.SaveFile(JSRuntime, filename, item.Value);
        }
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        ShowDialog = false;
    }

    /// <summary>
    /// Tab changed
    /// </summary>
    /// <param name = "name">Tab name</param>
    private void OnSelectedTabChanged(string name)
    {
        try
        {
            SelectedTab = name;
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            errorZeissLicensingAlert!.Show();
        }
    }

    #endregion
}
