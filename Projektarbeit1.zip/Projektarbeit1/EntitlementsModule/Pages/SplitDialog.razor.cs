﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.ViewModels;

namespace EntitlementsModule.Pages;

public partial class SplitDialog
{
    #region Fields

    private Modal? _ModalSplit;
    private SplitComponent? _SplitComponent;

    #endregion

    #region Properties

    [Parameter]
    public EventCallback<string> Closed { get; set; }

    public SplitDialogViewModel SplitDialogViewModel { get; set; } = new();

    [Inject]
    private IMessageService MessageService { get; set; } = null!;

    #endregion

    #region Methods

    /// <summary>
    /// Show the split dialog
    /// </summary>
    /// <param name="entitlement">Entitlement</param>
    /// <param name="currentUser"></param>
    public void ShowSplit(Entitlement entitlement, User? currentUser)
    {
        try
        {
            SplitDialogViewModel = new SplitDialogViewModel();
            SplitDialogViewModel.Entitlement = entitlement;
            _SplitComponent!.ShowSplit(entitlement);
            CurrentUser = currentUser;

            _ModalSplit!.Show();
            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Organization Modal Discard
    /// </summary>
    private void OnClickDiscard()
    {
        try
        {
            _ModalSplit!.Hide();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Hide Delete Modal OK
    /// </summary>
    private async Task OnClickOK()
    {
        var newEid = string.Empty;

        try
        {
            IsSaving = true;

            newEid = await _SplitComponent!.Split();
            string message;

            if (string.IsNullOrWhiteSpace(newEid))
            {
                message = string.Format(EntitlementResource.SPLITSEPARATEENTITLEMENTS, CurrentUser?.Email);
            }
            else
            {
                message = string.Format(EntitlementResource.SPLITONEENTITLEMENT, newEid);
            }

            await MessageService.Info(message, EntitlementResource.SPLITENTITLEMENT, options => options.ShowMessageIcon = false);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
        finally
        {
            await _ModalSplit!.Hide();

            await Closed.InvokeAsync(newEid);
            IsSaving = false;
        }
    }

    /// <summary>
    /// Value changed
    /// </summary>
    /// <param name="valuesChanged">Flag, if Values changed</param>
    private void OnValuesChanged(bool valuesChanged)
    {
        try
        {
            SplitDialogViewModel.CanSplit = valuesChanged;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    #endregion
}
