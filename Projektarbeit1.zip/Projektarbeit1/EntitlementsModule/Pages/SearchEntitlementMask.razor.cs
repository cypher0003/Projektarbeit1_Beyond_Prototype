#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.ViewModels;
using Microsoft.AspNetCore.Components.Web;

namespace EntitlementsModule.Pages;

public partial class SearchEntitlementMask
{
    #region Properties

    [Parameter]
    public EventCallback SearchClicked { get; set; }

    internal EntitlementSearchMaskViewModel EntitlementSearchMaskViewModel { get; } = new();

    [Inject]
    private IMessageService? MessageService { get; set; }

    private SearchObjectEntitlement SearchObjectEntitlement { get; } = new();

    private int SelectedEntitlementStateValue { get; set; } = -1;

    private CustomerSelectionModel CustomerSearchSelectionModel { get; } = new();

    /// <summary>
    /// Selected Available Quantity value
    /// </summary>
    private int SelectedAvailableQuantityValue { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        await InitializedAsync();
    }

    /// <summary>
    /// Search button pressed
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            SearchObjectEntitlement.ProductMaterialNumber = SearchObjectEntitlement.ProductMaterialNumber?.Replace("-", "");

            if (!string.IsNullOrWhiteSpace(SearchObjectEntitlement.ProductMaterialNumber) &&
                (SearchObjectEntitlement.SearchPattern == SearchPattern.Normal || SearchObjectEntitlement.SearchPattern == SearchPattern.Exact))
            {
                SearchObjectEntitlement.ProductMaterialNumber = SearchObjectEntitlement.ProductMaterialNumber.PadLeft(ComponentDefaults.MATERIALNUMBER_LENGTH, '0');
            }

            SearchObjectEntitlement.FactoryNumber = CustomerSearchSelectionModel.FactoryNumber;
            SearchObjectEntitlement.DistributorNumber = CustomerSearchSelectionModel.DistributorNumber;
            SearchObjectEntitlement.SSC1Number = CustomerSearchSelectionModel.SSC1Number;
            SearchObjectEntitlement.SSC2Number = CustomerSearchSelectionModel.SSC2Number;
            SearchObjectEntitlement.EndcustomerNumber = CustomerSearchSelectionModel.EndcustomerNumber;
            SearchObjectEntitlement.UseLoadMore = true;
            SearchObjectEntitlement.RestartLoadMore = true;
            SearchObjectEntitlement.ProductFamily = EntitlementSearchMaskViewModel.ProductFamily;
            await SearchClicked.InvokeAsync(SearchObjectEntitlement);
            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    internal async Task InitializedAsync()
    {
        try
        {
            await base.OnInitializedAsync();
            await base.GetSavedSearchMode();
            await EntitlementSearchMaskViewModel.LoadProductFamilies(AppSettingClient!);
            SearchObjectEntitlement.SearchPattern = (SearchPattern)SelectedSearchModeValue;
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// State changed
    /// </summary>
    /// <param name = "newValue">new mode</param>
    private void SelectedEntitlementStateValueChangedHandler(int newValue)
    {
        try
        {
            SelectedEntitlementStateValue = newValue;
            var state = newValue;

            if (-1 == state)
            {
                SearchObjectEntitlement.State = null;
            }
            else
            {
                SearchObjectEntitlement.State = (EntitlementState)state;
            }
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Check changed
    /// </summary>
    private void OnSelectedAvailableQuantityChanged(int val)
    {
        try
        {
            SelectedAvailableQuantityValue = val;

            SearchObjectEntitlement.EntitlementsWithAvailableQuantity = val switch
            {
                0 => null,
                1 => true,
                2 => false,
                _ => throw new NotImplementedException(),
            };
        }
        catch (Exception ex)
        {
            SnackbarException!.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// On Enter start search
    /// </summary>
    /// <param name="keyboardEventArgs">Event args</param>
    private async Task IdKeypressed(KeyboardEventArgs keyboardEventArgs)
    {
        if (keyboardEventArgs.Key == "Enter" && !LoadingSearch)
        {
            await OnSearchClicked();
        }
    }

    #endregion
}
