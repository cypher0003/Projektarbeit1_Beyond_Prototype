﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Zeiss.Licensing.Backend.UI.Data;

public class InitialApplicationState
{
    #region Properties

    public string IDToken { get; set; } = string.Empty;

    public string RefreshToken { get; set; } = string.Empty;

    #endregion
}
