﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Interfaces;
using ComponentsLibrary.Provider;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Zeiss.Licensing.Backend.UI.DataTypes;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.Models;

namespace Zeiss.Licensing.Backend.UI.Data;

/// <summary>
/// Service to share user information between Navigation and Modules
/// </summary>
public class UIService
{
    #region Fields

    /// <summary>
    /// client for the user api
    /// </summary>
    private readonly IUserClient _UserClient;

    /// <summary>
    /// Logger
    /// </summary>
    private readonly ILogger<UIService> _Logger;

    /// <summary>
    /// Last used items provider
    /// </summary>
    private readonly ILastUsedItemProvider _LastUsedItemProvider;

    /// <summary>
    /// member for the Controllers property
    /// </summary>
    private readonly List<IModuleController> _Controllers;

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="controller">Controller</param>
    /// <param name="userClient"></param>
    /// <param name="logger">Logger</param>
    /// <param name="lastUsedItemProvider">Lasat used item provider</param>
    public UIService(List<IModuleController> controller, IUserClient userClient, ILogger<UIService> logger, ILastUsedItemProvider lastUsedItemProvider)
    {
        _UserClient = userClient;

        _Controllers = controller;

        _Logger = logger;

        _LastUsedItemProvider = lastUsedItemProvider;
    }

    #endregion

    #region Properties

    /// <summary>
    /// List of registered ModulControllers
    /// </summary>
    public List<IModuleController> Controllers => _Controllers;

    #endregion

    #region Methods

    /// <summary>
    /// Get a list of available modules for the current user
    /// </summary>
    /// <returns></returns>
    public async Task<List<DataTypes.Module>> GetModulesForUser()
    {
        _Logger?.LogInformation("UIService.GetModulesForUser()");

        try
        {
            var user = await _UserClient.Authenticate();

            var modules = new List<DataTypes.Module>();

            if (user != null)
            {
                foreach (var item in Controllers)
                {
                    var module = item.GetModule(user);

                    if (module != null)
                    {
                        modules.Add(module);
                    }
                }
            }
            else
            {
                _Logger?.LogInformation("UIService.GetModulesForUser() : user == null");
            }

            // Get last used items
            if (user != null)
            {
                _LastUsedItemProvider.SetUser(user);
            }

            _Logger?.LogInformation($"UIService.GetModulesForUser() : return Modules count: {modules.Count}");
            return modules;
        }
        catch (Zeiss.Licensing.Data.Exceptions.ZeissLicensingException authEx)
        {
            if (authEx.ErrorCode == "10-0004")
            {
                throw new ComponentsLibrary.Exceptions.ZeissLicensingExpiredTokenException();
            }

            throw;
        }
    }

    #endregion
}
