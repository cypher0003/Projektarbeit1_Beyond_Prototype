#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.Web.Virtualization;
using Microsoft.JSInterop;
using ResourceLibrary.Resources;
using Zeiss.Licensing.Backend.UI.Shared;
using Blazorise;
using Blazorise.Components;
using LicenseModule.Pages;
using Zeiss.Licensing.Backend.UI;

namespace Zeiss.Licensing.Backend.UI.Pages;

public partial class Index
{
    #region Fields

    private Theme theme = new Theme { ColorOptions = new ThemeColorOptions { Primary = "#45B1E8", Secondary = "#A65529", }, };

    #endregion

    #region Properties

    [Inject]
    public NavigationManager? NavigationManager { get; set; }

    [CascadingParameter]
    private Task<AuthenticationState>? authenticationStateTask { get; set; }

    #endregion
}
