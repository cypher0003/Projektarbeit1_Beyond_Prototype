﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Auth;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Globalization;
using Zeiss.Licensing.Backend.UI.Auth;

namespace Zeiss.Licensing.Backend.UI.Pages;

public class _HostAuthModel : PageModel
{
    #region Fields

    private readonly BlazorServerAuthStateCache _cache;
    private readonly ILogger<_HostAuthModel> _logger;
    private readonly Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider _blazorServerAuthState;

    #endregion

    #region Constructors

    public _HostAuthModel(BlazorServerAuthStateCache cache, ILogger<_HostAuthModel> logger, Microsoft.AspNetCore.Components.Authorization.AuthenticationStateProvider blazorServerAuthState)
    {
        _cache = cache;
        _logger = logger;
        _blazorServerAuthState = blazorServerAuthState;
    }

    #endregion

    #region Methods

    public async Task OnGet()
    {
        HttpContext.Response.Cookies.Append(
            CookieRequestCultureProvider.DefaultCookieName,
            CookieRequestCultureProvider.MakeCookieValue(
                new RequestCulture(
                    CultureInfo.CurrentCulture,
                    CultureInfo.CurrentUICulture)));

        _logger.LogDebug($"AUTH: _Host OnGet IsAuth? {User.Identity?.IsAuthenticated}");

        if (User.Identity?.IsAuthenticated ?? false)
        {
            var oid = User.Claims
                          .Where(c => c.Type.Equals(AuthDefaults.OBJECT_IDENTIFIER_CLAIM))
                          .Select(c => c.Value)
                          .FirstOrDefault();

            _logger.LogDebug($"AUTH: oid: {oid}");

            if (oid != null && !_cache.HasObjectId(oid))
            {
                var authResult = await HttpContext.AuthenticateAsync(OpenIdConnectDefaults.AuthenticationScheme);
                var expiration = authResult.Properties?.ExpiresUtc!.Value ?? new DateTimeOffset(DateTime.UtcNow, new TimeSpan(0, 30, 0));
                var idToken = await HttpContext.GetTokenAsync("id_token");
                var accessToken = await HttpContext.GetTokenAsync("access_token");
                var refreshToken = await HttpContext.GetTokenAsync("refresh_token");

                var expiresAtToken = await HttpContext.GetTokenAsync("expires_at");

                if (!DateTimeOffset.TryParse(expiresAtToken, out var refreshAt) || refreshAt < DateTimeOffset.UtcNow || string.IsNullOrWhiteSpace(refreshToken))
                {
                    refreshAt = DateTimeOffset.UtcNow;
                }
                else
                {
                    var seconds = refreshAt.Subtract(DateTimeOffset.UtcNow).TotalSeconds;
                    refreshAt = DateTimeOffset.UtcNow.AddSeconds(seconds - AuthDefaults.AUTOMATIC_LOGOUT_TIMEOUT * 60);
                    _logger.LogDebug($"AUTH: refresh_at: {refreshAt.ToString("o")}");
                }

                var addIdToken = idToken ??= string.Empty;
                var addAccessToken = accessToken ??= string.Empty;
                var addRefreshToken = refreshToken ??= string.Empty;

                _cache.Add(oid, expiration, addIdToken, addAccessToken, addRefreshToken, refreshAt);
            }
            else if (oid != null && _cache.HasObjectId(oid))
            {
                var data = _cache.Get(oid);
                data.AccessToken = await HttpContext.GetTokenAsync("access_token")   ?? string.Empty;
                data.IdToken = await HttpContext.GetTokenAsync("id_token")           ?? string.Empty;
                data.RefreshToken = await HttpContext.GetTokenAsync("refresh_token") ?? string.Empty;
                var expiresAtToken = await HttpContext.GetTokenAsync("expires_at") ?? string.Empty;

                if (!DateTimeOffset.TryParse(expiresAtToken, out var refreshAt) || refreshAt < DateTimeOffset.UtcNow || string.IsNullOrWhiteSpace(data.RefreshToken))
                {
                    data.RefreshAt = DateTimeOffset.UtcNow;
                }
                else
                {
                    var seconds = refreshAt.Subtract(DateTimeOffset.UtcNow).TotalSeconds;
                    data.RefreshAt = DateTimeOffset.UtcNow.AddSeconds(seconds - AuthDefaults.AUTOMATIC_LOGOUT_TIMEOUT * 60);
                    _logger.LogDebug($"AUTH: refresh_at: {data.RefreshAt.ToString("o")}");
                }

                var token = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler().ReadJwtToken(data.IdToken);
            }
        }
    }

    /// <summary>
    /// Called when route login is called
    /// </summary>
    /// <returns></returns>
    public IActionResult OnGetLogin()
    {
        _ = ((BlazorServerAuthState)_blazorServerAuthState).EmergencyLogout();

        return Challenge(AuthProps(), OpenIdConnectDefaults.AuthenticationScheme);
    }

    /// <summary>
    /// Called when route Logout is called
    /// </summary>
    /// <returns></returns>
    public async Task<IActionResult> OnGetLogout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignOutAsync(OpenIdConnectDefaults.AuthenticationScheme);

        return Redirect("~/");
    }

    /// <summary>
    /// Properties for Authorisation
    /// </summary>
    /// <returns></returns>
    private AuthenticationProperties AuthProps()
    {
        return new AuthenticationProperties
        {
            RedirectUri = Url.Content("~/portal/")
        };
    }

    #endregion
}
