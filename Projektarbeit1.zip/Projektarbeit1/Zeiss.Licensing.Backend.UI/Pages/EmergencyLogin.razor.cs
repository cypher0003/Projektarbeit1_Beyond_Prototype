#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using System.Net.Http;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.Web.Virtualization;
using Microsoft.JSInterop;
using ResourceLibrary.Resources;
using Zeiss.Licensing.Backend.UI;
using Zeiss.Licensing.Backend.UI.Shared;
using Blazorise;
using Blazorise.Components;
using System.Text;
using Zeiss.Licensing.Backend.UI.Auth;
using Zeiss.Licensing.Data.Models;
using ComponentsLibrary.Helper;
using System.Net.Mail;

namespace Zeiss.Licensing.Backend.UI.Pages;

public partial class EmergencyLogin
{
    #region Fields

    private Alert? _ErrorZeissLicensingAlert;

    #endregion

    #region Properties

    private string EmergencyEMail { get; set; } = string.Empty;

    private string EmergencyPassword { get; set; } = string.Empty;

    private bool IsEmergencyLoginDisabled => string.IsNullOrWhiteSpace(EmergencyPassword);

    #endregion

    #region Methods

    /// <summary>
    /// Call generating emergency authorization password via email
    /// </summary>
    private async void OnGetEmergencyLogin()
    {
        try
        {
            await _ErrorZeissLicensingAlert!.Hide();

            EmergencyEMail = EmergencyEMail.Trim().ToLower();
            var from = new MailAddress(EmergencyEMail);

            var serviceUser = Configuration.GetSection("EmergencyLogin")["BasicAuthentication"];

            // Login with empty user name -> no cache object
            await ((BlazorServerAuthState)AuthenticationStateProvider).ServiceLogin(from.Address, serviceUser);
            await userClient.GenerateEmergencyAuthorizationPassword(from.Address);
            await NotificationService.Info(SharedResource.EMERGENCYLOGINMAIL, SharedResource.GETEMERGENCYLOGIN);
        }
        catch (Exception ex)
        {
            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();
        }
    }


    /// <summary>
    /// Emergency login clicked
    /// </summary>
    private async void OnEmergencyLogin()
    {
        var blazorServerAuthState = (BlazorServerAuthState)AuthenticationStateProvider;

        try
        {
            await _ErrorZeissLicensingAlert!.Hide();

            EmergencyEMail = EmergencyEMail.Trim().ToLower();
            var from = new MailAddress(EmergencyEMail);

            EmergencyPassword = EmergencyPassword.Trim();
            var basicAuthVal = CreateBasicAuthenticationValue(from.Address, EmergencyPassword);

            // Login with mail and mail+password BasicAuth value
            await blazorServerAuthState.EmergencyLogin(from.Address, basicAuthVal);

            await userClient.Authenticate();
            var expirationDate = await userClient.GetEmergencyAuthorizationExpirationDate(from.Address);
            blazorServerAuthState.SetEmergencyExpirationDate(from.Address, expirationDate);
#if DEBUG
            Console.WriteLine("OnEmergencyLogin() after userClient.Authenticate();");
#endif
            NavigationManager.NavigateTo("/");
        }
        catch (Exception ex)
        {
            await blazorServerAuthState.EmergencyLogout();

            ErrorZeissLicensingText = ex.Message;
            await _ErrorZeissLicensingAlert!.Show();

            StateHasChanged();
        }
    }

    /// <summary>
    /// Create Basic Authentication value
    /// </summary>
    /// <param name="username">Username</param>
    /// <param name="password">Password</param>
    /// <returns></returns>
    private string CreateBasicAuthenticationValue(string username, string password)
    {
        var encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                                                     .GetBytes(username + ":" + password));

        return encoded;
    }

    #endregion
}
