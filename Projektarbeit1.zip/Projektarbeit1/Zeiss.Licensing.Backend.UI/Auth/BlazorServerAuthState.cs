﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Auth;
using ComponentsLibrary.Helper;
using ComponentsLibrary.Interfaces;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text.Json;
using System.Web;
using Zeiss.Licensing.Backend.Logic.Interfaces;
using Zeiss.Licensing.Data.HttpClientProvider;

namespace Zeiss.Licensing.Backend.UI.Auth;

public class BlazorServerAuthState : RevalidatingServerAuthenticationStateProvider
{
    #region Nested types

    private class RefreshTokenResponse
    {
        #region Properties

        public string id_token { get; set; } = string.Empty;

        public string access_token { get; set; } = string.Empty;

        public string refresh_token { get; set; } = string.Empty;

        public string expires_in { get; set; } = string.Empty;

        #endregion
    }

    #endregion

    #region Fields

    private readonly ILogger<BlazorServerAuthStateCache> _logger;
    private readonly BlazorServerAuthStateCache _cache;
    private readonly NavigationManager _navigationManager;
    private readonly IHttpClientProvider _httpClientProvider;
    private readonly IConfiguration _configuration;
    private readonly IProtectedSessionStorageRepositoryHelper _protectedSessionStorageRepositoryHelper;


    /// <summary>
    /// The Timespan in minutes that the token should be refreshed before expiring
    /// </summary>
    private readonly int MINTOKENEXPIRYTIME = AuthDefaults.AUTOMATIC_LOGOUT_TIMEOUT;

    #endregion

    #region Constructors

    public BlazorServerAuthState(
        ILoggerFactory loggerFactory,
        ILogger<BlazorServerAuthStateCache> logger,
        BlazorServerAuthStateCache cache,
        NavigationManager navigationManager,
        IHttpClientProvider httpClientProvider,
        IConfiguration configuration,
        IProtectedSessionStorageRepositoryHelper protectedSessionStorageRepositoryHelper,
        IKeyVaultProvider keyVaultProvider)
        : base(loggerFactory)
    {
        _logger = logger;
        _cache = cache;
        _navigationManager = navigationManager;
        _httpClientProvider = httpClientProvider;
        _configuration = configuration;
        _protectedSessionStorageRepositoryHelper = protectedSessionStorageRepositoryHelper;
        _keyVaultProvider = keyVaultProvider;
    }

    #endregion

    #region Properties

    public TimeSpan AutomaticLogoutTimeout => TimeSpan.FromMinutes(_configuration.GetValue("AutomaticLogoutTimeout", AuthDefaults.AUTOMATIC_LOGOUT_TIMEOUT));

    public bool IsEmergencyAuthorizationActive { get; set; }

    protected override TimeSpan RevalidationInterval => TimeSpan.FromMinutes(_configuration.GetValue("RevalidationInterval", AuthDefaults.REVALIDATION_INTERVAL));

    private IKeyVaultProvider _keyVaultProvider { get; }

    #endregion

    #region Methods

    public async Task<DateTime> GetExpirationTime()
    {
        if (IsEmergencyAuthorizationActive)
        {
            return new DateTime();
        }

        var authenticationState = await GetAuthenticationStateAsync();

        var oid =
            authenticationState.User.Claims
                               .Where(c => c.Type.Equals(AuthDefaults.OBJECT_IDENTIFIER_CLAIM))
                               .Select(c => c.Value)
                               .FirstOrDefault();

        if (oid != null)
        {
            var name =
                authenticationState.User.Claims
                                   .Where(c => c.Type.Equals("ZeissIdBase"))
                                   .Select(c => c.Value)
                                   .FirstOrDefault() ??
                string.Empty;

            var zeissIdBase = JsonSerializer.Deserialize<ZeissIdBaseSimple>(name, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            var email = zeissIdBase?.EMail;

            _logger.LogDebug($"AUTH: Validate: {0} / {1}", email, oid);

            if (_cache.HasObjectId(oid))
            {
                var data = _cache.Get(oid);
                var token = new JwtSecurityTokenHandler().ReadJwtToken(data.IdToken ?? string.Empty);

                return token.ValidTo.ToLocalTime();
            }

            return new DateTime();
        }

        return new DateTime();
    }


    public override async Task<AuthenticationState> GetAuthenticationStateAsync()
    {
        if (IsEmergencyAuthorizationActive)
        {
            if (await _protectedSessionStorageRepositoryHelper.IsEmergencyLoggedIn())
            {
                await _protectedSessionStorageRepositoryHelper.LoadEmailAddress();

                //!String.IsNullOrWhiteSpace(((ProtectedSessionStorageRepositoryHelper)_protectedSessionStorageRepositoryHelper).EmailAddress))
                ClaimsIdentity claimsIdentity;

                claimsIdentity = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, ((ProtectedSessionStorageRepositoryHelper)_protectedSessionStorageRepositoryHelper).EmailAddress),
                }, "ZeissAuth");

                var state = new AuthenticationState(new ClaimsPrincipal(claimsIdentity));
#if DEBUG
                Console.WriteLine("GetAuthenticationStateAsync(), IsEmergencyLoggedIn. State.IsAuthenticated=" + state.User.Identity!.IsAuthenticated);
#endif
                return state;
            }
            else
            {
#if DEBUG
                Console.WriteLine("GetAuthenticationStateAsync(), NOT IsEmergencyLoggedIn");
#endif
                var state = new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
                return state;
            }
        }

        {
#if DEBUG
            Console.WriteLine("base.GetAuthenticationStateAsync()");
            await base.GetAuthenticationStateAsync();
#endif
            return await base.GetAuthenticationStateAsync();
        }
    }

    /// <summary>
    /// Emergency login 
    /// </summary>
    /// <param name="emailaddress">login name</param>
    /// <param name="basicAuthValue">Value for basic authentication</param>
    public async Task EmergencyLogin(string emailaddress, string basicAuthValue)
    {
        await ((ProtectedSessionStorageRepositoryHelper)_protectedSessionStorageRepositoryHelper).LoginWithEmailAddress(emailaddress);

        if (!string.IsNullOrWhiteSpace(emailaddress))
        {
            _cache.Add(emailaddress, new DateTimeOffset(DateTime.UtcNow.AddHours(1)), basicAuthValue, string.Empty, string.Empty, new DateTimeOffset());
        }

        Notify();
    }

    /// <summary>
    /// Set Emergency expiration date
    /// </summary>
    /// <param name="emailaddress">login name</param>
    /// <param name="expirationDateTime">Expiration date of the emergency login</param>
    public void SetEmergencyExpirationDate(string emailaddress, DateTime? expirationDateTime)
    {
        if (!string.IsNullOrWhiteSpace(emailaddress) && null != expirationDateTime)
        {
            var data = _cache.Get(emailaddress);

            data.Expiration = new DateTimeOffset(expirationDateTime.Value);
        }
    }

    /// <summary>
    /// Emergency login 
    /// </summary>
    /// <param name="emailaddress">login name</param>
    /// <param name="basicAuthValue">Value for basic authentication</param>
    public void Notify()
    {
        NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
    }

    /// <summary>
    /// Emergency service login to get password email
    /// </summary>
    /// <param name="emailaddress">login name</param>
    /// <param name="basicAuthValue">Value for basic authentication</param>
    public async Task ServiceLogin(string emailaddress, string basicAuthValue)
    {
        await ((ProtectedSessionStorageRepositoryHelper)_protectedSessionStorageRepositoryHelper).ServiceLogin(emailaddress);

        if (!string.IsNullOrWhiteSpace(emailaddress))
        {
            _cache.Add(emailaddress, new DateTimeOffset(DateTime.UtcNow.AddHours(1)), basicAuthValue, string.Empty, string.Empty, new DateTimeOffset());
        }
    }

    /// <summary>
    /// Emergency logout
    /// </summary>
    public async Task EmergencyLogout()
    {
        await EmergencyHelper.EmergencyLogout(_protectedSessionStorageRepositoryHelper, _cache);
    }

    protected override async Task<bool> ValidateAuthenticationStateAsync(AuthenticationState authenticationState, CancellationToken cancellationToken)
    {
        if (IsEmergencyAuthorizationActive)
        {
            return true;
        }

        var oid =
            authenticationState.User.Claims
                               .Where(c => c.Type.Equals(AuthDefaults.OBJECT_IDENTIFIER_CLAIM))
                               .Select(c => c.Value)
                               .FirstOrDefault();

        var name =
            authenticationState.User.Claims
                               .Where(c => c.Type.Equals("ZeissIdBase"))
                               .Select(c => c.Value)
                               .FirstOrDefault() ??
            string.Empty;

        var zeissIdBase = JsonSerializer.Deserialize<ZeissIdBaseSimple>(name, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        var email = zeissIdBase?.EMail ?? string.Empty;

        _logger.LogDebug($"AUTH: Validate: {email} / {oid}");

        if (oid != null && _cache.HasObjectId(oid))
        {
            var data = _cache.Get(oid);
            var token = new JwtSecurityTokenHandler().ReadJwtToken(data.IdToken);
            var refreshtoken = new JwtSecurityTokenHandler().ReadJwtToken(data.RefreshToken);

            if (DateTimeOffset.UtcNow >= token.ValidTo.ToLocalTime())
            {
                _logger.LogDebug($"AUTH: Token expired! Force logout for user '{email}'");

                _navigationManager.NavigateTo("/logout", true);
                return false;
            }

            _logger.LogDebug($"AUTH: User: {email} Now UTC: {DateTimeOffset.UtcNow:o} Refresh: {data.RefreshAt:o} Last user action: {data.LastUserAction:o} IDToken.ValidTo: {token.ValidTo:o}, RefreshToken.ValidTo: {refreshtoken.ValidTo:o}");

            if (data.RefreshAt < DateTimeOffset.UtcNow)
            {
                // if last user action has been within last 30 min, we refresh otherwise we automatically log out the user

                if (data.LastUserAction > DateTime.UtcNow.Subtract(AutomaticLogoutTimeout))
                {
                    await PerformTokenRefresh(data);
                }
                else
                {
                    _logger.LogDebug($"AUTH: User '{email}' automatically logged out due to expired token and inactivity");
                    _navigationManager.NavigateTo("/logout", true);
                    return false;
                }
            }
        }
        else
        {
            _logger.LogDebug("AUTH: not in cache");
        }

        return true;
    }

    private async Task PerformTokenRefresh(BlazorServerAuthData data)
    {
        _logger.LogDebug("AUTH: Perform token refresh...");
        var provider = (HttpClientProvider)_httpClientProvider;
        var UriBuilder = new UriBuilder();
        var parameters = HttpUtility.ParseQueryString(string.Empty);
        parameters["p"] = "B2C_1A_ZeissIdNormalSignIn";
        parameters["grant_type"] = "refresh_token";
        parameters["client_id"] = _configuration.GetSection("ZeissID")["ClientId"];

        parameters["client_secret"] = await _keyVaultProvider.GetKeyVaultSecret("ZeissIDSecret");
        parameters["refresh_token"] = data.RefreshToken;
        UriBuilder.Query = parameters.ToString();

        var client = new HttpClient();
        client.BaseAddress = new Uri(_configuration.GetSection("ZeissID")["RefreshAddress"]);

        var response = await client.PostAsync(UriBuilder.Uri.Query, new StringContent("", System.Text.Encoding.UTF8, "application/x-www-form-urlencoded"));

        if (response.IsSuccessStatusCode)
        {
            var content = await response.Content.ReadAsStringAsync();

            var TokenResponse = JsonSerializer.Deserialize<RefreshTokenResponse>(content);

            if (null != TokenResponse)
            {
                provider.IDToken = TokenResponse.id_token;
                provider.RefreshToken = TokenResponse.refresh_token;
                data.AccessToken = TokenResponse.access_token;
                data.IdToken = TokenResponse.id_token;
                data.RefreshToken = TokenResponse.refresh_token;
                _logger.LogDebug($"AUTH: Token Expires_in {TokenResponse.expires_in}.");
                var ok = int.TryParse(TokenResponse.expires_in, out var expireIn);

                if (ok)
                {
                    data.RefreshAt = DateTimeOffset.UtcNow + TimeSpan.FromSeconds(expireIn - MINTOKENEXPIRYTIME * 60);
                }

                _logger.LogDebug("AUTH: Token succesfully refreshed.");
            }
        }
        else
        {
            var content = await response.Content.ReadAsStringAsync();
            _logger.LogDebug($"AUTH: Token refresh failed with {response.StatusCode}:");
            _logger.LogDebug($"{content}");
        }
    }

    #endregion
}
