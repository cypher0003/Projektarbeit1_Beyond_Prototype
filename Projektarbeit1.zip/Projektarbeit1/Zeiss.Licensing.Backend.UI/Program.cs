#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Globalization;
using Blazorise;
using Blazorise.Bootstrap5;
using Blazorise.Icons.FontAwesome;
using ComponentsLibrary.Auth;
using ComponentsLibrary.Helper;
using ComponentsLibrary.Interfaces;
using ComponentsLibrary.Provider;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Localization;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Zeiss.Licensing.Backend.Logic.Helpers;
using Zeiss.Licensing.Backend.Logic.Interfaces;
using Zeiss.Licensing.Backend.Logic.Providers;
using Zeiss.Licensing.Backend.UI;
using Zeiss.Licensing.Backend.UI.Auth;
using Zeiss.Licensing.Backend.UI.Data;
using Zeiss.Licensing.Backend.UI.DataTypes;
using Zeiss.Licensing.Backend.UI.EntitlementsModule;
using Zeiss.Licensing.Backend.UI.EntitlementsModule.Provider;
using Zeiss.Licensing.Backend.WebServiceClient.Clients;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Backend.WebServiceClient.Models;
using Zeiss.Licensing.Data.HttpClientProvider;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();


builder.Logging.AddApplicationInsights();
builder.WebHost.UseSetting(WebHostDefaults.DetailedErrorsKey, "true");


builder.Services.Configure<CookiePolicyOptions>(options =>
{
    options.MinimumSameSitePolicy = SameSiteMode.None;
    options.Secure = CookieSecurePolicy.SameAsRequest;
});

builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.SameSite = SameSiteMode.None;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
});

//Workaraound to use Ilogger instead of ILogger<T>
var serviceProvider = builder.Services.BuildServiceProvider();
var logger = serviceProvider.GetService<ILogger<ApplicationLogs>>();

builder.Services.AddSingleton(typeof(ILogger), logger);

builder.Services.AddSingleton<ILocationPrefixValidator, LocationPrefixValidator>();
builder.Services.AddSingleton<IConfigurationKeyVaultClientFactory, ConfigurationKeyVaultClientFactory>();

builder.Services.AddAuthentication(sharedOptions =>
       {
           sharedOptions.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme; //"Cookies"
           sharedOptions.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme; //"OpenIdConnect"
           sharedOptions.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
       })
       .AddCookie(o =>
       {
           o.Cookie.HttpOnly = true;
           o.Cookie.SameSite = SameSiteMode.None;
           o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
       })
       .AddOpenIdConnect(o =>
           {
               o.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
               o.ClientId = builder.Configuration.GetSection("ZeissID")["ClientId"];

               o.ClientSecret = KeyVaultHelper.GetKeyVaultSecret(builder.Configuration, "ZeissIDSecret", logger).GetAwaiter().GetResult();

               o.MetadataAddress = string.Format(builder.Configuration.GetSection("ZeissID")["MetadataAddress"], builder.Configuration.GetSection("ZeissID")["SignUpSignInPolicyId"]);
               o.Scope.Add("openid");
               o.Scope.Add("offline_access");
               o.Scope.Add(o.ClientId);
               o.SaveTokens = true;
               o.NonceCookie.SameSite = SameSiteMode.None;
               o.NonceCookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
               o.NonceCookie.HttpOnly = true;
               o.CorrelationCookie.SameSite = SameSiteMode.None;
               o.CorrelationCookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
               o.CorrelationCookie.HttpOnly = true;
               o.AuthenticationMethod = OpenIdConnectRedirectBehavior.RedirectGet;
               o.UsePkce = false;

               o.ResponseType = OpenIdConnectResponseType.Code; //"code"


               if (builder.Configuration.GetSection("Endpoint")["Environment"] != "LOCAL") // So that I can use the original redirect to localhost in development
               {
                   Task RedirectToIdentityProvider(RedirectContext ctx)
                   {
                       ctx.ProtocolMessage.RedirectUri = builder.Configuration.GetSection("ZeissID")["GatewayHost"];
                       return Task.FromResult(0);
                   }

                   o.Events = new OpenIdConnectEvents
                   {
                       OnRedirectToIdentityProvider = RedirectToIdentityProvider
                   };
               }
           }
       );

builder.Services.AddBlazorise(options =>
       {
           options.Immediate = true;
           options.LicenseKey = "CjxRBHF7NQA9UQVwfzQ1BlEAc3s1DD5VAHF+NQg8bjoNJ2ZdYhBVCCo/CTRVBkxERldhE1EvN0xcNm46FD1gSkUHCkxESVFvBl4yK1FBfAYKEytiTWACQkxEWmdIImQACVdxSDxvDA9dZ1MxfxYdWmc2LX8eAkx1RTdjTERaZ002ZA4NSnVcL3UVC1pnQSJoHhFXd1swbx50S3dTL3kMB1FrAWlvHg1NeV43Yx4RSHlUPG8TAVJrUzwKDwFadEUueRUdCDJTPHwIHVFuRSZnHhFIeVQ8bxMBUmtTPAoPAVp0RS55FR0IMlM8ZBMLQG5FJmceEUh5VDxvEwFSa1M8Cg8BWnRFLnkVHQgySClXKydDaW0aCRYaLls7DVoQAHVBVStnBDtfX0AQATIPaU44AkIDH2sJWSRJImU0QnYRWC58SmA8OnpqO2oNPQtndmVqbWYye3J4YlN0GmkjHXMTTxkDcgdTD2ArQ3MLVQ9jIlsjGH1odCRbDStuXUQMZCoAYn1CE3gPIF9aSA5TeX9ofnYvQiggc1J8JAQiCUJ1bhYBIjh2UUY1dnkLX1JpW2kvGkQLZjtpfA== ";
       })
       .AddBootstrap5Providers()
       .AddFontAwesomeIcons();

builder.Services.AddHttpClient();

builder.Services.AddScoped<IHttpClientProvider, HttpClientProvider>();
builder.Services.AddScoped<INavHelper, NavHelper>();
builder.Services.AddScoped<IProtectedSessionStorageRepositoryHelper, ProtectedSessionStorageRepositoryHelper>();

builder.Services.AddServerSideBlazor().AddCircuitOptions(options => { options.DetailedErrors = true; });
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");

builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    CultureInfo[] supportedCultures =
    {
        new CultureInfo("en"),

        //new CultureInfo("de")
    };

    options.DefaultRequestCulture = new RequestCulture("en");
    options.SupportedCultures = supportedCultures;
    options.SupportedUICultures = supportedCultures;
});

builder.Services.AddCors();

#region Zeiss Services

builder.Services.AddScoped<IKeyVaultProvider>(provider => new KeyVaultProvider(provider.GetService<IConfigurationKeyVaultClientFactory>(), provider.GetService<IConfiguration>(), provider.GetService<ILogger>()));

var baseUrl = builder.Configuration.GetSection("Endpoint")["baseUrl"];

builder.Services.AddScoped<IUserClient>(provider => new UserClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IProductClient>(provider => new ProductClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IProductVariantClient>(provider => new ProductVariantClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IDeviceClient>(provider => new DeviceClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IDeviceTypeClient>(provider => new DeviceTypeClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IDocumentClient>(provider => new DocumentClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IEntitlementClient>(provider => new EntitlementClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<ILicenseClient>(provider => new LicenseClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IOrderClient>(provider => new OrderClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IOrganizationClient>(provider => new OrganizationClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IAppSettingClient>(provider => new AppSettingClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IActivationClient>(provider => new ActivationClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IReportClient>(provider => new ReportClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IEmailClient>(provider => new EmailClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));
builder.Services.AddScoped<IHistoryClient>(provider => new HistoryClient(provider.GetService<IHttpClientProvider>(), provider.GetService<ILogger>()));


List<IModuleController> modules = new();
modules.Add(new ModuleController());
modules.Add(new LicenseModule.ModuleController());
modules.Add(new Zeiss.Licensing.Backend.UI.ProductsModule.ModuleController());
modules.Add(new Zeiss.Licensing.Backend.UI.UserModule.ModuleController());
modules.Add(new Zeiss.Licensing.Backend.UI.OrganizationsModule.ModuleController());
modules.Add(new Zeiss.Licensing.Backend.UI.AppSettingsModule.ModuleController());
modules.Add(new Zeiss.Licensing.Backend.UI.OrdersModule.ModuleController());
modules.Add(new Zeiss.Licensing.Backend.UI.DeviceModule.ModuleController());
builder.Services.AddScoped(provider => new UIService(modules, provider.GetService<IUserClient>(), provider.GetService<ILogger<UIService>>(), provider.GetService<ILastUsedItemProvider>()));
builder.Services.AddTransient<ProductKeyProvider>();
builder.Services.AddApplicationInsightsTelemetry();

builder.Services.AddScoped<ILastUsedItemProvider>(provider => new LastUsedItemsProvider(provider.GetService<IUserClient>()));

#endregion

#region Auth services

builder.Services.AddSingleton<BlazorServerAuthStateCache>();
builder.Services.AddScoped<AuthenticationStateProvider, BlazorServerAuthState>();

#endregion


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Error");

    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UsePathBase("/portal");

var localizationOptions = new RequestLocalizationOptions()
                          .SetDefaultCulture("en-EN")
                          .AddSupportedCultures("en-US")
                          .AddSupportedUICultures("en-US");

app.UseRequestLocalization(localizationOptions);

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseCookiePolicy();

// global cors policy
app.UseCors(x => x
                 .AllowAnyMethod()
                 .AllowAnyHeader()
                 .SetIsOriginAllowed(origin => true) // allow any origin
                 .AllowCredentials()); // allow credentials

app.UseCertificateForwarding();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

//https://www.onelogin.com/blog/how-to-use-openid-connect-authentication-with-dotnet-core
// This is needed if running behind a reverse proxy
// like ngrok which is great for testing while developing
app.UseForwardedHeaders(new ForwardedHeadersOptions
{
    ForwardedHeaders = ForwardedHeaders.XForwardedProto | ForwardedHeaders.XForwardedHost
});


app.UseEndpoints(
    endpoints =>
    {
        endpoints.MapDefaultControllerRoute();
        endpoints.MapControllers();
        endpoints.MapBlazorHub();
        endpoints.MapFallbackToPage("/_Host");
    });

app.Run();
