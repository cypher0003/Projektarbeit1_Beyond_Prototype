#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Zeiss.Licensing.Backend.UI.Auth;

namespace Zeiss.Licensing.Backend.UI.Shared;

public partial class MainLayout
{
    #region Properties

    private NavMenu? refNavMenu { get; set; }

    #endregion

    #region Methods

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        var authState = await ((BlazorServerAuthState)authenticationStateProvider).GetAuthenticationStateAsync();
        var isAuth = authState!.User!.Identity!.IsAuthenticated;
#if DEBUG
        Console.WriteLine("MainLayout::OnAfterRenderAsync(), IsAuth: " + isAuth);
#endif
        if (isAuth)
        {
            await refNavMenu!.LoadModules();
        }
    }

    #endregion
}
