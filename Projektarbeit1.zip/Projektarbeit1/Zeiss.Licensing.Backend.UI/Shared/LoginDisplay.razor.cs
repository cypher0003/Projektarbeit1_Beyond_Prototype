#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Microsoft.AspNetCore.Components;
using Zeiss.Licensing.Backend.UI.Auth;

namespace Zeiss.Licensing.Backend.UI.Shared;

public partial class LoginDisplay
{
    #region Fields

    /// <summary>
    /// name of the loged in user
    /// </summary>
    private string name = string.Empty;

    #endregion

    #region Properties

    [CascadingParameter(Name = "EmergencyAuthorizationActive")]
    public bool IsEmergencyAuthorizationActive { get; set; }

    /// <summary>
    /// Flag Superuser
    /// </summary>
    public bool IsSuperUser { get; set; } = false;

    /// <summary>
    /// Information of configuration
    /// </summary>
    private string Info { get; set; } = string.Empty;

    #endregion

    #region Methods

    /// <summary>
    /// Called when page is initialized
    /// </summary>
    protected override async Task OnInitializedAsync()
    {
        ((BlazorServerAuthState)AuthenticationStateProvider).IsEmergencyAuthorizationActive = IsEmergencyAuthorizationActive;
        Info = Configuration["Information"];
        await GetName();
#if DEBUG
        Console.WriteLine("LoginDisplay::OnInitializedAsync()");
#endif
    }

    /// <summary>
    /// Sets the name member
    /// </summary>
    /// <returns></returns>
    private async Task GetName()
    {
        var authState = await ((BlazorServerAuthState)AuthenticationStateProvider).GetAuthenticationStateAsync();
        var user = authState.User;

        if (null != user && user!.Identity!.IsAuthenticated)
        {
            var claimValue = user.FindFirst("ZeissIdBase")?.Value;

            if (null != claimValue)
            {
                var dict = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(claimValue);

                if (null != dict)
                {
                    name = dict["firstName"] + " " + dict["lastName"];
                    IsSuperUser = name.ToLower() == "bernd schrenk" || name.ToLower() == "martin schabel" || name.ToLower() == "steffen lowski" || name.ToLower() == "sandro f�rster";
                }
            }
        }
    }

    #endregion
}
