#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Components;
using ComponentsLibrary.Interfaces;
using Microsoft.AspNetCore.Components;
using Zeiss.Licensing.Backend.UI.Auth;
using Zeiss.Licensing.Backend.UI.DataTypes;

namespace Zeiss.Licensing.Backend.UI.Shared;

public partial class NavMenu
{
    #region Fields

    /// <summary>
    /// DEV, STAGE,TEST,PROD
    /// </summary>
    private string env = "";

    /// <summary>
    /// List of available modules
    /// </summary>
    private List<Module> Modules = new();

    /// <summary>
    /// The current expanded submenu
    /// </summary>
    private string visibleSubMenu = "";

    #endregion

    #region Properties

    [CascadingParameter(Name = "EmergencyAuthorizationActive")]
    public bool IsEmergencyAuthorizationActive { get; set; }

    [CascadingParameter]
    public Error? ErrorHandler { get; set; }

    public EventCallback LoadModulesNeeded { get; set; }

    [Inject]
    private ILastUsedItemProvider LastUsedItemProvider { get; set; } = null!;

    private bool IsAuth { get; set; }

    #endregion

    #region Methods

    public async Task LoadModules()
    {
        var authState = await ((BlazorServerAuthState)authenticationStateProvider).GetAuthenticationStateAsync();
        var user = authState.User;

        try
        {
            if (user!.Identity!.IsAuthenticated && !Modules.Any())
            {
#if DEBUG
                Console.WriteLine("NavMenu::LoadModules(), IsAuth: " + IsAuth);
#endif
                var myModules = await UserModuleService.GetModulesForUser();
                Modules = new List<Module>(myModules);
                StateHasChanged();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }


    protected override async Task OnInitializedAsync()
    {
        ((BlazorServerAuthState)authenticationStateProvider).IsEmergencyAuthorizationActive = IsEmergencyAuthorizationActive;
        var authState = await ((BlazorServerAuthState)authenticationStateProvider).GetAuthenticationStateAsync();
        IsAuth = authState!.User!.Identity!.IsAuthenticated;
#if DEBUG
        Console.WriteLine("NavMenu::OnInitializedAsync(), IsAuth: " + IsAuth);
#endif

        var provider = (ComponentsLibrary.Helper.HttpClientProvider)HttpClientProvider;
        provider.IsEmergencyAuthorizationActive = IsEmergencyAuthorizationActive;

        if (IsAuth)
        {
            await LoadModules();
        }

        getEnv();

        if (null != LastUsedItemProvider)
        {
            LastUsedItemProvider.LastUsedItemsViewModel.PropertyChanged += LastUsedItemsViewModel_PropertyChanged;
        }

        await base.OnInitializedAsync();
    }

    private void LastUsedItemsViewModel_PropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        StateHasChanged();
    }

    private void getEnv()
    {
        env = Configuration.GetSection("Endpoint")["Environment"];
    }

    private void OnNavLinkClicked(string path)
    {
        NavigationManager.NavigateTo(path, true);
    }

    #endregion
}
