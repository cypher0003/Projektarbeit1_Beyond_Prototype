﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using LicenseModule.ViewModels;
using Microsoft.AspNetCore.Components.Web;
using Zeiss.Licensing.Backend.WebServiceClient.Models;

namespace LicenseModule.Components;

public partial class FileUploadComponent : ComponentBase
{
    #region Fields

    private Alert _AlertFileUpload = null!;

    private Alert _AlertActivationPreview = null!;

    private Alert _AlertUpgradePreview = null!;

    private FilePicker _FilePicker = null!;

    private bool _IsLoading = false;

    private bool _ActivationPreviewDialogIsLoading = false;

    private bool _UpgradePreviewDialogIsLoading = false;

    private bool _ShowActivationPreviewDialog = false;

    private bool _ShowUpgradePreviewDialog = false;

    private bool _ShowDialog = false;

    private FileUploadComponentViewModel _ViewModel = null!;

    #endregion

    #region Properties

    /// <summary>
    /// On clear callback
    /// </summary>
    [Parameter]
    public EventCallback OnClear { get; set; }

    private bool NextButtonDisabled => string.IsNullOrEmpty(_ViewModel.FileContent);

    #endregion

    #region Methods

    /// <summary>
    /// Clear component (reset file picker, hide alert panel)
    /// </summary>
    /// <returns></returns>
    public async Task ClearComponent()
    {
        await _FilePicker.Clear();
        await _AlertFileUpload.Hide();
    }

    protected override void OnInitialized()
    {
        base.OnInitialized();

        _ViewModel = new FileUploadComponentViewModel(ActivationClient, JsRuntime, Configuration, LocationPrefixValidator);
    }

    private async Task OnFileEditChanged(FileChangedEventArgs e)
    {
        await _AlertFileUpload.Hide();

        if (!e.Files.Any())
        {
            _ViewModel.FileContent = string.Empty;
            _ViewModel.FileName = string.Empty;
        }

        foreach (var file in e.Files)
        {
            var fileExtension = Path.GetExtension(file.Name).ToLower();

            if (!FileUploadComponentViewModel.IsFileExtensionValid(fileExtension))
            {
                await _FilePicker.Clear();
                _ViewModel.DialogCaption = LIC["INVALIDFILEEXTENSIONCAPTION"];
                _ViewModel.DialogText = string.Format(LIC["INVALIDFILEEXTENSIONTEXT"], fileExtension);
                _ShowDialog = true;
                break;
            }

            // A stream is going to be the destination stream we're writing to.
            using var stream = new MemoryStream();

            // Here we're telling the FileEdit where to write the upload result
            await file.WriteToStreamAsync(stream);

            // Once we reach this line it means the file is fully uploaded.
            // In this case we're going to offset to the beginning of file
            // so we can read it.
            stream.Seek(0, SeekOrigin.Begin);

            // Use the stream reader to read the content of uploaded file,
            // in this case we can assume it is a textual file.
            using var reader = new StreamReader(stream);

            _ViewModel.FileContent = await reader.ReadToEndAsync();
            _ViewModel.FileName = file.Name;
        }
    }

    private async Task OnNextButtonClicked(MouseEventArgs e)
    {
        _IsLoading = true;
        await OnClear.InvokeAsync();

        try
        {
            await _ViewModel.AnalyzeUploadedFile();

            switch (_ViewModel.UploadFile.Type)
            {
                case RequestFileType.Activation:
                case RequestFileType.CertificateActivation:
                case RequestFileType.TrustedStorageActivation:
                case RequestFileType.SignedActivation:
                case RequestFileType.SignedBindingActivation:
                    _ShowActivationPreviewDialog = _ViewModel.ActivationPreviewItems.Any();
                    _ShowDialog = _ViewModel.ActivationPreviewInvalidItems.Any();
                    break;
                case RequestFileType.SignedUpgrade:
                    _ShowUpgradePreviewDialog = true;
                    break;
                case RequestFileType.RevocationProof:
                case RequestFileType.SignedOneStepReturn:
                case RequestFileType.TrustedStorageReturn:
                case RequestFileType.TrustedStorageRepair:
                    await _FilePicker.Clear();
                    _ShowDialog = true;
                    break;
            }
        }
        catch
        {
            await _AlertFileUpload.Show();
        }
        finally
        {
            _IsLoading = false;
        }
    }

    private Task OnActivationPreviewCancelButtonClicked(MouseEventArgs e)
    {
        _ShowActivationPreviewDialog = false;
        return Task.CompletedTask;
    }

    private async Task OnActivationPreviewNextButtonClicked(MouseEventArgs e)
    {
        await _AlertActivationPreview.Hide();
        _ActivationPreviewDialogIsLoading = true;

        try
        {
            await _ViewModel.Activate();

            _ShowActivationPreviewDialog = false;
            await _FilePicker.Clear();
            _ShowDialog = true;
        }
        catch
        {
            await _AlertActivationPreview.Show();
        }
        finally
        {
            _ActivationPreviewDialogIsLoading = false;
        }
    }

    private Task OnUpgradePreviewCancelButtonClicked(MouseEventArgs e)
    {
        _ShowUpgradePreviewDialog = false;
        return Task.CompletedTask;
    }

    private async Task OnUpgradePreviewNextButtonClicked(MouseEventArgs e)
    {
        await _AlertUpgradePreview.Hide();
        _UpgradePreviewDialogIsLoading = true;

        try
        {
            await _ViewModel.Upgrade();

            _ShowUpgradePreviewDialog = false;
            _ShowDialog = true;
        }
        catch
        {
            await _AlertUpgradePreview.Show();
        }
        finally
        {
            _UpgradePreviewDialogIsLoading = false;
        }
    }

    private Task OnActivationPreviewDialogClosing(ModalClosingEventArgs e)
    {
        _ShowActivationPreviewDialog = false;
        return Task.CompletedTask;
    }

    private Task OnUpgradePreviewDialogClosing(ModalClosingEventArgs e)
    {
        _ShowUpgradePreviewDialog = false;
        return Task.CompletedTask;
    }

    private Task OnCloseDialog()
    {
        _ShowDialog = false;
        return Task.CompletedTask;
    }

    #endregion
}
