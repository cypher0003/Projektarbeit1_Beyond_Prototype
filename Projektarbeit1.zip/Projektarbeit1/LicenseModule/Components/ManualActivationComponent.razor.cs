﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Blazorise.Components;
using Blazorise;
using LicenseModule.ViewModels;
using Microsoft.Extensions.Configuration;
using Microsoft.JSInterop;
using Zeiss.Licensing.Data.TransferObjects.V1;

namespace LicenseModule.Components;

public partial class ManualActivationComponent : ComponentBase
{
    #region Fields

    private Alert _Alert = null!;

    private Modal _ManualActivationDialog = null!;

    private ActivationComponent _ActivationComponent = null!;

    private bool _IsLoading = false;

    private bool _ShowSuccessDialog = false;

    private ManualActivationComponentViewModel _ViewModel = null!;

    #endregion

    #region Properties

    /// <summary>
    /// On clear callback
    /// </summary>
    [Parameter]
    public EventCallback OnClear { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Clear component (reset item id and device name and hide alert panel)
    /// </summary>
    /// <returns></returns>
    public async Task ClearComponent()
    {
        _ViewModel.ItemId = string.Empty;
        _ViewModel.DeviceName = string.Empty;
        await _Alert.Hide();
    }

    protected override void OnInitialized()
    {
        base.OnInitialized();

        _ViewModel = new ManualActivationComponentViewModel(ActivationClient, LocationPrefixValidator, Configuration);
    }

    /// <summary>
    /// Next button clicked
    /// </summary>
    private async Task OnNextButtonClicked()
    {
        try
        {
            _IsLoading = true;
            await _Alert.Hide();
            await OnClear.InvokeAsync();

            _ViewModel.Validate();

            var activatableItems = await _ViewModel.GetActivatableItemsResponse();

            await ShowManualActivationDialog(_ViewModel.ItemId, _ViewModel.DeviceName, activatableItems);
        }
        catch
        {
            await _Alert.Show();
        }
        finally
        {
            _IsLoading = false;
        }
    }

    private async Task ShowManualActivationDialog(string itemIds, string deviceName, GetActivatableItemsResponse getActivatableItemsResponse)
    {
        await _ActivationComponent.ShowActivatableItems(itemIds, deviceName, getActivatableItemsResponse);
        await _ManualActivationDialog.Show();
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private async Task OnManualActivationDialogDiscardClicked()
    {
        await _ManualActivationDialog.Hide();
    }

    /// <summary>
    /// Hide Delete Modal Discard
    /// </summary>
    private async Task OnManualActivationSuccessful()
    {
        await _ManualActivationDialog.Hide();
        _ViewModel.ItemId = string.Empty;
        _ViewModel.DeviceName = string.Empty;
        _ShowSuccessDialog = true;
    }

    private Task OnCloseSuccessDialog()
    {
        _ShowSuccessDialog = false;
        return Task.CompletedTask;
    }

    #endregion
}
