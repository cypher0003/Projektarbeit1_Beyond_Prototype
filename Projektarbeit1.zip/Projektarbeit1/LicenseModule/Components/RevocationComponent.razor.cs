﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using LicenseModule.ViewModels;
using Microsoft.Extensions.Logging;
using Zeiss.Licensing.Backend.WebServiceClient.Clients;

namespace LicenseModule.Components;

public partial class RevocationComponent : ComponentBase
{
    #region Fields

    private Alert _Alert = null!;

    private bool _IsLoading = false;

    private bool _ShowSuccessDialog = false;

    private RevocationComponentViewModel _ViewModel = null!;

    #endregion

    #region Properties

    /// <summary>
    /// On clear callback
    /// </summary>
    [Parameter]
    public EventCallback OnClear { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Clear component (reset activation id and hide alert panel)
    /// </summary>
    /// <returns></returns>
    public async Task ClearComponent()
    {
        _ViewModel.ActivationId = string.Empty;
        await _Alert.Hide();
    }

    /// <summary>
    /// Check if user has grants to override policy
    /// </summary>
    /// <returns>Flag: True can override</returns>
    public async Task CheckUserGrants()
    {
        var authenticationState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
        var authenticationStateUser = authenticationState.User;

        if (authenticationStateUser.Identity?.IsAuthenticated != true)
        {
            return;
        }

        // grants
        try
        {
            var user = await UserClient.Authenticate();
            _ViewModel.IsUserOverridePolicyAvailable = user.Roles.Any(c => c.AdditionalGrants[AdditionalGrant.OverridePolicy.ToString()]);
        }
        catch (Exception ex)
        {
            Logger.LogError("CheckUserGrants(): {0}", ex.Message);
        }
    }

    protected override void OnInitialized()
    {
        base.OnInitialized();

        _ViewModel = new RevocationComponentViewModel(ActivationClient, JsRuntime);
    }

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        await base.OnInitializedAsync();

        await CheckUserGrants();
    }

    private async Task OnGetRevocationTicketButtonClicked()
    {
        _IsLoading = true;
        await OnClear.InvokeAsync();

        try
        {
            await _Alert.Hide();

            await _ViewModel.CreatePermissionTicket();

            _ShowSuccessDialog = true;
        }
        catch
        {
            await _Alert.Show();
        }
        finally
        {
            _IsLoading = false;
        }
    }

    private Task OnCloseSuccessDialog()
    {
        _ShowSuccessDialog = false;
        return Task.CompletedTask;
    }

    #endregion
}
