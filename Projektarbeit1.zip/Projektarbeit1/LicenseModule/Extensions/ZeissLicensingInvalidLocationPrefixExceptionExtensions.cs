﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Zeiss.Licensing.Backend.WebServiceClient.Exceptions;

namespace LicenseModule.Extensions
{
    internal static class ZeissLicensingInvalidLocationPrefixExceptionExtensions
    {
        public static string GetErrorMessage(this ZeissLicensingInvalidLocationPrefixException ex, IConfiguration configuration)
        {
            return ex.Prefix switch
            {
                "" => $"{ex.Message} {configuration.GetValue<string>("EuUrl")}",
                "A-" => $"{ex.Message} {configuration.GetValue<string>("SinUrl")}",
                _  => ex.Message
            };
        }
    }
}
