﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.JSInterop;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;

namespace LicenseModule.ViewModels;

internal class RevocationComponentViewModel
{
    #region Fields

    private readonly IActivationClient _ActivationClient;

    private readonly IJSRuntime _JsRuntime;

    private string _AlertText = string.Empty;

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="activationClient">Activation client for backend access</param>
    /// <param name="jsRuntime">JavaScript runtime</param>
    public RevocationComponentViewModel(IActivationClient activationClient, IJSRuntime jsRuntime)
    {
        _ActivationClient = activationClient;
        _JsRuntime = jsRuntime;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Activation id
    /// </summary>
    public string ActivationId { get; set; } = string.Empty;

    /// <summary>
    /// Error text
    /// </summary>
    public string AlertText
    {
        get => _AlertText;
        private set => _AlertText = $"[{DateTime.Now:MM/dd/yyyy HH:mm:ss}] {value}";
    }

    /// <summary>
    /// Is the user allowed to overwrite the revocation policy
    /// </summary>
    public bool IsUserOverridePolicyAvailable { get; set; } = false;

    /// <summary>
    /// Overwrite the revocation policy when executing the revocation
    /// </summary>
    public bool OverridePolicy { get; set; } = false;

    /// <summary>
    /// Validation error text which appears below the activation id text field when the
    /// entered activation id is not valid
    /// </summary>
    public string ValidationErrorText { get; private set; } = string.Empty;

    /// <summary>
    /// Next button disabled true / false
    /// </summary>
    public bool NextButtonDisabled => string.IsNullOrEmpty(ActivationId) || !IsActivationIdValid;

    /// <summary>
    /// Is the activation id valid.
    /// The activation id is valid when it is empty or when is matches the regex
    /// </summary>
    private bool IsActivationIdValid => Regex.IsMatch(ActivationId, "^[a-zA-Z0-9-_.]*$");

    #endregion

    #region Methods

    /// <summary>
    /// Create a permission ticket for the activation id
    /// </summary>
    /// <returns></returns>
    public async Task CreatePermissionTicket()
    {
        try
        {
            var permissionTicketResponse = await _ActivationClient.GetPermissionTickets(ActivationId, OverridePolicy);

            var permissionTicketContent = JsonSerializer.Serialize(permissionTicketResponse, Zeiss.Licensing.Data.Constants.JsonConstants.JsonSerializerOptions);

            var fileName = $"PermissionTicket_{ActivationId}.json";

            await FileHelper.SaveFile(_JsRuntime, fileName, permissionTicketContent);

            ActivationId = string.Empty;
        }
        catch (Exception ex)
        {
            AlertText = ex.Message;
            throw;
        }
    }

    /// <summary>
    /// Validation event handler for activation id textfield validator
    /// </summary>
    /// <param name="e">Event args for validator</param>
    public void ValidateActivationId(ValidatorEventArgs e)
    {
        e.Status = ValidationStatus.None;
        ValidationErrorText = "";

        if (IsActivationIdValid)
        {
            return;
        }

        e.Status = ValidationStatus.Error;
        ValidationErrorText = LicenseResource.VALIDACTIVATIONIDCHARACTERS;
    }

    #endregion
}
