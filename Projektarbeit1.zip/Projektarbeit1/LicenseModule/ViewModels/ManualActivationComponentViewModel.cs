﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using LicenseModule.Extensions;
using Microsoft.Extensions.Configuration;
using Zeiss.Licensing.Backend.WebServiceClient.Exceptions;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.TransferObjects.V1;

namespace LicenseModule.ViewModels;

internal class ManualActivationComponentViewModel
{
    #region Fields

    private readonly IActivationClient _ActivationClient;
    private readonly ILocationPrefixValidator _LocationPrefixValidator;
    private readonly IConfiguration _Configuration;

    private string _AlertText = string.Empty;

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="activationClient">Activation client for backend access</param>
    /// <param name="locationPrefixValidator"></param>
    /// <param name="configuration"></param>
    public ManualActivationComponentViewModel(IActivationClient activationClient, ILocationPrefixValidator locationPrefixValidator, IConfiguration configuration)
    {
        _ActivationClient = activationClient;
        _LocationPrefixValidator = locationPrefixValidator;
        _Configuration = configuration;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Item id (product key or entitlement id) for activation
    /// The property can contain multiple ids separated by comma(s)
    /// </summary>
    public string ItemId { get; set; } = string.Empty;

    /// <summary>
    /// Device name for activation
    /// </summary>
    public string DeviceName { get; set; } = string.Empty;

    /// <summary>
    /// Error text
    /// </summary>
    public string AlertText
    {
        get => _AlertText;
        private set => _AlertText = $"[{DateTime.Now:MM/dd/yyyy HH:mm:ss}] {value}";
    }

    private IEnumerable<string> ItemIds => ItemId.Split(',', StringSplitOptions.RemoveEmptyEntries);

    #endregion

    #region Methods

    public void Validate()
    {
        try
        {
            _LocationPrefixValidator.Validate(ItemIds);
        }
        catch (ZeissLicensingInvalidLocationPrefixException ex)
        {
            AlertText = ex.GetErrorMessage(_Configuration);
            throw;
        }
        catch (Exception ex)
        {
            AlertText = ex.Message;
            throw;
        }
    }

    /// <summary>
    /// Get activatable items for the item ids
    /// </summary>
    /// <returns></returns>
    public async Task<GetActivatableItemsResponse> GetActivatableItemsResponse()
    {
        try
        {
            var activatableItems = await _ActivationClient.GetActivatableItems(ItemIds.ToList());

            if (null == activatableItems?.ActivatableItems || !activatableItems.ActivatableItems.Any())
            {
                throw new InvalidDataException("No activatable items found");
            }

            return activatableItems;
        }
        catch (Exception ex)
        {
            AlertText = ex.Message;
            throw;
        }
    }

    #endregion
}
