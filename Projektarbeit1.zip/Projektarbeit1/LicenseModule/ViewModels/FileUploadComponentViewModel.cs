﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using LicenseModule.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.JSInterop;
using Zeiss.Licensing.Backend.WebServiceClient.Exceptions;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Backend.WebServiceClient.Models;
using Zeiss.Licensing.Data.TransferObjects.V1;
using Environment = System.Environment;

namespace LicenseModule.ViewModels;

internal class FileUploadComponentViewModel
{
    #region Nested types

    private sealed class EqualityComparerActivatableItem : IEqualityComparer<ActivatableItem>
    {
        #region Methods

        public bool Equals(ActivatableItem? x, ActivatableItem? y)
        {
            if (null == x || null == y)
            {
                return false;
            }

            return x.ProductKey == y.ProductKey;
        }

        public int GetHashCode(ActivatableItem obj)
        {
            return obj.ProductKey.GetHashCode();
        }

        #endregion
    }

    #endregion

    #region Fields

    public const string FILE_EXTENSION_JSON = ".json";

    public const string FILE_EXTENSION_XML = ".xml";

    /// <summary>
    /// Filter for file picker control
    /// </summary>
    public const string FILE_EXTENSION_FILTER = $"{FILE_EXTENSION_JSON}, {FILE_EXTENSION_XML}";

    private readonly IActivationClient _ActivationClient;

    private readonly IJSRuntime _JsRuntime;

    private readonly IConfiguration _Configuration;
    private readonly ILocationPrefixValidator _LocationPrefixValidator;

    private IRequestFile? _UploadFile;

    private ValidationResponse? _ValidationResponse;

    private string _AlertText = string.Empty;

    #endregion

    #region Constructors

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="activationClient">Activation client for backend access</param>
    /// <param name="jsRuntime">JavaScript runtime</param>
    /// <param name="configuration">Configuration</param>
    /// <param name="locationPrefixValidator"></param>
    public FileUploadComponentViewModel(IActivationClient activationClient, IJSRuntime jsRuntime, IConfiguration configuration, ILocationPrefixValidator locationPrefixValidator)
    {
        _ActivationClient = activationClient;
        _JsRuntime = jsRuntime;
        _Configuration = configuration;
        _LocationPrefixValidator = locationPrefixValidator;
    }

    #endregion

    #region Properties

    /// <summary>
    /// Error text
    /// </summary>
    public string AlertText
    {
        get => _AlertText;
        private set => _AlertText = $"[{DateTime.Now:MM/dd/yyyy HH:mm:ss}] {value}";
    }

    /// <summary>
    /// File content of uploaded file
    /// </summary>
    public string FileContent { get; set; } = string.Empty;

    /// <summary>
    /// File name of uploaded file
    /// </summary>
    public string FileName { get; set; } = string.Empty;

    /// <summary>
    /// Success text after the upload file was processed successful
    /// </summary>
    public string DialogText { get; set; } = string.Empty;

    /// <summary>
    /// Success caption after the upload file was processed successful
    /// </summary>
    public string DialogCaption { get; set; } = string.Empty;

    /// <summary>
    /// Serial number for activation process
    /// </summary>
    public string SerialNumber { get; set; } = string.Empty;

    /// <summary>
    /// Item ids for the activation preview dialog
    /// </summary>
    public List<string> ActivationPreviewItemIds { get; private set; } = new();

    /// <summary>
    /// All products which will be activated for activation preview dialog
    /// </summary>
    public List<ActivatableItem> ActivationPreviewItems { get; private set; } = new();

    public List<InvalidItem> ActivationPreviewInvalidItems { get; private set; } = new();

    /// <summary>
    /// Upgrade product key id for upgrade preview dialog
    /// </summary>
    public string UpgradePreviewItemId { get; private set; } = string.Empty;

    /// <summary>
    /// Activations which will be revoked during upgrade process
    /// </summary>
    public List<Activation> UpgradePreviewRevokeActivations { get; private set; } = new();

    /// <summary>
    /// Product variants which will be activated during the upgrade process
    /// </summary>
    public List<ProductVariant> UpgradePreviewProductVariants { get; private set; } = new();

    /// <summary>
    /// Upload file object
    /// </summary>
    public IRequestFile UploadFile => _UploadFile ?? throw new NullReferenceException($"{nameof(UploadFile)} property is not set.");

    #endregion

    #region Methods

    /// <summary>
    /// Analyze the uploaded file.
    /// Check content and call validation method if the content is valid
    /// </summary>
    /// <returns></returns>
    public async Task AnalyzeUploadedFile()
    {
        try
        {
            await CheckEdgeBrowser();

            _UploadFile = new RequestFileFactory(_ActivationClient, _LocationPrefixValidator).CreateUploadFile(FileContent);
            _ValidationResponse = await _UploadFile.Validate();

            switch (_UploadFile.Type)
            {
                case RequestFileType.Activation:
                case RequestFileType.CertificateActivation:
                case RequestFileType.TrustedStorageActivation:
                case RequestFileType.SignedActivation:
                case RequestFileType.SignedBindingActivation:
                    var invalidItemIds = _ValidationResponse.ActivationValidationResponse.InvalidItems.Select(c => c.ItemId);

                    ActivationPreviewItemIds = _ValidationResponse.ActivationValidationResponse.ActivationItemIds.Where(c => !invalidItemIds.Contains(c)).ToList();
                    ActivationPreviewItems = _ValidationResponse.ActivationValidationResponse.ActivatableItems.Distinct(new EqualityComparerActivatableItem()).ToList();
                    ActivationPreviewInvalidItems = _ValidationResponse.ActivationValidationResponse.InvalidItems.ToList();

                    if (ActivationPreviewInvalidItems.Any())
                    {
                        DialogCaption = LicenseResource.ACTIVATIONREQUESTCONTAINSINVALIDITEMSCAPTION;
                        DialogText = string.Join(Environment.NewLine, ActivationPreviewInvalidItems.Select(c => $"- {c.Reason}").ToArray());
                    }

                    break;
                case RequestFileType.SignedUpgrade:
                    UpgradePreviewItemId = _ValidationResponse.UpgradeValidationResponse.UpgradeItemId;
                    UpgradePreviewRevokeActivations = await _ValidationResponse.UpgradeValidationResponse.GetActivations(_ActivationClient);
                    UpgradePreviewProductVariants = _ValidationResponse.UpgradeValidationResponse.ProductVariants;
                    break;
                case RequestFileType.TrustedStorageReturn:
                case RequestFileType.TrustedStorageRepair:
                    var downloadFiles = await UploadFile.Process();

                    await DownloadFiles(downloadFiles);

                    DialogCaption = LicenseResource.PROCESSSUCCESSFULCAPTION;
                    DialogText = LicenseResource.PROCESSSUCCESSFULTEXT;
                    break;
                case RequestFileType.SignedOneStepReturn:
                    await UploadFile.Process();

                    DialogCaption = LicenseResource.ONESTEPRETURNSUCCESSFULCAPTION;
                    DialogText = LicenseResource.ONESTEPRETURNSUCCESSFULTEXT;
                    break;
                case RequestFileType.RevocationProof:
                    await UploadFile.Process();

                    DialogCaption = LicenseResource.REVOCATIONPROOFSUCCESSFULCAPTION;
                    DialogText = LicenseResource.REVOCATIONPROOFSUCCESSFULTEXT;
                    break;
            }
        }
        catch (ZeissLicensingInvalidLocationPrefixException ex)
        {
            AlertText = ex.GetErrorMessage(_Configuration);
            throw;
        }
        catch (Exception ex)
        {
            AlertText = ex.Message;
            throw;
        }
    }

    /// <summary>
    /// Execute the upload file process and set the success messages for activation
    /// </summary>
    /// <returns></returns>
    public async Task Activate()
    {
        try
        {
            var downloadFiles = await UploadFile.Process();

            await DownloadFiles(downloadFiles);

            DialogCaption = LicenseResource.ACTIVATIONSUCCESSFULCAPTION;
            DialogText = LicenseResource.ACTIVATIONSUCCESSFULTEXT;
        }
        catch (Exception ex)
        {
            AlertText = ex.Message;
            throw;
        }
    }

    /// <summary> 
    /// Execute the upload file process and set the success messages for upgrade
    /// </summary>
    /// <returns></returns>
    public async Task Upgrade()
    {
        try
        {
            var downloadFiles = await UploadFile.Process();

            await DownloadFiles(downloadFiles);

            DialogCaption = LicenseResource.UPGRADESUCCESSFULCAPTION;
            DialogText = LicenseResource.UPGRADESUCCESSFULTEXT;
        }
        catch (Exception ex)
        {
            AlertText = ex.Message;
            throw;
        }
    }

    /// <summary>
    /// Check if Edge browser is denied
    /// </summary>
    /// <returns></returns>
    public async Task CheckEdgeBrowser()
    {
        var isEdge = await _JsRuntime.InvokeAsync<bool>("isEdgeBrowser");
        var isXmlFile = Path.GetExtension(FileName).ToLower() == ".xml";
        var denyEdgeBrowser = Convert.ToBoolean(_Configuration["DenyXMLEdgeBrowser"]);

        if (isXmlFile && isEdge && denyEdgeBrowser)
        {
            throw new InvalidDataException(LicenseResource.ACTIVATIONXMLEDGE);
        }
    }

    public static bool IsFileExtensionValid(string extension)
    {
        return extension is FILE_EXTENSION_JSON or FILE_EXTENSION_XML;
    }

    private async Task DownloadFiles(IEnumerable<DownloadFile> downloadFiles)
    {
        foreach (var downloadFile in downloadFiles)
        {
            if (downloadFile.IsBinary)
            {
                var byteArr = Convert.FromBase64String(downloadFile.FileContent);
                await FileHelper.SaveBinaryFile(_JsRuntime, downloadFile.FileName, byteArr);
            }
            else
            {
                await FileHelper.SaveFile(_JsRuntime, downloadFile.FileName, downloadFile.FileContent);
            }
        }
    }

    #endregion
}
