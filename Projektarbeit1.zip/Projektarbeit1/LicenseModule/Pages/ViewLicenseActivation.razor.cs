﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using LicenseModule.Components;
using LicenseModule.ViewModels;
using Microsoft.Extensions.Logging;

namespace LicenseModule.Pages;

public partial class ViewLicenseActivation
{
    #region Fields

    private FileUploadComponent _FileUploadComponent = null!;
    private ManualActivationComponent _ManualActivationComponent = null!;
    private RevocationComponent _RevocationComponent = null!;

    #endregion

    #region Methods

    private async Task OnClearFileUploadComponent()
    {
        await _ManualActivationComponent.ClearComponent();
        await _RevocationComponent.ClearComponent();
    }

    private async Task OnClearActivationComponent()
    {
        await _FileUploadComponent.ClearComponent();
        await _RevocationComponent.ClearComponent();
    }

    private async Task OnClearRevocationComponent()
    {
        await _FileUploadComponent.ClearComponent();
        await _ManualActivationComponent.ClearComponent();
    }

    #endregion
}
