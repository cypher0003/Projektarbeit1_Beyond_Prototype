#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using System.Resources;
using ComponentsLibrary.Exceptions;
using Microsoft.Extensions.Localization;
using EntitlementResource = ResourceLibrary.EntitlementResource;
using LicenseResource = ResourceLibrary.LicenseResource;
using SharedResource = ResourceLibrary.SharedResource;

namespace LicenseModule.Pages;

public partial class ViewLicense
{
    #region Fields

    private HistoryDialog? _HistoryDialog;

    #endregion

    #region Properties

    [Parameter]
    public string? ProductKey { get; set; } = string.Empty;


    public override bool IsLoadMoreDisable => Licenses.Count == 0 || base.IsLoadMoreDisable;

    public Dictionary<string, string> LicenseExtensions { get; set; } = new();

    [Inject]
    public IStringLocalizer<SharedResource> L { get; set; } = null!;

    [Inject]
    public IStringLocalizer<LicenseResource> Lic { get; set; } = null!;

    [Inject]
    public IStringLocalizer<EntitlementResource> E { get; set; } = null!;

    internal List<Activation> Licenses { get; } = new();


    private Activation SelectedLicense { get; set; } = new();

    private SearchObjectLicense SearchObjectLicense { get; set; } = new();

    private string DownloadText { get; set; } = string.Empty;

    private string CustomerText { get; set; } = string.Empty;

    private string CustomerNumber { get; set; } = string.Empty;

    private string RevokeText { get; set; } = string.Empty;

    private string RevokeCaption { get; set; } = string.Empty;

    private bool ShowRevokeDialog { get; set; }

    private bool IsRevoking { get; set; }

    private bool IsRejecting { get; set; }

    #endregion

    #region Methods

    /// <summary>
    /// Init
    /// </summary>
    /// <returns></returns>
    protected override async Task OnInitializedAsync()
    {
        await InitializedAsync();
    }

    /// <summary>
    /// Search button pressed
    /// </summary>
    protected override async Task OnSearchClicked()
    {
        try
        {
            SearchObjectLicense.ProductMaterialNumber = SearchObjectLicense.ProductMaterialNumber?.Replace("-", "");

            if (!string.IsNullOrWhiteSpace(SearchObjectLicense.ProductMaterialNumber) &&
                (SearchObjectLicense.SearchPattern == SearchPattern.Normal || SearchObjectLicense.SearchPattern == SearchPattern.Exact))
            {
                SearchObjectLicense.ProductMaterialNumber = SearchObjectLicense.ProductMaterialNumber.PadLeft(ComponentDefaults.MATERIALNUMBER_LENGTH, '0');
            }

            LoadingSearch = true;
            UnauthorizedCount = 0;
            SearchObjectLicense.CustomerNumber = CustomerNumber;
            SearchObjectLicense.UseLoadMore = true;
            SearchObjectLicense.RestartLoadMore = true;
            LoadMoreEnded = !SearchObjectLicense.RestartLoadMore;
            Licenses.Clear();
            await UpdateDataList(SearchObjectLicense);
            LoadingSearch = false;
            StateHasChanged();

            if (Licenses.Count > 0)
            {
                SelectedLicense = Licenses.First();
                OnSelectedLicenseChanged(SelectedLicense);
            }

            await base.OnSearchClicked();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    internal async Task InitializedAsync()
    {
        try
        {
            CurrentUser = await UserClient.Authenticate();
            IsSuperUser = CurrentUser.AccountType == AccountType.SuperUser;
            IsUserAddGranted = IsSuperUser    || CurrentUser.Roles.Any(c => c.GrantLicense >= GrantType.Add);
            IsUserDeleteGranted = IsSuperUser || CurrentUser.Roles.Any(c => c.GrantLicense >= GrantType.Delete);
            IsUserEditGranted = IsSuperUser   || CurrentUser.Roles.Any(c => c.GrantLicense >= GrantType.Edit);

            // License types
            ResourceManager resourceManager = new(typeof(ResourceLibrary.Resources.SharedResource));

            LicenseExtensions.Add("xml", resourceManager.GetString("LICENSETYPEXML")   ?? string.Empty);
            LicenseExtensions.Add("lic", resourceManager.GetString("LICENSETYPELIC")   ?? string.Empty);
            LicenseExtensions.Add("bin", resourceManager.GetString("LICENSETYPEBIN")   ?? string.Empty);
            LicenseExtensions.Add("dat", resourceManager.GetString("LICENSETYPEDAT")   ?? string.Empty);
            LicenseExtensions.Add("vis", resourceManager.GetString("LICENSETYPEVIS")   ?? string.Empty);
            LicenseExtensions.Add("zlic", resourceManager.GetString("LICENSETYPEZLIC") ?? string.Empty);
            await base.OnInitializedAsync();
            await base.GetSavedSearchMode();
            SearchObjectLicense.SearchPattern = (SearchPattern)SelectedSearchModeValue;

            if (!string.IsNullOrWhiteSpace(ProductKey))
            {
                SearchObjectLicense.ProductKey = ProductKey;
                await OnSearchClicked();
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Delete organization
    /// </summary>
    private void OnDeleteOrganisationButtonClicked()
    {
        try
        {
            CustomerText = string.Empty;
            CustomerNumber = string.Empty;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Entitlement history button clicked
    /// </summary>
    /// <param name = "activation">Selected license</param>
    private void OnHistoryButtonClicked(Activation? activation)
    {
        try
        {
            if (null != activation && SelectedLicense != activation)
            {
                OnSelectedLicenseChanged(activation);
            }

            _ = _HistoryDialog!.ShowHistory(SelectedLicense.Id, SelectedLicense.ActivationId, HistoryType.License);
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Revoke Activation
    /// </summary>
    /// <param name = "activation">Selected license</param>
    private void OnRevokeButtonClicked(Activation? activation)
    {
        try
        {
            if (null != activation)
            {
                IsRejecting = activation.State == ActivationState.REVOCATION_IN_PROGRESS;
                RevokeCaption = IsRejecting ? L["REJECT"] : L["REVOKE"];
                RevokeText = IsRejecting ? L["REJECTLICENSE"] : L["REVOKELICENSE"];
                ShowRevokeDialog = true;
            }

            StateHasChanged();
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Revoke Dialog OK
    /// </summary>
    private async Task OnRevoke(bool revoke)
    {
        try
        {
            if (revoke)
            {
                IsRevoking = true;
                RevokeText = IsRejecting ? L["REJECTING"] : L["REVOKING"];

                if (IsRejecting)
                {
                    await LicenseClient.Reject(new() { SelectedLicense });
                }
                else
                {
                    await LicenseClient.BulkMarkRevoke(new() { SelectedLicense });
                }

                var revAct = await LicenseClient.GetLicense(SelectedLicense.ActivationId);
                var idx = Licenses.IndexOf(SelectedLicense);
                Licenses.Remove(SelectedLicense);
                Licenses.Insert(idx, revAct);
                SnackbarException.ShowMessage(IsRejecting ? ResourceLibrary.Resources.LicenseResource.REJECTOK : ResourceLibrary.Resources.LicenseResource.REVOCATIONOK);
            }
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        finally
        {
            IsRevoking = false;
        }

        ShowRevokeDialog = false;
        StateHasChanged();
    }

    /// <summary>
    /// Search organization button pressed
    /// </summary>
    private void OnSearchOrganizationOKClick(object organization)
    {
        try
        {
            base.OnSelectOrganizationOKClick((Organization)organization);
            CustomerText = OrganizationHelper.GetOrganizationText((Organization)organization);
            CustomerNumber = ((Organization)organization).Number;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Search button pressed
    /// </summary>
    private void OnSearchOrganizationDiscardClick()
    {
        try
        {
            ShowSearchOrganizationDialog = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// More Button clicked
    /// </summary>
    private async Task OnMoreClicked()
    {
        try
        {
            SearchObjectLicense.UseLoadMore = true;
            SearchObjectLicense.RestartLoadMore = false;
            LoadingMore = true;
            await UpdateDataList(SearchObjectLicense);
            LoadingMore = false;
        }
        catch (Exception ex)
        {
            SnackbarException.ShowException(ex.Message);
        }
    }

    /// <summary>
    /// Updates the list by new search object
    /// </summary>
    /// <param name = "searchObjectLicense">Search object of license</param>
    private async Task UpdateDataList(SearchObjectLicense searchObjectLicense)
    {
        try
        {
            SearchObjectLicense = searchObjectLicense;
            searchObjectLicense.PageSize = Convert.ToInt32(Configuration["PageSize"]);

            // Trim Strings of SearchObject
            TrimSearchObject(searchObjectLicense);
            PartialList<Activation> partialList = await LicenseClient.GetLicenses(searchObjectLicense);
            Licenses.AddRange(partialList.List);
            InvalidCount += partialList.InvalidCount;
            SearchTotalCount = partialList.TotalCount;
            UnauthorizedCount += partialList.UnauthorizedCount;
            LoadMoreEnded = partialList.IsLastPageIndex;
            StateHasChanged();
        }
        catch (Exception ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
    }

    /// <summary>
    /// Selected license/activaton has changed
    /// </summary>
    /// <param name = "activation">Selected license</param>
    private void OnSelectedLicenseChanged(Activation activation)
    {
        SelectedLicense = activation;
    }

    /// <summary>
    /// Download button pressed
    /// </summary>
    private async Task OnDownloadButtonClicked(Activation activation)
    {
        try
        {
            if (SelectedLicense != activation)
            {
                OnSelectedLicenseChanged(activation);
            }

            SelectedLicense = await LicenseClient.GetLicense(SelectedLicense.ActivationId);
            await LicenseHelper.SaveLicenseFile(SelectedLicense, JsRuntime);
            DownloadText = ResourceLibrary.Resources.LicenseResource.DOWNLOADOK;
            SnackbarException.ShowMessage(DownloadText);
        }
        catch (ZeissLicensingExpiredTokenException ex)
        {
            await ErrorHandler!.ProcessError(ex);
        }
        catch (Exception)
        {
            DownloadText = ResourceLibrary.Resources.LicenseResource.DOWNLOADERROR;
            SnackbarException.ShowException(DownloadText);
        }
    }

    /// <summary>
    /// Filter Expiration date
    /// </summary>
    /// <param name="itemValue">Item value</param>
    /// <param name="searchValue">Search value</param>
    /// <returns></returns>
    private bool OnExpirationDateCustomFilter(object? itemValue, object searchValue)
    {
        if (searchValue is string dateFilter && !string.IsNullOrWhiteSpace(dateFilter))
        {
            string cellValue;
            var date = (DateTime?)itemValue;

            if (date.HasValue)
            {
                cellValue = date.Value.ToString("MM/dd/yyyy");
            }
            else
            {
                cellValue = E["PERMANENT"];
            }

            return cellValue.Contains(dateFilter, StringComparison.CurrentCultureIgnoreCase);
        }

        return true;
    }

    /// <summary>
    /// Filter File extension
    /// </summary>
    /// <param name="itemValue">Item value</param>
    /// <param name="searchValue">Search value</param>
    /// <returns></returns>
    private bool OnFileExtensionCustomFilter(object? itemValue, object searchValue)
    {
        if (searchValue is string extFilter && !string.IsNullOrWhiteSpace(extFilter))
        {
            var cellValue = itemValue?.ToString() ?? string.Empty;

            if (LicenseExtensions.TryGetValue(cellValue, out var licTypeFound))
            {
                cellValue = licTypeFound;
            }

            return cellValue.Contains(extFilter, StringComparison.CurrentCultureIgnoreCase);
        }

        return true;
    }

    #endregion
}
