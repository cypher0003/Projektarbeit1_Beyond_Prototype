﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using OrganizationsModule.ViewModels;
using Zeiss.Licensing.Data.Models;

namespace UI.UnitTests.Organizations;

[TestClass]
public class OrganizationTests
{
    #region Properties

    private Organization Organization { get; set; } = null!;

    private OrganizationViewModel OrganizationViewModel { get; set; } = null!;

    #endregion

    #region Methods

    [TestInitialize]
    public void SetUp()
    {
        Organization = new Organization { Name = "Org1", SalesOrganizations = new List<string> { "SalesOrg1", "SalesOrg2" } };
        OrganizationViewModel = new OrganizationViewModel(Organization);
    }


    [TestMethod]
    public void Test_CreateOrganizationViewModel_OK()
    {
        Assert.IsTrue(OrganizationViewModel.SalesOrganizations.Count == 2);
        Assert.AreEqual("SalesOrg1", OrganizationViewModel.SalesOrganizations[0].SalesOrganization);
        Assert.AreEqual("SalesOrg2", OrganizationViewModel.SalesOrganizations[1].SalesOrganization);
    }

    [TestMethod]
    public void Test_GetSalesOrganizations_OK()
    {
        var list = OrganizationViewModel.GetSalesOrganizations();
        Assert.IsNotNull(list);
        Assert.AreEqual(2, list.Count);
    }

    #endregion
}
