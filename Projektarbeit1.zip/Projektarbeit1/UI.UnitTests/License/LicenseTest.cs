﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Moq;
using LicenseModule.Pages;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace UI.UnitTests.License;

[TestClass]
public class LicenseTest
{
    #region Fields

    private Mock<IUserClient>? _UserClientMock;
    private ViewLicense _ViewLicense = null!;

    #endregion

    #region Methods

    [TestInitialize]
    public void SetUp()
    {
        _UserClientMock = new Mock<IUserClient>();
        _ViewLicense = new ViewLicense();
    }

    [TestMethod]
    public async Task Test_Initialize_License_OK()
    {
        _ViewLicense.UserClient = _UserClientMock!.Object;

        User user = new() { LastName = "Last", FirstName = "First", AccountType = AccountType.SuperUser };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        await _ViewLicense.InitializedAsync();

        Assert.AreEqual(_ViewLicense.CurrentUser?.AccountType, user.AccountType);
    }

    [TestMethod]
    public void Test_IsLoadMoreDisable()
    {
        Assert.IsTrue(_ViewLicense.IsLoadMoreDisable);
        _ViewLicense.Licenses.Add(new Activation());
        _ViewLicense.LoadMoreEnded = false;
        Assert.IsFalse(_ViewLicense.IsLoadMoreDisable);
    }

    #endregion
}
