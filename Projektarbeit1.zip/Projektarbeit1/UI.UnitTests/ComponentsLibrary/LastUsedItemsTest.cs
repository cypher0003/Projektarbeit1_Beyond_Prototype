#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright � 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using ComponentsLibrary.Interfaces;
using ComponentsLibrary.Provider;
using ComponentsLibrary.ViewModels;
using Moq;
using System.Runtime;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.Models;
using Zeiss.Licensing.Data.TransferObjects;

namespace UI.UnitTests.ComponentsLibrary;

[TestClass]
public class LastUsedItemsTest
{
    #region Fields

    private Mock<IUserClient>? _UserClientMock;
    private LastUsedItemsViewModel? _LastUsedItemsViewModel;

    #endregion

    #region Properties

    private LastUsedItemsViewModel LastUsedItemsViewModel => _LastUsedItemsViewModel ?? throw new NullReferenceException();

    #endregion

    #region Methods

    [TestInitialize]
    public void SetUp()
    {
        _UserClientMock = new Mock<IUserClient>();

        _LastUsedItemsViewModel = new LastUsedItemsViewModel();
    }

    [TestMethod]
    public void AddLastUsedItem_OneItem_ListIncrease()
    {
        LastUsedItem lastUsedItem = new()
        {
            ObjectId = "SelectedEntitlement.EntitlementId",
            ObjectName = "SelectedEntitlement.EntitlementId",
            ObjectType = "SharedResource.ROUTEENTITLEMENTS",
            ObjectTypeName = "SharedResource.ENTITLEMENT"
        };

        User user = new() { LastName = "Last", FirstName = "First" };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        var retLastUsedItems = new List<LastUsedItem> { lastUsedItem };

        _UserClientMock!
            .Setup(provider => provider.AddLastUsedItem(It.IsAny<string>(), lastUsedItem))
            .ReturnsAsync(retLastUsedItems);

        var lastUsedItemsProvider = new LastUsedItemsProvider(_UserClientMock.Object);
        lastUsedItemsProvider.AddItem(lastUsedItem);
        Assert.IsTrue(lastUsedItemsProvider.LastUsedItemsViewModel.LastUsedItemViewModels.Count > 0);
    }

    [TestMethod]
    public void FillLastUsedItem_TwoItems_ListIncrease()
    {
        LastUsedItem lastUsedItem = new()
        {
            ObjectId = "SelectedEntitlement.EntitlementId",
            ObjectName = "SelectedEntitlement.EntitlementId",
            ObjectType = "SharedResource.ROUTEENTITLEMENTS",
            ObjectTypeName = "SharedResource.ENTITLEMENT"
        };

        User user = new() { LastName = "Last", FirstName = "First" };
        user.LastUsedItems.Add(lastUsedItem);
        user.LastUsedItems.Add(lastUsedItem);

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        var lastUsedItemsProvider = new LastUsedItemsProvider(_UserClientMock.Object);
        lastUsedItemsProvider.SetUser(user);
        Assert.IsTrue(lastUsedItemsProvider.LastUsedItemsViewModel.LastUsedItemViewModels.Count == 2);
    }

    [TestMethod]
    public void GetIcon_Entitlement_Icon()
    {
        LastUsedItem lastUsedItem = new()
        {
            ObjectId = "SelectedEntitlement.EntitlementId",
            ObjectName = "SelectedEntitlement.EntitlementId",
            ObjectType = "entitlements",
            ObjectTypeName = "SharedResource.ENTITLEMENT"
        };

        User user = new() { LastName = "Last", FirstName = "First" };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        var lastUsedItemsProvider = new LastUsedItemsProvider(_UserClientMock.Object);
        var icon = lastUsedItemsProvider.GetIcon(new LastUsedItemViewModel(lastUsedItem));
        Assert.IsTrue(icon == "zi-tutorial");
    }

    [TestMethod]
    public void GetIcon_User_StringEmpty()
    {
        LastUsedItem lastUsedItem = new()
        {
            ObjectId = "SelectedEntitlement.EntitlementId",
            ObjectName = "SelectedEntitlement.EntitlementId",
            ObjectType = "user",
            ObjectTypeName = "SharedResource.ENTITLEMENT"
        };

        User user = new() { LastName = "Last", FirstName = "First" };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        var lastUsedItemsProvider = new LastUsedItemsProvider(_UserClientMock.Object);
        var icon = lastUsedItemsProvider.GetIcon(new LastUsedItemViewModel(lastUsedItem));
        Assert.IsTrue(icon == "");
    }

    [TestMethod]
    public void AddLastUsedItemToViewModel_OneItem_ListIncrease()
    {
        LastUsedItem lastUsedItem = new()
        {
            ObjectId = "SelectedEntitlement.EntitlementId",
            ObjectName = "SelectedEntitlement.EntitlementId",
            ObjectType = "SharedResource.ROUTEENTITLEMENTS",
            ObjectTypeName = "SharedResource.ENTITLEMENT"
        };

        LastUsedItemsViewModel.Add(lastUsedItem);

        Assert.IsTrue(LastUsedItemsViewModel.LastUsedItemViewModels.Count == 1);
    }

    [TestMethod]
    public void FillLastUsedItemToViewModel_TwoItems_ListIncrease()
    {
        LastUsedItem lastUsedItem = new()
        {
            ObjectId = "SelectedEntitlement.EntitlementId",
            ObjectName = "SelectedEntitlement.EntitlementId",
            ObjectType = "SharedResource.ROUTEENTITLEMENTS",
            ObjectTypeName = "SharedResource.ENTITLEMENT"
        };

        LastUsedItemsViewModel.FillList(new List<LastUsedItem> { lastUsedItem, lastUsedItem });

        Assert.IsTrue(LastUsedItemsViewModel.LastUsedItemViewModels.Count == 2);
    }

    #endregion
}
