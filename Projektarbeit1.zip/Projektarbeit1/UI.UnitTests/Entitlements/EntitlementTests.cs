﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using EntitlementsModule.Pages;
using Moq;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace UI.UnitTests.Entitlements;

[TestClass]
public class EntitlementTests
{
    #region Fields

    private Mock<IUserClient>? _UserClientMock;
    private Mock<IAppSettingClient>? _AppSettingClientMock;
    private SearchEntitlementMask _SearchEntitlementMask = null!;

    #endregion

    #region Methods

    [TestInitialize]
    public void SetUp()
    {
        _UserClientMock = new Mock<IUserClient>();
        _AppSettingClientMock = new Mock<IAppSettingClient>();
        _SearchEntitlementMask = new SearchEntitlementMask();
    }

    [TestMethod]
    public async Task Test_Initialize_SearchEntitlementMask_OK()
    {
        _SearchEntitlementMask.UserClient = _UserClientMock!.Object;
        _SearchEntitlementMask.AppSettingClient = _AppSettingClientMock!.Object;

        User user = new() { LastName = "Last", FirstName = "First", AccountType = AccountType.SuperUser };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        _AppSettingClientMock!
            .Setup(provider => provider.GetProductFamilies(false))
            .ReturnsAsync(new List<ProductFamily> { new() { Businessgroup = "CIT", Name = "Prodfam1" }, new() { Businessgroup = "CIT", Name = "Prodfam2" } });

        await _SearchEntitlementMask.InitializedAsync();

        // there is a default entry added at initialization, that is why the count is checked to 3
        Assert.IsTrue(_SearchEntitlementMask.EntitlementSearchMaskViewModel.ProductFamilies.Count == 3);
        Assert.AreEqual(_SearchEntitlementMask.EntitlementSearchMaskViewModel.ProductFamilies[1].Name, "Prodfam1");
        Assert.AreEqual(_SearchEntitlementMask.EntitlementSearchMaskViewModel.ProductFamilies[2].Name, "Prodfam2");
    }

    [TestMethod]
    public async Task Test_LoadProductFamilies_OK()
    {
        _AppSettingClientMock!
            .Setup(provider => provider.GetProductFamilies(false))
            .ReturnsAsync(new List<ProductFamily>
            {
                new() { Businessgroup = "CIT", Name = "Prodfam3" },
                new() { Businessgroup = "CIT", Name = "Prodfam4" },
                new() { Businessgroup = "CIT", Name = "Prodfam5" }
            });

        await _SearchEntitlementMask.EntitlementSearchMaskViewModel.LoadProductFamilies(_AppSettingClientMock!.Object);

        Assert.IsTrue(_SearchEntitlementMask.EntitlementSearchMaskViewModel.ProductFamilies.Count == 4);
    }

    #endregion
}
