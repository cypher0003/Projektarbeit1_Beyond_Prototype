﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Castle.Components.DictionaryAdapter;
using ComponentsLibrary.Enums;
using Moq;
using ProductsModule.Pages;
using ProductsModule.ViewModels;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.Collections;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace UI.UnitTests.Products;

[TestClass]
public class ProductVariantTests
{
    #region Fields

    private Mock<IUserClient>? _UserClientMock;
    private Mock<IProductVariantClient>? _ProductVariantClientMock;
    private Mock<IProductClient>? _ProductClientMock;
    private Mock<IDeviceTypeClient>? _DeviceTypeClientMock;
    private ViewProductVariants _ViewProductVariants = null!;

    #endregion

    #region Methods

    [TestInitialize]
    public void SetUp()
    {
        _UserClientMock = new Mock<IUserClient>();
        _ProductClientMock = new Mock<IProductClient>();
        _ProductVariantClientMock = new Mock<IProductVariantClient>();
        _DeviceTypeClientMock = new Mock<IDeviceTypeClient>();
        _ViewProductVariants = new ViewProductVariants();
        _ViewProductVariants.ProductVariantViewModel = new ProductVariantViewModel(_ProductVariantClientMock.Object);

        _ViewProductVariants.ProductVariantViewModel.LicenseModels = new()
        {
            new LicenseModel { Name = "Thales_Connected", LicenseMode = LicenseMode.Thales_Connected },
            new LicenseModel { Name = "BG_LicenseModel", LicenseMode = LicenseMode.Thales_Connected },
            new LicenseModel { Name = "BG_LicenseModelAdditional", LicenseMode = LicenseMode.Thales_Connected }
        };

        _ViewProductVariants.ProductVariantViewModel.FilteredLicenseModelsAdditional.Add(
            new LicenseModel { Name = "BG_LicenseModelAdditional", LicenseMode = LicenseMode.Thales_Connected });
    }

    [TestMethod]
    public async Task Test_Initialize_ProductVariants_OK()
    {
        _ViewProductVariants.UserClient = _UserClientMock!.Object;
        _ViewProductVariants.ProductClient = _ProductClientMock!.Object;

        User user = new() { LastName = "Last", FirstName = "First", AccountType = AccountType.SuperUser };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        _ProductClientMock!
            .Setup(provider => provider.GetLicenseModels())
            .ReturnsAsync(new EditableList<LicenseModel>());

        _ProductClientMock!
            .Setup(provider => provider.GetBusinessgroups())
            .ReturnsAsync(new List<string>());

        var partialList = new PartialList<DeviceType>();

        _DeviceTypeClientMock!
            .Setup(provider => provider.GetDeviceTypes(null))
            .ReturnsAsync(partialList);

        _ViewProductVariants.DeviceTypeClient = _DeviceTypeClientMock.Object;
        _ViewProductVariants.ProductClient = _ProductClientMock.Object;

        await _ViewProductVariants.InitializedAsync();

        Assert.AreEqual(_ViewProductVariants.CurrentUser?.AccountType, user.AccountType);
    }

    [TestMethod]
    public void Test_UseEmailInOrder_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariantUseEmailInSalesOrder = true;
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.EmailBehaviour == EmailBehaviour.EmailBySalesorder);

        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariantUseEmailInSalesOrder = false;
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant);
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.EmailBehaviour == EmailBehaviour.None);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.ProductVariantStateList);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.ConcurrencyStateList);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.EditOriginalProductVariant);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.LicenseModels);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.FilteredLicenseModels);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.FilteredLicenseModelsAdditional);
        Assert.IsNotNull(_ViewProductVariants.ProductVariantViewModel.Hasp);
    }

    [TestMethod]
    public void Test_OnSelectedProductVariantChanged_Existing()
    {
        var productVariant = new ProductVariant { Id = "12345", Name = "NamePV" };

        _ViewProductVariants.OnSelectedProductVariantChanged(productVariant);
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Id   == productVariant.Id);
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Name == productVariant.Name);
    }

    [TestMethod]
    public void Test_IsProductVariantOfTypeUprade_OK()
    {
        var productVariant = new ProductVariant { Id = "12345", Name = "NamePV", Type = ProductVariantType.Upgrade };

        _ViewProductVariants.OnSelectedProductVariantChanged(productVariant);
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Type == ProductVariantType.Upgrade);
    }

    [TestMethod]
    public void Test_ViewModel_SelectedProductVariantChanged_Existing()
    {
        var productVariant = CreateProductVariant("12345", "NamePV");

        _ViewProductVariants.ProductVariantViewModel.SelectProductVariantChanged(productVariant);
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Id   == productVariant.Id);
        Assert.IsTrue(_ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Name == productVariant.Name);
    }

    [TestMethod]
    public void Test_ViewModel_SelectedProductVariantStateChanged_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV");

        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariantStateChanged((int)ProductVariantState.DRAFT);
        Assert.AreEqual((int)ProductVariantState.DRAFT, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariantStateValue);
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariantStateChanged((int)ProductVariantState.ENABLED);
        Assert.AreEqual((int)ProductVariantState.ENABLED, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariantStateValue);
    }

    [TestMethod]
    public void Test_ViewModel_SelectedConcurrencyStateChanged_PerUser_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV");

        _ViewProductVariants.ProductVariantViewModel.SelectedConcurrencyStateChanged((int)NamedUsersConcurrencyCriteria.PerUser);
        Assert.AreEqual((int)NamedUsersConcurrencyCriteria.PerUser, _ViewProductVariants.ProductVariantViewModel.SelectedConcurrencyStateValue);
    }

    [TestMethod]
    public void Test_ViewModel_BusinessGroupValueChanged_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");

        const string newBusinessGroup = "BusinessgroupTestNew";
        _ViewProductVariants.ProductVariantViewModel.BusinessGroupValueChanged(newBusinessGroup);
        Assert.AreEqual(newBusinessGroup, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Businessgroup);
    }

    [TestMethod]
    public void Test_ViewModel_VariantLicenseModelValueChanged_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");

        const string newLicenseModel = "LicenseModelTestNew";
        _ViewProductVariants.ProductVariantViewModel.VariantLicenseModelValueChanged(newLicenseModel);
        Assert.AreEqual(newLicenseModel, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel);
    }

    [TestMethod]
    public void Test_ViewModel_VariantLicenseModelValueChanged_NoThalesLicenseModel_Changed()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel = "Thales";
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.NamedUsersConcurrencyCriteria = NamedUsersConcurrencyCriteria.PerUser;

        const string newLicenseModel = "LicenseModelTestNew";
        _ViewProductVariants.ProductVariantViewModel.VariantLicenseModelValueChanged(newLicenseModel);
        Assert.AreEqual(newLicenseModel, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel);
        Assert.AreEqual(NamedUsersConcurrencyCriteria.PerUser, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.NamedUsersConcurrencyCriteria);
    }

    [TestMethod]
    public void Test_ViewModel_VariantLicenseModelValueChanged_ThalesLicenseModel_Changed()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel = "Thales";
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.NamedUsersConcurrencyCriteria = 0;

        const string newLicenseModel = "Thales_Connected";
        _ViewProductVariants.ProductVariantViewModel.VariantLicenseModelValueChanged(newLicenseModel);
        Assert.AreEqual(newLicenseModel, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel);
        Assert.AreEqual(NamedUsersConcurrencyCriteria.PerLogin, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.NamedUsersConcurrencyCriteria);
    }

    [TestMethod]
    public void Test_ViewModel_LicenseModelAdditionalChanged_Existing()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");

        const string newLicenseModel = "AditionalLicenseModelTestNew";
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional = newLicenseModel;
        Assert.AreEqual(newLicenseModel, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional);
    }

    [TestMethod]
    public void Test_VadfadfasdfafaiewModel_LicenseModelAdditionalChanged_Existing()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");

        const string newLicenseModel = "AditionalLicenseModelTestNew";
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional = newLicenseModel;
        Assert.AreEqual(newLicenseModel, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional);
    }

    [TestMethod]
    public void ActionAdd_ProductVariant_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");
        const string newLicenseModel = "BG_LicenseModel";
        const string newLicenseModelAdditional = "BG_LicenseModelAdditional";
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel = newLicenseModel;
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional = newLicenseModelAdditional;

        const string newBusinessGroup = "BG";
        _ViewProductVariants.ProductVariantViewModel.ActionAdd(newBusinessGroup);

        Assert.AreEqual(string.Empty, _ViewProductVariants.ProductVariantViewModel.ProductText);
        Assert.AreEqual(newLicenseModel, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModel);
        Assert.AreEqual(newLicenseModelAdditional, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.LicenseModelAdditional);
    }

    [TestMethod]
    public void ActionEdit_Productvariant_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest");

        _ViewProductVariants.ProductVariantViewModel.ActionEdit();

        Assert.AreEqual(_ViewProductVariants.ProductVariantViewModel.EditOriginalProductVariant.Id, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.Id);
    }

    [TestMethod]
    public void AssignSearchedProduct_Productvariant_OK()
    {
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = CreateProductVariant("12345", "NamePV", "BGTest", "1.1");

        const string idProduct = "333";
        const string nameProduct = "NameSearched";
        const string versionProduct = "2.2";

        _ViewProductVariants.ProductVariantViewModel.AssignSearchedProduct(CreateProduct(idProduct, nameProduct, versionProduct));
        Assert.AreEqual($"{nameProduct}, {versionProduct}", _ViewProductVariants.ProductVariantViewModel.ProductText);
        Assert.AreEqual(idProduct, _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant.ProductId);
    }

    [TestMethod]
    public async Task SetToUpgradeVariant_AllValuesClear_OK()
    {
        var productVariant = CreateProductVariant("12345", "NamePV", "BGTest", "1.1");
        productVariant.DefaultDuration = 10;
        productVariant.DemoDuration = 10;
        productVariant.Description = "string.Empty";
        productVariant.DeployOnDelivery = true;
        productVariant.DeviceTypeId = "string.Empty";
        productVariant.DeviceTypeIdAdditional = "string.Empty";
        productVariant.DeviceTypeName = "string.Empty";
        productVariant.DeviceTypeNameAdditional = "string.Empty";
        productVariant.AllowMultipleGenerationPerUser = true;
        productVariant.IsDemoProduct = true;
        productVariant.IsPackage = true;
        productVariant.LicenseModel = "string.Empty";
        productVariant.LicenseModelAdditional = "string.Empty";
        productVariant.LimitNamedUserAssignment = true;
        productVariant.NamedUsersConcurrencyCriteria = NamedUsersConcurrencyCriteria.PerUser;
        productVariant.Notes = "string.Empty";
        productVariant.ProductId = "string.Empty";
        productVariant.ProductRatePlanChargeDescription = "string.Empty";
        productVariant.ProductRatePlanChargeId = "string.Empty";
        productVariant.ProductRatePlanChargeName = "string.Empty";
        productVariant.ProductRatePlanDescription = "string.Empty";
        productVariant.ProductRatePlanId = "string.Empty";
        productVariant.ProductRatePlanName = "string.Empty";
        productVariant.SubscriptionTerm = SubscriptionTerm.MONTHLY;
        productVariant.SerialNumberRequired = true;
        productVariant.UpgradeFrom = new List<ProductVariant>();
        productVariant.UseNamedUsers = true;
        productVariant.Type = ProductVariantType.Perpetual;
        _ViewProductVariants.ProductVariantViewModel.SelectedProductVariant = productVariant;

        await _ViewProductVariants.ProductVariantViewModel.SetToUpgradeVariant();
        Assert.AreEqual(0, productVariant.DefaultDuration);
        Assert.AreEqual(0, productVariant.DemoDuration);
        Assert.AreEqual(string.Empty, productVariant.Description);
        Assert.AreEqual(false, productVariant.DeployOnDelivery);
        Assert.AreEqual(string.Empty, productVariant.DeviceTypeId);
        Assert.AreEqual(string.Empty, productVariant.DeviceTypeIdAdditional);
        Assert.AreEqual(string.Empty, productVariant.DeviceTypeName);
        Assert.AreEqual(string.Empty, productVariant.DeviceTypeNameAdditional);
        Assert.AreEqual(false, productVariant.AllowMultipleGenerationPerUser);
        Assert.AreEqual(false, productVariant.IsDemoProduct);
        Assert.AreEqual(false, productVariant.IsPackage);
        Assert.AreEqual(string.Empty, productVariant.LicenseModel);
        Assert.AreEqual(string.Empty, productVariant.LicenseModelAdditional);
        Assert.AreEqual(false, productVariant.LimitNamedUserAssignment);
        Assert.AreEqual(NamedUsersConcurrencyCriteria.PerLogin, productVariant.NamedUsersConcurrencyCriteria);
        Assert.AreEqual(string.Empty, productVariant.Notes);
        Assert.AreEqual(string.Empty, productVariant.ProductId);
        Assert.AreEqual(string.Empty, productVariant.ProductRatePlanChargeDescription);
        Assert.AreEqual(string.Empty, productVariant.ProductRatePlanChargeId);
        Assert.AreEqual(string.Empty, productVariant.ProductRatePlanChargeName);
        Assert.AreEqual(string.Empty, productVariant.ProductRatePlanDescription);
        Assert.AreEqual(string.Empty, productVariant.ProductRatePlanId);
        Assert.AreEqual(string.Empty, productVariant.ProductRatePlanName);
        Assert.AreEqual(SubscriptionTerm.UNDEFINED, productVariant.SubscriptionTerm);
        Assert.AreEqual(false, productVariant.SerialNumberRequired);
        Assert.IsTrue(productVariant.UpgradeFrom.Count == 0);
        Assert.AreEqual(false, productVariant.UseNamedUsers);
        Assert.AreEqual(ProductVariantType.Upgrade, productVariant.Type);
    }

    [TestMethod]
    public async Task UpgradeRuleList_AddUpgradeRule_OK()
    {
        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById(It.IsAny<string>()))
            .ReturnsAsync(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));

        var upgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(_ProductVariantClientMock.Object);
        var productVariantName = "NamePV";
        await upgradeRuleGridComponentViewModel.AddUpgradeRule(CreateProductVariant("12345", productVariantName, "BGTest", "1.1"));

        Assert.IsTrue(upgradeRuleGridComponentViewModel.UpgradeRuleViewModels.Count == 1);
        Assert.AreEqual(productVariantName, upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0].OutputProductVariant.Name);
    }

    [TestMethod]
    public async Task UpgradeRuleList_EditUpgradeRule_OK()
    {
        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById(It.IsAny<string>()))
            .ReturnsAsync(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));

        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById("22345"))
            .ReturnsAsync(CreateProductVariant("22345", "NamePV22345", "BGTest", "1.1"));

        var upgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(_ProductVariantClientMock.Object);
        await upgradeRuleGridComponentViewModel.AddUpgradeRule(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));
        Assert.AreEqual("NamePV", upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0].OutputProductVariant.Name);

        await upgradeRuleGridComponentViewModel.ChangeUpgradeRuleOutputProductVariant(CreateProductVariant("22345", "NamePV22345", "BGTest", "1.1"));

        Assert.IsTrue(upgradeRuleGridComponentViewModel.UpgradeRuleViewModels.Count == 1);
        Assert.AreEqual("NamePV22345", upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0].OutputProductVariant.Name);
    }

    [TestMethod]
    public async Task UpgradeRuleList_DeleteUpgradeRule_OK()
    {
        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById(It.IsAny<string>()))
            .ReturnsAsync(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));

        var upgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(_ProductVariantClientMock.Object);
        await upgradeRuleGridComponentViewModel.AddUpgradeRule(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));
        Assert.AreEqual("NamePV", upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0].OutputProductVariant.Name);

        upgradeRuleGridComponentViewModel.ActionDelete();

        Assert.IsTrue(upgradeRuleGridComponentViewModel.UpgradeRuleViewModels.Count == 0);
    }

    [TestMethod]
    public async Task UpgradeRuleValidationList_AddValidation_OK()
    {
        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById(It.IsAny<string>()))
            .ReturnsAsync(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));

        var upgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(_ProductVariantClientMock.Object);
        var productVariantName = "NamePV";
        await upgradeRuleGridComponentViewModel.AddUpgradeRule(CreateProductVariant("12345", productVariantName, "BGTest", "1.1"));
        var upgradeRuleViewModel = upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0];
        Assert.IsTrue(upgradeRuleViewModel.Validations.Count == 0);

        productVariantName = "NamePV22345";
        var productVariantVersion = "1.1";
        upgradeRuleViewModel.IsAddCondition = true;
        upgradeRuleViewModel.OnSearchOkClick(CreateProductVariant("22345", productVariantName, "BGTest", productVariantVersion));

        Assert.AreEqual($"{productVariantName}  {productVariantVersion}", upgradeRuleViewModel.Validations[0].ProductVariantNameVersion);
    }

    [TestMethod]
    public async Task UpgradeRuleValidationList_EditValidation_OK()
    {
        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById(It.IsAny<string>()))
            .ReturnsAsync(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));

        var upgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(_ProductVariantClientMock.Object);
        var productVariantName = "NamePV";
        await upgradeRuleGridComponentViewModel.AddUpgradeRule(CreateProductVariant("12345", productVariantName, "BGTest", "1.1"));
        var upgradeRuleViewModel = upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0];
        Assert.IsTrue(upgradeRuleViewModel.Validations.Count == 0);

        productVariantName = "NamePV22345";
        var productVariantVersion = "1.1";
        upgradeRuleViewModel.IsAddCondition = true;
        upgradeRuleViewModel.OnSearchOkClick(CreateProductVariant("22345", productVariantName, "BGTest", productVariantVersion));

        Assert.AreEqual($"{productVariantName}  {productVariantVersion}", upgradeRuleViewModel.Validations[0].ProductVariantNameVersion);

        productVariantName = "NamePV22345222";
        productVariantVersion = "2.2";
        upgradeRuleViewModel.IsAddCondition = false;
        upgradeRuleViewModel.OnSearchOkClick(CreateProductVariant("223456", productVariantName, "BGTest", productVariantVersion));

        Assert.AreEqual($"{productVariantName}  {productVariantVersion}", upgradeRuleViewModel.Validations[0].ProductVariantNameVersion);
    }

    [TestMethod]
    public async Task UpgradeRuleValidationList_DeleteValidation_OK()
    {
        _ProductVariantClientMock!
            .Setup(provider => provider.GetProductVariantById(It.IsAny<string>()))
            .ReturnsAsync(CreateProductVariant("12345", "NamePV", "BGTest", "1.1"));

        var upgradeRuleGridComponentViewModel = new UpgradeRuleGridComponentViewModel(_ProductVariantClientMock.Object);
        var productVariantName = "NamePV";
        await upgradeRuleGridComponentViewModel.AddUpgradeRule(CreateProductVariant("12345", productVariantName, "BGTest", "1.1"));
        var upgradeRuleViewModel = upgradeRuleGridComponentViewModel.UpgradeRuleViewModels[0];
        Assert.IsTrue(upgradeRuleViewModel.Validations.Count == 0);

        productVariantName = "NamePV22345";
        var productVariantVersion = "1.1";
        upgradeRuleViewModel.IsAddCondition = true;
        upgradeRuleViewModel.OnSearchOkClick(CreateProductVariant("22345", productVariantName, "BGTest", productVariantVersion));

        Assert.AreEqual($"{productVariantName}  {productVariantVersion}", upgradeRuleViewModel.Validations[0].ProductVariantNameVersion);

        upgradeRuleViewModel.DeleteValidation();

        Assert.IsTrue(upgradeRuleViewModel.Validations.Count == 0);
    }

    private static ProductVariant CreateProductVariant(string id, string name, string businessgroup = "", string version = "")
    {
        return new ProductVariant { Id = id, Name = name, Businessgroup = businessgroup, Version = version };
    }

    private static Product CreateProduct(string id, string name, string version = "")
    {
        return new Product { Id = id, Name = name, Version = version };
    }

    #endregion
}
