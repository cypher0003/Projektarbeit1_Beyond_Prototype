﻿#region Copyright

// Carl Zeiss AG
// http://www.zeiss.com
// 
// Copyright © 2020 - 2024 Carl Zeiss AG - All Rights Reserved.
// ZEISS, ZEISS.com are registered trademarks of Carl Zeiss AG

#endregion

using Blazorise.DataGrid;
using Moq;
using ProductsModule.Pages;
using Zeiss.Licensing.Backend.WebServiceClient.Interfaces;
using Zeiss.Licensing.Data.Enums;
using Zeiss.Licensing.Data.Models;

namespace UI.UnitTests.Products;

[TestClass]
public class ProductFamilyTests
{
    #region Fields

    private Mock<IUserClient>? _UserClientMock;
    private Mock<IProductClient>? _ProductClientMock;
    private Mock<IAppSettingClient>? _AppSettingClientMock;
    private ViewProductfamilies _ViewProductFamilies = null!;

    #endregion

    #region Methods

    [TestInitialize]
    public void SetUp()
    {
        _UserClientMock = new Mock<IUserClient>();
        _ProductClientMock = new Mock<IProductClient>();
        _AppSettingClientMock = new Mock<IAppSettingClient>();
        _ViewProductFamilies = new ViewProductfamilies();
    }

    [TestMethod]
    public async Task Test_Initialize_ProductFamilies_OK()
    {
        _ViewProductFamilies.UserClient = _UserClientMock!.Object;
        _ViewProductFamilies.ProductClient = _ProductClientMock!.Object;
        _ViewProductFamilies.AppSettingClient = _AppSettingClientMock!.Object;

        User user = new() { LastName = "Last", FirstName = "First", AccountType = AccountType.SuperUser };

        _UserClientMock!
            .Setup(provider => provider.Authenticate())
            .ReturnsAsync(user);

        _AppSettingClientMock!
            .Setup(provider => provider.GetProductFamilies(true))
            .ReturnsAsync(new List<ProductFamily> { new ProductFamily { Businessgroup = "BG", Name = "PF" } });

        await _ViewProductFamilies.InitializedAsync();

        Assert.AreEqual(_ViewProductFamilies.CurrentUser?.AccountType, user.AccountType);
        Assert.IsTrue(_ViewProductFamilies.CanDeleteProductFamily);
        Assert.IsTrue(_ViewProductFamilies.CanAddProductFamily);
    }


    [TestMethod]
    public void Test_Initialize_ProductFamiliesProperties_OK()
    {
        _ViewProductFamilies.SelectedProductFamily = new ProductFamily { Name = "bbb", Businessgroup = "BG" };
        Assert.IsTrue(_ViewProductFamilies.CanSaveProductFamily);
    }

    [TestMethod]
    public void Test_OnSelectedProductFamilyChanged()
    {
        var productFamily = new ProductFamily { Businessgroup = "BG", Name = "PF_1" };
        _ViewProductFamilies.IsReadOnly = false;
        _ViewProductFamilies.OnSelectedProductFamilyChanged(productFamily);

        Assert.IsTrue(_ViewProductFamilies.IsReadOnly);
        Assert.AreEqual(productFamily, _ViewProductFamilies.SelectedProductFamily);
    }

    [TestMethod]
    public void Test_BusinessGroupValueChangedHandler()
    {
        _ViewProductFamilies.BusinessGroupValueChangedHandler("BG2");

        Assert.AreEqual("BG2", _ViewProductFamilies.SelectedProductFamily.Businessgroup);
    }

    [TestMethod]
    public void Test_OnAddButtonClicked()
    {
        var productFamily = new ProductFamily { Businessgroup = "BG", Name = "PF_1" };
        _ViewProductFamilies.SelectedProductFamily = productFamily;

        _ViewProductFamilies.IsReadOnly = true;
        _ViewProductFamilies.OnAddButtonClicked();

        Assert.IsFalse(_ViewProductFamilies.IsReadOnly);
        Assert.IsTrue(string.IsNullOrWhiteSpace(_ViewProductFamilies.SelectedProductFamily.Businessgroup));
    }

    [TestMethod]
    public async Task Test_OnDeleteButtonClicked()
    {
        _ViewProductFamilies.AppSettingClient = _AppSettingClientMock!.Object;

        var productFamily = new ProductFamily { Businessgroup = "BG", Name = "PF_1" };
        _ViewProductFamilies.ProductFamilies.Add(productFamily);
        _ViewProductFamilies.SelectedProductFamily = productFamily;

        _AppSettingClientMock!
            .Setup(provider => provider.DeleteProductFamily(_ViewProductFamilies.SelectedProductFamily))
            .Returns(Task.CompletedTask);

        await _ViewProductFamilies.OnDeleteOK();

        Assert.IsFalse(_ViewProductFamilies.ProductFamilies.Any());
    }

    [TestMethod]
    public void Test_OnDiscardButtonClicked()
    {
        _ViewProductFamilies.IsReadOnly = false;
        _ViewProductFamilies.OnDiscardButtonClicked();

        Assert.IsTrue(_ViewProductFamilies.IsReadOnly);
    }

    [TestMethod]
    public void Test_OnPageChanged()
    {
        var args = new DataGridPageChangedEventArgs(3, 20);
        _ViewProductFamilies.OnPageChanged(args);

        Assert.IsTrue(_ViewProductFamilies.CurrentPage == 3);
    }

    #endregion
}
